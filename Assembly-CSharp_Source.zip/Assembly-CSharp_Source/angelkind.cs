using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct angelkind
{
    public short _name;
    public short _info;
    public float _firerate;
    public float _speed;
    public short _arrowkind;
    public short _splashEF;
}


using System;
using UnityEngine;

public class AI_Ride_Enemy : MonoBehaviour
{
    private float attackdelay;
    private float attackrangeX;
    private float attackrangeZ;
    private Transform cha1;
    private Transform ef_hit;
    private bool life = true;
    public Transform mon;
    private Transform mytransform;
    private Vector3 rndposition = Vector3.zero;
    private Cam_Move_ride script_cam;
    private Cha_Control_ride_cha script_cha1;
    private AI_Ride_Enemy2 script_mon;
    private SoundEf_slash script_sound;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.script_mon = this.mon.GetComponent<AI_Ride_Enemy2>();
    }

    private void OnEnable()
    {
        base.animation.Play("move");
        this.life = true;
        this.script_mon.Wake();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.transform.IsChildOf(this.cha1))
        {
            this.life = false;
            base.animation.Play("down");
            this.script_sound.SoundOn(3);
            this.script_cam.Hitcam();
            this.ef_hit.gameObject.active = true;
            this.ef_hit.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.05f));
            this.script_cha1.GetSoulStone(3);
            this.script_mon.Defeat();
        }
    }

    public void SetRndPosition()
    {
        this.rndposition = (Vector3) ((Vector3.right * UnityEngine.Random.Range((float) -1f, (float) 1f)) + (Vector3.forward * UnityEngine.Random.Range((float) -0.4f, (float) 0.6f)));
    }

    private void Start()
    {
        this.cha1 = GameObject.FindWithTag("Player").transform;
        this.script_cha1 = this.cha1.GetComponent<Cha_Control_ride_cha>();
        base.animation["down"].speed = 0.3f;
        base.animation.Play("move");
        base.InvokeRepeating("SetRndPosition", UnityEngine.Random.Range((float) 0.1f, (float) 3f), UnityEngine.Random.Range((float) 1f, (float) 2f));
        base.gameObject.active = false;
        this.script_mon.Defeat();
        this.script_sound = GameObject.FindWithTag("sound").GetComponent<SoundEf_slash>();
        this.script_cam = Camera.main.GetComponent<Cam_Move_ride>();
        this.ef_hit = GameObject.FindWithTag("icon_skill").transform;
    }

    private void Update()
    {
        if (this.life)
        {
            this.mytransform.position = Vector3.Lerp(this.mytransform.position, this.rndposition, Time.deltaTime * 0.5f);
        }
        else
        {
            this.mytransform.position -= (Vector3) ((Vector3.forward * Time.deltaTime) * 1f);
            if (this.mytransform.position.z < -1f)
            {
                this.mytransform.position = (Vector3) (Vector3.one * 4f);
                base.gameObject.active = false;
            }
        }
        this.attackrangeZ = this.mytransform.position.z - this.cha1.position.z;
        if (this.attackdelay > 0f)
        {
            this.attackdelay -= Time.deltaTime;
        }
        else if (Mathf.Abs(this.attackrangeZ) < 0.15f)
        {
            this.attackrangeX = this.mytransform.position.x - this.cha1.position.x;
            if (Mathf.Abs(this.attackrangeX) < 0.25f)
            {
                if (this.attackrangeX > 0f)
                {
                    this.script_cha1.Attack(true);
                }
                else
                {
                    this.script_cha1.Attack(false);
                }
                this.attackdelay = 0.2f;
            }
        }
    }
}


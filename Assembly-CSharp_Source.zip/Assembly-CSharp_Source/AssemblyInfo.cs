// Assembly Assembly-CSharp, Version 0.0.0.0

[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]


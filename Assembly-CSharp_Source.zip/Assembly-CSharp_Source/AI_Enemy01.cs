using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class AI_Enemy01 : MonoBehaviour
{
    private int accuracy;
    private short att_status;
    private bool attach_weaponEf;
    private AnimationState attack_impact;
    private Vector3 attackdir;
    private float attackforce;
    private float attackrange = 5f;
    private bool attackstart;
    private Vector3 attackstartVector;
    private float backspeed;
    private int behaviour;
    private float behaviour_delay = 2f;
    private AnimationState bekicked;
    private AnimationState bethrust;
    private short block;
    private Transform cha1;
    private int chamovestat;
    private Transform clone_arrow;
    private Transform clone_weapon;
    private float damage;
    private short dash;
    public Transform direction_arrow;
    private Vector3 directionVector;
    private bool downhigh;
    public Transform ef_weapon;
    private monster enemy;
    public int enemykind;
    private float f_risefactor;
    private float firerange;
    private AnimationState getup;
    private bool grabed;
    private int grabstyle;
    private float haveExp;
    private short hp;
    private Transform hpbar;
    private float hpbar_height;
    private bool impact;
    private short kind;
    private bool lastmon;
    private short level;
    private bool life = true;
    private Quaternion lookrotation;
    private float magnitude_behitdir;
    private short maxhp;
    public short monmovestat;
    private Renderer monrender;
    private float movespeed;
    private float moving_atk;
    private Animation myanimation;
    private AudioSource myaudio;
    private Transform mytransform;
    private short old_delay;
    private Texture originTex;
    private int petrify_rate;
    private bool pierce;
    private int playkind;
    private bool poison;
    private float poison_damage;
    private float poison_delay;
    private short power;
    private float restrictArea = 100f;
    private bool risedrop;
    private float runspeed;
    private Cam_Move script_cam;
    private Cha_Control script_cha;
    private Hp_bar script_hpbar;
    private Monster_efs script_monEf;
    private SoundEf_slash script_sound;
    private int shadow_index;
    private bool showme;
    private short sizekind;
    public AudioClip snd_attack;
    private AudioClip snd_move;
    private bool spawn_ing;
    private float speed_idle;
    private Transform target;
    private bool target_fix;
    private Transform target_onlyone;
    private bool targetreset;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myanimation = base.animation;
        this.myaudio = base.audio;
        this.script_monEf = GameObject.FindWithTag("efs_mon").GetComponent<Monster_efs>();
        this.enemy = GameObject.FindWithTag("Respawn").GetComponent<DB_Monster>().enemy[this.enemykind];
        this.cha1 = GameObject.FindWithTag("Player").transform;
        this.script_cha = this.cha1.GetComponent<Cha_Control>();
        this.script_sound = GameObject.FindWithTag("sound").GetComponent<SoundEf_slash>();
        this.script_cam = Camera.main.GetComponent<Cam_Move>();
    }

    [DebuggerHidden]
    public IEnumerator Burn()
    {
        return new <Burn>c__Iterator3 { <>f__this = this };
    }

    private void BurnDamage()
    {
        short num = (short) (this.script_cha.atk / 10);
        if (num < 1)
        {
            num = 1;
        }
        this.hp = (short) (this.hp - num);
        this.script_monEf.SetDamageNum(this.mytransform.position, num, this.attackdir);
        this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, this.hpbar_height, -1);
        if (this.hp <= 0)
        {
            this.Dead(0);
        }
    }

    public void CountDown()
    {
        if (this.life)
        {
            this.clone_arrow = (Transform) UnityEngine.Object.Instantiate(this.direction_arrow, this.cha1.position, Quaternion.identity);
            this.showme = true;
            this.lastmon = true;
        }
    }

    [DebuggerHidden]
    public IEnumerator Darken()
    {
        return new <Darken>c__Iterator5 { <>f__this = this };
    }

    public void Dead(int _kind)
    {
        this.monmovestat = -4;
        this.life = false;
        this.script_hpbar.FreeSelect();
        this.lastmon = false;
        this.hp = 0;
        Vector3 position = this.mytransform.position;
        this.attackdir[1] = 0f;
        if (_kind == 2)
        {
            this.script_sound.SoundOn(4);
            UnityEngine.Object.Destroy(base.gameObject);
            this.script_monEf.EnemyDead(this.kind, position, this.monrender.material.mainTexture, this.mytransform.localScale, this.attackdir);
        }
        else if (_kind == 1)
        {
            UnityEngine.Object.Destroy(base.gameObject, 2f);
            this.bekicked.wrapMode = WrapMode.ClampForever;
            this.script_monEf.EnemyDead(0, position, null, Vector3.zero, Vector3.zero);
            this.script_monEf.DestroyShadow(this.shadow_index);
        }
        else if (_kind == 0)
        {
            this.script_sound.SoundOn(4);
            UnityEngine.Object.Destroy(base.gameObject);
            this.script_monEf.EnemyDead(1, position, null, Vector3.zero, Vector3.zero);
        }
        else if (_kind == 3)
        {
            this.script_sound.SoundOn(4);
            UnityEngine.Object.Destroy(base.gameObject);
            this.script_monEf.EnemyDead(3, position, this.monrender.material.mainTexture, this.mytransform.localScale, Vector3.zero);
        }
        this.script_cha.GainExp(this.haveExp);
        this.script_monEf.SetItemBox(this.level, this.mytransform.position);
        if (this.clone_arrow != null)
        {
            UnityEngine.Object.Destroy(this.clone_arrow.gameObject);
            this.clone_arrow = null;
        }
        if (this.clone_weapon != null)
        {
            UnityEngine.Object.Destroy(this.clone_weapon.gameObject);
            this.clone_weapon = null;
        }
    }

    [DebuggerHidden]
    public IEnumerator Freeze(short _damage)
    {
        return new <Freeze>c__Iterator2 { <>f__this = this };
    }

    public void Grabed()
    {
        if ((this.att_status <= 0) && !this.grabed)
        {
            this.attackdir = Vector3.Normalize((Vector3) ((this.mytransform.position - (Vector3.right * this.cha1.position.x)) - (Vector3.forward * this.cha1.position.z)));
            this.mytransform.forward = -this.attackdir;
            this.myanimation.Stop();
            this.grabstyle = UnityEngine.Random.Range(0, 3);
            if (this.sizekind == 20)
            {
                this.grabstyle += 3;
            }
            else if (this.kind != 2)
            {
                this.grabstyle = 6;
            }
            UnityEngine.Object.Destroy(base.collider);
            if (this.grabstyle != 6)
            {
                this.myanimation.AddClip(this.script_monEf.begrab[this.grabstyle], "downforever");
                this.myanimation.AddClip(this.script_monEf.bethrust[this.grabstyle], "bethrust");
                this.myanimation.AddClip(this.script_monEf.bekicked[this.grabstyle], "bekicked");
                this.myanimation.AddClip(this.script_monEf.getup[this.grabstyle], "getup");
            }
            this.myanimation.Play("downforever");
            this.myanimation["downforever"].speed = this.script_monEf.speed_begrab[this.grabstyle];
            this.myanimation["downforever"].layer = 3;
            this.bethrust = this.myanimation.PlayQueued("bethrust");
            this.bethrust.speed = this.script_monEf.speed_bethrust[this.grabstyle];
            this.bethrust.layer = 3;
            this.bekicked = this.myanimation.PlayQueued("bekicked");
            this.bekicked.speed = this.script_monEf.speed_bekicked[this.grabstyle];
            this.bekicked.layer = 3;
            base.rigidbody.AddForce(this.attackdir * this.script_monEf.force_grab[this.grabstyle]);
            this.script_cha.Grab(this.grabstyle, this.mytransform.position);
            this.grabed = true;
            this.poison_delay = -1f;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        int layer = other.gameObject.layer;
        if (this.grabed || !this.life)
        {
            return;
        }
        if (layer < 0x10)
        {
            return;
        }
        this.accuracy = this.script_cha.hitrate;
        this.downhigh = this.script_cha.attack_rising;
        if (layer == 0x1c)
        {
            this.attackdir = this.mytransform.position - this.cha1.position;
            this.attackdir.y = 0f;
            this.attackdir = Vector3.Normalize(this.attackdir);
        }
        else
        {
            this.attackdir = this.mytransform.position - other.transform.position;
            this.attackdir.y = 0f;
            this.magnitude_behitdir = this.attackdir.magnitude;
            if (this.magnitude_behitdir != 0f)
            {
                if (this.magnitude_behitdir < 0.08f)
                {
                    this.attackdir = (Vector3) ((this.attackdir / this.magnitude_behitdir) * 1.6f);
                }
                else
                {
                    this.attackdir = (Vector3) (this.attackdir / this.magnitude_behitdir);
                }
            }
        }
        switch (layer)
        {
            case 0x10:
                this.attackforce = -10f;
                this.downhigh = false;
                this.damage = 0f;
                this.target = this.cha1;
                if (this.att_status != 1)
                {
                    this.myanimation.enabled = false;
                    base.StartCoroutine(this.Freeze((short) this.damage));
                    this.att_status = 2;
                }
                goto Label_0AED;

            case 0x11:
                this.attackforce = 0f;
                this.damage = this.script_cha.atk * 0.2f;
                this.script_cam.Hitcam2(0.08f);
                this.downhigh = false;
                if (!this.risedrop)
                {
                    this.mytransform.rotation = UnityEngine.Random.rotation;
                    this.f_risefactor = 1.2f;
                }
                else
                {
                    this.f_risefactor = 0.6f;
                }
                this.risedrop = true;
                this.target = this.cha1;
                this.script_monEf.CreatBlood(this.mytransform.position, this.attackdir);
                goto Label_0AED;

            case 0x12:
                this.attackforce = 40f;
                this.damage = this.script_cha.atk;
                if (other.transform.root == this.cha1)
                {
                    this.script_cam.Hitcam();
                }
                this.target = this.cha1;
                if (this.att_status != 3)
                {
                    this.monrender.material.mainTexture = this.script_monEf.attribute_tex[2];
                    this.script_monEf.CreatBlood(this.mytransform.position, this.attackdir);
                    base.InvokeRepeating("ShockDamage", 0.5f, 0.1f);
                    base.StartCoroutine(this.Shock((short) this.damage));
                    this.att_status = 3;
                }
                goto Label_0AED;

            case 0x13:
                this.attackforce = 40f;
                this.damage = this.script_cha.atk;
                if (other.transform.root == this.cha1)
                {
                    this.script_cam.Hitcam();
                }
                this.target = this.cha1;
                if (this.att_status != 4)
                {
                    this.monrender.material.mainTexture = this.script_monEf.attribute_tex[3];
                    this.script_monEf.CreatBlood(this.mytransform.position, this.attackdir);
                    base.StartCoroutine(this.Darken());
                    this.att_status = 4;
                }
                goto Label_0AED;

            case 20:
                this.attackforce = 40f;
                if ((UnityEngine.Random.Range(0, 100) >= (this.block - this.accuracy)) || (this.monmovestat < 0))
                {
                    this.damage = this.script_cha.atk;
                    this.script_cam.Hitcam();
                    this.target = this.cha1;
                    this.script_monEf.CreatBlood(this.mytransform.position, this.attackdir);
                    goto Label_0AED;
                }
                this.script_cha.Blocked(this.mytransform.position);
                base.rigidbody.AddForce((Vector3) (this.attackdir * 10f));
                return;

            case 0x15:
                this.attackforce = 30f;
                this.damage = this.script_cha.atk;
                this.script_cam.Hitcam2(1f);
                this.downhigh = true;
                this.target = this.cha1;
                this.script_monEf.CreatBlood_Only(this.mytransform.position, this.attackdir);
                goto Label_0AED;

            case 0x16:
                this.attackforce = 10f;
                this.damage = other.rigidbody.mass;
                this.script_cam.Hitcam();
                this.downhigh = true;
                this.target = this.cha1;
                this.script_monEf.CreatBlood_Only(this.mytransform.position, this.attackdir);
                goto Label_0AED;

            case 0x17:
            {
                this.attackforce = 10f;
                float mass = other.rigidbody.mass;
                if (mass != 0.1f)
                {
                    this.poison = true;
                    this.poison_damage = mass;
                    this.damage = this.poison_damage * 50f;
                    this.script_cam.Hitcam();
                    this.downhigh = true;
                    this.poison_delay = 5f;
                    this.target = this.cha1;
                    this.script_monEf.CreatBlood_Only(this.mytransform.position, this.attackdir);
                    goto Label_0AED;
                }
                this.damage = 0f;
                this.poison = true;
                this.poison_damage = this.script_cha.atk * 0.6f;
                this.poison_delay = 4f;
                this.downhigh = false;
                this.target = this.cha1;
                return;
            }
            case 0x18:
                this.attackforce = 0f;
                this.script_cam.Hitcam();
                this.life = false;
                this.petrify_rate = (int) other.rigidbody.mass;
                base.gameObject.layer = 10;
                base.StartCoroutine(this.Petrify());
                this.monrender.material.mainTexture = this.script_monEf.attribute_tex[1];
                this.target = this.cha1;
                this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, this.hpbar_height, 2);
                goto Label_0AED;

            case 0x19:
                this.attackforce = 60f;
                this.damage = this.script_cha.atk;
                this.target = this.cha1;
                this.script_monEf.CreatBlood_Only(this.mytransform.position, this.attackdir);
                this.downhigh = false;
                goto Label_0AED;

            case 0x1a:
                this.myanimation.AddClip(this.script_monEf.pierce, "pierced");
                this.myanimation["pierced"].speed = 0.3f;
                base.StartCoroutine(this.Pierced());
                this.attackforce = 0f;
                this.pierce = true;
                this.life = false;
                base.collider.enabled = false;
                this.damage = other.rigidbody.mass;
                this.hp = (short) (this.hp - ((short) this.damage));
                this.target = this.cha1;
                this.script_hpbar.Damaged(this.maxhp, 0, this.mytransform, 9f, 0);
                this.script_monEf.CreatBlood_Only(this.mytransform.position, this.attackdir);
                goto Label_0AED;

            case 0x1b:
                this.attackforce = 10f;
                this.damage = other.rigidbody.mass;
                this.target = other.transform;
                this.script_monEf.CreatBlood_Only(this.mytransform.position, this.attackdir);
                this.targetreset = true;
                this.downhigh = false;
                goto Label_0AED;

            case 0x1c:
                this.attackforce = 40f;
                this.damage = this.script_cha.atk;
                this.script_cam.Hitcam();
                this.target = this.cha1;
                this.script_monEf.CreatBlood(this.mytransform.position, this.attackdir);
                goto Label_0AED;

            case 0x1d:
                this.attackforce = 0f;
                this.damage = this.script_cha.atk * 0.4f;
                this.downhigh = false;
                if (!this.risedrop)
                {
                    this.mytransform.rotation = UnityEngine.Random.rotation;
                    this.f_risefactor = 3.4f;
                    break;
                }
                this.f_risefactor = 0.6f;
                break;

            case 30:
                this.attackforce = 40f;
                this.damage = this.script_cha.atk;
                if (other.transform.root == this.cha1)
                {
                    this.script_cam.Hitcam();
                }
                this.target = this.cha1;
                if (this.att_status != 2)
                {
                    this.monrender.material.mainTexture = this.script_monEf.attribute_tex[0];
                    this.script_monEf.CreatBlood(this.mytransform.position, this.attackdir);
                    base.InvokeRepeating("BurnDamage", 0.5f, 1f);
                    base.StartCoroutine(this.Burn());
                    this.att_status = 1;
                }
                goto Label_0AED;

            case 0x1f:
                this.attackforce = 40f;
                this.downhigh = false;
                this.damage = this.script_cha.atk;
                if (other.transform.root == this.cha1)
                {
                    this.script_cam.Hitcam();
                }
                this.target = this.cha1;
                if ((this.att_status != 1) && !this.myanimation.IsPlaying("down_high"))
                {
                    this.myanimation.enabled = false;
                    this.monrender.material.mainTexture = this.script_monEf.attribute_tex[1];
                    this.script_monEf.CreatBlood(this.mytransform.position, this.attackdir);
                    base.StartCoroutine(this.Freeze((short) this.damage));
                    this.att_status = 2;
                }
                goto Label_0AED;

            default:
                goto Label_0AED;
        }
        this.risedrop = true;
        this.target = this.cha1;
        this.script_monEf.CreatBlood_Only(this.mytransform.position, this.attackdir);
    Label_0AED:
        this.movespeed = 0f;
        this.script_sound.SoundOn(1);
        if (!this.life)
        {
            if (this.pierce)
            {
                this.myanimation.Play("pierced");
                this.pierce = false;
            }
            else
            {
                this.myanimation.Stop();
            }
        }
        else
        {
            this.myanimation.Stop();
            if (this.downhigh)
            {
                this.mytransform.Rotate((float) 0f, (float) UnityEngine.Random.Range(0, 360), (float) 0f);
                this.myanimation.Play("down_high");
            }
            else
            {
                this.myanimation.Play("down");
            }
            base.rigidbody.AddForce((Vector3) (this.attackdir * this.attackforce));
            if (this.directionVector == Vector3.zero)
            {
                this.directionVector = -Vector3.forward;
            }
            if (this.damage > 0f)
            {
                this.hp = (short) (this.hp - ((short) this.damage));
                this.script_monEf.SetDamageNum(this.mytransform.position, (short) this.damage, this.attackdir);
                this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, this.hpbar_height, -1);
            }
            if (UnityEngine.Random.Range(0, 5) == 0)
            {
                this.myaudio.clip = this.script_monEf.ScreamSFX();
                this.myaudio.Play();
            }
        }
        if ((this.hp <= 0) && this.life)
        {
            if (!this.risedrop)
            {
                this.Dead(2);
            }
        }
        else if (this.target_fix)
        {
            this.target = this.target_onlyone;
        }
    }

    [DebuggerHidden]
    public IEnumerator Petrify()
    {
        return new <Petrify>c__Iterator6 { <>f__this = this };
    }

    [DebuggerHidden]
    public IEnumerator Pierced()
    {
        return new <Pierced>c__Iterator7 { <>f__this = this };
    }

    public void SetDir()
    {
        if (!(!this.life | this.spawn_ing))
        {
            this.chamovestat = this.script_cha.chamovestat;
            if (this.target == null)
            {
                this.target = this.cha1;
            }
            switch (this.att_status)
            {
                case 2:
                    this.directionVector = Vector3.zero;
                    this.attackrange = 2f;
                    break;

                case 3:
                    this.directionVector = -this.mytransform.forward;
                    this.attackrange = 2f;
                    break;

                case 4:
                    this.attackrange = 2f;
                    this.directionVector = this.mytransform.position - this.target.position;
                    this.directionVector[1] = 0f;
                    this.directionVector = Vector3.Normalize(this.directionVector);
                    break;

                default:
                    this.attackrange = Vector3.Distance(this.mytransform.position, this.target.position);
                    this.directionVector = this.target.position - this.mytransform.position;
                    this.directionVector[1] = 0f;
                    this.directionVector = Vector3.Normalize(this.directionVector);
                    break;
            }
            if (this.directionVector != Vector3.zero)
            {
                this.lookrotation = Quaternion.LookRotation(this.directionVector);
            }
            if (this.behaviour_delay < 0f)
            {
                this.behaviour = UnityEngine.Random.Range(0, 6);
                if (this.behaviour == 0)
                {
                    this.myaudio.clip = this.snd_move;
                    this.myaudio.Play();
                }
                this.behaviour_delay = 2f;
            }
            if (this.attackrange < this.firerange)
            {
                if (!this.attackstart)
                {
                    if ((this.chamovestat < 110) && (this.monmovestat >= 0))
                    {
                        this.myanimation.Play("m_attack1");
                        this.attack_impact = this.myanimation.PlayQueued("m_attack1_i", QueueMode.CompleteOthers);
                        this.attack_impact.speed = this.myanimation["m_attack1_i"].speed;
                        this.attackstart = true;
                        this.attackstartVector = this.directionVector;
                        if (this.targetreset)
                        {
                            this.target = this.cha1;
                            this.targetreset = false;
                        }
                    }
                    else
                    {
                        this.movespeed = this.backspeed;
                        this.myanimation["idle"].speed = this.speed_idle * -0.5f;
                        this.myanimation.CrossFade("idle");
                        this.behaviour = -1;
                        this.behaviour_delay = 1f;
                    }
                }
            }
            else if (this.monrender.isVisible)
            {
                if (this.behaviour != -1)
                {
                    if (this.behaviour >= 3)
                    {
                        this.myanimation["idle"].speed = this.speed_idle;
                        this.movespeed = this.runspeed * 0.4f;
                        this.myanimation.CrossFade("idle");
                    }
                    else
                    {
                        this.movespeed = this.runspeed;
                        this.myanimation.CrossFade("move");
                    }
                }
                if (this.lastmon)
                {
                    this.showme = false;
                    this.clone_arrow.renderer.enabled = false;
                }
            }
            else
            {
                this.movespeed = this.runspeed * UnityEngine.Random.Range((float) 0.7f, (float) 1f);
                this.myanimation.Stop();
                if (this.directionVector != Vector3.zero)
                {
                    this.mytransform.rotation = Quaternion.LookRotation(this.directionVector);
                }
                if (this.lastmon)
                {
                    this.showme = true;
                    this.clone_arrow.renderer.enabled = true;
                }
            }
        }
    }

    public void SetLevel(short _level, int _playkind, bool _issummon, float _restrictArea)
    {
        this.level = (short) (_level + 1);
        this.restrictArea = _restrictArea;
        this.maxhp = (short) (this.maxhp + ((short) ((((0.1445f * this.level) * this.level) + (6.3873f * this.level)) - 5f)));
        this.power = (short) (this.power + ((short) ((((0.0058f * this.level) * this.level) + (1.008f * this.level)) - 5f)));
        this.block = (short) (this.block + ((short) (this.level * 0.4f)));
        this.hp = this.maxhp;
        this.haveExp += this.level * 0.1f;
        this.playkind = _playkind;
        if (this.playkind == 6)
        {
            this.target_fix = true;
            this.target_onlyone = GameObject.FindWithTag("general").transform;
            this.target = this.target_onlyone;
        }
        else
        {
            this.target = this.cha1;
        }
        if (_issummon)
        {
            this.SummonStart();
        }
        else
        {
            this.myanimation.Stop();
        }
    }

    [DebuggerHidden]
    public IEnumerator Shock(short _damage)
    {
        return new <Shock>c__Iterator4 { <>f__this = this };
    }

    private void ShockDamage()
    {
        this.myanimation.Stop();
        this.myanimation.Play("down");
    }

    private void Start()
    {
        this.maxhp = (short) (this.maxhp + this.enemy._maxhp);
        this.power = (short) (this.power + this.enemy._power);
        this.haveExp += this.enemy._haveExp;
        this.block = (short) (this.block + this.enemy._block);
        this.sizekind = this.enemy._sizekind;
        this.runspeed = this.enemy._runspeed;
        this.backspeed = this.enemy._backspeed;
        this.firerange = this.enemy._firerange;
        this.moving_atk = this.enemy._moving_atk;
        this.kind = this.enemy._kind;
        this.dash = this.enemy._dash;
        this.attach_weaponEf = this.enemy._attach_ef;
        this.myanimation["move"].speed = this.enemy._speed_move;
        this.myanimation["down"].speed = 0.24f;
        this.myanimation["down_high"].speed = 0.28f;
        this.myanimation["m_attack1"].speed = this.enemy._speed_m_attack1;
        this.myanimation["m_attack1_i"].speed = this.enemy._speed_m_attack1_i;
        this.myanimation["idle"].speed = this.enemy._speed_idle - 0.05f;
        this.speed_idle = this.myanimation["idle"].speed;
        this.myanimation["down"].layer = 2;
        this.myanimation["down_high"].layer = 2;
        this.myanimation["move"].layer = 0;
        this.myanimation["m_attack1"].layer = 1;
        this.myanimation["m_attack1_i"].layer = 1;
        this.myanimation["idle"].layer = 0;
        this.monmovestat = 0;
        this.monrender = this.mytransform.GetChild(1).renderer;
        this.originTex = this.monrender.material.mainTexture;
        base.InvokeRepeating("SetDir", 0.1f, 0.5f);
        this.hp = this.maxhp;
        this.accuracy = this.script_cha.hitrate;
        this.snd_move = this.script_monEf.snd_move[UnityEngine.Random.Range(0, 3)];
        this.hpbar = this.script_monEf.SetHpbar();
        this.hpbar.position = this.mytransform.position;
        this.hpbar_height = 0.1f + (this.sizekind * 0.007f);
        this.script_hpbar = this.hpbar.GetComponent<Hp_bar>();
        this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, this.hpbar_height, 0);
        this.shadow_index = this.script_monEf.CreatShadow(this.mytransform.GetChild(0), 1f);
    }

    public void SummonFinish()
    {
        this.spawn_ing = false;
    }

    public void SummonStart()
    {
        float time = 1.5f;
        if (this.enemy._kind == 2)
        {
            this.myanimation.AddClip(this.script_monEf.summon[0], "summon");
            this.myanimation["summon"].speed = 0.2f;
        }
        else
        {
            this.myanimation.AddClip(this.script_monEf.summon[1], "summon");
            this.myanimation["summon"].speed = 0.6f;
            time = 0.4f;
        }
        this.spawn_ing = true;
        this.mytransform.rotation = Quaternion.Euler(0f, (float) UnityEngine.Random.Range(0, 360), 0f);
        this.myanimation.Stop();
        this.myanimation.Play("summon");
        base.Invoke("SummonFinish", time);
    }

    private void Update()
    {
        if (this.life)
        {
            if (this.risedrop)
            {
                this.mytransform.position += (Vector3) ((Vector3.up * this.f_risefactor) * Time.deltaTime);
                this.f_risefactor -= Time.deltaTime * 5f;
                if (this.mytransform.position.y >= 0f)
                {
                    return;
                }
                this.myanimation.Play("down");
                this.mytransform.position = new Vector3(this.mytransform.position.x, 0f, this.mytransform.position.z);
                this.risedrop = false;
                this.f_risefactor = 0f;
                this.damage = this.script_cha.atk;
                this.hp = (short) (this.hp - ((short) this.damage));
                if (this.hp <= 0)
                {
                    this.Dead(3);
                }
                else if (this.attackdir != Vector3.zero)
                {
                    this.mytransform.rotation = Quaternion.LookRotation(this.attackdir);
                }
                else
                {
                    this.mytransform.rotation = Quaternion.identity;
                }
            }
            this.behaviour_delay -= Time.deltaTime;
            if (this.grabed)
            {
                if (this.myanimation.IsPlaying("downforever"))
                {
                    this.script_cha.Grabfinish(this.mytransform.position, this.mytransform.forward);
                    this.monmovestat = -2;
                    this.mytransform.position = this.cha1.position;
                }
                else if (this.myanimation.IsPlaying("bethrust"))
                {
                    this.script_cha.Grabfinish(this.mytransform.position, this.mytransform.forward);
                    if (this.monmovestat != -3)
                    {
                        this.hp = 0;
                        this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, this.hpbar_height, 0);
                        Transform transform = GameObject.Find("weapon_dummy").transform;
                        Quaternion quaternion = Quaternion.LookRotation(-transform.forward, new Vector3(0f, -1.3f, 1f));
                        this.script_monEf.CreatGrabBlood(transform.position + ((Vector3) (transform.forward * 0.01f)), quaternion);
                        this.script_cam.Hitcam2(1f);
                        this.script_sound.SoundOn(3);
                    }
                    this.monmovestat = -3;
                }
                else if (this.myanimation.IsPlaying("bekicked"))
                {
                    if (this.monmovestat != -4)
                    {
                        base.rigidbody.AddForce(this.mytransform.forward * this.script_monEf.force_kick[this.grabstyle]);
                        this.script_cam.Hitcam2(1f);
                        this.script_sound.SoundOn(2);
                        if (this.hp <= 0)
                        {
                            this.Dead(1);
                        }
                        else
                        {
                            if (this.grabstyle != 6)
                            {
                                this.myanimation.AddClip(this.script_monEf.getup[this.grabstyle], "getup");
                            }
                            this.getup = this.myanimation.PlayQueued("getup");
                            this.getup.speed = this.script_monEf.speed_getup[this.grabstyle];
                        }
                    }
                    this.monmovestat = -4;
                    this.grabed = false;
                }
            }
            else if (this.myanimation.IsPlaying("getup"))
            {
                this.monmovestat = 0;
            }
            else if (this.myanimation.IsPlaying("summon"))
            {
                this.monmovestat = 0;
            }
            else if (this.myanimation.IsPlaying("down_high"))
            {
                this.monmovestat = -1;
            }
            else if (this.myanimation.IsPlaying("down"))
            {
                this.monmovestat = -1;
            }
            else if (this.myanimation.IsPlaying("m_attack1"))
            {
                this.impact = false;
                this.monmovestat = 11;
                this.lookrotation = Quaternion.LookRotation(this.attackstartVector);
                this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, this.lookrotation, Time.deltaTime * 6f);
                this.mytransform.position += (Vector3) ((this.attackstartVector * Time.deltaTime) * this.moving_atk);
            }
            else if (this.myanimation.IsPlaying("m_attack1_i"))
            {
                this.monmovestat = 12;
                if (!this.impact)
                {
                    this.impact = true;
                    Vector3 position = this.mytransform.position + ((Vector3) (Vector3.up * this.ef_weapon.localPosition.y));
                    base.rigidbody.AddForce(this.mytransform.forward * this.dash);
                    if (this.clone_weapon == null)
                    {
                        this.clone_weapon = (Transform) UnityEngine.Object.Instantiate(this.ef_weapon, position, this.mytransform.rotation);
                        this.clone_weapon.GetComponent<WeaponDamage>().PressDamage(this.power);
                        if (this.attach_weaponEf)
                        {
                            this.clone_weapon.parent = this.mytransform;
                        }
                    }
                    else
                    {
                        this.clone_weapon.position = position;
                        this.clone_weapon.rotation = this.mytransform.rotation;
                        this.clone_weapon.gameObject.active = true;
                    }
                    base.audio.clip = this.snd_attack;
                    this.myaudio.Play();
                    this.mytransform.position = (Vector3) ((Vector3.right * this.mytransform.position.x) + (Vector3.forward * this.mytransform.position.z));
                }
            }
            else if ((this.myanimation.IsPlaying("move") || this.myanimation.IsPlaying("idle")) || !this.myanimation.isPlaying)
            {
                this.attackstart = false;
                this.grabed = false;
                this.monmovestat = 1;
            }
            else
            {
                this.monmovestat = 1;
            }
            if (this.monmovestat == 1)
            {
                this.mytransform.position += (Vector3) ((this.directionVector * Time.deltaTime) * this.movespeed);
                if (this.myanimation.isPlaying)
                {
                    this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, this.lookrotation, Time.deltaTime * 3f);
                }
            }
            if (this.lastmon && this.showme)
            {
                Vector3 forward = Vector3.Normalize(this.mytransform.position - this.cha1.position);
                if (forward != Vector3.zero)
                {
                    this.clone_arrow.rotation = Quaternion.LookRotation(forward);
                }
                forward = (Vector3) ((this.cha1.position + (Vector3.up * 0.02f)) + (forward * 0.3f));
                this.clone_arrow.position = Vector3.Lerp(this.clone_arrow.position, forward, Time.deltaTime * 4f);
            }
            if (this.poison)
            {
                this.poison_delay -= Time.deltaTime;
                if (this.poison_delay < 0f)
                {
                    this.poison = false;
                    this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, this.hpbar_height, 0);
                }
                else if (((short) this.poison_delay) != this.old_delay)
                {
                    this.hp = (short) (this.hp - ((short) this.poison_damage));
                    this.script_monEf.SetDamageNum(this.mytransform.position, (short) this.poison_damage, this.attackdir);
                    this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, this.hpbar_height, 1);
                    this.old_delay = (short) this.poison_delay;
                    if (this.hp <= 0)
                    {
                        this.Dead(0);
                    }
                }
            }
            Vector2 a = new Vector2(this.mytransform.position.x, this.mytransform.position.z);
            if (Vector2.SqrMagnitude(a) > this.restrictArea)
            {
                base.rigidbody.AddForce((Vector3) (-new Vector3(a.x, 0f, a.y) * 5f));
            }
        }
    }

    [CompilerGenerated]
    private sealed class <Burn>c__Iterator3 : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal AI_Enemy01 <>f__this;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.$current = new WaitForSeconds(3f);
                    this.$PC = 1;
                    return true;

                case 1:
                    this.<>f__this.att_status = 0;
                    this.<>f__this.monrender.material.mainTexture = this.<>f__this.originTex;
                    this.<>f__this.CancelInvoke("BurnDamage");
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [CompilerGenerated]
    private sealed class <Darken>c__Iterator5 : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal AI_Enemy01 <>f__this;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.$current = new WaitForSeconds(2f);
                    this.$PC = 1;
                    return true;

                case 1:
                    this.<>f__this.att_status = 0;
                    this.<>f__this.monrender.material.mainTexture = this.<>f__this.originTex;
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [CompilerGenerated]
    private sealed class <Freeze>c__Iterator2 : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal AI_Enemy01 <>f__this;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.$current = new WaitForSeconds(2f);
                    this.$PC = 1;
                    return true;

                case 1:
                    this.<>f__this.att_status = 0;
                    this.<>f__this.myanimation.enabled = true;
                    this.<>f__this.monrender.material.mainTexture = this.<>f__this.originTex;
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [CompilerGenerated]
    private sealed class <Petrify>c__Iterator6 : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal int <_rate>__0;
        internal AI_Enemy01 <>f__this;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<_rate>__0 = UnityEngine.Random.Range(0, 100);
                    this.$current = new WaitForSeconds(2.5f);
                    this.$PC = 1;
                    return true;

                case 1:
                    if (this.<>f__this.petrify_rate <= this.<_rate>__0)
                    {
                        this.<>f__this.gameObject.layer = 8;
                        this.<>f__this.monrender.material.mainTexture = this.<>f__this.originTex;
                        this.<>f__this.life = true;
                        this.<>f__this.script_hpbar.Damaged(this.<>f__this.maxhp, this.<>f__this.hp, this.<>f__this.mytransform, this.<>f__this.hpbar_height, 0);
                        break;
                    }
                    this.<>f__this.Dead(0);
                    break;

                default:
                    goto Label_00F3;
            }
            this.$PC = -1;
        Label_00F3:
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [CompilerGenerated]
    private sealed class <Pierced>c__Iterator7 : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal AI_Enemy01 <>f__this;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.$current = new WaitForSeconds(4f);
                    this.$PC = 1;
                    return true;

                case 1:
                    if (this.<>f__this.hp > 0)
                    {
                        this.<>f__this.script_hpbar.Damaged(this.<>f__this.maxhp, this.<>f__this.hp, this.<>f__this.mytransform, this.<>f__this.hpbar_height, 0);
                        break;
                    }
                    this.<>f__this.Dead(0);
                    break;

                default:
                    goto Label_0142;
            }
            this.<>f__this.myanimation.Stop();
            this.<>f__this.myanimation.Play("down");
            this.<>f__this.script_cam.Hitcam();
            this.<>f__this.script_monEf.CreatBlood_Only(this.<>f__this.mytransform.position, this.<>f__this.attackdir);
            this.<>f__this.movespeed = 0f;
            this.<>f__this.script_sound.SoundOn(1);
            this.<>f__this.collider.enabled = true;
            this.<>f__this.life = true;
            this.$PC = -1;
        Label_0142:
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [CompilerGenerated]
    private sealed class <Shock>c__Iterator4 : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal AI_Enemy01 <>f__this;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.$current = new WaitForSeconds(1.2f);
                    this.$PC = 1;
                    return true;

                case 1:
                    this.<>f__this.att_status = 0;
                    this.<>f__this.monrender.material.mainTexture = this.<>f__this.originTex;
                    this.<>f__this.CancelInvoke("ShockDamage");
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }
}


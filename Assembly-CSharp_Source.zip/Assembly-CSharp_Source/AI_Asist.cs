using System;
using UnityEngine;

public class AI_Asist : MonoBehaviour
{
    private int a_index;
    public Transform a_mesh;
    private Transform cha1;
    private float cur_speed = 0.3f;
    private float delay_atack;
    private Vector3 directionVector;
    private Transform ef_splash;
    private float firerate = 1f;
    private Transform m_arrow;
    private Collider mycollider;
    private Transform mytransform;
    private Quaternion rotate;
    private DB_angel script_db;
    private bool shoot;
    private float speed = 0.3f;
    private Vector3 targetPos;
    public Texture[] tex_grade = new Texture[8];
    public Texture[] tex_pt = new Texture[8];

    public void AttackFinish()
    {
        this.shoot = false;
        if (this.ef_splash != null)
        {
            Vector3 forward = this.m_arrow.forward;
            forward.y = 0f;
            this.targetPos.y = 0f;
            this.ef_splash.forward = forward;
            this.ef_splash.position = this.targetPos;
            this.ef_splash.gameObject.active = true;
        }
    }

    private void AttackOn(Vector3 _targetpos)
    {
        this.targetPos = _targetpos;
        this.m_arrow.forward = this.targetPos - this.mytransform.position;
        this.m_arrow.position = this.mytransform.position;
        this.m_arrow.gameObject.active = true;
    }

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
        this.cha1 = GameObject.FindWithTag("Player").transform;
        this.a_index = Crypto.Load_int_key("n61");
        this.script_db = base.GetComponent<DB_angel>();
    }

    public void LoadDir()
    {
        this.directionVector = this.cha1.position - this.mytransform.position;
        this.directionVector[1] = 0f;
        if (this.directionVector != Vector3.zero)
        {
            this.rotate = Quaternion.LookRotation(this.directionVector);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!this.shoot)
        {
            int layer = other.gameObject.layer;
            if (other.gameObject.layer == 8)
            {
                this.AttackOn(other.transform.position);
                this.mycollider.enabled = false;
                this.delay_atack = 0f;
                this.shoot = true;
            }
        }
    }

    public void SetIndex(int _index)
    {
        this.a_index = _index;
        this.Start();
    }

    private void Start()
    {
        if (this.a_index == 0)
        {
            this.mytransform.position = (Vector3) (Vector3.up * 21f);
            base.gameObject.active = false;
        }
        else
        {
            this.mytransform.position = (Vector3) (Vector3.up * 0.2f);
            base.particleSystem.renderer.material.mainTexture = this.tex_pt[this.a_index - 1];
            this.a_mesh.renderer.material.mainTexture = this.tex_grade[this.a_index - 1];
            int num = 0x19;
            this.speed = this.script_db.ag[this.a_index - 1]._speed;
            this.firerate = this.script_db.ag[this.a_index - 1]._firerate;
            num = this.script_db.ag[this.a_index - 1]._arrowkind;
            GameObject obj2 = Resources.Load("bullet_angel" + this.a_index.ToString()) as GameObject;
            this.m_arrow = (Transform) UnityEngine.Object.Instantiate(obj2.transform, (Vector3) (Vector3.up * 4f), Quaternion.identity);
            this.m_arrow.gameObject.layer = num;
            short num2 = this.script_db.ag[this.a_index - 1]._splashEF;
            if (num2 > 0)
            {
                GameObject obj3 = Resources.Load("angel_splash" + num2.ToString()) as GameObject;
                this.ef_splash = (Transform) UnityEngine.Object.Instantiate(obj3.transform, (Vector3) (Vector3.up * 4f), Quaternion.identity);
            }
            else
            {
                this.ef_splash = null;
            }
        }
        base.InvokeRepeating("LoadDir", 0.1f, 0.1f);
    }

    private void Update()
    {
        if (this.shoot)
        {
            this.cur_speed = Mathf.Lerp(this.cur_speed, 0f, Time.deltaTime * 4f);
        }
        else
        {
            this.cur_speed = Mathf.Lerp(this.cur_speed, this.speed, Time.deltaTime * 4f);
            if (this.delay_atack > this.firerate)
            {
                this.mycollider.enabled = true;
                this.delay_atack = 0f;
            }
            else
            {
                this.delay_atack += Time.deltaTime;
            }
        }
        this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, this.rotate, (Time.deltaTime * this.cur_speed) * 4f);
        this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * this.cur_speed);
    }
}


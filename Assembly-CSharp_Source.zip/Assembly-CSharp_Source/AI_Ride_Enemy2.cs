using System;
using UnityEngine;

public class AI_Ride_Enemy2 : MonoBehaviour
{
    public Transform bullet;
    private Transform c_bullet;
    private Transform cha1;
    private bool impact;
    private bool live;
    private Transform mytransform;
    private float rot_limit;
    private float rot_speed;
    private AnimationState state;
    private Vector3 targetdir;
    private AnimationState temp;

    public void Attack()
    {
        if (this.live)
        {
            base.animation.Play("ride_mon_shoot");
            this.temp = base.animation.PlayQueued("ride_mon_shoot_i");
            this.temp.speed = 0.25f;
            this.temp.layer = 1;
        }
    }

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    public void Defeat()
    {
        this.live = false;
    }

    private void Start()
    {
        this.cha1 = GameObject.FindWithTag("Player").transform;
        base.animation["ride_mon"].speed = 0.25f;
        base.animation["ride_mon_shoot"].speed = 0.25f;
        base.animation["ride_mon_shoot"].layer = 1;
        base.animation.Play("ride_mon");
        base.InvokeRepeating("Attack", 4f, UnityEngine.Random.Range((float) 3f, (float) 5f));
        this.c_bullet = (Transform) UnityEngine.Object.Instantiate(this.bullet, (Vector3) (Vector3.one * 10f), Quaternion.identity);
        this.c_bullet.gameObject.active = false;
    }

    private void Update()
    {
        if (this.live)
        {
            if (base.animation.IsPlaying("ride_mon_shoot_i"))
            {
                this.rot_limit = -1f;
                this.rot_speed = 8f;
                if (!this.impact)
                {
                    this.c_bullet.gameObject.active = true;
                    this.c_bullet.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.08f));
                    this.c_bullet.rotation = this.mytransform.rotation;
                    this.impact = true;
                }
            }
            else if (base.animation.IsPlaying("ride_mon_shoot"))
            {
                this.rot_limit = -1f;
                this.rot_speed = 8f;
                this.impact = false;
            }
            else if (base.animation.IsPlaying("ride_mon"))
            {
                this.rot_limit = 0f;
                this.rot_speed = 4f;
            }
            this.targetdir = this.cha1.position - this.mytransform.position;
            this.targetdir[1] = 0f;
            this.targetdir = Vector3.Normalize(this.targetdir);
            if (this.targetdir.z > this.rot_limit)
            {
                this.mytransform.forward = Vector3.Lerp(this.mytransform.forward, this.targetdir, Time.deltaTime * this.rot_speed);
            }
            else
            {
                this.mytransform.forward = Vector3.Lerp(this.mytransform.forward, Vector3.forward, Time.deltaTime * 6f);
            }
        }
    }

    public void Wake()
    {
        this.live = true;
    }
}


using System;
using UnityEngine;

public class Mirage : MonoBehaviour
{
    private bool bounce;
    private Vector3 bouncescale = new Vector3(1f, 1f, 2f);
    private float delay_finish;
    private Vector3 directionVector;
    private float dropdown;
    private bool move;
    private Vector3 mypos;
    private Transform mytransform;
    private Vector3 startscale = new Vector3(1f, 1f, 0.5f);

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void OnEnable()
    {
        this.mytransform.localScale = this.startscale;
        this.dropdown = 0.2f;
        this.move = false;
        this.bounce = false;
        this.delay_finish = 0f;
        this.mypos = this.mytransform.position;
    }

    private void Update()
    {
        if (this.move)
        {
            this.mypos += (Vector3) ((this.directionVector * Time.deltaTime) * 1.5f);
            if (!this.bounce)
            {
                this.dropdown -= Time.deltaTime * 3f;
                this.directionVector = this.mytransform.forward + ((Vector3) (Vector3.up * this.dropdown));
                this.mytransform.rotation = Quaternion.LookRotation(this.directionVector);
            }
            else
            {
                this.mytransform.localScale = Vector3.Lerp(this.mytransform.localScale, this.bouncescale, Time.deltaTime * 3f);
            }
            if (this.mypos.y < 0f)
            {
                this.mypos[1] = 0f;
                this.dropdown = 0.4f;
                this.bounce = true;
                this.directionVector[1] = 0f;
                this.directionVector = (Vector3) ((this.directionVector + (Vector3.up * 0.3f)) * 2f);
                this.mytransform.rotation = Quaternion.LookRotation(this.directionVector);
            }
        }
        else
        {
            this.mytransform.localScale = Vector3.Lerp(this.mytransform.localScale, this.bouncescale, Time.deltaTime * 5f);
        }
        this.mytransform.position = this.mypos;
        this.delay_finish += Time.deltaTime;
        if (this.delay_finish > 1f)
        {
            base.gameObject.active = false;
            this.delay_finish = 0f;
        }
        else if (this.delay_finish > 0.1f)
        {
            this.move = true;
        }
    }
}


using System;
using UnityEngine;

public class UI_Ingame_story : MonoBehaviour
{
    public GUISkin basicSkin;
    private GameObject cha1;
    private float chaexp;
    private int chahp;
    private int chalv = 1;
    private int chamaxhp = 100;
    private float chamaxsp = 100f;
    private bool chargeon;
    private float chasp;
    private int coin;
    private float exp_height;
    private float f_charge;
    private Transform g_power;
    private Gauge_UV gauge_exp;
    private Gauge_UV gauge_hp;
    private Gauge_UV gauge_power;
    private Gauge_UV gauge_sp;
    private int guide = -1;
    public Texture2D[] guide_img = new Texture2D[4];
    private string[] guide_txt = new string[4];
    private int language;
    public Transform pack;
    public Texture2D pop_blank;
    private Cha_Control script_cha;
    private Pet_horse script_horse;
    private MakeUI script_pack;
    private Vector3 shootdir;
    private int soul;
    private bool uistart = true;
    public GUIStyle yesno;

    public void GainCoin(int a)
    {
        this.coin += a;
    }

    public void GainSoul(int a)
    {
        this.soul += a;
        this.chaexp = this.script_cha.exp;
        this.exp_height = (1f - (this.chaexp / ((float) (this.chalv * 100)))) * 0.125f;
        this.gauge_exp.UvMove((Vector2) (Vector2.up * this.exp_height));
    }

    public void GuideOn(int a)
    {
        this.script_cha.StopControl();
        Time.timeScale = 0f;
        this.guide = a;
    }

    private void OnGUI()
    {
        if (this.uistart)
        {
            GUI.skin = this.basicSkin;
            GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
            GUI.depth = 0;
            if (this.guide >= 0)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 96f, 256f, 128f), this.pop_blank);
                GUI.Label(Crypto.Rect2(124f, 104f, 232f, 36f), string.Empty + this.guide_txt[this.guide], "txt12_0");
                GUI.Label(Crypto.Rect2(118f, 200f, 244f, 14f), string.Empty + (this.guide + 1) + " / 4", "txt12_0");
                GUI.DrawTexture(Crypto.Rect2(170f, 138f, 128f, 64f), this.guide_img[this.guide]);
                if (this.guide == 3)
                {
                    if (GUI.Button(Crypto.Rect2(290f, 184f, 64f, 32f), Language.intxt[this.language, 4], this.yesno))
                    {
                        this.guide = -1;
                        Time.timeScale = 1f;
                        this.script_cha.StartControl();
                    }
                }
                else if (GUI.Button(Crypto.Rect2(290f, 184f, 64f, 32f), Language.intxt[this.language, 0x2f], this.yesno))
                {
                    this.guide++;
                }
            }
        }
    }

    public void PowerCharge()
    {
        this.chargeon = true;
        this.g_power.gameObject.active = true;
    }

    public void ResetPower()
    {
        this.chargeon = false;
        this.f_charge = 0f;
        this.gauge_power.UvMove(Vector2.zero);
        this.g_power.gameObject.active = false;
    }

    private void Start()
    {
        this.language = PlayerPrefs.GetInt("language");
        this.chamaxhp = 100;
        this.chamaxsp = 100f;
        this.script_pack = this.pack.GetComponent<MakeUI>();
        this.script_pack.CreatCustomPlane(new Vector2(0.25f, 0.25f), 0f, new Vector3(-1.35f, 2.85f, 2f), new Vector2(0.5f, 0.625f), new Vector2(0.625f, 0.75f), "bg_hp", null, 0f, 0);
        Transform transform = this.script_pack.CreatCustomPlane(new Vector2(0.9f, 0.1f), 0f, new Vector3(-0.757f, 2.92f, 1.8f), new Vector2(0f, 0.5f), new Vector2(0.5f, 0.5625f), "gauge_hp", "Gauge_UV", 0.2f, 0);
        Transform transform2 = this.script_pack.CreatCustomPlane(new Vector2(1.06f, 0.05f), 0f, new Vector3(-0.6775f, 2.85f, 1.8f), new Vector2(0f, 0.47f), new Vector2(0.5f, 0.498f), "gauge_sp", "Gauge_UV", 0.12f, 0);
        Transform transform3 = this.script_pack.CreatCustomPlane((Vector2) (Vector2.one * 0.186f), 0f, new Vector3(-1.352f, 2.85f, 2.1f), new Vector2(0.875f, 0.75f), new Vector2(1f, 0.875f), "gauge_exp", "Gauge_UV", 0f, 0);
        this.g_power = this.script_pack.CreatCustomPlane(new Vector2(0.4f, 0.05f), 0f, new Vector3(0f, 2.4f, 2.1f), new Vector2(0.5f, 0.5f), new Vector2(1f, 0.5625f), "gauge_power", "Gauge_UV", 0f, 0);
        this.cha1 = GameObject.FindWithTag("Player");
        this.script_cha = this.cha1.GetComponent<Cha_Control>();
        this.gauge_hp = transform.GetComponent<Gauge_UV>();
        this.gauge_sp = transform2.GetComponent<Gauge_UV>();
        this.gauge_exp = transform3.GetComponent<Gauge_UV>();
        this.gauge_power = this.g_power.GetComponent<Gauge_UV>();
        this.guide_txt[0] = Language.intxt[this.language, 0x21];
        this.guide_txt[1] = Language.intxt[this.language, 0x22];
        this.guide_txt[2] = Language.intxt[this.language, 0x23];
        this.guide_txt[3] = Language.intxt[this.language, 360];
        this.g_power.gameObject.active = false;
    }

    public void StatUpdate(int _hp, int _maxhp, float _sp)
    {
        this.chahp = _hp;
        this.chasp = _sp;
        this.chamaxhp = _maxhp;
        float x = (1f - (((float) this.chahp) / ((float) this.chamaxhp))) * 0.5f;
        this.gauge_hp.UvMove(new Vector2(x, 0f));
        float num2 = (1f - (this.chasp / this.chamaxsp)) * 0.5f;
        if (this.chasp >= 50f)
        {
            this.gauge_sp.UvMove((Vector2) (Vector2.right * num2));
        }
        else
        {
            this.gauge_sp.UvMove((Vector2) ((Vector2.right * num2) - (Vector2.up * 0.03125f)));
        }
    }

    private void Update()
    {
        if (this.chargeon)
        {
            if (this.f_charge < 0.5f)
            {
                this.f_charge += Time.deltaTime * 0.6f;
            }
            else
            {
                this.f_charge = 0f;
                this.script_cha.Eximpact();
                this.chargeon = false;
                this.g_power.gameObject.active = false;
            }
            this.gauge_power.UvMove((Vector2) (Vector2.right * -this.f_charge));
        }
    }
}


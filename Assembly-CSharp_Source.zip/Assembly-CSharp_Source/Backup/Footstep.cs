using System;
using UnityEngine;

public class Footstep : MonoBehaviour
{
    private int chamovestat;
    private ParticleEmitter myparticle;
    private float s_delay;
    private Cha_Control script_cha;
    private bool turnon;

    private void Start()
    {
        this.myparticle = base.particleEmitter;
        this.script_cha = base.transform.parent.GetComponent<Cha_Control>();
        base.particleEmitter.emit = false;
    }

    private void Update()
    {
        if (this.s_delay > 0.5f)
        {
            this.chamovestat = this.script_cha.chamovestat;
            if (this.chamovestat == 2)
            {
                if (!this.turnon)
                {
                    this.turnon = true;
                    this.myparticle.emit = true;
                }
            }
            else
            {
                this.turnon = false;
                this.myparticle.emit = false;
            }
        }
        else
        {
            this.s_delay += Time.deltaTime;
        }
    }
}


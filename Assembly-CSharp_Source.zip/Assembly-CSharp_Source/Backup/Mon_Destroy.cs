using System;
using UnityEngine;

public class Mon_Destroy : MonoBehaviour
{
    private float delay_finish;
    private float downaccel = 1f;
    public Transform headbone;
    private Transform mytransform;

    private void Awake()
    {
        base.animation["dt1"].speed = 0.3f;
        this.mytransform = base.transform;
        base.gameObject.active = false;
    }

    public void FinishNow()
    {
        this.delay_finish = 5f;
    }

    public void TextureChange(Texture a, Vector3 _scale, int _kind)
    {
        base.animation.Stop();
        base.animation.Play("dt1");
        this.delay_finish = 0f;
        this.downaccel = 0f;
        if (_kind == 2)
        {
            this.mytransform.Find("p1").renderer.material.SetTexture("_MainTex", a);
            this.mytransform.Find("p2").renderer.material.SetTexture("_MainTex", a);
            if (_scale.x > 1f)
            {
                this.mytransform.localScale = (Vector3) (_scale * 1.2f);
                this.headbone.localScale = (Vector3) (Vector3.one * 0.7f);
            }
            else
            {
                this.mytransform.localScale = (Vector3) (Vector3.one * 1.2f);
                this.headbone.localScale = Vector3.one;
            }
        }
        else
        {
            base.animation["dt1"].speed = 0.55f;
        }
    }

    private void Update()
    {
        if (this.delay_finish > 3f)
        {
            base.gameObject.active = false;
            this.mytransform.position = (Vector3) (Vector3.one * 6f);
            this.delay_finish = 0f;
        }
        else
        {
            this.delay_finish += Time.deltaTime;
        }
        if (this.mytransform.position.y > 0f)
        {
            this.downaccel += Time.deltaTime * 5f;
            this.mytransform.position -= (Vector3) ((Vector3.up * Time.deltaTime) * this.downaccel);
        }
        else
        {
            this.mytransform.position = new Vector3(this.mytransform.position.x, 0f, this.mytransform.position.z);
        }
    }
}


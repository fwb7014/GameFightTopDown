using System;
using UnityEngine;

public class Hp_bar_fixed : MonoBehaviour
{
    private float _amount;
    private Vector2 amountU;
    private Vector2 amuontV;
    private Transform mytransform;
    private int oldstatus;
    private Vector2[] originUV = new Vector2[4];
    private Mesh thismesh;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.thismesh = base.GetComponent<MeshFilter>().mesh;
        this.originUV = this.thismesh.uv;
        this.amuontV = (Vector2) (Vector2.up * 0.25f);
    }

    public void Damaged(int _maxhp, int _hp, Transform _parent, float _height, int _status)
    {
        if (_maxhp != 0)
        {
            this._amount = (1f - (((float) _hp) / ((float) _maxhp))) * 0.5f;
            this.amountU = (Vector2) (Vector2.right * this._amount);
            if (_status == -1)
            {
                _status = this.oldstatus;
            }
            this.thismesh.uv = new Vector2[] { (this.originUV[0] + this.amountU) + (this.amuontV * _status), (this.originUV[1] + this.amountU) + (this.amuontV * _status), (this.originUV[2] + this.amountU) + (this.amuontV * _status), (this.originUV[3] + this.amountU) + (this.amuontV * _status) };
        }
        this.oldstatus = _status;
    }

    public void FreeSelect()
    {
        this.mytransform.position = (Vector3) (Vector3.one * 4f);
    }
}


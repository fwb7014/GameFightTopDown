using System;
using UnityEngine;

public class SwordDance : MonoBehaviour
{
    public float hitrate = 0.2f;
    private Collider mycollider;
    private Material mymaterial;
    private Vector2 offset;
    public float startdelay = 0.1f;
    public float uvspeed = 1f;

    private void Awake()
    {
        this.mymaterial = base.renderer.sharedMaterial;
        this.mycollider = base.collider;
    }

    private void DanceHit()
    {
        this.mycollider.enabled = false;
        this.mycollider.enabled = true;
    }

    private void OnEnable()
    {
        this.offset = Vector2.zero;
        this.mymaterial.mainTextureOffset = Vector2.zero;
        base.InvokeRepeating("DanceHit", this.startdelay, this.hitrate);
    }

    private void Update()
    {
        this.offset += (Vector2) ((Vector2.right * Time.deltaTime) * this.uvspeed);
        if (this.offset.x >= 0.9f)
        {
            base.CancelInvoke();
            this.mycollider.enabled = false;
            base.transform.position = (Vector3) (Vector3.one * 38f);
            base.gameObject.active = false;
        }
        else
        {
            this.mymaterial.mainTextureOffset = this.offset;
        }
    }
}


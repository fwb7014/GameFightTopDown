using System;
using UnityEngine;

public class Bullet_spear : MonoBehaviour
{
    private Transform mytransform;
    private Vector3 originscale;
    public float tune;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.originscale = this.mytransform.localScale;
    }

    private void OnEnable()
    {
        this.mytransform.position += (Vector3) (this.mytransform.forward * this.tune);
    }

    private void Update()
    {
        this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * (0.2f + this.tune));
        this.mytransform.localScale -= (Vector3) ((Vector3.right * 0.6f) * Time.deltaTime);
        if (this.mytransform.localScale.x < 0f)
        {
            base.gameObject.active = false;
            this.mytransform.localScale = this.originscale;
        }
    }
}


using System;
using UnityEngine;

public class Cha_Control_ride_cha_story2 : MonoBehaviour
{
    private bool dooropen;

    private void Awake()
    {
    }

    private void Start()
    {
        base.animation.Stop();
        base.transform.position = new Vector3(0f, -1.33f, -0.03f);
        base.transform.localScale = new Vector3(1.3f, 1.3f, 1.3f);
        base.transform.rotation = Quaternion.Euler(0f, 180f, 0f);
        GameObject obj2 = GameObject.Find("cha1_riding");
        obj2.animation["push_door"].speed = 0.13f;
        obj2.animation.Play("push_door");
        obj2.animation.CrossFadeQueued("walk_free").speed = 0.4f;
    }

    private void Update()
    {
        if (base.animation.IsPlaying("walk_free"))
        {
            Transform transform = base.transform;
            transform.position -= (Vector3) ((new Vector3(0f, 0.05f, 1f) * Time.deltaTime) * 0.3f);
        }
        else if (!this.dooropen)
        {
            GameObject.Find("door").animation["open_door"].speed = 0.05f;
            this.dooropen = true;
        }
    }
}


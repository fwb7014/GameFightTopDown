using System;
using UnityEngine;

public class FortuneTeller : MonoBehaviour
{
    private GameObject c_plane;
    private float creat_delay;
    private Renderer creatrender;
    public Transform ef_shuffle;
    private bool efon;
    public Material main_material;
    private Transform mytransform;
    private Vector3 targetVector;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    public void FortuneMesh(int _atk, int _def, int _hp, int _rate)
    {
        this.c_plane = new GameObject("fortunemesh");
        MeshFilter filter = this.c_plane.AddComponent<MeshFilter>();
        Mesh mesh = new Mesh();
        this.c_plane.AddComponent<MeshRenderer>();
        mesh.vertices = new Vector3[] { (Vector3.up * _atk) * 0.1f, (Vector3.right * _def) * 0.1f, (-Vector3.right * _rate) * 0.1f, (-Vector3.up * _hp) * 0.1f };
        mesh.uv = new Vector2[] { Vector2.up, Vector2.one, Vector2.zero, Vector2.right };
        this.creatrender = this.c_plane.renderer;
        this.creatrender.enabled = false;
        this.creatrender.sharedMaterial = this.main_material;
        mesh.triangles = new int[] { 0, 1, 2, 2, 1, 3 };
        mesh.RecalculateNormals();
        filter.mesh = mesh;
        this.c_plane.transform.position = (Vector3) ((this.mytransform.position + (Vector3.forward * 0.1f)) + (Vector3.up * -0.32f));
        this.c_plane.transform.parent = this.mytransform;
        this.c_plane.layer = this.mytransform.gameObject.layer;
    }

    private void OnEnable()
    {
        this.ef_shuffle.gameObject.active = true;
        this.targetVector = new Vector3(0f, 0.2f, 0.5f);
        this.mytransform.position = this.targetVector - ((Vector3) (Vector3.up * 2f));
        if (this.c_plane != null)
        {
            UnityEngine.Object.Destroy(this.c_plane);
        }
        this.creat_delay = 0f;
        this.efon = false;
    }

    private void Update()
    {
        if (this.creat_delay > 3f)
        {
            if (this.creatrender != null)
            {
                this.creatrender.enabled = true;
            }
            this.ef_shuffle.gameObject.active = false;
            this.efon = true;
        }
        else if (!this.efon)
        {
            this.creat_delay += Time.deltaTime;
        }
        this.mytransform.position = Vector3.MoveTowards(this.mytransform.position, this.targetVector, Time.deltaTime * 5f);
    }
}


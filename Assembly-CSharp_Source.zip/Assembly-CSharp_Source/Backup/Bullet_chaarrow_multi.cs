using System;
using UnityEngine;

public class Bullet_chaarrow_multi : MonoBehaviour
{
    private float finish_delay;
    private Transform mytransform;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void Start()
    {
    }

    private void Update()
    {
        if (this.finish_delay > 0.2f)
        {
            base.gameObject.active = false;
            this.finish_delay = 0f;
            this.mytransform.localScale = (Vector3) (Vector3.one * 0.1f);
        }
        else
        {
            this.finish_delay += Time.deltaTime;
            this.mytransform.localScale += (Vector3) ((4f * Vector3.one) * Time.deltaTime);
            this.mytransform.position += (Vector3) ((4f * base.transform.forward) * Time.deltaTime);
        }
    }
}


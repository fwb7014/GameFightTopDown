using System;
using UnityEngine;

public class Txt_result : MonoBehaviour
{
    private float destroydelay;
    private Transform mytransform;
    private Vector3 originpos;
    private Vector3 originscale;
    private Mesh thismesh;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.thismesh = base.GetComponent<MeshFilter>().mesh;
        this.originpos = this.mytransform.position;
        this.originscale = this.mytransform.localScale;
    }

    private void OnEnable()
    {
        this.destroydelay = 0f;
        this.mytransform.position = this.originpos;
        this.mytransform.localScale = (Vector3) (Vector3.one * 3f);
    }

    private void Start()
    {
    }

    private void Update()
    {
        this.mytransform.localScale = Vector3.Lerp(this.mytransform.localScale, this.originscale, Time.deltaTime * 12f);
        if (this.destroydelay < 2f)
        {
            this.destroydelay += Time.deltaTime;
        }
        else
        {
            base.gameObject.active = false;
            this.mytransform.position = (Vector3) (Vector3.one * 5f);
            this.destroydelay = 0f;
        }
    }

    public void UvMove(Vector2 _startUV)
    {
        this.thismesh.uv = new Vector2[] { _startUV + (Vector2.up * 0.25f), (_startUV + Vector2.right) + (Vector2.up * 0.25f), _startUV, _startUV + Vector2.right };
    }
}


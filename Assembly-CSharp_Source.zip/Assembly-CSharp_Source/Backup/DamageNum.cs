using System;
using UnityEngine;

public class DamageNum : MonoBehaviour
{
    private Vector3 dir;
    private float finishdelay = 1f;
    private Transform mytransform;
    private TextMesh text_mesh;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.text_mesh = base.GetComponent<TextMesh>();
        base.gameObject.active = false;
    }

    public void TextOn(Vector3 _pos, short _damage, Vector3 _dir)
    {
        this.text_mesh.text = _damage.ToString();
        this.mytransform.position = _pos + ((Vector3) (Vector3.up * 0.2f));
        this.dir = _dir;
        base.gameObject.active = true;
    }

    private void Update()
    {
        this.finishdelay -= Time.deltaTime * 2f;
        if (this.finishdelay < 0f)
        {
            this.finishdelay = 1f;
            base.gameObject.active = false;
        }
        this.mytransform.position += (Vector3) ((((Vector3.up + this.dir) * this.finishdelay) * Time.deltaTime) * 0.3f);
    }
}


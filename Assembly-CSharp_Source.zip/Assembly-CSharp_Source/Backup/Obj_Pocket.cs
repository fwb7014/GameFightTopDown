using System;
using UnityEngine;

public class Obj_Pocket : MonoBehaviour
{
    private Transform hand;
    private Transform mytransform;
    private bool pick;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mytransform.localScale = Vector3.zero;
    }

    public void PickPocket()
    {
        this.hand = GameObject.Find("Bip01 L Finger0").transform;
        this.pick = true;
        this.mytransform.position = this.hand.position;
        this.mytransform.parent = this.hand;
    }

    private void Update()
    {
        if (this.pick)
        {
            this.mytransform.localScale = Vector3.Lerp(this.mytransform.localScale, (Vector3) (Vector3.one * 0.6f), Time.deltaTime * 7f);
            this.mytransform.up = Vector3.up;
        }
    }
}


using System;
using UnityEngine;

public class DeathHand : MonoBehaviour
{
    private float current_time;
    private bool dash;
    private float finish_delay = 1.2f;
    private float fogdelay = 0.2f;
    private Collider mycollider;
    private Transform myparent;
    private Renderer myrenderer;
    private Transform mytransform;
    private Transform pt;
    private Cha_Control script_cha;
    private float start_delay = 0.4f;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
        this.myrenderer = base.renderer;
        this.mycollider.enabled = false;
    }

    private void Start()
    {
        this.myrenderer.enabled = false;
        this.pt = this.mytransform.GetChild(0);
        this.myparent = this.mytransform.parent;
        this.script_cha = this.myparent.GetComponent<Cha_Control>();
    }

    private void Update()
    {
        this.current_time += Time.deltaTime;
        if (this.current_time > this.finish_delay)
        {
            base.gameObject.active = false;
            this.current_time = 0f;
            this.mycollider.enabled = false;
            this.myrenderer.enabled = false;
            this.dash = false;
            this.pt.particleEmitter.emit = false;
        }
        else if (this.current_time > this.start_delay)
        {
            if (!this.dash)
            {
                this.dash = true;
                this.myparent.rigidbody.AddForce((Vector3) (this.myparent.forward * 200f));
                this.myrenderer.enabled = true;
                this.mycollider.enabled = true;
                this.pt.particleEmitter.emit = true;
            }
            if (this.fogdelay >= 0.2f)
            {
                this.script_cha.FogOn(1);
                this.fogdelay = 0f;
            }
            else
            {
                this.fogdelay += Time.deltaTime;
            }
        }
    }
}


using System;
using UnityEngine;

public class Inventory_Gem : MonoBehaviour
{
    public GUISkin basicSkin;
    public Texture2D bg_material;
    public GUIStyle bt_yesno;
    private int cur_stage_index;
    private short getitem;
    private int getitem_grade;
    private Texture2D getitem_tex;
    public Texture2D icon_key;
    public Texture2D[] jeweltex = new Texture2D[5];
    private int language;
    private int posX = 0xb0;
    private int posY = 0x5e;
    private UI_result script_ui;

    private void Awake()
    {
        this.language = PlayerPrefs.GetInt("language");
        this.script_ui = GameObject.FindWithTag("ui").GetComponent<UI_result>();
        this.cur_stage_index = Crypto.Load_int_key("cur_stage_index");
    }

    public void GetItem()
    {
        int num = this.script_ui.max_stage_index;
        int num2 = 0;
        if ((this.cur_stage_index == num) && (num == 12))
        {
            num2 = 12;
        }
        else if (num > 12)
        {
            num2 = UnityEngine.Random.Range(0, 13);
        }
        else if (num >= 3)
        {
            num2 = UnityEngine.Random.Range(0, 10);
        }
        if (num2 < 3)
        {
            this.getitem = 2;
            int[] intArray = PlayerPrefsX.GetIntArray("treasure");
            int num3 = UnityEngine.Random.Range(1, 0x19);
            this.getitem_tex = Resources.Load("treasure" + num3.ToString()) as Texture2D;
            intArray[num3 - 1]++;
            PlayerPrefsX.SetIntArray("treasure", intArray);
        }
        else if (num2 < 10)
        {
            this.getitem = 1;
            int[] numArray2 = PlayerPrefsX.GetIntArray("n39");
            int b = UnityEngine.Random.Range(0, 0x271) - (this.cur_stage_index * 5);
            float f = Mathf.Sqrt((float) Mathf.Max(0, b));
            this.getitem_grade = 4 - ((int) Mathf.Sqrt(f));
            this.getitem_tex = this.jeweltex[this.getitem_grade];
            numArray2[this.getitem_grade]++;
            PlayerPrefsX.SetIntArray("n39", numArray2);
            this.script_ui.GetGem();
        }
        else
        {
            this.getitem = 3;
            this.getitem_tex = this.icon_key;
            int num6 = Crypto.Load_int_key("n10") + 1;
            Crypto.Save_int_key("n10", num6);
        }
        this.script_ui.OpenShop();
    }

    private void OnGUI()
    {
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.skin = this.basicSkin;
        GUI.depth = -5;
        if (this.getitem > 0)
        {
            GUI.DrawTexture(Crypto.Rect2((float) this.posX, (float) this.posY, 128f, 128f), this.bg_material);
            GUI.DrawTexture(Crypto.Rect2((float) (this.posX + 0x30), (float) (this.posY + 0x2e), 32f, 32f), this.getitem_tex);
            if (GUI.Button(Crypto.Rect2((float) (this.posX + 0x20), (float) (this.posY + 0x5c), 64f, 32f), Language.intxt[this.language, 0x2d], this.bt_yesno))
            {
                this.script_ui.GoNext();
                this.getitem = 0;
            }
            if (this.getitem == 1)
            {
                GUI.Label(Crypto.Rect2((float) this.posX, (float) (this.posY + 10), 128f, 14f), Language.intxt[this.language, 0xfd] + "  LV " + (this.getitem_grade + 1), "txt12_w");
            }
            else if (this.getitem == 2)
            {
                GUI.Label(Crypto.Rect2((float) this.posX, (float) (this.posY + 10), 128f, 14f), Language.intxt[this.language, 0xfe], "txt12_w");
            }
            else if (this.getitem == 3)
            {
                GUI.Label(Crypto.Rect2((float) this.posX, (float) (this.posY + 10), 128f, 14f), Language.intxt[this.language, 0xff], "txt12_w");
            }
        }
    }
}


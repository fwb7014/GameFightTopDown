using System;
using UnityEngine;

public class Cutin01 : MonoBehaviour
{
    public Transform bg_black;
    private bool cinematicMode;
    private float endlerp;
    private Transform mytransform;
    private Vector3 originpos = Vector3.zero;
    private Vector3 originscale = Vector3.zero;
    private float prevtimescale = 1f;
    private Cam_Move script_cam;
    private Cha_Control script_cha;
    private float startlerp;
    private float starttime;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    public void CutinOn(Vector3 startpos, Vector3 finishpos, Vector3 _originscale, float timescale, float a, float b, bool cinema)
    {
        this.originscale = _originscale;
        base.renderer.enabled = true;
        this.prevtimescale = Time.timeScale;
        this.starttime = Time.realtimeSinceStartup;
        this.mytransform.position = startpos;
        this.mytransform.localScale = (Vector3) (this.originscale * 10f);
        Time.timeScale = timescale;
        this.originpos = finishpos;
        this.startlerp = a;
        this.endlerp = b;
        this.cinematicMode = cinema;
        this.bg_black.gameObject.active = true;
    }

    private void Start()
    {
        this.script_cha = GameObject.FindWithTag("Player").GetComponent<Cha_Control>();
        this.script_cam = Camera.main.GetComponent<Cam_Move>();
        base.renderer.enabled = false;
        base.gameObject.active = false;
    }

    private void Update()
    {
        if (base.renderer.enabled)
        {
            if (this.cinematicMode)
            {
                this.script_cha.StopControl();
                this.cinematicMode = false;
            }
            if (this.starttime != 0f)
            {
                if ((Time.realtimeSinceStartup - this.starttime) < this.startlerp)
                {
                    this.mytransform.position = Vector3.Lerp(this.mytransform.position, this.originpos, Time.deltaTime * 30f);
                    this.mytransform.localScale = Vector3.Lerp(this.mytransform.localScale, this.originscale, Time.deltaTime * 50f);
                }
                else if ((Time.realtimeSinceStartup - this.starttime) < this.endlerp)
                {
                    Time.timeScale = this.prevtimescale;
                    this.mytransform.localScale = Vector3.Lerp(this.mytransform.localScale, (Vector3) (this.originscale * 10f), Time.deltaTime * 5.6f);
                }
                else
                {
                    Time.timeScale = 1f;
                    this.script_cam.ResetCam();
                    this.script_cha.StartControl();
                    base.renderer.enabled = false;
                    this.starttime = 0f;
                    this.mytransform.localScale = (Vector3) (this.originscale * 10f);
                    this.mytransform.position = new Vector3(-2f, 1f, 0f);
                    base.gameObject.active = false;
                    this.bg_black.gameObject.active = false;
                }
            }
        }
    }
}


using System;
using UnityEngine;

public class Bullet_sword : MonoBehaviour
{
    private Transform mytransform;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void Update()
    {
        this.mytransform.position += (Vector3) ((Vector3.up * Time.deltaTime) * 0.1f);
    }
}


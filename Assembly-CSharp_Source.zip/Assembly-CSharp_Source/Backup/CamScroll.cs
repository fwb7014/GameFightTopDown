using System;
using UnityEngine;

public class CamScroll : MonoBehaviour
{
    private float camsize = 1f;
    private bool camsizechange;
    private float current_camsize = 1f;
    private Vector3 currentCampos;
    public bool drag;
    private bool isevent;
    private int movecamspeed = 7;
    private float movedelay;
    private Transform mytransform;
    private float prevMposX;
    private float prevMposY;
    private bool scrollOn;
    private bool stopmove;
    private Transform target;
    private Vector3 targetpos;
    private float tempx;
    private float tempy;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    public void DisableMove()
    {
        this.stopmove = true;
    }

    public void EnableMove()
    {
        this.stopmove = false;
    }

    public void MoveTarget(Transform _target, bool _isevent)
    {
        this.target = _target;
        this.targetpos = _target.position;
        this.targetpos[0] = Mathf.Clamp(this.targetpos[0], -1.7f, 1.7f);
        this.targetpos[1] = Mathf.Clamp(this.targetpos[1], -2.3f, 2.3f);
        this.targetpos[2] = 1f;
        this.movedelay = 0.6f;
        this.tempx = 0f;
        this.tempy = 0f;
        PlayerPrefsX.SetVector3("uiCampos", this.targetpos);
        this.isevent = _isevent;
        this.movecamspeed = 7;
    }

    public void MoveTargetCancel()
    {
        this.movedelay = 0f;
        this.isevent = false;
    }

    private void Start()
    {
        base.camera.projectionMatrix = Matrix4x4.Ortho(-1.8f, 1.8f, -1.2f, 1.2f, 0.3f, 5f);
        this.mytransform.position = PlayerPrefsX.GetVector3("uiCampos");
    }

    private void Update()
    {
        if (this.movedelay > 0f)
        {
            this.movedelay -= Time.deltaTime;
            this.mytransform.position = Vector3.Lerp(this.mytransform.position, this.targetpos, Time.deltaTime * this.movecamspeed);
            this.currentCampos = this.mytransform.position;
            this.scrollOn = false;
            if (this.isevent && (this.movedelay <= 0f))
            {
                this.target.GetComponent<Icon_Stage>().IconDown();
            }
        }
        else
        {
            if (this.stopmove)
            {
                return;
            }
            if (Input.GetMouseButtonDown(0))
            {
                this.drag = false;
                this.scrollOn = true;
                this.prevMposX = Input.mousePosition.x;
                this.prevMposY = Input.mousePosition.y;
                this.currentCampos = this.mytransform.position;
            }
            else if (Input.GetMouseButtonUp(0))
            {
                this.scrollOn = false;
            }
        }
        if (this.scrollOn)
        {
            this.tempx = (0.006f * (Input.mousePosition.x - this.prevMposX)) * (480f / ((float) Screen.width));
            this.tempy = (-0.006f * (Input.mousePosition.y - this.prevMposY)) * (320f / ((float) Screen.height));
            if ((Mathf.Abs(this.tempx) > 0.06f) || (Mathf.Abs(this.tempy) > 0.06f))
            {
                this.drag = true;
            }
            this.tempx += this.currentCampos.x;
            this.tempy += this.currentCampos.y;
            this.tempx = Mathf.Clamp(this.tempx, -1.7f, 1.7f);
            this.tempy = Mathf.Clamp(this.tempy, -2.3f, 2.3f);
            this.mytransform.position = new Vector3(this.tempx, this.tempy, 1f);
        }
        if (this.camsizechange)
        {
            if (this.current_camsize == this.camsize)
            {
                this.camsizechange = false;
            }
            this.current_camsize = Mathf.MoveTowards(this.current_camsize, this.camsize, Time.deltaTime * 3f);
            base.camera.projectionMatrix = Matrix4x4.Ortho(-1.5f * this.current_camsize, 1.5f * this.current_camsize, -this.current_camsize, this.current_camsize, 0.1f, 5f);
        }
    }

    public void Zoom(bool _zoomout, Vector3 _pos)
    {
        this.drag = false;
        this.camsizechange = true;
        this.isevent = false;
        if (_zoomout)
        {
            this.stopmove = true;
            this.camsize = 2.3f;
            this.targetpos = new Vector3(0f, -0.05f, 1f);
            this.movedelay = 0.6f;
            this.movecamspeed = 7;
        }
        else
        {
            this.stopmove = false;
            this.camsize = 1.2f;
            this.targetpos = _pos;
            this.targetpos[0] = Mathf.Clamp(this.targetpos[0], -1.7f, 1.7f);
            this.targetpos[1] = Mathf.Clamp(this.targetpos[1], -2.3f, 2.3f);
            this.targetpos[2] = 1f;
            this.movedelay = 0.8f;
            this.movecamspeed = 3;
        }
    }
}


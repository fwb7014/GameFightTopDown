using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class Cha_Control : MonoBehaviour
{
    private int[] accessory = new int[6];
    private Vector3 arrowpos;
    public int atk;
    private float atkspd;
    private float atkspd_origin;
    public AnimationClip[] attack_blade = new AnimationClip[13];
    public AnimationClip[] attack_bow = new AnimationClip[13];
    public AnimationClip[] attack_dual = new AnimationClip[13];
    private int attack_eagle;
    private int attack_horse;
    public AnimationClip[] attack_magic = new AnimationClip[13];
    public bool attack_rising;
    public AnimationClip[] attack_spear = new AnimationClip[13];
    public AnimationClip[] attack_staff = new AnimationClip[13];
    private float attackDot;
    private int attackkind_factor;
    private Vector3 attackVector;
    private int autorate;
    private int battlestyle;
    private Transform bip01;
    public AudioClip boom;
    private Transform[] c_stepfog = new Transform[4];
    private Transform[] c_thrustfog = new Transform[4];
    private RaycastHit casthit;
    private int cha_hp;
    private int cha_maxhp;
    public int chamovestat;
    private bool change_cha;
    private Vector3 chapos;
    private AnimationState clone_ride;
    private Vector3 collider_center;
    private Vector3 collider_dodge;
    private Vector3 collider_fly;
    private Vector3 collider_horse;
    private float collider_radius;
    private float combotime;
    private float commendDelay;
    public int critical;
    private int cur_difficulty;
    private int cur_weapon;
    private int current_costume;
    private int currentPet;
    private Vector3 currentTouchPos;
    private int curruntattack;
    private int damage;
    public int defence;
    private float delay_invincibility;
    private Vector3 directionVector;
    private float dubbleclick = 1f;
    public Transform dummy_general;
    public Transform dummy_weapon;
    private bool dunenter;
    public Transform ef_arrow_multy;
    public Transform ef_arrow_single;
    public Transform ef_block;
    public Transform ef_blockbreak;
    public Transform ef_blur;
    public Transform ef_firesplash;
    public Transform ef_linehit;
    public Transform ef_punch;
    public Transform ef_riseattack;
    public Transform ef_rotfog;
    public Transform ef_splash;
    public Transform ef_stepfog;
    public Transform ef_super;
    private Transform ef_swing1;
    private Transform ef_swing2;
    private Transform ef_swingex1;
    private Transform ef_swingex2;
    public Transform ef_swordExtreme;
    public Transform ef_thrustfog;
    public int endurance;
    public int evasion;
    public int exattack;
    public float exp;
    private float expboost = 1f;
    private bool exstart;
    private bool extremeStageHeal;
    private float fogdelay = 0.15f;
    public AudioClip footstep;
    public short g_atk;
    private float g_atkspd;
    private short g_def;
    public int g_hp;
    private short g_maxhp;
    private AudioClip[] g_skillyell = new AudioClip[2];
    private AudioClip[] g_yell = new AudioClip[2];
    private bool general;
    private short general_kind;
    private short general_weapon;
    private bool grab_ing;
    private AnimationState grabfinish;
    private float grabheal_factor = 0.1f;
    private bool grabstart;
    private int guard_break;
    public Camera guicam;
    public Transform guide_circle;
    private bool helper;
    public int hitrate;
    private int hp;
    private int hpplus;
    private AnimationState impact;
    private bool infinitymode;
    private bool isinvincibility;
    private bool isplaycha;
    private float itemboolst = 1f;
    private bool keydown;
    public int level;
    public bool life = true;
    public float limit_x = 2.65f;
    public float limit_y_b = -2.6f;
    public float limit_y_f = 2.5f;
    private float longdash;
    public Transform magicspear;
    private float magnitude_attackdir;
    private float magnitude_temp;
    private Collider mapcollider;
    public int maxatk;
    private int maxhp;
    public float maxsp;
    public int minatk;
    private float movespeed;
    private float movespeed_origin = 0.48f;
    private Animation myanimation;
    private AudioSource myaudio;
    private SphereCollider mycollider;
    private Rigidbody myrigidbody;
    private Transform mytransform;
    private bool noeagle;
    private int nowstep;
    private int nowthrust;
    private int origin_defence;
    private int origin_endurance;
    private int origin_hitrate;
    private int origin_maxattack;
    private int origin_minattack;
    public Transform pet_eagle;
    public Transform pet_horse;
    private bool pet_ing;
    private float pressdelay;
    private Vector3 prevPoint;
    public Transform pt_heal;
    public Transform pt_rising;
    private Ray ray;
    public int resist;
    private float restrictArea = 100f;
    public bool rideon;
    private Quaternion rotate;
    private bool savetouchposition;
    public Transform screen_effect;
    private Cam_Move script_cam;
    private Pet_eagle script_eagle;
    private Ef_twirl script_getitem;
    private Pet_horse script_horse;
    private Bullet_punch script_punch;
    private Ef_rotfog script_rotfog;
    private Cha_Skill script_skill;
    private SoundEf_slash script_sound;
    private Spawn script_spawn;
    private Ef_splash script_splash;
    private Ef_swing1 script_swing;
    private Ef_swing1 script_swing_sub;
    private Ef_swing1 script_swingex1;
    private Ef_swing1 script_swingex2;
    private Ef_swing1 script_thrust;
    private Txt_effect script_txtef;
    private UI_Ingame script_ui;
    private UI_Ingame_story script_ui_story;
    private Cha_Weapon script_weapon;
    private int selequip_grade;
    private int selequip_hp;
    private int selequip_special;
    public Transform shadow;
    private bool skill_ing;
    private float skillboost = 1f;
    private bool skillicondown;
    public AudioClip[] skillyell = new AudioClip[2];
    public AudioClip snd_dodge;
    public AudioClip snd_getitem;
    public AudioClip snd_riseattack;
    public AudioClip snd_skillstart;
    public AudioClip snd_swing;
    public float sp;
    private int special_amount;
    private int special_kind = -2;
    private int special_kind_origin = -2;
    private float speedfactor = 7f;
    private float spplus_amount;
    private bool story_scene;
    private bool storyrun;
    private short superMode;
    private float target_invincibility;
    private Transform targetenemy;
    private Vector3 targetpos = Vector3.zero;
    private AnimationState temp_attack;
    private AnimationState temp_fly;
    private AnimationState tempani;
    private Vector3 tempdir;
    public Transform txtef;
    public int vitality;
    public int weapon_kind;
    private float weaponweight = 2f;
    public AudioClip[] yell = new AudioClip[3];

    public void Arrow_shoot()
    {
        this.ef_arrow_multy.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.05f));
        this.ef_arrow_multy.rotation = this.mytransform.rotation;
        this.ef_arrow_multy.gameObject.active = true;
    }

    public void Attack_arrow(Vector3 monpos)
    {
        if (this.chamovestat == 0xcb)
        {
            this.mycollider.enabled = false;
            this.RndAtk(false);
            this.chamovestat = 0xc0;
            this.directionVector = monpos - this.mytransform.position;
            this.directionVector = (Vector3) ((Vector3.right * this.directionVector.x) + (Vector3.forward * this.directionVector.z));
            this.myanimation.Play("eagle_shoot");
            this.mytransform.rotation = Quaternion.LookRotation(this.directionVector);
            this.arrowpos = (Vector3) ((this.mytransform.position + (Vector3.up * 0.24f)) + (this.mytransform.forward * 0.1f));
            this.ef_arrow_single.position = this.arrowpos;
            this.ef_arrow_single.rotation = Quaternion.LookRotation((monpos - this.arrowpos) + ((Vector3) (Vector3.up * 0.08f)));
            this.ef_arrow_single.gameObject.active = true;
        }
    }

    public void Attack_spear(Vector3 monpos)
    {
        if (this.chamovestat == 0xd4)
        {
            this.mycollider.enabled = false;
            this.RndAtk(true);
            this.attackVector = monpos - this.mytransform.position;
            this.attackVector[1] = 0f;
            this.attackVector = Vector3.Normalize(this.attackVector);
            this.myrigidbody.AddForce((Vector3) (this.attackVector * 40f));
            if (this.combotime > 0f)
            {
                this.curruntattack = (this.curruntattack + 1) % 2;
            }
            else if (this.combotime <= 0f)
            {
                this.curruntattack = 0;
            }
            int index = UnityEngine.Random.Range(0, 5);
            if (index < 2)
            {
                this.myaudio.clip = this.yell[index];
                this.myaudio.Play();
            }
            switch (this.curruntattack)
            {
                case 0:
                    this.chamovestat = 0xd6;
                    this.myanimation.Play("attack_ride1");
                    this.ef_swingex1.localRotation = Quaternion.Euler(0f, 0f, 160f);
                    this.ef_swingex1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.17f));
                    this.ef_swingex1.localScale = (Vector3) (Vector3.one * 2.8f);
                    this.script_swingex1.SwingOn(0.18f, 2, 2, 20, 1, 0);
                    break;

                case 1:
                    this.chamovestat = 0xd6;
                    this.myanimation.Play("attack_ride2");
                    this.ef_swingex1.localRotation = Quaternion.Euler(0f, 0f, 20f);
                    this.ef_swingex1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.17f));
                    this.ef_swingex1.localScale = (Vector3) (Vector3.one * 3f);
                    this.script_swingex1.SwingOn(0.18f, 2, 2, 20, 1, 0);
                    break;
            }
        }
    }

    public void AttackOn(Vector3 monpos)
    {
        this.attack_rising = false;
        this.attackVector = monpos - this.mytransform.position;
        this.attackVector[1] = 0f;
        this.magnitude_attackdir = this.attackVector.magnitude;
        this.attackVector = (Vector3) (this.attackVector / this.magnitude_attackdir);
        this.attackDot = Vector3.Dot(this.attackVector, this.directionVector);
        if (this.magnitude_attackdir > 0.2f)
        {
            if (this.attackDot < 0.5f)
            {
                this.chamovestat = 0x11;
                this.mycollider.enabled = true;
                return;
            }
        }
        else if (this.attackDot < -0.2f)
        {
            this.chamovestat = 0x11;
            this.mycollider.enabled = true;
            return;
        }
        this.RndAtk(true);
        this.speedfactor = 5.2f;
        if (this.chamovestat == 3)
        {
            this.curruntattack = -1;
            this.Invincibility(1f);
        }
        else if (this.combotime > 0f)
        {
            this.curruntattack = (((this.curruntattack + 1) - this.attackkind_factor) % 5) + this.attackkind_factor;
        }
        else if (this.combotime <= 0f)
        {
            this.curruntattack = this.attackkind_factor;
        }
        int index = UnityEngine.Random.Range(0, 5);
        if (index < 2)
        {
            if (!this.general)
            {
                this.myaudio.clip = this.yell[index];
            }
            else
            {
                this.myaudio.clip = this.g_yell[index];
            }
            this.myaudio.Play();
        }
        this.mytransform.rotation = Quaternion.LookRotation(this.attackVector);
        this.FogOn(0);
        switch ((this.curruntattack + 1))
        {
            case 0:
                this.chamovestat = 0x13;
                this.pressdelay = 0f;
                this.myanimation.Play("dash_attack");
                this.temp_attack = this.myanimation.PlayQueued("1t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.ef_swingex1.localScale = (Vector3) (Vector3.one * 2.4f);
                this.ef_swingex1.localRotation = Quaternion.Euler(0f, 0f, 180f);
                this.ef_swingex1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.055f));
                this.script_swingex1.SwingOn(0.48f, 2, 2, 20, 1, 120);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * 50f));
                this.curruntattack = this.attackkind_factor;
                this.script_cam.ZoomIn(3, 0x16, 0.2f);
                break;

            case 1:
                this.chamovestat = 11;
                this.myanimation.Play("attack1");
                this.temp_attack = this.myanimation.PlayQueued("1t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.ef_swing1.localRotation = Quaternion.Euler(0f, 0f, 180f);
                this.ef_swing1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.055f));
                this.script_swing.SwingOn(0.15f - this.atkspd, 2, 2, 20, 1, 0);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * 110f));
                break;

            case 2:
                this.attack_rising = true;
                this.chamovestat = 11;
                this.myanimation.Play("attack2");
                this.temp_attack = this.myanimation.PlayQueued("2t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.ef_swing1.localRotation = Quaternion.Euler(0f, 0f, 40f);
                this.ef_swing1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.12f));
                this.script_swing.SwingOn(0.15f - this.atkspd, 2, 2, 20, 1, 0);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * 110f));
                break;

            case 3:
                this.chamovestat = 11;
                this.myanimation.Play("attack3");
                this.temp_attack = this.myanimation.PlayQueued("3t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.ef_swing1.localRotation = Quaternion.Euler(0f, 0f, 330f);
                this.ef_swing1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.1f));
                this.script_swing.SwingOn(0.2f - this.atkspd, 2, 2, 20, 1, 0);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * 110f));
                break;

            case 4:
                this.chamovestat = 12;
                this.myanimation.Play("attack4");
                this.temp_attack = this.myanimation.PlayQueued("4t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.script_thrust.SwingOn(0.28f - this.atkspd, 4, 1, 20, 1, 100);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * 30f));
                break;

            case 5:
                this.attack_rising = true;
                this.chamovestat = 11;
                this.myanimation.Play("attack5");
                this.ef_swing1.localRotation = Quaternion.identity;
                this.ef_swing1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.055f));
                this.script_swing.SwingOn(0.21f - this.atkspd, 2, 2, 20, 1, 150);
                break;

            case 11:
                this.chamovestat = 11;
                this.myanimation.Play("attack1");
                this.temp_attack = this.myanimation.PlayQueued("1t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.ef_swing1.localRotation = Quaternion.Euler(0f, 0f, 180f);
                this.ef_swing1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.06f));
                this.script_swing.SwingOn(0.15f - this.atkspd, 2, 2, 20, 1, 0);
                this.ef_swing2.localRotation = Quaternion.Euler(0f, 0f, -40f);
                this.ef_swing2.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.08f));
                this.script_swing_sub.SwingOn(0.4f - this.atkspd, 2, 2, 20, 1, 100);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * 120f));
                break;

            case 12:
                this.chamovestat = 11;
                this.myanimation.Play("attack2");
                this.temp_attack = this.myanimation.PlayQueued("2t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.ef_swing1.localRotation = Quaternion.Euler(0f, 0f, 340f);
                this.ef_swing1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.06f));
                this.script_swing.SwingOn(0.2f - this.atkspd, 2, 2, 20, 1, 0);
                this.ef_swing2.localRotation = Quaternion.Euler(0f, 0f, 10f);
                this.ef_swing2.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.06f));
                this.script_swing_sub.SwingOn(0.4f - this.atkspd, 2, 2, 20, 1, 100);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * 120f));
                break;

            case 13:
                this.attack_rising = true;
                this.chamovestat = 11;
                this.myanimation.Play("attack3");
                this.temp_attack = this.myanimation.PlayQueued("3t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.ef_swing1.localRotation = Quaternion.Euler(0f, 0f, 90f);
                this.ef_swing1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.14f));
                this.script_swing.SwingOn(0.15f - this.atkspd, 2, 2, 20, 1, 140);
                this.ef_swing2.localRotation = Quaternion.Euler(0f, 0f, 90f);
                this.ef_swing2.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.16f));
                this.script_swing_sub.SwingOn(0.31f - this.atkspd, 2, 2, 20, 1, 80);
                break;

            case 14:
                this.chamovestat = 11;
                this.myanimation.Play("attack4");
                this.temp_attack = this.myanimation.PlayQueued("4t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.ef_swing1.localRotation = Quaternion.Euler(-20f, 0f, -90f);
                this.ef_swing1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.06f));
                this.script_swing.SwingOn(0.11f - this.atkspd, 2, 2, 20, 1, 0);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * 150f));
                break;

            case 15:
                this.attack_rising = true;
                this.chamovestat = 11;
                this.myanimation.Play("attack5");
                this.ef_swing1.localRotation = Quaternion.Euler(0f, 0f, 170f);
                this.ef_swing1.position = (Vector3) ((this.mytransform.position - (this.mytransform.right * 0.07f)) + (Vector3.up * 0.06f));
                this.script_swing.SwingOn(0.4f - this.atkspd, 2, 2, 20, 1, 180);
                this.ef_swing2.localRotation = Quaternion.Euler(0f, 0f, 10f);
                this.ef_swing2.position = (Vector3) ((this.mytransform.position + (this.mytransform.right * 0.07f)) + (Vector3.up * 0.055f));
                this.script_swing_sub.SwingOn(0.4f - this.atkspd, 2, 2, 20, 1, 0);
                break;

            case 0x15:
                this.attack_rising = true;
                this.chamovestat = 11;
                this.myanimation.Play("attack1");
                this.temp_attack = this.myanimation.PlayQueued("1t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.ef_swing1.localRotation = Quaternion.identity;
                this.ef_swing1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.06f));
                this.script_swing.SwingOn(0.15f - this.atkspd, 2, 2, 20, 1, 0);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * 160f));
                break;

            case 0x16:
                this.attack_rising = true;
                this.chamovestat = 11;
                this.myanimation.Play("attack2");
                this.temp_attack = this.myanimation.PlayQueued("2t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.ef_swing1.localRotation = Quaternion.Euler(0f, 0f, -90f);
                this.ef_swing1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.1f));
                this.script_swing.SwingOn(0.42f - this.atkspd, 2, 2, 20, 1, 0);
                this.script_splash.SplashOn(true, 0.1f, 0.5f - this.atkspd);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * 130f));
                break;

            case 0x17:
                this.chamovestat = 12;
                this.myanimation.Play("attack3");
                this.temp_attack = this.myanimation.PlayQueued("3t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.ef_swing1.localRotation = Quaternion.Euler(0f, 0f, 180f);
                this.ef_swing1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.1f));
                this.script_swing.SwingOn(0.5f - this.atkspd, 2, 2, 20, 1, 90);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * 90f));
                break;

            case 0x18:
                this.attack_rising = true;
                this.chamovestat = 11;
                this.myanimation.Play("attack4");
                this.temp_attack = this.myanimation.PlayQueued("4t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.ef_swingex1.localRotation = Quaternion.Euler(0f, 0f, 160f);
                this.ef_swingex1.localScale = (Vector3) (Vector3.one * 2.4f);
                this.ef_swingex1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.1f));
                this.script_swingex1.SwingOn(0.36f - this.atkspd, 2, 2, 20, 1, 120);
                break;

            case 0x19:
                this.attack_rising = true;
                this.chamovestat = 11;
                this.myanimation.Play("attack5");
                this.ef_swing1.localRotation = Quaternion.Euler(0f, 0f, -20f);
                this.ef_swing1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.1f));
                this.script_swing.SwingOn(0.4f - this.atkspd, 2, 2, 20, 1, 200);
                break;

            case 0x1f:
                this.chamovestat = 11;
                this.myanimation.Play("attack1");
                this.temp_attack = this.myanimation.PlayQueued("1t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                base.Invoke("Arrow_shoot", 0.3f - this.atkspd);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * -30f));
                break;

            case 0x20:
                this.chamovestat = 11;
                this.myanimation.Play("attack2");
                this.temp_attack = this.myanimation.PlayQueued("2t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                base.Invoke("Arrow_shoot", 0.7f - this.atkspd);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * -30f));
                break;

            case 0x21:
                this.attack_rising = true;
                this.chamovestat = 12;
                this.myanimation.Play("attack3");
                this.temp_attack = this.myanimation.PlayQueued("3t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                base.Invoke("Arrow_shoot", 0.8f - this.atkspd);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * -30f));
                break;

            case 0x22:
                this.attack_rising = true;
                this.chamovestat = 11;
                this.myanimation.Play("attack4");
                this.temp_attack = this.myanimation.PlayQueued("4t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                base.Invoke("Arrow_shoot", 0.8f - this.atkspd);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * -30f));
                break;

            case 0x23:
                this.attack_rising = true;
                this.chamovestat = 11;
                this.myanimation.Play("attack5");
                base.Invoke("Arrow_shoot", 0.8f - this.atkspd);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * -30f));
                break;

            case 0x29:
                this.chamovestat = 11;
                this.myanimation.Play("attack1");
                this.temp_attack = this.myanimation.PlayQueued("1t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.script_thrust.SwingOn(0.1f - this.atkspd, 4, 1, 20, 1, 30);
                this.script_punch.PunchShoot(0.3f - this.atkspd, 0, this.targetenemy, 0f, 0f, 0.06f, false);
                break;

            case 0x2a:
                this.attack_rising = true;
                this.chamovestat = 11;
                this.myanimation.Play("attack2");
                this.temp_attack = this.myanimation.PlayQueued("2t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.script_punch.PunchShoot(0.3f - this.atkspd, 40, this.targetenemy, (-3f * this.atkspd) * 15f, 0.8f, 0.1f, false);
                break;

            case 0x2b:
                this.chamovestat = 11;
                this.myanimation.Play("attack3");
                this.temp_attack = this.myanimation.PlayQueued("3t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.script_thrust.SwingOn(0.24f - this.atkspd, 4, 1, 20, 1, 30);
                this.script_punch.PunchShoot(0.1f - this.atkspd, 0, this.targetenemy, 0f, 0f, 0.06f, false);
                break;

            case 0x2c:
                this.attack_rising = true;
                this.chamovestat = 12;
                this.myanimation.Play("attack4");
                this.temp_attack = this.myanimation.PlayQueued("4t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.script_punch.PunchShoot(0.4f - this.atkspd, 0, this.targetenemy, (2f * this.atkspd) * 15f, 0f, 0.15f, true);
                this.Invincibility(1.5f - this.atkspd);
                break;

            case 0x2d:
                this.chamovestat = 11;
                this.myanimation.Play("attack5");
                this.script_thrust.SwingOn(0.2f - this.atkspd, 4, 1, 20, 1, 70);
                this.script_splash.SplashOn(true, 0.05f, 0.6f - this.atkspd);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * 120f));
                break;

            case 0x33:
                this.chamovestat = 11;
                this.myanimation.Play("attack1");
                this.temp_attack = this.myanimation.PlayQueued("1t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                base.Invoke("Magic_shoot", 0.2f - this.atkspd);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * 10f));
                break;

            case 0x34:
                this.chamovestat = 11;
                this.myanimation.Play("attack2");
                this.temp_attack = this.myanimation.PlayQueued("2t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                base.Invoke("Magic_shoot", 0.4f - this.atkspd);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * 10f));
                break;

            case 0x35:
                this.chamovestat = 11;
                this.myanimation.Play("attack3");
                this.temp_attack = this.myanimation.PlayQueued("3t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.4f;
                this.temp_attack.layer = 1;
                base.Invoke("Magic_shoot", 0.3f - this.atkspd);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * 10f));
                break;

            case 0x36:
                this.chamovestat = 12;
                this.myanimation.Play("attack4");
                this.temp_attack = this.myanimation.PlayQueued("4t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.4f;
                this.temp_attack.layer = 1;
                base.Invoke("FireSplash", 0.5f - this.atkspd);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * -60f));
                break;

            case 0x37:
                this.chamovestat = 11;
                this.myanimation.Play("attack5");
                base.Invoke("Magic_shoot", 0.3f - this.atkspd);
                this.myrigidbody.AddForce((Vector3) (this.attackVector * 80f));
                break;
        }
        this.directionVector = this.attackVector;
    }

    public void AttackSpeedUp(float _amount)
    {
        _amount *= 0.02f;
        AnimationState state1 = this.myanimation["attack1"];
        state1.speed += _amount;
        AnimationState state2 = this.myanimation["attack2"];
        state2.speed += _amount;
        AnimationState state3 = this.myanimation["attack3"];
        state3.speed += _amount;
        AnimationState state4 = this.myanimation["attack4"];
        state4.speed += _amount;
        AnimationState state5 = this.myanimation["attack5"];
        state5.speed += _amount;
    }

    public void AttakUp(float _factor)
    {
        this.maxatk = (int) (((this.minatk + this.maxatk) * 0.5f) * _factor);
        this.minatk = this.maxatk - 1;
        this.hitrate = 200;
    }

    private void Awake()
    {
        this.myanimation = base.animation;
        this.mytransform = base.transform;
        this.myrigidbody = base.rigidbody;
        this.mycollider = base.collider as SphereCollider;
        this.myaudio = base.audio;
        this.cur_weapon = Crypto.Load_int_key("n44");
        int num = Crypto.Load_int_key("play_kind");
        if (Application.loadedLevelName == "Story")
        {
            this.story_scene = true;
        }
        if (num == 7)
        {
            this.limit_x = 1.1f;
            this.limit_y_b = -0.34f;
            this.limit_y_f = 9.26f;
        }
        else if (num > 5)
        {
            this.limit_x = 1.1f;
            this.limit_y_b = -0.34f;
            this.limit_y_f = 17f;
        }
        else
        {
            this.limit_x = 2.65f;
            this.limit_y_b = -2.6f;
            this.limit_y_f = 2.5f;
        }
        GameObject.FindWithTag("efs_mon").GetComponent<Monster_efs>().RestrictArea(this.limit_x, this.limit_y_b, this.limit_y_f);
        this.accessory = PlayerPrefsX.GetIntArray("n36");
        this.current_costume = Crypto.Load_int_key("n05");
        this.level = Crypto.Load_int_key("n47");
        this.exp = Crypto.Load_int_key("n11");
        this.maxatk = Crypto.Load_int_key("n31");
        this.skillboost = this.maxatk;
        this.minatk = Crypto.Load_int_key("n04");
        this.atkspd = Crypto.Load_int_key("n35") * 0.01f;
        this.hpplus = Crypto.Load_int_key("n21");
        this.hitrate = Crypto.Load_int_key("n08");
        this.vitality = Crypto.Load_int_key("n26");
        this.evasion = Crypto.Load_int_key("n30");
        this.endurance = Crypto.Load_int_key("n28");
        this.critical = Crypto.Load_int_key("n32");
        this.maxsp = this.vitality;
        this.script_cam = Camera.main.GetComponent<Cam_Move>();
        this.script_spawn = GameObject.FindWithTag("Respawn").GetComponent<Spawn>();
        if (!this.story_scene)
        {
            this.script_ui = GameObject.FindWithTag("ui").GetComponent<UI_Ingame>();
            if (this.accessory[0] > 0)
            {
                this.maxatk = (int) (this.maxatk * 1.1f);
                this.minatk = (int) (this.minatk * 1.1f);
            }
            if (this.accessory[1] > 0)
            {
                this.defence = (int) (this.defence * 1.2f);
            }
            if (this.accessory[2] > 0)
            {
                this.script_ui.SoulStartplus();
            }
            if (this.accessory[4] > 0)
            {
                this.spplus_amount = 1.2f;
            }
            else
            {
                this.spplus_amount = 1f;
            }
            if (this.accessory[5] > 0)
            {
                this.atkspd += 0.02f;
            }
        }
        else
        {
            this.script_ui_story = GameObject.FindWithTag("ui").GetComponent<UI_Ingame_story>();
            this.script_cam.IconHideStop(true);
            this.script_cam.ThisIsStory();
        }
        this.origin_maxattack = this.maxatk;
        this.origin_minattack = this.minatk;
        this.origin_hitrate = this.hitrate;
        this.origin_defence = this.defence;
        this.origin_endurance = this.endurance;
        this.atkspd_origin = this.atkspd;
        this.ef_swing1 = this.mytransform.Find("ef_swing1");
        this.ef_swing2 = this.mytransform.Find("ef_swing2");
        this.ef_swingex1 = this.mytransform.Find("ef_swing_ex1");
        this.ef_swingex2 = this.mytransform.Find("ef_swing_ex2");
        this.mapcollider = GameObject.Find("ground").collider;
        this.script_weapon = this.dummy_weapon.GetComponent<Cha_Weapon>();
        this.script_swing = this.ef_swing1.GetComponent<Ef_swing1>();
        this.script_swing_sub = this.ef_swing2.GetComponent<Ef_swing1>();
        this.script_thrust = this.mytransform.Find("ef_thrust").GetComponent<Ef_swing1>();
        this.script_swingex1 = this.ef_swingex1.GetComponent<Ef_swing1>();
        this.script_swingex2 = this.ef_swingex2.GetComponent<Ef_swing1>();
        this.script_skill = base.GetComponent<Cha_Skill>();
        this.script_punch = this.ef_punch.GetComponent<Bullet_punch>();
        this.script_getitem = this.mytransform.Find("ef_getitem").GetComponent<Ef_twirl>();
        this.script_splash = this.ef_splash.GetComponent<Ef_splash>();
        this.script_rotfog = this.ef_rotfog.GetComponent<Ef_rotfog>();
        this.script_eagle = this.pet_eagle.GetComponent<Pet_eagle>();
        this.script_horse = this.pet_horse.GetComponent<Pet_horse>();
        this.script_sound = GameObject.FindWithTag("sound").GetComponent<SoundEf_slash>();
        this.cha_maxhp = 0x5f + (this.level * 5);
        this.cha_maxhp += this.hpplus;
        this.maxhp = this.cha_maxhp;
        this.hp = this.maxhp;
        this.cha_hp = this.hp;
        this.sp = this.maxsp;
    }

    public void Blocked(Vector3 _monpos)
    {
        if ((this.chamovestat >= 0) && !this.rideon)
        {
            this.chamovestat = -1;
            this.directionVector = Vector3.Normalize(_monpos - this.mytransform.position);
            this.mytransform.rotation = Quaternion.LookRotation(this.directionVector);
            if (this.guard_break > UnityEngine.Random.Range(0, 100))
            {
                this.script_sound.SoundOn(-1);
                this.ef_blockbreak.gameObject.active = true;
                this.ef_blockbreak.position = _monpos + ((Vector3) (Vector3.up * 0.05f));
                this.ef_block.rotation = this.mytransform.rotation;
                this.myrigidbody.AddForce((Vector3) (this.directionVector * -10f));
            }
            else
            {
                this.script_sound.SoundOn(0);
                this.ef_block.gameObject.active = true;
                this.ef_block.position = this.mytransform.position;
                this.ef_block.rotation = this.mytransform.rotation;
                this.CancelAtk();
                this.script_txtef.TxtEfOn(3);
                this.myanimation.Stop();
                this.myanimation.Play("blocked");
                this.myrigidbody.AddForce((Vector3) (this.directionVector * -80f));
            }
        }
    }

    public void CallHorse()
    {
        this.myaudio.PlayOneShot(this.snd_skillstart);
        this.pet_ing = true;
        this.currentPet = 0;
        this.myanimation.Stop();
        this.myanimation.Play("jump_changeweapon");
        this.clone_ride = this.myanimation.PlayQueued("jump_changeweapon_i");
        this.clone_ride.speed = this.myanimation["jump_changeweapon_i"].speed;
        this.clone_ride = this.myanimation.PlayQueued("horse_start");
        this.clone_ride.speed = this.myanimation["horse_start"].speed;
        this.clone_ride = this.myanimation.PlayQueued("horse_chacry");
        this.clone_ride.speed = this.myanimation["horse_chacry"].speed;
        this.clone_ride = this.myanimation.PlayQueued("ride1");
        this.clone_ride.wrapMode = WrapMode.Loop;
        this.clone_ride.speed = 0.05f;
        this.script_horse.SkillOn();
        this.movespeed = 0.8f;
        this.AttakUp(this.attack_horse * 0.01f);
        this.mycollider.radius = this.collider_radius;
        this.mycollider.center = this.collider_horse;
    }

    public void CancelAtk()
    {
        switch (this.battlestyle)
        {
            case 0:
                this.script_swing.SwingOff();
                this.script_thrust.SwingOff();
                break;

            case 1:
                this.script_swing.SwingOff();
                this.script_swing_sub.SwingOff();
                break;

            case 2:
                this.script_swing.SwingOff();
                this.script_splash.SplashOff();
                break;

            case 3:
                base.CancelInvoke("Arrow_shoot");
                break;

            case 4:
                this.script_thrust.SwingOff();
                this.script_punch.PunchOff();
                this.script_splash.SplashOff();
                break;

            case 5:
                this.script_splash.SplashOff();
                base.CancelInvoke("Magic_shoot");
                base.CancelInvoke("FireSplash");
                break;
        }
    }

    public void ChangeCharacter(int _weapon_kind)
    {
        switch (_weapon_kind)
        {
            case 0:
                this.collider_center = new Vector3(0f, 0.05f, 0.17f);
                this.collider_radius = 0.13f;
                for (int i = 0; i < 5; i++)
                {
                    this.myanimation.AddClip(this.attack_blade[i], "attack" + ((i + 1)).ToString());
                }
                this.myanimation.AddClip(this.attack_blade[5], "1t");
                this.myanimation.AddClip(this.attack_blade[6], "2t");
                this.myanimation.AddClip(this.attack_blade[7], "3t");
                this.myanimation.AddClip(this.attack_blade[8], "4t");
                this.myanimation.AddClip(this.attack_blade[9], "run");
                this.myanimation.AddClip(this.attack_blade[10], "walk");
                this.myanimation.AddClip(this.attack_blade[11], "idle");
                this.myanimation.AddClip(this.attack_blade[12], "land_changeweapon");
                this.ef_swing1.localScale = new Vector3(1.6f, 2f, 2f);
                this.attackkind_factor = 0;
                this.myanimation["run"].speed = 0.6f;
                break;

            case 1:
                this.collider_center = new Vector3(0f, 0.05f, 0.16f);
                this.collider_radius = 0.13f;
                for (int j = 0; j < 5; j++)
                {
                    this.myanimation.AddClip(this.attack_dual[j], "attack" + ((j + 1)).ToString());
                }
                this.myanimation.AddClip(this.attack_dual[5], "1t");
                this.myanimation.AddClip(this.attack_dual[6], "2t");
                this.myanimation.AddClip(this.attack_dual[7], "3t");
                this.myanimation.AddClip(this.attack_dual[8], "4t");
                this.myanimation.AddClip(this.attack_dual[9], "run");
                this.myanimation.AddClip(this.attack_dual[10], "walk");
                this.myanimation.AddClip(this.attack_dual[11], "idle");
                this.myanimation.AddClip(this.attack_dual[12], "land_changeweapon");
                this.attackkind_factor = 10;
                this.ef_swing1.localScale = new Vector3(1.3f, 1.7f, 1.7f);
                this.atkspd -= 0.02f;
                this.myanimation["run"].speed = 0.6f;
                break;

            case 2:
                this.collider_center = new Vector3(0f, 0.05f, 0.2f);
                this.collider_radius = 0.15f;
                for (int k = 0; k < 5; k++)
                {
                    this.myanimation.AddClip(this.attack_spear[k], "attack" + ((k + 1)).ToString());
                }
                this.myanimation.AddClip(this.attack_spear[5], "1t");
                this.myanimation.AddClip(this.attack_spear[6], "2t");
                this.myanimation.AddClip(this.attack_spear[7], "3t");
                this.myanimation.AddClip(this.attack_spear[8], "4t");
                this.myanimation.AddClip(this.attack_spear[9], "run");
                this.myanimation.AddClip(this.attack_spear[10], "walk");
                this.myanimation.AddClip(this.attack_spear[11], "idle");
                this.myanimation.AddClip(this.attack_spear[12], "land_changeweapon");
                this.attackkind_factor = 20;
                if (!this.general)
                {
                    this.ef_swing1.localScale = new Vector3(2f, 2.6f, 2.6f);
                    this.myanimation["run"].speed = 0.6f;
                }
                else
                {
                    this.ef_swing1.localScale = new Vector3(1.6f, 2f, 2f);
                    this.myanimation["run"].speed = 0.45f;
                }
                break;

            case 3:
                this.collider_center = new Vector3(0f, 0.05f, 0.25f);
                this.collider_radius = 0.15f;
                for (int m = 0; m < 5; m++)
                {
                    this.myanimation.AddClip(this.attack_bow[m], "attack" + ((m + 1)).ToString());
                }
                this.myanimation.AddClip(this.attack_bow[5], "1t");
                this.myanimation.AddClip(this.attack_bow[6], "2t");
                this.myanimation.AddClip(this.attack_bow[7], "3t");
                this.myanimation.AddClip(this.attack_bow[8], "4t");
                this.myanimation.AddClip(this.attack_bow[9], "run");
                this.myanimation.AddClip(this.attack_bow[10], "walk");
                this.myanimation.AddClip(this.attack_bow[11], "idle");
                this.myanimation.AddClip(this.attack_bow[12], "land_changeweapon");
                this.attackkind_factor = 30;
                this.atkspd += 0.02f;
                this.myanimation["run"].speed = 0.6f;
                break;

            case 4:
                this.collider_center = new Vector3(0f, 0.05f, 0.2f);
                this.collider_radius = 0.15f;
                for (int n = 0; n < 5; n++)
                {
                    this.myanimation.AddClip(this.attack_staff[n], "attack" + ((n + 1)).ToString());
                }
                this.myanimation.AddClip(this.attack_staff[5], "1t");
                this.myanimation.AddClip(this.attack_staff[6], "2t");
                this.myanimation.AddClip(this.attack_staff[7], "3t");
                this.myanimation.AddClip(this.attack_staff[8], "4t");
                this.myanimation.AddClip(this.attack_staff[9], "run");
                this.myanimation.AddClip(this.attack_staff[10], "walk");
                this.myanimation.AddClip(this.attack_staff[11], "idle");
                this.myanimation.AddClip(this.attack_staff[12], "land_changeweapon");
                this.attackkind_factor = 40;
                this.atkspd -= 0.02f;
                this.myanimation["run"].speed = 0.6f;
                break;

            case 5:
                this.collider_center = new Vector3(0f, 0.05f, 0.25f);
                this.collider_radius = 0.15f;
                for (int num6 = 0; num6 < 5; num6++)
                {
                    this.myanimation.AddClip(this.attack_magic[num6], "attack" + ((num6 + 1)).ToString());
                }
                this.myanimation.AddClip(this.attack_magic[5], "1t");
                this.myanimation.AddClip(this.attack_magic[6], "2t");
                this.myanimation.AddClip(this.attack_magic[7], "3t");
                this.myanimation.AddClip(this.attack_magic[8], "4t");
                this.myanimation.AddClip(this.attack_magic[9], "run");
                this.myanimation.AddClip(this.attack_magic[10], "walk");
                this.myanimation.AddClip(this.attack_magic[11], "idle");
                this.myanimation.AddClip(this.attack_magic[12], "land_changeweapon");
                this.ef_swing1.localScale = new Vector3(1.6f, 2f, 2f);
                this.attackkind_factor = 50;
                this.atkspd += 0.04f;
                this.myanimation["run"].speed = 0.6f;
                break;
        }
        this.myanimation["attack1"].speed = 0.24f + this.atkspd;
        this.myanimation["attack2"].speed = 0.24f + this.atkspd;
        this.myanimation["attack3"].speed = 0.24f + this.atkspd;
        this.myanimation["attack4"].speed = 0.24f + this.atkspd;
        this.myanimation["attack5"].speed = 0.24f + this.atkspd;
        this.myanimation["idle"].speed = 0.1f;
        this.myanimation["walk"].speed = 0.9f;
        this.myanimation["land_changeweapon"].speed = 0.2f;
        this.myanimation["idle"].layer = 0;
        this.myanimation["walk"].layer = 0;
        this.myanimation["run"].layer = 0;
        this.myanimation["1t"].layer = 1;
        this.myanimation["2t"].layer = 1;
        this.myanimation["3t"].layer = 1;
        this.myanimation["4t"].layer = 1;
        this.myanimation["attack1"].layer = 1;
        this.myanimation["attack2"].layer = 1;
        this.myanimation["attack3"].layer = 1;
        this.myanimation["attack4"].layer = 1;
        this.myanimation["attack5"].layer = 1;
        this.curruntattack = this.attackkind_factor;
        this.mycollider.radius = this.collider_radius;
        this.mycollider.center = this.collider_center;
        this.battlestyle = _weapon_kind;
    }

    public void ChangeFinish(bool _generalin, bool _jumpatk)
    {
        this.change_cha = false;
        this.chamovestat = 5;
        if (_generalin)
        {
            this.myanimation.Stop();
            if (_jumpatk)
            {
                this.myanimation["1t"].speed = 0.24f;
                this.myanimation.Play("1t");
            }
            else
            {
                this.myanimation.Play("idle");
            }
            this.script_weapon.GeneralWeaponOn(this.general_kind + 1, this.general_weapon);
            base.GetComponent<Cha_Costume>().Costume(this.general_kind + 0x11);
            if (this.general_kind == 1)
            {
                this.mytransform.localScale = (Vector3) (Vector3.one * 1.4f);
            }
            else if (this.general_kind == 3)
            {
                this.mytransform.localScale = (Vector3) (Vector3.one * 1.1f);
            }
        }
    }

    public void Costume_Special()
    {
        int num = PlayerPrefsX.GetIntArray("n45")[this.current_costume];
        this.SetUpArmor(num);
        this.defence += this.selequip_hp;
        this.origin_defence = this.defence;
        switch (this.selequip_special)
        {
            case 1:
                this.itemboolst = (short) ((this.selequip_grade - 1) * 0.1f);
                break;

            case 2:
                this.expboost = 1.2f + ((this.selequip_grade - 1) * 0.1f);
                break;

            case 3:
                this.atkspd_origin += 0.005f + (this.selequip_grade * 0.005f);
                break;
        }
    }

    public void Damaged(Vector3 _damageVector)
    {
        if (!this.isinvincibility && (this.chamovestat <= 50))
        {
            int num = UnityEngine.Random.Range(0, 100);
            this.damage = (int) _damageVector.y;
            _damageVector[1] = 0f;
            if ((this.evasion >= num) && (this.chamovestat >= 0))
            {
                this.chamovestat = -1;
                this.script_txtef.TxtEfOn(1);
                this.Invincibility(1f);
                if (_damageVector != Vector3.zero)
                {
                    this.mytransform.rotation = Quaternion.LookRotation(_damageVector);
                }
                this.myrigidbody.AddForce((Vector3) (_damageVector * 140f));
                this.script_cam.ZoomIn(5, 0x16, 0.2f);
                this.myanimation.Play("evade");
                this.myanimation.PlayQueued("idle");
            }
            else
            {
                this.chamovestat = -1;
                this.screen_effect.gameObject.active = true;
                if (this.cur_difficulty == 2)
                {
                    this.script_ui.Damaged();
                }
                else if (this.general)
                {
                    this.g_hp -= Mathf.Max(1, this.damage - this.defence);
                    this.hp = this.g_hp;
                }
                else
                {
                    this.cha_hp -= Mathf.Max(1, this.damage - this.defence);
                    this.hp = this.cha_hp;
                    if (this.infinitymode)
                    {
                        this.script_ui.Damaged_Extreme();
                    }
                }
                int num2 = UnityEngine.Random.Range(0, 100);
                this.script_cam.ZoomIn(5, 0x16, 0.2f);
                this.myrigidbody.mass = 2f;
                this.combotime = 0f;
                if (this.hp <= 0)
                {
                    if (!this.story_scene)
                    {
                        if (this.general)
                        {
                            this.chamovestat = 12;
                            this.g_hp = 0;
                            this.Spcharge(100f);
                            this.script_ui.CallGeneral(1);
                        }
                        else
                        {
                            this.life = false;
                            this.hp = 0;
                            this.myanimation.Play("dead");
                            this.Invincibility(10f);
                            this.script_ui.GameOver();
                        }
                    }
                    else
                    {
                        this.hp = 0x5f;
                    }
                }
                else if (num2 > this.endurance)
                {
                    this.myanimation.Stop();
                    this.myanimation.Play("behitdown");
                    this.Invincibility(2f);
                    this.myrigidbody.AddForce((Vector3) (_damageVector * 180f));
                }
                else
                {
                    this.Invincibility(0.5f);
                    this.myrigidbody.AddForce((Vector3) (_damageVector * 20f));
                }
                if (!this.story_scene)
                {
                    this.script_ui.StatUpdate_hp(this.hp, this.maxhp);
                }
                else
                {
                    this.script_ui_story.StatUpdate(this.hp, this.maxhp, this.sp);
                }
            }
            this.mycollider.enabled = false;
            this.CancelAtk();
            this.ResetPower();
        }
    }

    public void DefenceUp()
    {
        this.defence = (int) (this.defence * 2.4f);
        this.endurance = 200;
    }

    public void EnterDun()
    {
        this.chapos = Vector3.zero;
        this.mytransform.forward = Vector3.forward;
        this.myanimation.Play("change_in");
        this.targetpos = (Vector3) (Vector3.forward * 0.01f);
        this.script_ui.ResetExtreme();
    }

    public void Eximpact()
    {
        this.script_swingex2.SwingOn(0f, 2, 2, 20, 1, 0);
        this.myanimation.Play("attackex2_impact");
        this.exstart = false;
        this.myaudio.clip = this.boom;
        this.myaudio.Play();
        this.myrigidbody.AddForce((Vector3) (this.mytransform.forward * 30f));
        this.keydown = false;
        this.prevPoint = this.currentTouchPos;
    }

    public void Exstart()
    {
        if (!this.general)
        {
            this.CancelAtk();
            base.audio.clip = this.skillyell[0];
            base.audio.Play();
            this.exstart = true;
            this.myanimation.Play("attackex2");
            if (this.directionVector != Vector3.zero)
            {
                this.mytransform.forward = this.directionVector;
            }
            this.commendDelay = 0f;
            this.helper = false;
            if (!this.story_scene)
            {
                this.script_ui.PowerCharge();
            }
            else
            {
                this.script_ui_story.PowerCharge();
            }
        }
    }

    public void FindItem(Transform _finditem)
    {
        if ((UnityEngine.Random.Range(0, 100) < this.autorate) && !this.noeagle)
        {
            this.pet_eagle.gameObject.active = true;
            this.script_eagle.GetItem(_finditem);
        }
    }

    public void FireSplash()
    {
        this.ef_firesplash.gameObject.active = true;
        this.ef_firesplash.position = this.mytransform.position + ((Vector3) (this.mytransform.forward * 0.4f));
    }

    public void Fly()
    {
        this.myaudio.PlayOneShot(this.snd_skillstart);
        this.pet_ing = true;
        this.currentPet = 1;
        this.myanimation.Stop();
        this.myanimation.Play("jump_changeweapon");
        this.myanimation.PlayQueued("jump_changeweapon_i").speed = this.myanimation["jump_changeweapon_i"].speed;
        this.myanimation.PlayQueued("eagle_start").speed = this.myanimation["eagle_start"].speed;
        AnimationState state = this.myanimation.PlayQueued("eagle");
        state.speed = this.myanimation["eagle"].speed;
        state.wrapMode = WrapMode.Loop;
        this.movespeed = 0.3f;
        if (!this.noeagle)
        {
            this.pet_eagle.gameObject.active = true;
            this.script_eagle.SkillOn();
        }
        this.AttakUp(this.attack_eagle * 0.01f);
        this.mycollider.radius = this.collider_radius;
        this.mycollider.center = this.collider_fly;
    }

    public void FogOn(int _kind)
    {
        switch (_kind)
        {
            case 0:
                this.c_stepfog[this.nowstep].gameObject.active = true;
                this.c_stepfog[this.nowstep].position = this.mytransform.position;
                this.c_stepfog[this.nowstep].rotation = this.mytransform.rotation;
                this.nowstep = (this.nowstep + 1) % 3;
                break;

            case 1:
                this.c_thrustfog[this.nowthrust].gameObject.active = true;
                this.c_thrustfog[this.nowthrust].position = (Vector3) ((this.mytransform.position + (this.mytransform.forward * 0.2f)) + (Vector3.up * 0.15f));
                this.c_thrustfog[this.nowthrust].up = this.mytransform.forward;
                this.c_thrustfog[this.nowthrust].RotateAround(this.mytransform.forward, (float) UnityEngine.Random.Range(0, 360));
                this.nowthrust = (this.nowthrust + 1) % 3;
                break;

            case 2:
                this.c_thrustfog[this.nowthrust].gameObject.active = true;
                this.c_thrustfog[this.nowthrust].position = (Vector3) ((this.bip01.position + (this.bip01.forward * 0.2f)) + (Vector3.up * 0.15f));
                this.c_thrustfog[this.nowthrust].up = this.bip01.forward;
                this.c_thrustfog[this.nowthrust].RotateAround(this.bip01.forward, (float) UnityEngine.Random.Range(0, 360));
                this.nowthrust = (this.nowthrust + 1) % 3;
                break;
        }
    }

    public void GainExp(float _amount)
    {
        if (this.level >= 0xc7)
        {
            this.exp = 0f;
        }
        else
        {
            this.exp += _amount * this.expboost;
            if (this.exp > (this.level * 100))
            {
                this.level++;
                this.exp = 0f;
                this.cha_maxhp += 5;
                Crypto.Save_int_key("n47", this.level);
                Crypto.Save_int_key("n11", (int) this.exp);
            }
        }
    }

    public void GateEnter(Vector3 _pos)
    {
        this.mytransform.forward = this.targetpos - this.mytransform.position;
        this.isplaycha = false;
        this.dunenter = true;
        this.targetpos = _pos;
    }

    public void GeneralOnOff(bool _general, short _dead)
    {
        if (_dead == 0)
        {
            this.Spcharge(-10f);
        }
        this.general = _general;
        this.change_cha = true;
        this.myanimation.Stop();
        this.script_cam.ZoomIn(3, 0x10, 0.5f);
        this.mytransform.localScale = Vector3.one;
        if (!this.general)
        {
            this.myaudio.clip = this.yell[0];
            base.audio.Play();
            this.special_kind = this.special_kind_origin;
            this.script_cam.IconHideStop(false);
            this.script_weapon.GeneralWeaponOff();
            this.maxhp = this.cha_maxhp;
            this.maxatk = this.origin_maxattack;
            this.minatk = this.origin_minattack;
            this.hitrate = this.origin_hitrate;
            this.defence = this.origin_defence;
            this.atkspd = this.atkspd_origin;
            this.hp = this.cha_hp;
            if ((this.chamovestat < 10) && (this.chamovestat >= 0))
            {
                this.myanimation.Play("change_in");
            }
            else
            {
                this.myanimation.Play("change_in_atk");
                this.temp_attack = this.myanimation.PlayQueued("1t", QueueMode.CompleteOthers);
                this.temp_attack.speed = 0.24f;
                this.temp_attack.layer = 1;
                this.ef_swingex1.localScale = (Vector3) (Vector3.one * 2f);
                this.ef_swingex1.localRotation = Quaternion.Euler(0f, 0f, 180f);
                this.ef_swingex1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.055f));
                this.script_swingex1.SwingOn(0.6f, 2, 2, 20, 1, 120);
                this.curruntattack = this.attackkind_factor;
            }
            this.dummy_general.position = this.mytransform.position;
            this.dummy_general.rotation = this.mytransform.rotation;
            this.ChangeCharacter(this.weapon_kind);
            if (_dead == 0)
            {
                this.dummy_general.GetComponent<General_dummy>().ShowOut();
            }
            else
            {
                this.dummy_general.GetComponent<General_dummy>().Dead();
                this.script_ui.GeneralDead();
                this.change_cha = false;
                this.chamovestat = 0;
                this.Invincibility(1f);
            }
            base.GetComponent<Cha_Costume>().ResetCostume();
        }
        else
        {
            this.myaudio.clip = this.g_yell[0];
            base.audio.Play();
            this.special_kind = -1;
            this.script_cam.IconHideStop(true);
            this.general = true;
            this.maxhp = this.g_maxhp;
            this.maxatk = this.g_atk;
            this.minatk = (int) (this.g_atk * 0.8f);
            this.hitrate = 100;
            this.defence = this.g_def;
            this.atkspd = this.g_atkspd;
            this.hp = this.g_hp;
            if (_dead == 0)
            {
                this.myanimation.Play("change_out");
            }
            else
            {
                this.myanimation.Play("dead");
            }
            if ((this.chamovestat > 10) || (this.chamovestat < 0))
            {
                this.ef_swingex1.localScale = (Vector3) (Vector3.one * 2f);
                this.ef_swingex1.localRotation = Quaternion.Euler(0f, 0f, 180f);
                this.ef_swingex1.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.055f));
                this.script_swingex1.SwingOn(0.6f, 2, 2, 20, 1, 120);
                this.curruntattack = this.attackkind_factor;
                this.dummy_general.GetComponent<General_dummy>().ShowIn_atk();
            }
            else
            {
                this.dummy_general.GetComponent<General_dummy>().ShowIn();
            }
            this.dummy_general.position = this.mytransform.position;
            this.dummy_general.rotation = this.mytransform.rotation;
            this.ChangeCharacter(this.general_kind + 1);
        }
        this.Weapon_Special();
        this.script_ui.StatUpdate_hp(this.hp, this.maxhp);
        this.chamovestat = 100;
    }

    public void GetItem(int _kind, int _level)
    {
        this.script_getitem.TwirlOn(4, 4, 20, false);
        this.myaudio.PlayOneShot(this.snd_getitem);
        switch (_kind)
        {
            case 0:
            {
                int a = (short) ((1.34f * _level) + 2f);
                this.script_ui.GainCoin(a);
                break;
            }
            case 1:
                this.Spcharge(10f + this.itemboolst);
                break;

            case 2:
                this.Heal((int) (((100 + (this.level - 1)) * 0.1f) * this.itemboolst));
                break;

            case 3:
                this.script_ui.GainSoul(1f);
                break;

            case 4:
                this.script_ui.GainJade(1);
                break;

            default:
                this.script_ui.SkillPlus(_kind - 100);
                break;
        }
    }

    public void Grab(int kind, Vector3 monpos)
    {
        float num = 0f;
        this.grab_ing = true;
        this.script_cam.LookTarget(this.bip01, 0, 0f);
        this.myanimation.Stop();
        this.mycollider.enabled = false;
        this.Spcharge(-50f);
        if (!this.story_scene)
        {
            this.script_ui.ComboPlus(0.1f);
        }
        this.chamovestat = 0x70;
        Vector3 vector = monpos - this.mytransform.position;
        if (vector != Vector3.zero)
        {
            this.mytransform.forward = new Vector3(vector.x, 0f, vector.z);
        }
        this.SwingStart();
        switch (kind)
        {
            case 0:
                num = 1.6f;
                this.myanimation.Play("grab10");
                this.grabfinish = this.myanimation.PlayQueued("grab10_finish", QueueMode.CompleteOthers);
                this.grabfinish.speed = this.myanimation["grab10_finish"].speed;
                this.grabfinish = this.myanimation.PlayQueued("grab10_finish2", QueueMode.CompleteOthers);
                this.grabfinish.speed = this.myanimation["grab10_finish2"].speed;
                break;

            case 1:
                num = 1.6f;
                this.myanimation.Play("grab11");
                this.grabfinish = this.myanimation.PlayQueued("grab11_finish", QueueMode.CompleteOthers);
                this.grabfinish.speed = this.myanimation["grab11_finish"].speed;
                this.grabfinish = this.myanimation.PlayQueued("grab11_finish2", QueueMode.CompleteOthers);
                this.grabfinish.speed = this.myanimation["grab11_finish2"].speed;
                break;

            case 2:
                num = 2f;
                this.myanimation.Play("grab12");
                this.grabfinish = this.myanimation.PlayQueued("grab12_finish", QueueMode.CompleteOthers);
                this.grabfinish.speed = this.myanimation["grab12_finish"].speed;
                this.grabfinish = this.myanimation.PlayQueued("grab12_finish2", QueueMode.CompleteOthers);
                this.grabfinish.speed = this.myanimation["grab12_finish2"].speed;
                break;

            case 3:
                num = 1.6f;
                this.myanimation.Play("grab20");
                this.grabfinish = this.myanimation.PlayQueued("grab20_finish", QueueMode.CompleteOthers);
                this.grabfinish.speed = this.myanimation["grab20_finish"].speed;
                this.grabfinish = this.myanimation.PlayQueued("grab20_finish2", QueueMode.CompleteOthers);
                this.grabfinish.speed = this.myanimation["grab20_finish2"].speed;
                break;

            case 4:
                num = 1.6f;
                this.myanimation.Play("grab21");
                this.grabfinish = this.myanimation.PlayQueued("grab21_finish", QueueMode.CompleteOthers);
                this.grabfinish.speed = this.myanimation["grab21_finish"].speed;
                this.grabfinish = this.myanimation.PlayQueued("grab21_finish2", QueueMode.CompleteOthers);
                this.grabfinish.speed = this.myanimation["grab21_finish2"].speed;
                break;

            case 5:
                num = 3f;
                this.myanimation.Play("grab22");
                this.grabfinish = this.myanimation.PlayQueued("grab22_finish", QueueMode.CompleteOthers);
                this.grabfinish.speed = this.myanimation["grab22_finish"].speed;
                this.grabfinish = this.myanimation.PlayQueued("grab22_finish2", QueueMode.CompleteOthers);
                this.grabfinish.speed = this.myanimation["grab22_finish2"].speed;
                break;

            case 6:
                num = 1.2f;
                this.myanimation.Play("grab30");
                this.grabfinish = this.myanimation.PlayQueued("grab30_finish", QueueMode.CompleteOthers);
                this.grabfinish.speed = this.myanimation["grab30_finish"].speed;
                this.grabfinish = this.myanimation.PlayQueued("grab30_finish2", QueueMode.CompleteOthers);
                this.grabfinish.speed = this.myanimation["grab30_finish2"].speed;
                break;
        }
        this.script_cam.ZoomIn(5, 13, num);
    }

    public void Grabfinish(Vector3 monpos, Vector3 lookat)
    {
        monpos.y = 0f;
        this.mytransform.position = Vector3.Lerp(base.transform.position, monpos, Time.deltaTime * 15f);
        this.mytransform.forward = -new Vector3(lookat.x, 0f, lookat.z);
    }

    public void Heal(int a)
    {
        this.pt_heal.particleEmitter.emit = true;
        base.StartCoroutine(this.Sk_Heal());
        this.hp = Mathf.Min(this.hp + a, this.maxhp);
        if (this.general)
        {
            this.g_hp = this.hp;
        }
        else
        {
            this.cha_hp = this.hp;
        }
        if (!this.story_scene)
        {
            this.script_ui.StatUpdate_hp(this.hp, this.maxhp);
        }
        else
        {
            this.script_ui_story.StatUpdate(this.hp, this.maxhp, this.sp);
        }
    }

    public void Invincibility(float t)
    {
        if (this.life)
        {
            this.ef_super.gameObject.active = true;
        }
        this.isinvincibility = true;
        this.target_invincibility = t;
        this.hitrate = 200;
    }

    public void ItemBuff(int _index)
    {
        switch (_index)
        {
            case 1:
                this.origin_maxattack = (int) (this.origin_maxattack * 1.1f);
                this.origin_minattack = (int) (this.origin_minattack * 1.1f);
                this.maxatk = this.origin_maxattack;
                this.minatk = this.origin_minattack;
                break;

            case 2:
                this.origin_defence = (int) (this.origin_defence * 1.2f);
                this.defence = this.origin_defence;
                break;

            case 3:
                this.cha_maxhp = (int) (this.cha_maxhp * 1.15f);
                this.cha_hp = this.cha_maxhp;
                this.hp = this.cha_hp;
                break;

            case 4:
                this.skillboost *= 1.1f;
                this.script_skill.SetBaseDamage(this.skillboost);
                break;

            case 5:
                this.extremeStageHeal = true;
                break;

            case 6:
                this.grabheal_factor = 0.2f;
                break;
        }
    }

    public void KillEnemy()
    {
        if (this.special_kind == 5)
        {
            this.Spcharge((float) (this.special_amount * 2));
        }
        if (!this.general && (this.cur_weapon >= 6))
        {
            this.Heal(this.special_amount - 1);
        }
    }

    public void LoadingFinish()
    {
        int num = Crypto.Load_int_key("n06");
        if (!this.infinitymode)
        {
            this.mytransform.rotation = Quaternion.Euler(0f, 40f, 0f);
            this.pet_ing = true;
            this.PetSkillFinish(0);
            this.isplaycha = true;
        }
        else
        {
            UnityEngine.Object.Destroy(this.pet_eagle.gameObject);
            this.noeagle = true;
            this.EnterDun();
        }
        if (num < 5)
        {
            UnityEngine.Object.Destroy(this.pet_eagle.gameObject);
            this.noeagle = true;
        }
        this.cur_difficulty = this.script_ui.cur_difficulty;
    }

    public void Magic_shoot()
    {
        this.magicspear.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.05f));
        this.magicspear.rotation = this.mytransform.rotation;
        this.magicspear.gameObject.active = true;
    }

    public void MaxCombo()
    {
        this.superMode = 1;
    }

    public void MissionFail()
    {
        this.myanimation.Play("dead");
        this.Invincibility(10f);
        this.life = false;
    }

    public void MoveSpeedUp(float _amount)
    {
        this.myanimation["run"].speed = _amount * 1.25f;
        this.movespeed_origin = _amount;
        this.movespeed = this.movespeed_origin;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == 8)
        {
            if ((this.chamovestat <= 10) && (this.chamovestat >= 0))
            {
                this.targetenemy = other.transform;
                this.AttackOn(this.targetenemy.position);
                this.mycollider.enabled = false;
            }
            else if (this.chamovestat == 0xd4)
            {
                this.Attack_spear(other.transform.position);
            }
            else if (this.chamovestat == 0xcb)
            {
                this.Attack_arrow(other.transform.position);
            }
            else if (this.grabstart && !this.general)
            {
                other.gameObject.SendMessage("Grabed");
                this.grabstart = false;
            }
        }
    }

    public void PetSkillFinish(int i)
    {
        this.curruntattack = this.attackkind_factor;
        this.myanimation.Stop();
        this.chapos[1] = 0f;
        this.chamovestat = 180;
        if (i == 1)
        {
            this.myanimation.Play("eagle_finish");
            this.tempani = this.myanimation.PlayQueued("land_changeweapon");
            this.tempani.layer = 4;
            this.tempani.speed = this.myanimation["land_changeweapon"].speed;
            this.script_eagle.SkillOff();
        }
        else if (i == 0)
        {
            this.myrigidbody.AddForce((Vector3) (-this.mytransform.forward * 120f));
            this.myanimation.Play("horse_finish");
            this.script_horse.GetOffHorse();
            this.tempani = this.myanimation.PlayQueued("land_changeweapon");
            this.tempani.layer = 4;
            this.tempani.speed = this.myanimation["land_changeweapon"].speed;
            this.rideon = false;
        }
        this.currentPet = -1;
        this.ResetAtk();
    }

    public void ResetAtk()
    {
        if (!this.general)
        {
            this.maxatk = this.origin_maxattack;
            this.minatk = this.origin_minattack;
            this.hitrate = this.origin_hitrate;
        }
        else
        {
            this.maxatk = this.g_atk;
            this.minatk = (int) (this.g_atk * 0.8f);
            this.hitrate = 100;
        }
    }

    public void ResetDef()
    {
        this.defence = this.origin_defence;
        this.endurance = this.origin_endurance;
    }

    public void ResetPower()
    {
        if (!this.general && this.exstart)
        {
            if (!this.story_scene)
            {
                this.script_ui.ResetPower();
            }
            else
            {
                this.script_ui_story.ResetPower();
            }
            this.pressdelay = 0f;
            this.prevPoint = this.currentTouchPos;
            this.exstart = false;
            this.script_swingex2.SwingOff();
            this.myanimation.CrossFade("evade");
        }
    }

    public void Resurection()
    {
        this.life = true;
        Time.timeScale = 1f;
        this.isplaycha = true;
        this.maxhp = this.cha_maxhp;
        this.cha_hp = this.maxhp;
        this.hp = this.maxhp;
        this.sp = this.maxsp;
        this.script_ui.StatUpdate_hp(this.hp, this.maxhp);
        this.script_ui.StatUpdate_sp(this.sp);
        if (this.general)
        {
            this.Spcharge(100f);
            this.script_ui.CallGeneral(1);
        }
        else
        {
            base.animation.Stop();
            base.animation.CrossFade("idle");
        }
        this.target_invincibility = 0f;
        this.isinvincibility = false;
        this.Invincibility(3f);
        this.script_skill.BoomOn(0, true);
        int num = Crypto.Load_int_key("resurrection") + 1;
        Crypto.Save_int_key("resurrection", num);
    }

    public void RideHorse()
    {
        this.pet_ing = true;
        this.myanimation.Stop();
        this.myanimation.Play("ride_s");
        this.myanimation.PlayQueued("ride1").speed = 0f;
        this.movespeed = 0.8f;
    }

    public void RndAtk(bool _critical)
    {
        this.atk = UnityEngine.Random.Range(this.minatk, this.maxatk + 1);
        if (_critical && (this.critical >= UnityEngine.Random.Range(0, 100)))
        {
            this.script_txtef.TxtEfOn(2);
            this.atk = this.maxatk;
        }
    }

    public void Set_General(short _weapon, short _kind, short _maxhp, short _maxatk, short _def, float _atkspd, short _unique, int _hp, short _voice)
    {
        this.general_weapon = _weapon;
        this.general_kind = _kind;
        this.g_maxhp = _maxhp;
        this.g_atk = _maxatk;
        this.g_def = _def;
        this.g_atkspd = _atkspd;
        this.g_hp = _hp;
        this.dummy_general.GetComponent<General_dummy>().SetCostume(this.general_kind, this.general_weapon);
        if (this.general_kind == 1)
        {
            this.dummy_general.localScale = (Vector3) (Vector3.one * 1.4f);
        }
        else if (this.general_kind == 3)
        {
            this.dummy_general.localScale = (Vector3) (Vector3.one * 1.1f);
        }
        if (this.accessory[3] > 0)
        {
            this.g_atk = (short) (this.g_atk * 1.1f);
        }
        this.g_yell[0] = Resources.Load("general_yell" + _voice.ToString() + "a") as AudioClip;
        this.g_yell[1] = Resources.Load("general_yell" + _voice.ToString() + "b") as AudioClip;
        this.g_skillyell[0] = Resources.Load("general_skillyell" + _voice.ToString() + "a") as AudioClip;
        this.g_skillyell[1] = Resources.Load("general_skillyell" + _voice.ToString() + "b") as AudioClip;
    }

    public void SetPetSkillLV(int _autorate, int _attack_horse, int _attack_eagle)
    {
        this.autorate = _autorate;
        this.attack_horse = _attack_horse;
        this.attack_eagle = _attack_eagle;
    }

    public void SetRestrictArea(float _area)
    {
        this.restrictArea = _area;
    }

    public void SetUpArmor(int _index)
    {
        _index /= 100;
        int[] numArray = new int[2];
        for (int i = 0; i < 2; i++)
        {
            numArray[i] = _index % 10;
            _index /= 10;
        }
        this.selequip_grade = numArray[0];
        this.selequip_special = numArray[1];
        this.selequip_hp = _index;
    }

    [DebuggerHidden]
    public IEnumerator Sk_Heal()
    {
        return new <Sk_Heal>c__Iterator9 { <>f__this = this };
    }

    public void SkillStart()
    {
        this.skill_ing = true;
        this.myaudio.PlayOneShot(this.snd_skillstart);
        if (!this.general)
        {
            this.myaudio.PlayOneShot(this.skillyell[1]);
        }
        else
        {
            this.myaudio.PlayOneShot(this.g_skillyell[0]);
        }
    }

    public void Spcharge(float a)
    {
        this.sp = Mathf.Min(this.sp + a, this.maxsp);
        if (!this.story_scene)
        {
            this.script_ui.StatUpdate_sp(this.sp);
        }
        else
        {
            this.script_ui_story.StatUpdate(this.hp, this.maxhp, this.sp);
        }
    }

    public void SpRecover()
    {
        this.Spcharge(this.spplus_amount * 3f);
        if (this.current_costume >= 6)
        {
            if (!this.general)
            {
                this.hp = Mathf.Min(this.hp + 1, this.maxhp);
            }
            this.script_ui.StatUpdate_hp(this.hp, this.maxhp);
        }
    }

    private void Start()
    {
        this.script_skill.Set_R_hand(this.dummy_weapon);
        this.exattack = Crypto.Load_int_key("exattack");
        for (int i = 0; i < 3; i++)
        {
            this.c_stepfog[i] = (Transform) UnityEngine.Object.Instantiate(this.ef_stepfog, (Vector3) (Vector3.one * 4f), base.transform.root.rotation);
            this.c_thrustfog[i] = (Transform) UnityEngine.Object.Instantiate(this.ef_thrustfog, (Vector3) (Vector3.one * 4f), this.ef_thrustfog.localRotation);
        }
        this.directionVector = Vector3.zero;
        this.myanimation["dead"].wrapMode = WrapMode.ClampForever;
        this.myanimation["cast1"].wrapMode = WrapMode.ClampForever;
        this.myanimation["cast2"].wrapMode = WrapMode.ClampForever;
        this.myanimation["cast3"].wrapMode = WrapMode.ClampForever;
        this.myanimation["cast4"].wrapMode = WrapMode.ClampForever;
        this.myanimation["change_out"].speed = 0.2f;
        this.myanimation["change_in"].speed = 0.3f;
        this.myanimation["change_in_atk"].speed = 0.3f;
        this.myanimation["dodge"].speed = 0.4f;
        this.myanimation["grabstart"].speed = 0.3f;
        this.myanimation["grab10"].speed = 0.25f;
        this.myanimation["grab10_finish"].speed = 0.5f;
        this.myanimation["grab10_finish2"].speed = 0.25f;
        this.myanimation["grab11"].speed = 0.28f;
        this.myanimation["grab11_finish"].speed = 0.28f;
        this.myanimation["grab11_finish2"].speed = 0.25f;
        this.myanimation["grab12"].speed = 0.24f;
        this.myanimation["grab12_finish"].speed = 0.28f;
        this.myanimation["grab12_finish2"].speed = 0.25f;
        this.myanimation["grab20"].speed = 0.35f;
        this.myanimation["grab20_finish"].speed = 0.25f;
        this.myanimation["grab20_finish2"].speed = 0.25f;
        this.myanimation["grab21"].speed = 0.4f;
        this.myanimation["grab21_finish"].speed = 0.25f;
        this.myanimation["grab21_finish2"].speed = 0.2f;
        this.myanimation["grab22"].speed = 0.22f;
        this.myanimation["grab22_finish"].speed = 0.25f;
        this.myanimation["grab22_finish2"].speed = 0.28f;
        this.myanimation["grab30"].speed = 0.35f;
        this.myanimation["grab30_finish"].speed = 0.35f;
        this.myanimation["grab30_finish2"].speed = 0.25f;
        this.myanimation["behitdown"].speed = 0.7f;
        this.myanimation["dead"].speed = 0.5f;
        this.myanimation["attackex1"].speed = 0.25f;
        this.myanimation["attackex1_impact"].speed = 0.25f;
        this.myanimation["attackex2"].speed = 0.24f;
        this.myanimation["attackex2_impact"].speed = 0.25f;
        this.myanimation["attackex3"].speed = 2.35f;
        this.myanimation["attackex3_impact"].speed = 0.25f;
        this.myanimation["dash_attack"].speed = 0.35f;
        this.myanimation["wing"].speed = 0.2f;
        this.myanimation["wing_i"].speed = 0.2f;
        this.myanimation["skill01"].speed = 0.2f;
        this.myanimation["skill02"].speed = 0.2f;
        this.myanimation["skill03"].speed = 0.25f;
        this.myanimation["skill04"].speed = 0.2f;
        this.myanimation["jumpattack_air"].speed = 0.3f;
        this.myanimation["evade"].speed = 0.35f;
        this.myanimation["wheelwind"].speed = 0.34f;
        this.myanimation["ride1"].speed = 0.6f;
        this.myanimation["ride_s"].speed = 0.2f;
        this.myanimation["attack_ride1"].speed = 0.3f;
        this.myanimation["attack_ride2"].speed = 0.3f;
        this.myanimation["blocked"].speed = 0.4f;
        this.myanimation["cast1"].speed = 2.5f;
        this.myanimation["cast2"].speed = 2.5f;
        this.myanimation["cast3"].speed = 2.5f;
        this.myanimation["cast4"].speed = 2.5f;
        this.myanimation["jump_changeweapon"].speed = 0.2f;
        this.myanimation["jump_changeweapon_i"].speed = 0.4f;
        this.myanimation["riseattack"].speed = 0.28f;
        this.myanimation["eagle"].speed = 0.1f;
        this.myanimation["eagle_start"].speed = 0.25f;
        this.myanimation["eagle_finish"].speed = 0.3f;
        this.myanimation["eagle_shoot"].speed = 0.5f;
        this.myanimation["horse_start"].speed = 0.3f;
        this.myanimation["horse_finish"].speed = 0.3f;
        this.myanimation["horse_chacry"].speed = 0.32f;
        this.myanimation["rapidstab"].speed = 0.3f;
        this.myanimation["skill_chargesmash"].speed = 0.16f;
        this.myanimation["change_out"].layer = 3;
        this.myanimation["change_in"].layer = 3;
        this.myanimation["change_in_atk"].layer = 1;
        this.myanimation["behitdown"].layer = 3;
        this.myanimation["dead"].layer = 4;
        this.myanimation["dodge"].layer = 2;
        this.myanimation["grabstart"].layer = 2;
        this.myanimation["grab10"].layer = 4;
        this.myanimation["grab10_finish"].layer = 4;
        this.myanimation["grab10_finish2"].layer = 4;
        this.myanimation["grab11"].layer = 4;
        this.myanimation["grab11_finish"].layer = 4;
        this.myanimation["grab11_finish2"].layer = 4;
        this.myanimation["grab12"].layer = 4;
        this.myanimation["grab12_finish"].layer = 4;
        this.myanimation["grab12_finish2"].layer = 4;
        this.myanimation["grab20"].layer = 4;
        this.myanimation["grab20_finish"].layer = 4;
        this.myanimation["grab20_finish2"].layer = 4;
        this.myanimation["grab21"].layer = 4;
        this.myanimation["grab21_finish"].layer = 4;
        this.myanimation["grab21_finish2"].layer = 4;
        this.myanimation["grab22"].layer = 4;
        this.myanimation["grab22_finish"].layer = 4;
        this.myanimation["grab22_finish2"].layer = 4;
        this.myanimation["grab30"].layer = 4;
        this.myanimation["grab30_finish"].layer = 4;
        this.myanimation["grab30_finish2"].layer = 4;
        this.myanimation["attackex1"].layer = 1;
        this.myanimation["attackex2"].layer = 1;
        this.myanimation["attackex3"].layer = 1;
        this.myanimation["attackex1_impact"].layer = 1;
        this.myanimation["attackex2_impact"].layer = 1;
        this.myanimation["attackex3_impact"].layer = 1;
        this.myanimation["dash_attack"].layer = 1;
        this.myanimation["wing"].layer = 2;
        this.myanimation["wing_i"].layer = 2;
        this.myanimation["skill01"].layer = 2;
        this.myanimation["skill02"].layer = 2;
        this.myanimation["skill03"].layer = 2;
        this.myanimation["skill04"].layer = 2;
        this.myanimation["jumpattack_air"].layer = 2;
        this.myanimation["jumpattack_impact"].layer = 2;
        this.myanimation["evade"].layer = 1;
        this.myanimation["wheelwind"].layer = 2;
        this.myanimation["ride1"].layer = 4;
        this.myanimation["ride_s"].layer = 4;
        this.myanimation["attack_ride1"].layer = 5;
        this.myanimation["attack_ride2"].layer = 5;
        this.myanimation["blocked"].layer = 3;
        this.myanimation["cast1"].layer = 3;
        this.myanimation["cast2"].layer = 3;
        this.myanimation["cast3"].layer = 3;
        this.myanimation["cast4"].layer = 3;
        this.myanimation["jump_changeweapon"].layer = 4;
        this.myanimation["jump_changeweapon_i"].layer = 4;
        this.myanimation["riseattack"].layer = 1;
        this.myanimation["eagle"].layer = 4;
        this.myanimation["eagle_start"].layer = 4;
        this.myanimation["eagle_finish"].layer = 4;
        this.myanimation["eagle_shoot"].layer = 5;
        this.myanimation["horse_start"].layer = 4;
        this.myanimation["horse_finish"].layer = 4;
        this.myanimation["horse_chacry"].layer = 4;
        this.myanimation["rapidstab"].layer = 3;
        this.myanimation["skill_chargesmash"].layer = 3;
        this.rotate = Quaternion.identity;
        this.combotime = 1f;
        this.script_txtef = this.txtef.GetComponent<Txt_effect>();
        Transform transform = (Transform) UnityEngine.Object.Instantiate(this.shadow, this.mytransform.position, this.mytransform.rotation);
        this.bip01 = this.mytransform.Find("Bip01");
        transform.GetComponent<Shadow>().Pickparent(this.bip01, 1f);
        this.collider_dodge = new Vector3(0f, 0.05f, 0.05f);
        this.collider_fly = new Vector3(0f, 0.05f, 0.32f);
        this.collider_horse = new Vector3(0f, 0.05f, 0.22f);
        this.movespeed = this.movespeed_origin;
        this.RndAtk(false);
        if (!this.story_scene)
        {
            this.ef_swordExtreme.GetComponent<Sword_Extreme>().SetPower(this.origin_maxattack + this.origin_minattack);
            this.infinitymode = this.script_spawn.infinitymode;
            this.script_horse.Rideing(this.infinitymode);
            this.Costume_Special();
            base.InvokeRepeating("SpRecover", 3f, 3f);
            this.weapon_kind = Crypto.Load_int_key("n34");
            this.weapon_kind = (int) (this.weapon_kind * 0.01f);
            int num2 = Crypto.Load_int_key("n38");
            if (num2 >= 20)
            {
                this.special_kind = num2 % 10;
                this.special_kind_origin = this.special_kind;
                this.special_amount = num2 / 10;
                this.Weapon_Special();
            }
            this.script_skill.SetBaseDamage(this.skillboost);
            this.ChangeCharacter(this.weapon_kind);
        }
        else
        {
            this.collider_center = new Vector3(0f, 0.05f, 0.17f);
            this.collider_radius = 0.13f;
            this.atkspd = 0.02f;
            this.myanimation["attack1"].speed = 0.24f + this.atkspd;
            this.myanimation["attack2"].speed = 0.24f + this.atkspd;
            this.myanimation["attack3"].speed = 0.24f + this.atkspd;
            this.myanimation["attack4"].speed = 0.24f + this.atkspd;
            this.myanimation["attack5"].speed = 0.24f + this.atkspd;
            this.myanimation["idle"].speed = 0.1f;
            this.myanimation["walk"].speed = 0.9f;
            this.myanimation["run"].speed = 0.6f;
            this.myanimation["land_changeweapon"].speed = 0.2f;
            this.myanimation["idle"].layer = 0;
            this.myanimation["walk"].layer = 0;
            this.myanimation["run"].layer = 0;
            this.myanimation["1t"].layer = 1;
            this.myanimation["2t"].layer = 1;
            this.myanimation["3t"].layer = 1;
            this.myanimation["4t"].layer = 1;
            this.myanimation["attack1"].layer = 1;
            this.myanimation["attack2"].layer = 1;
            this.myanimation["attack3"].layer = 1;
            this.myanimation["attack4"].layer = 1;
            this.myanimation["attack5"].layer = 1;
            this.myanimation["land_changeweapon"].layer = 4;
            this.maxhp = 100;
            this.hp = this.maxhp;
            this.isplaycha = false;
        }
    }

    public void StartControl()
    {
        this.isplaycha = true;
        this.script_weapon.ShowBlade();
        if (!this.noeagle)
        {
            this.pet_eagle.gameObject.active = true;
        }
        this.isinvincibility = false;
        this.target_invincibility = 0f;
    }

    private void StepOn()
    {
        if (this.chamovestat <= 10)
        {
            this.myaudio.clip = this.footstep;
            this.myaudio.Play();
        }
    }

    public void StopControl()
    {
        this.isplaycha = false;
        this.directionVector = Vector3.zero;
        if (this.rideon)
        {
            this.script_horse.RunStart(false);
            this.clone_ride.speed = 0.1f;
        }
        this.chamovestat = 300;
        this.script_weapon.HideBlade();
        this.isinvincibility = true;
        this.target_invincibility = 10f;
    }

    public void SwingStart()
    {
        this.myaudio.PlayOneShot(this.snd_swing);
    }

    private void Update()
    {
        this.chapos = this.mytransform.position;
        if (this.isinvincibility)
        {
            if (this.delay_invincibility < this.target_invincibility)
            {
                this.delay_invincibility += Time.deltaTime;
            }
            else
            {
                this.hitrate = this.origin_hitrate;
                this.ef_super.gameObject.active = false;
                this.isinvincibility = false;
                this.delay_invincibility = 0f;
            }
        }
        if (!this.isplaycha)
        {
            if (this.targetpos != Vector3.zero)
            {
                if (this.infinitymode)
                {
                    if (this.dunenter)
                    {
                        this.chapos = Vector3.MoveTowards(this.chapos, this.targetpos, Time.deltaTime);
                        this.directionVector = this.targetpos - this.chapos;
                        if (this.chapos == this.targetpos)
                        {
                            this.dunenter = false;
                            this.targetpos = Vector3.zero;
                            this.script_spawn.SetMapExtreme(true);
                            this.EnterDun();
                        }
                    }
                    else if (!this.myanimation.IsPlaying("change_in"))
                    {
                        this.myanimation.Play("land_changeweapon");
                        this.script_weapon.ReturnBlade();
                        this.targetpos = Vector3.zero;
                        this.isplaycha = true;
                        this.script_spawn.RegenStart();
                        this.script_ui.ResetTime();
                        if (this.extremeStageHeal)
                        {
                            this.Heal((int) (this.cha_maxhp * 0.1f));
                        }
                    }
                }
                else if (!this.storyrun)
                {
                    this.directionVector = this.targetpos - this.chapos;
                    this.chamovestat = 1;
                    this.mytransform.position = Vector3.MoveTowards(this.mytransform.position, this.targetpos, Time.deltaTime * 0.1f);
                    if (!this.myanimation.IsPlaying("ride_s"))
                    {
                        if (!this.myanimation.IsPlaying("ride1"))
                        {
                            if (this.directionVector.magnitude >= 0.05f)
                            {
                                this.mytransform.rotation = Quaternion.LookRotation(this.directionVector);
                                return;
                            }
                            this.RideHorse();
                        }
                        else
                        {
                            GameObject.Find("scene_trans").GetComponent<Story_trans>().ScreenOn(2f);
                            this.targetpos = Vector3.zero;
                        }
                    }
                }
                else
                {
                    this.speedfactor = 6.5f;
                    this.movespeed = this.movespeed_origin;
                    if (this.directionVector != Vector3.zero)
                    {
                        this.mytransform.rotation = Quaternion.LookRotation(this.directionVector);
                    }
                    if (Vector3.Distance(this.mytransform.position, this.targetpos) < 0.35f)
                    {
                        this.targetpos = Vector3.zero;
                        this.isplaycha = true;
                        this.script_cam.ResetCam();
                        GameObject.Find("scene_trans").GetComponent<Story_trans>().ScreenOn(0f);
                        GameObject.FindWithTag("Respawn").GetComponent<Spawn_story>().RegenStart();
                    }
                }
            }
            this.longdash = 0f;
        }
        else if (Input.anyKeyDown)
        {
            this.savetouchposition = false;
            this.ray = this.guicam.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(this.ray, out this.casthit, 4f))
            {
                if ((this.chamovestat < 100) && this.casthit.transform.gameObject.GetComponent<Icon_Skill_p>().SkillColliderOn())
                {
                    this.mycollider.enabled = false;
                    this.CancelAtk();
                }
                this.skillicondown = true;
            }
            this.pressdelay = 0f;
            this.keydown = true;
        }
        else if (Input.anyKey)
        {
            this.ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            if (!this.skillicondown && this.mapcollider.Raycast(this.ray, out this.casthit, 4f))
            {
                this.currentTouchPos = this.casthit.point;
                if (!this.savetouchposition)
                {
                    this.prevPoint = this.currentTouchPos;
                    this.savetouchposition = true;
                }
                this.tempdir = this.currentTouchPos - this.mytransform.position;
                this.tempdir[1] = 0f;
                this.magnitude_temp = this.tempdir.magnitude;
                this.tempdir = (Vector3) (this.tempdir / this.magnitude_temp);
                if (((((this.dubbleclick < 0.3f) && (this.chamovestat < 50)) && (this.chamovestat >= 0)) && (this.sp >= (this.weaponweight * 2f))) && (Vector3.Distance(this.currentTouchPos, this.prevPoint) < 0.1f))
                {
                    this.directionVector = this.tempdir;
                    this.mytransform.rotation = Quaternion.LookRotation(this.directionVector);
                    this.speedfactor = 6.5f;
                    this.myrigidbody.mass = 2f;
                    this.Spcharge(-this.weaponweight * 2f);
                    this.CancelAtk();
                    base.audio.clip = this.snd_dodge;
                    base.audio.Play();
                    this.myanimation.Stop();
                    this.myanimation.Play("dodge");
                    this.chamovestat = 0x35;
                    this.myrigidbody.AddForce((Vector3) (this.directionVector * 220f));
                    this.mycollider.enabled = false;
                    this.pressdelay = 1f;
                }
                if (this.magnitude_temp < 0.05f)
                {
                    this.directionVector = Vector3.zero;
                    if (this.rideon)
                    {
                        this.script_horse.RunStart(false);
                        if (this.clone_ride != null)
                        {
                            this.clone_ride.speed = 0.1f;
                        }
                    }
                }
                else if (this.magnitude_temp > 0.08f)
                {
                    this.directionVector = this.tempdir;
                    this.speedfactor = 6.5f;
                }
            }
            if (this.chamovestat < 0x13)
            {
                this.pressdelay += Time.deltaTime;
                if (this.pressdelay > 0.3f)
                {
                    this.Exstart();
                }
                else if ((((this.pressdelay < 0.1f) && !this.general) && (!this.grabstart && ((this.sp >= 50f) || (this.superMode != 0)))) && (Vector3.Distance(this.prevPoint, this.currentTouchPos) > 0.2f))
                {
                    this.myaudio.clip = this.yell[2];
                    base.audio.Play();
                    this.chamovestat = 0x35;
                    this.myaudio.PlayOneShot(this.snd_skillstart);
                    Vector3 forward = Vector3.Normalize(this.currentTouchPos - this.prevPoint);
                    if (forward != Vector3.zero)
                    {
                        this.mytransform.rotation = Quaternion.LookRotation(forward);
                    }
                    if (this.superMode == 0)
                    {
                        this.myrigidbody.AddForce((Vector3) (forward * 300f));
                        this.myanimation.Play("grabstart");
                        this.grabstart = true;
                    }
                    else if (this.superMode == 1)
                    {
                        this.myrigidbody.mass = 6f;
                        base.rigidbody.drag = 15f;
                        this.myanimation.Stop();
                        this.skill_ing = true;
                        Time.timeScale = 0.1f;
                        this.superMode = 2;
                        this.myanimation["attackex3"].speed = 1.35f;
                        this.myanimation.Play("attackex3");
                        this.myanimation.PlayQueued("attackex3_impact").speed = 0.25f;
                        this.Invincibility(1f);
                        this.script_ui.SuperModeOn();
                        this.ef_swordExtreme.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.1f));
                        this.ef_swordExtreme.gameObject.active = true;
                        this.mytransform.forward = forward;
                    }
                    this.mycollider.radius = 0.1f;
                    this.mycollider.center = this.collider_dodge;
                    this.mycollider.enabled = false;
                    this.mycollider.enabled = true;
                    this.CancelAtk();
                    this.pressdelay = 1f;
                }
            }
        }
        else if (this.keydown)
        {
            this.savetouchposition = false;
            this.dubbleclick = 0f;
            this.keydown = false;
            this.skillicondown = false;
            this.ResetPower();
        }
        this.dubbleclick += 2f * Time.deltaTime;
        if (this.myanimation.IsPlaying("dead"))
        {
            this.mycollider.enabled = false;
            this.chamovestat = 500;
            this.directionVector = Vector3.zero;
            this.combotime = 0f;
        }
        else
        {
            if (this.change_cha)
            {
                if (!this.myanimation.isPlaying || this.myanimation.IsPlaying("1t"))
                {
                    this.change_cha = false;
                    this.chamovestat = 5;
                }
            }
            else if (this.pet_ing)
            {
                if (this.myanimation.IsPlaying("land_changeweapon"))
                {
                    if (this.chamovestat != 0xb6)
                    {
                        this.script_weapon.ReturnBlade();
                        this.chamovestat = 0xb6;
                        this.pet_ing = false;
                    }
                }
                else if (this.myanimation.IsPlaying("jump_changeweapon"))
                {
                    this.chamovestat = 180;
                }
                else if (this.myanimation.IsPlaying("jump_changeweapon_i"))
                {
                    if (this.chamovestat != 0xb5)
                    {
                        this.script_weapon.SwitchWepon(this.currentPet, 3, 0f, 0f);
                    }
                    this.chamovestat = 0xb5;
                }
                else if (this.myanimation.IsPlaying("eagle_shoot"))
                {
                    this.chamovestat = 0xc0;
                    this.chapos[1] = (0.02f * Mathf.Sin(Time.time * 8f)) + 0.02f;
                }
                else if (this.myanimation.IsPlaying("eagle_start"))
                {
                    this.chamovestat = 200;
                    this.chapos[1] = (0.02f * Mathf.Sin(Time.time * 8f)) + 0.02f;
                }
                else if (this.myanimation.IsPlaying("eagle"))
                {
                    if (this.chamovestat != 0xcb)
                    {
                        this.mycollider.enabled = true;
                        this.movespeed = 0.3f;
                        this.chamovestat = 0xcb;
                    }
                    this.chapos[1] = (0.02f * Mathf.Sin(Time.time * 8f)) + 0.02f;
                }
                else if (this.myanimation.IsPlaying("eagle_finish") || this.myanimation.IsPlaying("horse_finish"))
                {
                    this.chamovestat = 0xb8;
                }
                else if (this.myanimation.IsPlaying("horse_chacry"))
                {
                    if (this.chamovestat != 0xb9)
                    {
                        this.rideon = true;
                        this.script_horse.RideandCry();
                        this.chamovestat = 0xb9;
                    }
                }
                else if (this.myanimation.IsPlaying("ride_s") || this.myanimation.IsPlaying("horse_start"))
                {
                    this.chamovestat = 0xb8;
                    this.directionVector = Vector3.zero;
                    this.chapos = Vector3.Lerp(this.mytransform.position, this.pet_horse.position, Time.deltaTime * 5f);
                    this.mytransform.rotation = Quaternion.Slerp(this.mytransform.rotation, this.pet_horse.rotation, Time.deltaTime * 5f);
                }
                else if (this.myanimation.IsPlaying("attack_ride1") || this.myanimation.IsPlaying("attack_ride2"))
                {
                    this.chamovestat = 0xd6;
                    this.combotime = 1f;
                }
                else if (this.myanimation.IsPlaying("ride1") && (this.chamovestat != 0xd4))
                {
                    this.chamovestat = 0xd4;
                    this.mycollider.enabled = true;
                }
            }
            else if (this.skill_ing)
            {
                if ((this.myanimation.IsPlaying("cast1") || this.myanimation.IsPlaying("cast3")) || this.myanimation.IsPlaying("cast4"))
                {
                    if (this.directionVector != Vector3.zero)
                    {
                        this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, Quaternion.LookRotation(this.directionVector), Time.deltaTime * 80f);
                    }
                    this.chamovestat = 110;
                    this.combotime = 0f;
                }
                else if (this.myanimation.IsPlaying("cast2"))
                {
                    this.chamovestat = 110;
                    this.combotime = 0f;
                }
                else if (((this.myanimation.IsPlaying("skill01") || this.myanimation.IsPlaying("skill02")) || (this.myanimation.IsPlaying("skill03") || this.myanimation.IsPlaying("skill04"))) || (this.myanimation.IsPlaying("rapidstab") || this.myanimation.IsPlaying("skill_chargesmash")))
                {
                    this.chamovestat = 0x6f;
                    this.combotime = 0f;
                    this.skill_ing = false;
                }
                else if (this.myanimation.IsPlaying("wing_i"))
                {
                    if (this.chamovestat != 0x70)
                    {
                        this.script_skill.DelaySkill(0x13);
                        this.chamovestat = 0x70;
                        this.myaudio.clip = this.boom;
                        this.myaudio.Play();
                    }
                    this.combotime = 0f;
                    this.skill_ing = false;
                }
                else if (this.myanimation.IsPlaying("wing"))
                {
                    if (this.fogdelay >= 0.1f)
                    {
                        this.FogOn(2);
                        this.fogdelay = 0f;
                    }
                    else
                    {
                        this.fogdelay += Time.deltaTime;
                    }
                    this.chamovestat = 0x6f;
                    this.combotime = 0f;
                    this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, Quaternion.identity, Time.deltaTime * 3f);
                }
                else if (this.myanimation.IsPlaying("wheelwind"))
                {
                    this.movespeed = 0.5f;
                    this.chamovestat = 0xde;
                    this.combotime = 0f;
                }
                else if (this.myanimation.IsPlaying("jumpattack_air"))
                {
                    this.chapos += (Vector3) ((this.directionVector * Time.deltaTime) * 0.6f);
                    this.chamovestat = 0x97;
                    this.combotime = 0f;
                }
                else if (this.myanimation.IsPlaying("jumpattack_impact"))
                {
                    if (this.chamovestat != 0x70)
                    {
                        this.script_skill.DelaySkill(2);
                        this.chamovestat = 0x70;
                        this.myaudio.clip = this.boom;
                        this.myaudio.Play();
                    }
                    this.combotime = 0f;
                    this.skill_ing = false;
                }
                else if (this.myanimation.IsPlaying("attackex3"))
                {
                    this.chapos += (Vector3) ((this.directionVector * 0.03f) * Time.deltaTime);
                    if (this.directionVector != Vector3.zero)
                    {
                        this.mytransform.forward = this.directionVector;
                    }
                    this.chamovestat = 0x67;
                }
                else if (this.myanimation.IsPlaying("attackex3_impact"))
                {
                    if (this.fogdelay >= 0.1f)
                    {
                        this.FogOn(0);
                        this.fogdelay = 0f;
                    }
                    if (this.chamovestat != 0x66)
                    {
                        this.myaudio.clip = this.boom;
                        this.myaudio.Play();
                        if (this.superMode == 2)
                        {
                            this.superMode = 0;
                            this.ef_linehit.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.02f));
                            this.ef_linehit.right = -base.transform.forward;
                            this.ef_linehit.gameObject.active = true;
                            Time.timeScale = 1f;
                            this.myrigidbody.AddForce((Vector3) (this.mytransform.forward * 4000f));
                        }
                        else
                        {
                            this.myrigidbody.AddForce((Vector3) (this.mytransform.forward * 380f));
                        }
                    }
                    this.chamovestat = 0x66;
                }
                else
                {
                    this.skill_ing = false;
                }
            }
            else if (this.grab_ing)
            {
                if ((this.myanimation.IsPlaying("grab10_finish2") || this.myanimation.IsPlaying("grab20_finish2")) || (this.myanimation.IsPlaying("grab22_finish2") || this.myanimation.IsPlaying("grab30_finish2")))
                {
                    if (this.chamovestat != 0x72)
                    {
                        this.script_cam.ResetCam();
                        this.script_txtef.TxtEfOn(0);
                        this.Heal((int) (this.cha_maxhp * this.grabheal_factor));
                    }
                    this.chamovestat = 0x72;
                    this.combotime = 0f;
                }
                else if ((this.myanimation.IsPlaying("grab11_finish2") || this.myanimation.IsPlaying("grab12_finish2")) || this.myanimation.IsPlaying("grab21_finish2"))
                {
                    if (this.chamovestat != 0x72)
                    {
                        this.Heal((int) (this.cha_maxhp * 0.1f));
                        this.script_splash.SplashOn(true, 0.07f, 0f);
                        this.ef_rotfog.position = this.mytransform.position;
                        this.script_rotfog.RotfogOn(4f, 5f, 80, 8, 2f);
                        this.script_cam.ResetCam();
                        this.script_txtef.TxtEfOn(0);
                    }
                    this.chamovestat = 0x72;
                }
                else if (((this.myanimation.IsPlaying("grab10_finish") || this.myanimation.IsPlaying("grab11_finish")) || (this.myanimation.IsPlaying("grab12_finish") || this.myanimation.IsPlaying("grab20_finish"))) || ((this.myanimation.IsPlaying("grab21_finish") || this.myanimation.IsPlaying("grab22_finish")) || this.myanimation.IsPlaying("grab30_finish")))
                {
                    this.chamovestat = 0x71;
                    this.combotime = 0f;
                }
                else if (((this.myanimation.IsPlaying("grab10") || this.myanimation.IsPlaying("grab11")) || (this.myanimation.IsPlaying("grab12") || this.myanimation.IsPlaying("grab20"))) || ((this.myanimation.IsPlaying("grab21") || this.myanimation.IsPlaying("grab22")) || this.myanimation.IsPlaying("grab30")))
                {
                    this.chamovestat = 0x70;
                    this.combotime = 0f;
                }
                else
                {
                    this.grab_ing = false;
                }
            }
            else if (this.myanimation.IsPlaying("behitdown"))
            {
                this.chamovestat = -1;
            }
            else if (this.myanimation.IsPlaying("blocked") || this.myanimation.IsPlaying("evade"))
            {
                this.chamovestat = -1;
                this.combotime = 0f;
            }
            else if (this.myanimation.IsPlaying("grabstart"))
            {
                this.chamovestat = 0x35;
            }
            else if (this.myanimation.IsPlaying("dodge"))
            {
                this.chamovestat = 0x35;
                this.combotime = 0f;
            }
            else if (this.myanimation.IsPlaying("attackex2"))
            {
                this.pressdelay = 1f;
                this.chamovestat = 0x13;
                this.commendDelay = 0f;
                this.helper = false;
            }
            else if (this.myanimation.IsPlaying("attackex2_impact"))
            {
                if (!this.general)
                {
                    this.commendDelay += Time.deltaTime;
                    if (!this.helper && (this.commendDelay > 0.3f))
                    {
                        this.guide_circle.gameObject.active = true;
                        this.helper = true;
                    }
                    if (Input.anyKeyDown)
                    {
                        if ((this.commendDelay < 0.7f) && (this.commendDelay > 0.5f))
                        {
                            this.script_weapon.SwitchWepon(0, 8, 0.6f, 1f);
                            this.myanimation.Play("attackex1");
                            this.impact = this.myanimation.PlayQueued("attackex1_impact");
                            this.impact.speed = 0.25f;
                            this.myaudio.PlayOneShot(this.snd_skillstart);
                            this.commendDelay = 1f;
                        }
                        else
                        {
                            this.commendDelay = 1f;
                        }
                    }
                    this.pressdelay = 1f;
                }
                if (this.chamovestat != 0x66)
                {
                    this.myaudio.clip = this.boom;
                    this.myaudio.Play();
                    this.script_splash.SplashOn(true, 0.1f, 0f);
                }
                this.chamovestat = 0x66;
            }
            else if (this.myanimation.IsPlaying("attackex1"))
            {
                if (this.fogdelay >= 0.15f)
                {
                    this.FogOn(0);
                    this.fogdelay = 0f;
                }
                else
                {
                    this.fogdelay += Time.deltaTime;
                }
                this.chapos += (Vector3) ((this.directionVector * 0.5f) * Time.deltaTime);
                if (this.directionVector != Vector3.zero)
                {
                    this.mytransform.forward = this.directionVector;
                }
                this.chamovestat = 0x65;
                this.commendDelay = 0f;
                this.helper = false;
            }
            else if (this.myanimation.IsPlaying("attackex1_impact"))
            {
                this.fogdelay = 0.15f;
                this.commendDelay += Time.deltaTime;
                if (!this.helper && (this.commendDelay > 0.3f))
                {
                    this.guide_circle.gameObject.active = true;
                    this.helper = true;
                }
                if (Input.anyKeyDown)
                {
                    if ((this.commendDelay < 0.7f) && (this.commendDelay > 0.5f))
                    {
                        this.script_cam.Topview();
                        this.pt_rising.position = this.mytransform.position;
                        this.pt_rising.gameObject.active = true;
                        this.myanimation.Play("riseattack");
                        this.script_weapon.SwitchWepon(1, 8, 1.4f, 1f);
                        this.myaudio.clip = this.snd_riseattack;
                        this.myaudio.PlayOneShot(this.snd_skillstart);
                        this.exattack++;
                        this.commendDelay = 1f;
                    }
                    else
                    {
                        this.commendDelay = 1f;
                    }
                }
                if (this.chamovestat != 0x66)
                {
                    this.script_cam.Topview();
                    this.ef_riseattack.position = this.mytransform.position;
                    this.ef_riseattack.gameObject.active = true;
                    this.myaudio.clip = this.boom;
                    this.myaudio.Play();
                }
                this.chamovestat = 0x66;
            }
            else if (this.myanimation.IsPlaying("riseattack"))
            {
                this.chamovestat = 0x66;
                this.myaudio.Play();
                this.pt_rising.Rotate((Vector3) ((Vector3.up * Time.deltaTime) * 2000f));
            }
            else if (this.myanimation.IsPlaying("attack3"))
            {
                this.combotime = 1f;
                this.chamovestat = 11;
                this.fogdelay = 0f;
            }
            else if (this.myanimation.IsPlaying("attack4"))
            {
                if (this.weapon_kind == 0)
                {
                    if (this.fogdelay >= 0.15f)
                    {
                        this.FogOn(1);
                        this.fogdelay = 0f;
                    }
                    else
                    {
                        this.fogdelay += Time.deltaTime;
                    }
                }
                this.combotime = 1f;
                this.movespeed = this.movespeed_origin;
                this.chamovestat = 12;
                this.commendDelay = 0f;
                this.helper = false;
            }
            else if (this.myanimation.IsPlaying("attack5"))
            {
                this.chamovestat = 13;
            }
            else if (this.myanimation.IsPlaying("attack2"))
            {
                this.chamovestat = 13;
                this.combotime = 1f;
            }
            else if (this.myanimation.IsPlaying("attack1"))
            {
                this.commendDelay = 0f;
                this.chamovestat = 11;
                this.combotime = 1f;
            }
            else if (this.myanimation.IsPlaying("dash_attack"))
            {
                this.chapos += (Vector3) ((this.mytransform.forward * Time.deltaTime) * 0.5f);
                this.commendDelay = 0f;
                this.chamovestat = 0x13;
                this.combotime = 1f;
            }
            else if (this.myanimation.IsPlaying("run"))
            {
                this.movespeed = this.movespeed_origin;
                if (this.chamovestat == 2)
                {
                    if (this.longdash < 3f)
                    {
                        this.longdash += Time.deltaTime;
                    }
                    else if (this.chamovestat != 3)
                    {
                        this.ef_blur.gameObject.active = true;
                        if (!this.noeagle)
                        {
                            this.pet_eagle.gameObject.active = true;
                        }
                        this.chamovestat = 3;
                        this.mycollider.center = this.collider_horse;
                        this.mycollider.radius = 0.2f;
                    }
                }
                else if (this.chamovestat != 3)
                {
                    this.pet_ing = false;
                    this.skill_ing = false;
                    this.grabstart = false;
                    this.myrigidbody.mass = 2f;
                    base.rigidbody.drag = 5f;
                    this.longdash = 0f;
                    this.chamovestat = 2;
                    this.mycollider.radius = this.collider_radius;
                    this.mycollider.center = this.collider_center;
                    this.mycollider.enabled = false;
                    this.mycollider.enabled = true;
                }
            }
            else if (this.myanimation.IsPlaying("walk"))
            {
                if (this.chamovestat != 1)
                {
                    this.mycollider.enabled = true;
                    this.chamovestat = 1;
                }
            }
            else if (this.myanimation.IsPlaying("idle"))
            {
                this.chamovestat = 0;
            }
            if ((!this.myanimation.isPlaying || (this.chamovestat <= 10)) || (this.chamovestat > 200))
            {
                this.combotime -= 2f * Time.deltaTime;
                if ((this.directionVector == Vector3.zero) || (this.chamovestat < 0))
                {
                    this.myanimation.CrossFade("idle");
                }
                else
                {
                    this.rotate = Quaternion.LookRotation(this.directionVector);
                    if (this.rideon)
                    {
                        if ((this.clone_ride != null) && (this.clone_ride.speed < 0.6f))
                        {
                            this.clone_ride.speed = 0.6f;
                            this.movespeed = 0.8f;
                            this.clone_ride.layer = 3;
                            this.script_horse.RunStart(true);
                        }
                        this.speedfactor = 7f;
                    }
                    else if (this.speedfactor > 4.5f)
                    {
                        this.speedfactor -= 2f * Time.deltaTime;
                        this.myanimation.CrossFade("run");
                    }
                    else if (this.speedfactor > 0.2f)
                    {
                        this.speedfactor -= 2f * Time.deltaTime;
                        this.myanimation.CrossFade("walk");
                        this.myanimation["walk"].speed = (this.speedfactor / 7.5f) + 0.2f;
                        this.movespeed = this.speedfactor / 12f;
                    }
                    else
                    {
                        this.directionVector = Vector3.zero;
                    }
                    this.chapos += (Vector3) ((this.directionVector * Time.deltaTime) * this.movespeed);
                    this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, this.rotate, Time.deltaTime * 8f);
                }
            }
            if (!this.infinitymode)
            {
                this.chapos[0] = Mathf.Clamp(this.chapos[0], -this.limit_x, this.limit_x);
                this.chapos[2] = Mathf.Clamp(this.chapos[2], this.limit_y_b, this.limit_y_f);
            }
            else
            {
                Vector3 chapos = this.chapos;
                chapos.y = 0f;
                if (Vector3.SqrMagnitude(chapos) > this.restrictArea)
                {
                    this.directionVector = -chapos;
                    this.chapos -= (Vector3) (chapos * Time.deltaTime);
                }
            }
            this.mytransform.position = this.chapos;
        }
    }

    public void WakToward(Vector3 _pos, bool _run, bool _ride)
    {
        this.myanimation.Stop();
        this.isplaycha = false;
        if (!_run)
        {
            this.script_weapon.SwitchWepon(3, 3, 0f, 1f);
            this.myanimation["walk_free"].speed = 0.45f;
            this.myanimation.Play("walk_free");
        }
        else
        {
            this.script_weapon.SetStoryBlade();
            this.script_weapon.ReturnBlade();
            this.chamovestat = 2;
            this.myanimation.Play("run");
        }
        this.targetpos = _pos;
        this.storyrun = _run;
        this.directionVector = this.targetpos - this.mytransform.position;
    }

    public void Weapon_Special()
    {
        switch ((this.special_kind + 1))
        {
            case 0:
                this.ef_swing1.GetComponent<Attribute_swing>().ChangeAttribute(0, 0);
                this.ef_swing2.GetComponent<Attribute_swing>().ChangeAttribute(0, 0);
                GameObject.FindWithTag("efs_mon").GetComponent<Monster_efs>().BloodAttribute(0);
                break;

            case 1:
                this.ef_swing1.GetComponent<Attribute_swing>().ChangeAttribute(1, this.special_amount);
                this.ef_swing2.GetComponent<Attribute_swing>().ChangeAttribute(1, this.special_amount);
                GameObject.FindWithTag("efs_mon").GetComponent<Monster_efs>().BloodAttribute(1);
                break;

            case 2:
                this.ef_swing1.GetComponent<Attribute_swing>().ChangeAttribute(2, this.special_amount);
                this.ef_swing2.GetComponent<Attribute_swing>().ChangeAttribute(2, this.special_amount);
                GameObject.FindWithTag("efs_mon").GetComponent<Monster_efs>().BloodAttribute(2);
                break;

            case 3:
                this.ef_swing1.GetComponent<Attribute_swing>().ChangeAttribute(3, this.special_amount);
                this.ef_swing2.GetComponent<Attribute_swing>().ChangeAttribute(3, this.special_amount);
                GameObject.FindWithTag("efs_mon").GetComponent<Monster_efs>().BloodAttribute(3);
                break;

            case 4:
                this.ef_swing1.GetComponent<Attribute_swing>().ChangeAttribute(4, this.special_amount);
                this.ef_swing2.GetComponent<Attribute_swing>().ChangeAttribute(4, this.special_amount);
                GameObject.FindWithTag("efs_mon").GetComponent<Monster_efs>().BloodAttribute(0);
                break;

            case 5:
                this.guard_break = this.special_amount * 20;
                break;

            case 7:
                if (this.special_amount != 4)
                {
                    if (this.special_amount == 3)
                    {
                        this.skillboost *= 1.1f;
                    }
                    else
                    {
                        this.skillboost *= 1.07f;
                    }
                    break;
                }
                this.skillboost *= 1.5f;
                break;
        }
    }

    [CompilerGenerated]
    private sealed class <Sk_Heal>c__Iterator9 : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal Cha_Control <>f__this;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.$current = new WaitForSeconds(1.2f);
                    this.$PC = 1;
                    return true;

                case 1:
                    this.<>f__this.pt_heal.particleEmitter.emit = false;
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }
}


using System;
using UnityEngine;

public class Cam_Loading_Story : MonoBehaviour
{
    private Transform horse;
    private bool stopCam;

    public void DisappearCam()
    {
        this.stopCam = true;
    }

    private void Start()
    {
        base.camera.projectionMatrix = Matrix4x4.Perspective(50f, 1.5f, 0.01f, 20f);
        this.horse = GameObject.Find("pet_horse_riding").transform;
    }

    private void Update()
    {
        if (!this.stopCam)
        {
            base.transform.LookAt(this.horse.position + new Vector3(-0.4f, 0.16f, 0f));
        }
    }
}


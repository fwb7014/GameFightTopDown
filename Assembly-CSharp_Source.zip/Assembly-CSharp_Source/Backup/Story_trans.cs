using System;
using UnityEngine;

public class Story_trans : MonoBehaviour
{
    private bool b_delay = true;
    public GUISkin basicSkin;
    public Texture2D black2;
    public GUIStyle bt_skip;
    private GameObject cha1;
    private bool cinema_window = true;
    private float color_alpha = 1f;
    private float f_delay = 2f;
    private GameObject horse;
    private int language;
    private int max_stage_index = -1;
    private Cha_Control script_cha;
    private int story_index;
    private string[] storytxt = new string[8];

    private void Awake()
    {
        UnityEngine.Object.DontDestroyOnLoad(base.transform.gameObject);
    }

    private void OnGUI()
    {
        GUI.skin = this.basicSkin;
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.depth = -1;
        if (this.cinema_window)
        {
            GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 64f), this.black2);
            GUI.DrawTexture(Crypto.Rect2(0f, 256f, 480f, 74f), this.black2);
        }
        if (this.color_alpha == 0f)
        {
            if (this.story_index < 8)
            {
                if ((this.story_index > 3) && GUI.Button(Crypto.Rect2(400f, 290f, 64f, 32f), "NEXT", this.bt_skip))
                {
                    this.ScreenOn(1f);
                }
            }
            else
            {
                UnityEngine.Object.Destroy(base.gameObject);
            }
        }
        else if (this.b_delay)
        {
            GUI.depth = -8;
            GUI.color = new Color(0f, 0f, 0f, this.color_alpha);
            GUI.DrawTexture(Crypto.Rect2(0f, 0f, 490f, 330f), this.black2);
            GUI.color = Color.white;
            GUI.Label(Crypto.Rect2(0f, 0f, 480f, 320f), string.Empty + this.storytxt[this.story_index], "txt12_w");
            if (this.story_index >= 7)
            {
                AudioSource audio = base.audio;
                audio.volume -= Time.deltaTime;
            }
        }
        else if (!this.b_delay)
        {
            GUI.color = new Color(0f, 0f, 0f, this.color_alpha);
            GUI.DrawTexture(Crypto.Rect2(0f, 0f, 490f, 330f), this.black2);
        }
    }

    public void ScreenOn(float t)
    {
        this.b_delay = true;
        this.f_delay = t;
    }

    private void Start()
    {
        this.language = PlayerPrefs.GetInt("language");
        this.cha1 = GameObject.FindWithTag("Player");
        this.horse = GameObject.Find("pet_horse");
        this.script_cha = this.cha1.GetComponent<Cha_Control>();
        this.max_stage_index = Crypto.Load_int_key("n06");
        if (this.max_stage_index == -1)
        {
            this.storytxt[0] = Language.intxt[this.language, 0x25];
            this.storytxt[1] = " ";
            this.storytxt[2] = Language.intxt[this.language, 0x26];
            this.storytxt[3] = Language.intxt[this.language, 0x27];
            this.storytxt[4] = Language.intxt[this.language, 40];
            this.storytxt[5] = Language.intxt[this.language, 0x29];
            this.storytxt[6] = Language.intxt[this.language, 0x2a];
            this.storytxt[7] = Language.intxt[this.language, 0x2b];
        }
        else
        {
            this.storytxt[0] = Language.intxt[this.language, 0x16a];
            this.storytxt[1] = " ";
            this.storytxt[2] = Language.intxt[this.language, 0x16b];
            this.storytxt[3] = Language.intxt[this.language, 0x16c];
            this.storytxt[4] = Language.intxt[this.language, 0x16d];
            this.storytxt[5] = Language.intxt[this.language, 0x16e];
            this.storytxt[6] = Language.intxt[this.language, 0x16f];
            this.storytxt[7] = Language.intxt[this.language, 0x170];
        }
    }

    public void Story_Contents()
    {
        switch (this.story_index)
        {
            case 0:
                this.cinema_window = true;
                break;

            case 1:
                this.cinema_window = false;
                base.audio.Play();
                break;

            case 2:
            {
                this.cinema_window = true;
                this.cha1.transform.position = Vector3.zero;
                GameObject obj2 = GameObject.Find("npc");
                obj2.transform.position = (Vector3) (Vector3.right * -0.1f);
                Camera.main.GetComponent<Cam_Move>().LookTarget(obj2.transform, 0x19, 10f);
                this.script_cha.WakToward(this.horse.transform.position, false, true);
                break;
            }
            case 3:
                Application.LoadLevel("Story_2");
                break;

            case 4:
                GameObject.Find("cha1_riding").GetComponent<Cha_Control_ride_cha_story1>().CrynStop();
                GameObject.Find("pet_horse_riding").GetComponent<Cha_Control_ride_horse_story>().Scene_third();
                Application.LoadLevel("Story_3");
                break;

            case 5:
            {
                UnityEngine.Object.Destroy(GameObject.Find("pet_horse_riding"));
                GameObject obj3 = GameObject.Find("cha1_riding");
                UnityEngine.Object.Destroy(obj3.GetComponent<Cha_Control_ride_cha_story1>());
                obj3.AddComponent<Cha_Control_ride_cha_story2>();
                Application.LoadLevel("Story_4");
                break;
            }
            case 6:
                GameObject.Find("Main_Camera").GetComponent<Cam_Move_story2>().ShowOff();
                UnityEngine.Object.Destroy(GameObject.Find("cha1_riding"));
                Application.LoadLevel("Story_5");
                break;

            case 7:
            {
                GameObject.Find("Main_Camera").GetComponent<Cam_Move_story>().ShowOff();
                if (this.max_stage_index == -1)
                {
                    int[] intArray = new int[] { 1, 1 };
                    PlayerPrefsX.SetIntArray("petgrade", intArray);
                }
                int num = Crypto.Load_int_key("gamemode");
                PlayerPrefs.SetInt("IsContinue", 6);
                if (num == 0)
                {
                    Application.LoadLevel("Map");
                }
                else
                {
                    Application.LoadLevel("Extreme");
                }
                this.cinema_window = false;
                break;
            }
        }
    }

    private void Update()
    {
        if (this.b_delay)
        {
            this.color_alpha += Time.deltaTime * 2f;
            this.color_alpha = Mathf.Clamp(this.color_alpha, 0f, 1f);
            this.f_delay -= Time.deltaTime;
            if (this.f_delay <= 0f)
            {
                this.f_delay = 0f;
                this.b_delay = false;
                this.Story_Contents();
                this.story_index++;
            }
        }
        else
        {
            this.color_alpha -= Time.deltaTime * 2f;
            this.color_alpha = Mathf.Clamp(this.color_alpha, 0f, 1f);
        }
    }
}


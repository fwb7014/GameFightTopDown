using System;
using UnityEngine;

public class WeaponStat : MonoBehaviour
{
    private int bottom_weaponicon;
    private int[] extractseed = new int[6];
    public int weapon_cost;
    public int weapon_grade;
    public int weapon_index;
    public int weapon_kind;
    public int weapon_maxatk;
    public int weapon_meshkind;
    public int weapon_minatk;
    public int weapon_name;
    public float weapon_spd;
    public int weapon_special;
    public int weapon_special_txt;
    public int weapon_upgrade;
    public weapon[] wi = new weapon[0x19];

    private void Awake()
    {
        this.wi = base.GetComponent<DB_Weapon>().wi;
    }

    public int Cost_only(int _seed)
    {
        int index = _seed / 0xf4240;
        return this.wi[index]._jadecost;
    }

    public int IconImage_Only(int _seed)
    {
        int index = _seed / 0xf4240;
        this.bottom_weaponicon = this.wi[index]._mesh;
        return this.bottom_weaponicon;
    }

    public void SetStat(int _swordindex)
    {
        for (int i = 0; i < 6; i++)
        {
            this.extractseed[i] = _swordindex % 10;
            _swordindex /= 10;
        }
        this.weapon_index = _swordindex;
        this.weapon_meshkind = this.wi[this.weapon_index]._mesh;
        this.weapon_kind = this.wi[this.weapon_index]._kind;
        this.weapon_grade = this.extractseed[4];
        this.weapon_upgrade = this.extractseed[5];
        this.weapon_name = this.wi[this.weapon_index]._name;
        if (this.weapon_grade != 4)
        {
            this.weapon_maxatk = (int) ((((this.extractseed[0] * this.weapon_index) * 0.05f) + (this.weapon_grade * (2f + (this.weapon_index * 0.05f)))) + this.wi[this.weapon_index]._power);
        }
        else
        {
            this.weapon_maxatk = (this.extractseed[0] + (this.weapon_grade * 3)) + this.wi[this.weapon_index]._power;
        }
        this.weapon_minatk = (int) ((0.7f + (this.extractseed[1] * 0.03f)) * this.weapon_maxatk);
        this.weapon_spd = (this.extractseed[2] * 0.002f) + (this.wi[this.weapon_index]._speed * 0.01f);
        this.weapon_cost = this.wi[this.weapon_index]._jadecost;
        if (this.weapon_grade > 1)
        {
            this.weapon_special = this.extractseed[3] % 7;
        }
        else
        {
            this.weapon_special = 0;
        }
        if (this.weapon_grade == 1)
        {
            this.weapon_special_txt = 0;
        }
        else if (this.weapon_grade == 2)
        {
            this.weapon_special_txt = (this.weapon_special % 10) + 0x5b;
        }
        else if (this.weapon_grade == 3)
        {
            this.weapon_special_txt = (this.weapon_special % 10) + 0x65;
        }
        else if (this.weapon_grade == 4)
        {
            if (this.weapon_index < 0x10)
            {
                this.weapon_special_txt = (this.weapon_special % 10) + 0x65;
            }
            else
            {
                this.weapon_special_txt = (this.weapon_special % 10) + 0x6f;
            }
        }
    }
}


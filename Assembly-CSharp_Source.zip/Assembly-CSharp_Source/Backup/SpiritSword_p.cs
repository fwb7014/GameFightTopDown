using System;
using UnityEngine;

public class SpiritSword_p : MonoBehaviour
{
    private Vector3 directionVector;
    private float dt;
    private bool fireon;
    private Collider mycollider;
    private TrailRenderer mytrail;
    private Transform mytransform;
    private Transform target;
    private Vector3 targetpos;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
        this.mytrail = base.GetComponent<TrailRenderer>();
    }

    public void FireSword(Transform enemy)
    {
        this.mycollider.enabled = true;
        this.mytransform.parent = null;
        this.fireon = true;
        this.target = enemy;
        this.mytrail.enabled = true;
    }

    private void OnEnable()
    {
        this.mytransform.localScale = Vector3.right + Vector3.up;
        this.mycollider.enabled = false;
        this.dt = 0f;
    }

    private void Update()
    {
        if (this.fireon)
        {
            if (this.mytransform.position.y > 0f)
            {
                if (this.dt < 10f)
                {
                    this.dt += Time.deltaTime * 5f;
                }
                if (this.target != null)
                {
                    this.targetpos = this.target.position;
                }
                this.directionVector = this.targetpos - this.mytransform.position;
                if (this.directionVector != Vector3.zero)
                {
                    this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, Quaternion.LookRotation(this.directionVector), (4f * this.dt) * Time.deltaTime);
                }
                this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * 1.8f);
            }
            else
            {
                this.mycollider.enabled = false;
                this.mytrail.enabled = false;
                this.fireon = false;
                base.gameObject.active = false;
            }
        }
        else if (this.mytransform.localScale.z < 1f)
        {
            this.mytransform.localScale += (Vector3) ((Vector3.forward * Time.deltaTime) * 6f);
        }
        else
        {
            this.mytransform.localScale = Vector3.one;
        }
    }
}


using System;
using UnityEngine;

public class Flower_cannon : MonoBehaviour
{
    private Vector3 ballPos;
    private Vector3 ballPosStartPos;
    public Transform cannonball;
    private bool cannonshot;
    private float dy;
    private Animation myanimation;
    private float posY;
    private Trap_Extreme script_trap;
    private Transform target;
    private Vector3 targetPos;
    public Transform trap;

    public void CannonShot()
    {
        this.ballPos = this.ballPosStartPos;
        this.targetPos = this.target.position;
        this.dy = 1.5f;
        this.posY = this.ballPosStartPos.y;
        this.cannonshot = true;
    }

    public void FisnishShoot()
    {
        this.myanimation.Stop();
        this.myanimation.Play("flower_idle");
    }

    private void Start()
    {
        this.myanimation = base.animation;
        base.animation["flower"].speed = 0.1f;
        base.animation["flower_idle"].speed = 0.001f;
        this.target = GameObject.FindWithTag("Player").transform;
        this.script_trap = this.trap.GetComponent<Trap_Extreme>();
        this.ballPosStartPos = this.cannonball.position;
    }

    public void StartShoot()
    {
        this.myanimation.Play("flower");
    }

    private void Update()
    {
        if (this.cannonshot)
        {
            this.ballPos = Vector3.MoveTowards(this.ballPos, this.targetPos, Time.deltaTime);
            this.posY += Time.deltaTime * this.dy;
            this.dy -= Time.deltaTime * 2f;
            this.ballPos.y = this.posY;
            if (this.ballPos.y < 0f)
            {
                this.cannonshot = false;
                this.script_trap.DirectFire(this.ballPos);
                this.trap.GetChild(0).particleEmitter.Emit();
                this.trap.GetChild(1).particleEmitter.Emit();
                this.cannonball.position = (Vector3) (Vector3.up * 34f);
            }
            else
            {
                this.cannonball.position = this.ballPos;
            }
        }
    }
}


using System;
using UnityEngine;

public class UICampos : MonoBehaviour
{
    private void Start()
    {
        if (Crypto.Load_int_key("gamemode") == 0)
        {
            if (GameObject.Find("bg_worldmap") == null)
            {
                GameObject obj2 = Resources.Load("bg_worldmap") as GameObject;
                Transform transform = (Transform) UnityEngine.Object.Instantiate(obj2.transform, Vector3.zero, Quaternion.identity);
                transform.name = "bg_worldmap";
            }
            base.camera.projectionMatrix = Matrix4x4.Ortho(-1.8f, 1.8f, -1.2f, 1.2f, 0.3f, 5f);
            base.transform.position = PlayerPrefsX.GetVector3("uiCampos");
        }
        else
        {
            if (GameObject.Find("bg_dun") == null)
            {
                GameObject obj3 = Resources.Load("bg_dun") as GameObject;
                GameObject obj4 = Resources.Load("bg_dun_cover") as GameObject;
                GameObject obj5 = Resources.Load("bg_dun_below") as GameObject;
                Transform transform2 = (Transform) UnityEngine.Object.Instantiate(obj3.transform, new Vector3(0f, -0.15f, -1f), Quaternion.identity);
                Transform transform3 = (Transform) UnityEngine.Object.Instantiate(obj4.transform, new Vector3(0f, -0.15f, -0.5f), Quaternion.identity);
                Transform transform4 = (Transform) UnityEngine.Object.Instantiate(obj5.transform, new Vector3(0f, -0.15f, -1f), Quaternion.identity);
                transform2.name = "bg_dun";
                transform3.name = "bg_dun_cover";
                transform4.name = "bg_dun_below";
            }
            base.camera.projectionMatrix = Matrix4x4.Ortho(-1.5f, 1.5f, -1f, 1f, 0.3f, 5f);
            base.transform.position = PlayerPrefsX.GetVector3("uiCampos2");
        }
    }
}


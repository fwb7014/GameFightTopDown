using System;
using UnityEngine;

public class SoulStone_soul : MonoBehaviour
{
    private GameObject cha1;
    private Transform mytransform;
    private Cha_Control_ride_cha script_cha;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other == this.cha1.collider)
        {
            this.script_cha.GetSoulStone(1);
            this.mytransform.position = (Vector3) (-2f * Vector3.forward);
        }
    }

    private void Start()
    {
        this.cha1 = GameObject.FindWithTag("Player");
        this.script_cha = this.cha1.GetComponent<Cha_Control_ride_cha>();
        this.mytransform.rotation = Quaternion.Euler(0f, (float) UnityEngine.Random.Range(0, 360), 0f);
    }

    private void Update()
    {
        if (base.transform.position.z > -0.6f)
        {
            Transform transform = base.transform;
            transform.position += (Vector3) ((Vector3.forward * -1.8f) * Time.deltaTime);
            this.mytransform.Rotate((Vector3) ((Vector3.up * 500f) * Time.deltaTime));
        }
        else
        {
            this.mytransform.position = (Vector3) (-2f * Vector3.forward);
        }
    }
}


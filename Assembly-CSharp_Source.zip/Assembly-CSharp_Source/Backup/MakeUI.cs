using System;
using UnityEngine;

public class MakeUI : MonoBehaviour
{
    public Material main_material;
    public Material mat_txtresult;
    public Transform peticon_folder;
    private Transform skillicon_folder;

    public Transform Creat_result(Vector2 _size, Vector3 _pos, string _name)
    {
        GameObject obj2 = new GameObject(_name);
        MeshFilter filter = obj2.AddComponent<MeshFilter>();
        Mesh mesh = new Mesh();
        obj2.AddComponent<MeshRenderer>();
        mesh.vertices = new Vector3[] { new Vector3(-_size.x, _size.y, 0f) * 0.5f, new Vector3(_size.x, _size.y, 0f) * 0.5f, new Vector3(-_size.x, -_size.y, 0f) * 0.5f, new Vector3(_size.x, -_size.y, 0f) * 0.5f };
        mesh.uv = new Vector2[] { Vector2.zero, Vector2.zero, Vector2.zero, Vector2.zero };
        Renderer renderer = obj2.renderer;
        renderer.receiveShadows = false;
        renderer.castShadows = false;
        renderer.sharedMaterial = this.mat_txtresult;
        mesh.triangles = new int[] { 0, 1, 2, 2, 1, 3 };
        mesh.RecalculateNormals();
        filter.mesh = mesh;
        Transform transform = obj2.transform;
        transform.position += _pos;
        obj2.transform.parent = base.transform;
        obj2.layer = base.gameObject.layer;
        obj2.AddComponent("Txt_result");
        return obj2.transform;
    }

    public Transform Creat_star(Vector2 _size)
    {
        GameObject obj2 = new GameObject("star");
        MeshFilter filter = obj2.AddComponent<MeshFilter>();
        Mesh mesh = new Mesh();
        obj2.AddComponent<MeshRenderer>();
        mesh.vertices = new Vector3[] { new Vector3(-_size.x, _size.y, 0f) * 0.5f, new Vector3(_size.x, _size.y, 0f) * 0.5f, new Vector3(-_size.x, -_size.y, 0f) * 0.5f, new Vector3(_size.x, -_size.y, 0f) * 0.5f };
        mesh.uv = new Vector2[] { (Vector2) (Vector2.up * 0.25f), new Vector2(1f, 0.25f), Vector2.zero, Vector2.right };
        Renderer renderer = obj2.renderer;
        renderer.receiveShadows = false;
        renderer.castShadows = false;
        renderer.sharedMaterial = this.mat_txtresult;
        mesh.triangles = new int[] { 0, 1, 2, 2, 1, 3 };
        mesh.RecalculateNormals();
        filter.mesh = mesh;
        Transform transform = obj2.transform;
        transform.position += new Vector3(0f, 2.5f, 2f);
        obj2.transform.parent = base.transform;
        obj2.layer = base.gameObject.layer;
        obj2.AddComponent("Txt_star");
        return obj2.transform;
    }

    public Transform CreatCustomPlane(Vector2 _size, float _collidersize, Vector3 _pos, Vector2 _leftbottomUV, Vector2 _rightupUV, string _name, string _scriptname, float _skew, short skillicon)
    {
        GameObject obj2 = new GameObject(_name);
        MeshFilter filter = obj2.AddComponent<MeshFilter>();
        Mesh mesh = new Mesh();
        if (_collidersize > 0f)
        {
            SphereCollider collider = obj2.AddComponent<SphereCollider>();
            collider.radius = _collidersize;
            collider.isTrigger = true;
        }
        obj2.AddComponent<MeshRenderer>();
        mesh.vertices = new Vector3[] { new Vector3(-_size.x + _skew, _size.y, 0f) * 0.5f, new Vector3(_size.x + _skew, _size.y, 0f) * 0.5f, new Vector3(-_size.x, -_size.y, 0f) * 0.5f, new Vector3(_size.x, -_size.y, 0f) * 0.5f };
        mesh.uv = new Vector2[] { new Vector2(_leftbottomUV.x, _rightupUV.y), new Vector2(_rightupUV.x, _rightupUV.y), new Vector2(_leftbottomUV.x, _leftbottomUV.y), new Vector2(_rightupUV.x, _leftbottomUV.y) };
        Renderer renderer = obj2.renderer;
        renderer.receiveShadows = false;
        renderer.castShadows = false;
        renderer.sharedMaterial = this.main_material;
        mesh.triangles = new int[] { 0, 1, 2, 2, 1, 3 };
        mesh.RecalculateNormals();
        filter.mesh = mesh;
        Transform transform = obj2.transform;
        transform.position += _pos;
        if (skillicon == 0)
        {
            obj2.transform.parent = base.transform;
        }
        else if (skillicon == 1)
        {
            obj2.transform.parent = this.skillicon_folder;
        }
        else if (skillicon == 2)
        {
            obj2.transform.parent = this.peticon_folder;
        }
        obj2.layer = base.gameObject.layer;
        if (_scriptname != null)
        {
            obj2.AddComponent(_scriptname);
        }
        return obj2.transform;
    }

    private void Start()
    {
        this.skillicon_folder = GameObject.FindWithTag("icon_skill").transform;
    }
}


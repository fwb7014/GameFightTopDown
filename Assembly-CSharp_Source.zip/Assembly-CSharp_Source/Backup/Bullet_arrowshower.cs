using System;
using UnityEngine;

public class Bullet_arrowshower : MonoBehaviour
{
    private Transform c_arrow;
    private Transform cha1;
    private int damage;
    private Transform mytransform;
    public Transform sub_arrow;
    private Vector3 subarrowPos;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.cha1 = GameObject.FindWithTag("Player").transform;
        this.damage = base.GetComponent<WeaponDamage>().damage;
    }

    private void OnEnable()
    {
        this.mytransform.position = this.cha1.transform.position + new Vector3(UnityEngine.Random.Range((float) -0.04f, (float) 0.04f), 2f, UnityEngine.Random.Range((float) -0.04f, (float) 0.04f));
        for (int i = 0; i < 4; i++)
        {
            this.subarrowPos = ((Vector3) (UnityEngine.Random.insideUnitSphere * 0.5f)) + this.mytransform.position;
            this.c_arrow = (Transform) UnityEngine.Object.Instantiate(this.sub_arrow, this.subarrowPos, this.mytransform.rotation);
            this.c_arrow.GetComponent<WeaponDamage>().PressDamage(this.damage);
        }
    }

    private void Update()
    {
        if (this.mytransform.position.y > 0.2f)
        {
            this.mytransform.position -= (Vector3) ((Vector3.up * Time.deltaTime) * 3f);
        }
        else
        {
            base.gameObject.active = false;
            this.mytransform.position = (Vector3) (Vector3.one * 16f);
        }
    }
}


using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;

public static class Crypto
{
    private static string deviceid = "abcdefgh";
    private static string IV = "45287112549354892144548565456541";
    private static string KEY = "anjueolh";
    private static string KEY2 = string.Empty;
    public static long memberNo;
    public static int telecomPayCode;
    public static string usimsIndex = "CT";

    public static byte[] Decode(string str)
    {
        return Convert.FromBase64String(str);
    }

    public static string DecryptRJ256(byte[] cypher, string KeyString, string IVString)
    {
        UTF8Encoding encoding = new UTF8Encoding();
        byte[] bytes = encoding.GetBytes(KeyString);
        byte[] rgbIV = encoding.GetBytes(IVString);
        string str = string.Empty;
        RijndaelManaged managed = new RijndaelManaged {
            Mode = CipherMode.CBC,
            KeySize = 0x100,
            BlockSize = 0x100,
            Key = bytes,
            IV = rgbIV
        };
        try
        {
            MemoryStream stream = new MemoryStream(cypher);
            using (CryptoStream stream2 = new CryptoStream(stream, managed.CreateDecryptor(bytes, rgbIV), CryptoStreamMode.Read))
            {
                using (StreamReader reader = new StreamReader(stream2))
                {
                    str = reader.ReadLine();
                }
                stream2.Close();
            }
        }
        finally
        {
            managed.Clear();
        }
        return str;
    }

    public static string EncryptString(string message, string KeyString, string IVString)
    {
        byte[] bytes = Encoding.UTF8.GetBytes(KeyString);
        byte[] rgbIV = Encoding.UTF8.GetBytes(IVString);
        string str = null;
        RijndaelManaged managed = new RijndaelManaged {
            BlockSize = 0x100,
            Key = bytes,
            IV = rgbIV,
            Mode = CipherMode.CBC
        };
        try
        {
            MemoryStream stream = new MemoryStream();
            using (CryptoStream stream2 = new CryptoStream(stream, managed.CreateEncryptor(bytes, rgbIV), CryptoStreamMode.Write))
            {
                using (StreamWriter writer = new StreamWriter(stream2))
                {
                    writer.Write(message);
                    writer.Close();
                }
                stream2.Close();
            }
            str = Convert.ToBase64String(stream.ToArray());
            stream.Close();
        }
        catch (CryptographicException exception)
        {
            Console.WriteLine("A Cryptographic error occurred: {0}", exception.Message);
            return null;
        }
        catch (UnauthorizedAccessException exception2)
        {
            Console.WriteLine("A file error occurred: {0}", exception2.Message);
            return null;
        }
        catch (Exception exception3)
        {
            Console.WriteLine("An error occurred: {0}", exception3.Message);
        }
        finally
        {
            managed.Clear();
        }
        return str;
    }

    public static void Init()
    {
        deviceid = SystemInfo.deviceUniqueIdentifier;
        deviceid = deviceid + "somissu2";
        KEY = deviceid.Substring(0, 8);
        deviceid = AndroidScript.i.getDeviceId();
        deviceid = deviceid + "somissu2";
        KEY2 = deviceid.Substring(0, 8);
    }

    public static int Load_int_key(string _kind)
    {
        string str = _kind + "hideahidea";
        string str2 = PlayerPrefs.GetString(_kind);
        string str3 = string.Empty;
        try
        {
            str3 = DecryptRJ256(Decode(str2), KEY + str.Substring(0, 8), IV);
            char[] chArray = str3.ToCharArray();
            bool flag = false;
            for (int i = 0; i < chArray.Length; i++)
            {
                char ch = char.Parse(chArray[i].ToString());
                if ((ch < '!') || (ch > '~'))
                {
                    flag = true;
                    break;
                }
            }
            if (flag)
            {
                str3 = DecryptRJ256(Decode(str2), KEY2 + str.Substring(0, 8), IV);
            }
        }
        catch (Exception)
        {
            str3 = DecryptRJ256(Decode(str2), KEY2 + str.Substring(0, 8), IV);
        }
        return Convert.ToInt32(str3);
    }

    public static string Load_string_key(string _kind)
    {
        string str = _kind + "hideahidea";
        string str2 = PlayerPrefs.GetString(_kind);
        try
        {
            string str4 = DecryptRJ256(Decode(str2), KEY + str.Substring(0, 8), IV);
            char ch = char.Parse(str4.Substring(0, 1));
            if ((ch >= '!') && (ch <= '~'))
            {
                return str4;
            }
            return DecryptRJ256(Decode(str2), KEY2 + str.Substring(0, 8), IV);
        }
        catch (Exception)
        {
            return DecryptRJ256(Decode(str2), KEY2 + str.Substring(0, 8), IV);
        }
    }

    public static bool Property_change(int _value, bool _jade)
    {
        int num = 0;
        if (_jade)
        {
            num = Load_int_key("n24");
        }
        else
        {
            num = Load_int_key("n17");
        }
        if ((_value < 0) && (num < (_value * -1)))
        {
            return false;
        }
        if (_jade)
        {
            Save_int_key("n24", num + _value);
        }
        else
        {
            Save_int_key("n17", num + _value);
        }
        return true;
    }

    public static Rect Rect2(float _posx, float _posy, float _width, float _height)
    {
        return new Rect(_posx * 2f, _posy * 2f, _width * 2f, _height * 2f);
    }

    public static void Save_int_key(string _kind, int _key_int)
    {
        string str = _kind + "hideahidea";
        string str2 = EncryptString(_key_int.ToString(), KEY + str.Substring(0, 8), IV);
        PlayerPrefs.SetString(_kind, str2);
    }

    public static void Save_string_key(string _kind, string _key_string)
    {
        string str = _kind + "hideahidea";
        string str2 = EncryptString(_key_string, KEY + str.Substring(0, 8), IV);
        PlayerPrefs.SetString(_kind, str2);
    }

    public static void SetTelecomPayCode(int _code)
    {
        telecomPayCode = _code;
    }

    public static void SetUsim(string index)
    {
        usimsIndex = index;
    }
}


using System;
using UnityEngine;

public class RepeatDamage : MonoBehaviour
{
    private Collider mycollider;
    public float repeatdelay = 0.2f;
    public float startdelay = 0.5f;

    private void Awake()
    {
        this.mycollider = base.collider;
    }

    public void ColliderClick()
    {
        this.mycollider.enabled = true;
    }

    public void DamageCancel()
    {
        base.CancelInvoke();
    }

    private void OnEnable()
    {
        base.InvokeRepeating("ColliderClick", this.startdelay, this.repeatdelay);
    }
}


using System;
using UnityEngine;

public class Bullet_Angel4_m : MonoBehaviour
{
    private float bullet_speed = -1f;
    private Vector3 dir;
    private Vector3 myPos;
    private Transform mytransform;
    private Vector3 originScale;
    private int side;
    private float side_speed;
    private Vector3 sidedir;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.originScale = this.mytransform.localScale;
        base.gameObject.active = false;
    }

    public void Init(int _side)
    {
        this.side = _side;
    }

    private void OnEnable()
    {
        this.mytransform.localScale = Vector3.zero;
        this.bullet_speed = -2f;
        this.side_speed = 0.2f + UnityEngine.Random.Range((float) -0.1f, (float) 0.1f);
        this.dir = this.mytransform.forward;
        this.sidedir = this.mytransform.right * this.side;
    }

    private void Update()
    {
        this.myPos = this.mytransform.position;
        this.bullet_speed += Time.deltaTime * 6f;
        this.side_speed = Mathf.Lerp(this.side_speed, 0f, Time.deltaTime * 2f);
        this.mytransform.localScale = Vector3.Lerp(this.mytransform.localScale, this.originScale, Time.deltaTime * 4f);
        this.myPos += (Vector3) ((this.sidedir * Time.deltaTime) * this.side_speed);
        this.myPos += (Vector3) ((this.dir * Time.deltaTime) * this.bullet_speed);
        if (this.mytransform.position.y < 0f)
        {
            this.mytransform.root.GetComponent<Bullet_Angel4>().SplashOn(this.myPos);
            base.gameObject.active = false;
        }
        this.mytransform.position = this.myPos;
    }
}


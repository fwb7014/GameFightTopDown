using System;
using UnityEngine;

[Serializable]
public class BendingSegment
{
    internal float angleH;
    internal float angleV;
    public float bendingMultiplier = 0.6f;
    internal int chainLength;
    internal Vector3 dirUp;
    public Transform firstTransform;
    public Transform lastTransform;
    public float maxAngleDifference = 30f;
    public float maxBendingAngle = 80f;
    internal Quaternion[] origRotations;
    internal Vector3 referenceLookDir;
    internal Vector3 referenceUpDir;
    public float responsiveness = 5f;
    public float thresholdAngleDifference;
}


using System;
using UnityEngine;

public class Ef_boom : MonoBehaviour
{
    private Collider mycollider;
    private Material mymaterial;
    private ParticleEmitter myparticle;
    private Transform mytransform;
    public Texture2D[] pttex = new Texture2D[3];

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myparticle = base.particleEmitter;
        this.mymaterial = base.renderer.sharedMaterial;
        this.mycollider = base.collider;
    }

    private void EmitStop()
    {
        this.myparticle.emit = false;
        this.mycollider.enabled = false;
        this.mytransform.position = (Vector3) (Vector3.up * 11f);
    }

    public void SetTex(int _index, Vector3 _pos, bool _collider)
    {
        _pos[1] = 0.02f;
        this.mytransform.position = _pos;
        this.myparticle.emit = false;
        this.myparticle.ClearParticles();
        this.myparticle.emit = true;
        this.mymaterial.SetTexture("_MainTex", this.pttex[_index]);
        if (_collider)
        {
            this.mycollider.enabled = true;
        }
        base.Invoke("EmitStop", 0.5f);
    }
}


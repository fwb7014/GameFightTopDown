using System;
using UnityEngine;

public class Bullet_trigger : MonoBehaviour
{
    public float bullet_speed;
    public Transform bullet_splash;
    private Transform c_splash;
    private float delay_finish;
    private Transform mytransform;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == 8)
        {
            this.c_splash.position = this.mytransform.position + ((Vector3) (this.mytransform.forward * 0.1f));
            this.c_splash.gameObject.active = true;
            base.gameObject.active = false;
            this.mytransform.position = (Vector3) (Vector3.one * 4f);
        }
    }

    private void Start()
    {
        this.c_splash = (Transform) UnityEngine.Object.Instantiate(this.bullet_splash, this.mytransform.position, Quaternion.identity);
        this.c_splash.gameObject.active = false;
        this.c_splash.rigidbody.mass = base.rigidbody.mass;
    }

    private void Update()
    {
        if (this.delay_finish > 0.4f)
        {
            base.gameObject.active = false;
            this.delay_finish = 0f;
        }
        this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * this.bullet_speed);
    }
}


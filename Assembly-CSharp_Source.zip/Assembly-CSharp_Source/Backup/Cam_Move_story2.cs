using System;
using UnityEngine;

public class Cam_Move_story2 : MonoBehaviour
{
    public GUISkin basic;
    public GUIStyle bt_skip;
    public Texture2D cha_cutin;
    private string chaname;
    private float color_alpha;
    private int language;
    private bool showcut;
    private string speech;
    private bool trans;
    public Texture2D txt_box;
    private float updelay;

    private void OnGUI()
    {
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.skin = this.basic;
        GUI.depth = -5;
        GUI.color = new Color(1f, 1f, 1f, this.color_alpha);
        GUI.DrawTexture(Crypto.Rect2(216f, 0f, 320f, 320f), this.cha_cutin);
        if (base.transform.position.z < -3.2f)
        {
            this.showcut = false;
        }
        else if (base.transform.position.z < -1.2f)
        {
            this.showcut = true;
            GUI.Label(Crypto.Rect2(0f, 280f, 480f, 20f), this.chaname, "txt12_w");
            GUI.DrawTexture(Crypto.Rect2(80f, 40f, 256f, 64f), this.txt_box);
            GUI.Label(Crypto.Rect2(88f, 60f, 240f, 20f), this.speech, "txt12_0");
        }
        if (GUI.Button(Crypto.Rect2(400f, 290f, 64f, 32f), "NEXT", this.bt_skip))
        {
            GameObject.Find("scene_trans").GetComponent<Story_trans>().ScreenOn(1f);
        }
    }

    public void ShowOff()
    {
        this.color_alpha = 0f;
    }

    private void Start()
    {
        base.camera.projectionMatrix = Matrix4x4.Perspective(30f, 1.5f, 0.01f, 10f);
        this.language = PlayerPrefs.GetInt("language");
        this.chaname = Language.intxt[this.language, 0x47] + " , 26 " + Language.intxt[this.language, 0x169];
        if (Crypto.Load_int_key("n06") != -1)
        {
            UnityEngine.Object.Destroy(GameObject.Find("back_head"));
            this.cha_cutin = Resources.Load("cc_cha3") as Texture2D;
            this.speech = Language.intxt[this.language, 0x175];
        }
        else
        {
            this.speech = Language.intxt[this.language, 0x31];
        }
    }

    private void Update()
    {
        this.updelay += Time.deltaTime * 0.1f;
        Transform transform = base.transform;
        transform.position -= (Vector3) ((new Vector3(0f, 0f, 1f) * Time.deltaTime) * this.updelay);
        if ((base.transform.position.z < -4f) && !this.trans)
        {
            GameObject.Find("scene_trans").GetComponent<Story_trans>().ScreenOn(2f);
            this.trans = true;
            this.updelay = 0f;
        }
        if (this.showcut)
        {
            if (this.color_alpha < 1f)
            {
                this.color_alpha += Time.deltaTime * 2f;
            }
            else
            {
                this.color_alpha = 1f;
            }
        }
        else if (this.color_alpha > 0f)
        {
            this.color_alpha -= Time.deltaTime * 2f;
        }
        else
        {
            this.color_alpha = 0f;
        }
    }
}


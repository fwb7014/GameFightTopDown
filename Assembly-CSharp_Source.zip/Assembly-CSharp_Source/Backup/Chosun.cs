using System;
using UnityEngine;

public class Chosun : MonoBehaviour
{
    private bool attack;
    private int attack_count;
    private float attack_delay;
    private Transform cha1;
    private Vector3 directionVector;
    private Vector3 edgepos;
    private bool flystart;
    private Collider mycollider;
    private Transform mytransform;
    public Transform pt_leaf;
    private Vector3 rndPos;
    private Vector3 targetpos;

    private void Awake()
    {
        this.mytransform = base.transform;
        base.animation["appear"].speed = 2.2f;
        base.animation["fly_chosun"].speed = 0.2f;
        this.mycollider = base.collider;
        this.mycollider.enabled = false;
    }

    private void OnEnable()
    {
        base.animation["appear"].speed = 0f;
        base.animation.Play("appear");
        base.animation.PlayQueued("fly_chosun").speed = 0.25f;
        this.attack = false;
        this.mycollider.enabled = false;
        this.pt_leaf.particleEmitter.emit = true;
        this.flystart = false;
        this.attack_count = 0;
        this.attack_delay = 0f;
    }

    private void Start()
    {
        this.cha1 = GameObject.FindWithTag("Player").transform;
    }

    private void Update()
    {
        if (!this.flystart)
        {
            if (this.attack_delay > 0.1f)
            {
                base.animation["appear"].speed = 2.2f;
                Time.timeScale = 0.1f;
                this.flystart = true;
            }
            else
            {
                this.attack_delay += Time.deltaTime;
            }
        }
        else if (!this.attack)
        {
            if (base.animation.IsPlaying("fly_chosun"))
            {
                this.attack = true;
                this.attack_delay = 1.2f;
                base.animation["appear"].speed = 0.25f;
                Time.timeScale = 1f;
                base.audio.Play();
            }
        }
        else if (this.attack_delay > 0.5f)
        {
            this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * 2.5f);
            this.attack_delay -= Time.deltaTime;
            this.mycollider.enabled = true;
        }
        else if (this.attack_delay > 0f)
        {
            this.attack_delay -= Time.deltaTime;
            this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * 4f);
            this.mycollider.enabled = false;
        }
        else
        {
            this.attack_delay = 1.2f;
            this.edgepos = (Vector3) (UnityEngine.Random.onUnitSphere * 1f);
            this.edgepos[1] = 0f;
            this.attack_count++;
            if (this.attack_count >= 6)
            {
                this.mytransform.position = (Vector3) (Vector3.one * 15f);
                base.gameObject.active = false;
                this.mycollider.enabled = false;
                this.pt_leaf.particleEmitter.emit = false;
            }
            else if (this.attack)
            {
                this.rndPos = this.cha1.position + this.edgepos;
                this.directionVector = this.cha1.position - this.rndPos;
                this.mytransform.position = this.rndPos;
                base.audio.Play();
                if (this.directionVector != Vector3.zero)
                {
                    this.mytransform.rotation = Quaternion.LookRotation(this.directionVector);
                }
            }
        }
    }
}


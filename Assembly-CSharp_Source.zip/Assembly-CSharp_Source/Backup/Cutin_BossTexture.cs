using System;
using UnityEngine;

public class Cutin_BossTexture : MonoBehaviour
{
    public GUISkin basicSkin;
    private int cutindex = 1;
    private int language = 1;
    private Texture2D nameimg;
    private bool nameon;
    private float namepos;
    private float starttime;

    private void Awake()
    {
        this.language = PlayerPrefs.GetInt("language");
    }

    private void OnGUI()
    {
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.skin = this.basicSkin;
        GUI.depth = -8;
        if (this.nameon)
        {
            GUI.DrawTexture(Crypto.Rect2(this.namepos, 200f, 200f, 100f), this.nameimg);
            GUI.Label(Crypto.Rect2(this.namepos + 40f, 294f, 128f, 24f), Language.intxt[this.language, 0x4a + this.cutindex], "txt14_w");
        }
    }

    public void SetCutinTexture(int _index)
    {
        this.cutindex = _index;
        string str = this.cutindex.ToString();
        base.renderer.material.mainTexture = Resources.Load("portrait_boss" + str) as Texture;
        this.nameimg = Resources.Load("name_boss" + str) as Texture2D;
        this.starttime = Time.realtimeSinceStartup;
        this.nameon = true;
    }

    private void Update()
    {
        this.namepos = Mathf.MoveTowards(-100f, 10f, (Time.realtimeSinceStartup - this.starttime) * 1000f);
    }
}


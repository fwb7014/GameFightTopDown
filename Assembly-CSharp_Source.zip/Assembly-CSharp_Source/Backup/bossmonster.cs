using System;
using System.Runtime.InteropServices;
using UnityEngine;

[StructLayout(LayoutKind.Sequential)]
public struct bossmonster
{
    public short _level;
    public short _maxhp;
    public short _power1;
    public short _power2;
    public short _power3;
    public short _haveExp;
    public short _block;
    public short _sizekind;
    public float _runspeed;
    public float _turnspeed;
    public float _firerange1;
    public float _firerange2;
    public float _firerange3;
    public short _dash1;
    public short _dash2;
    public short _dash3;
    public Vector2 _moving_atk1;
    public Vector2 _moving_atk2;
    public Vector2 _moving_atk3;
    public short _attach_ef1;
    public short _attach_ef2;
    public short _attach_ef3;
    public bool _collideroff1;
    public bool _collideroff2;
    public bool _collideroff3;
    public float _speed_move;
    public float _speed_down;
    public float _speed_down_high;
    public float _speed_b_attack1;
    public float _speed_b_attack1_i;
    public float _speed_b_attack2;
    public float _speed_b_attack2_i;
    public float _speed_b_attack3;
    public float _speed_b_attack3_i;
    public float _speed_idle;
}


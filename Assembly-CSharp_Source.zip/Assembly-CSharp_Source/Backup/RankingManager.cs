using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class RankingManager : MonoBehaviour
{
    private int factor = 2;
    private int gameNo;
    public bool imagefinish;
    public bool loadfinish;
    public int maxfriend;
    private const int MAXRANKING = 50;
    public int mygrade;
    public int mypoint;
    private short range = 1;
    public string resettime;
    private short scopemode;
    public Texture2D[] userimg = new Texture2D[50];
    public string[] username = new string[50];
    public int[] userpoint = new int[50];

    private void Awake()
    {
    }

    [DebuggerHidden]
    private IEnumerator ImageLoading(int _imagecount, string _url)
    {
        return new <ImageLoading>c__Iterator11 { _url = _url, _imagecount = _imagecount, <$>_url = _url, <$>_imagecount = _imagecount, <>f__this = this };
    }

    public void S_LoadRanking(int _factor, short _all, short _range)
    {
        DateTime time = DateTime.Now.ToUniversalTime();
        time = time.AddHours((double) (-time.Hour + 0x15));
        time = time.AddMinutes((double) -time.Minute);
        time = time.AddSeconds((double) -time.Second);
        this.factor = _factor;
        DayOfWeek dayOfWeek = time.DayOfWeek;
        int num = 0 - dayOfWeek;
        if (num < 0)
        {
            time = time.AddDays((double) (num + 7));
        }
        else
        {
            time = time.AddDays((double) num);
        }
        this.resettime = time.ToLocalTime().ToString("MM/dd hh:mm tt");
        this.loadfinish = false;
        this.imagefinish = false;
        this.scopemode = _all;
        this.range = _range;
    }

    private void Start()
    {
        UnityEngine.Object.DontDestroyOnLoad(base.gameObject);
    }

    [CompilerGenerated]
    private sealed class <ImageLoading>c__Iterator11 : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal int _imagecount;
        internal string _url;
        internal int <$>_imagecount;
        internal string <$>_url;
        internal RankingManager <>f__this;
        internal WWW <www>__0;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<www>__0 = new WWW(this._url);
                    this.$current = this.<www>__0;
                    this.$PC = 1;
                    return true;

                case 1:
                    if (this.<www>__0.error == null)
                    {
                        this.<>f__this.userimg[this._imagecount] = this.<www>__0.texture;
                    }
                    if ((this.<>f__this.maxfriend - 1) == this._imagecount)
                    {
                        this.<>f__this.imagefinish = true;
                    }
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }
}


using System;
using UnityEngine;

public class SoulStone_obj : MonoBehaviour
{
    private GameObject cha1;
    private Transform mytransform;
    public Transform obj_break;
    private Cha_Control_ride_cha script_cha;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other == this.cha1.collider)
        {
            UnityEngine.Object.Instantiate(this.obj_break, this.mytransform.position, this.mytransform.rotation);
            this.script_cha.FallDown();
            this.mytransform.position = (Vector3) (-2f * Vector3.forward);
        }
        else if (other.gameObject.layer == 8)
        {
            UnityEngine.Object.Instantiate(this.obj_break, this.mytransform.position, this.mytransform.rotation);
            this.mytransform.position = (Vector3) (-2f * Vector3.forward);
        }
    }

    private void Start()
    {
        this.cha1 = GameObject.FindWithTag("Player");
        this.script_cha = this.cha1.GetComponent<Cha_Control_ride_cha>();
    }

    private void Update()
    {
        if (base.transform.position.z > -0.6f)
        {
            Transform transform = base.transform;
            transform.position += (Vector3) ((Vector3.forward * -1.8f) * Time.deltaTime);
        }
        else
        {
            this.mytransform.position = (Vector3) (-2f * Vector3.forward);
        }
    }
}


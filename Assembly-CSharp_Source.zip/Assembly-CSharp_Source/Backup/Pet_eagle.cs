using System;
using UnityEngine;

public class Pet_eagle : MonoBehaviour
{
    private bool anispeedchange;
    private Transform cha1;
    private int currentmotion;
    private Vector3 directionVector;
    private Vector3 edgepos;
    private Transform finditem;
    private float finishdelay = -3f;
    private float flyspeed = 0.5f;
    private float getitem_delay;
    private int itembehaviour;
    private Animation myanimation;
    private Transform mytransform;
    private Vector3 rndPos;
    private Quaternion rotate;
    private float skilldelay = 2f;
    private bool skillon;
    private Vector3 tochaV;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myanimation = base.animation;
        this.cha1 = GameObject.FindWithTag("Player").transform;
    }

    public void GetItem(Transform _finditem)
    {
        if ((this.itembehaviour == 0) && !this.skillon)
        {
            this.finishdelay = 5.5f;
            this.finditem = _finditem;
            this.itembehaviour = 1;
            this.directionVector = this.finditem.position - this.mytransform.position;
            this.directionVector[1] = 0f;
            base.CancelInvoke("LoadDir");
            base.CancelInvoke("SetRndPosition");
        }
    }

    public void LoadDir()
    {
        this.rndPos = this.cha1.position + this.edgepos;
        this.directionVector = this.rndPos - this.mytransform.position;
        this.directionVector[1] = 0f;
        if (this.directionVector != Vector3.zero)
        {
            this.rotate = Quaternion.LookRotation(this.directionVector);
        }
    }

    public void OnEnable()
    {
        base.InvokeRepeating("LoadDir", 0.1f, 0.1f);
        base.InvokeRepeating("SetRndPosition", 0.1f, 2f);
        float num = (2 * UnityEngine.Random.Range(0, 2)) - 1;
        float num2 = (2 * UnityEngine.Random.Range(0, 2)) - 1;
        this.finishdelay = 0f;
        this.edgepos = new Vector3(num * 0.6f, 0.3f, num2 * 0.5f);
        this.mytransform.position = this.cha1.position + this.edgepos;
        this.flyspeed = 0.5f;
        this.myanimation.CrossFade("fly_flap");
    }

    public void SetRndPosition()
    {
        this.edgepos = (Vector3) (UnityEngine.Random.insideUnitSphere * 0.1f);
        this.edgepos[1] = 0.3f;
        this.currentmotion = UnityEngine.Random.Range(0, 10);
        if ((this.currentmotion < 7) || this.skillon)
        {
            this.myanimation.CrossFade("fly_flap");
        }
        else
        {
            this.myanimation.CrossFade("fly_glide");
        }
    }

    public void SkillOff()
    {
        this.skillon = false;
        this.anispeedchange = true;
    }

    public void SkillOn()
    {
        this.skillon = true;
        this.anispeedchange = true;
    }

    private void Start()
    {
        this.myanimation["fly_glide"].layer = 1;
        this.myanimation["fly_flap"].layer = 1;
        this.myanimation["fly_glide"].speed = 0.4f;
        this.myanimation["fly_flap"].speed = 0.4f;
        this.finishdelay = -3f;
    }

    private void Update()
    {
        if (this.skillon)
        {
            if (this.skilldelay > 0f)
            {
                this.mytransform.position = Vector3.Lerp(this.mytransform.position, this.cha1.position + ((Vector3) (Vector3.up * 0.3f)), Time.deltaTime * 6f);
                this.skilldelay -= Time.deltaTime;
                this.tochaV = this.cha1.position - this.mytransform.position;
                this.tochaV[1] = 0f;
                if (this.tochaV != Vector3.zero)
                {
                    this.mytransform.rotation = Quaternion.LookRotation(this.tochaV);
                }
            }
            else
            {
                this.mytransform.position = this.cha1.position + ((Vector3) (Vector3.up * 0.3f));
                this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, this.cha1.rotation, Time.deltaTime * 3f);
                if (this.anispeedchange)
                {
                    this.myanimation["fly_flap"].speed = 0.7f;
                    this.anispeedchange = false;
                }
            }
        }
        else if (this.itembehaviour == 1)
        {
            if (this.finditem.gameObject.active)
            {
                this.myanimation.CrossFade("fly_flap");
                this.getitem_delay += Time.deltaTime;
                if (this.getitem_delay > 2.5f)
                {
                    this.getitem_delay = 0f;
                    this.itembehaviour = 2;
                }
                else if (this.getitem_delay > 2.2f)
                {
                    this.finditem.position = Vector3.MoveTowards(this.finditem.position, this.mytransform.position, Time.deltaTime);
                }
                this.mytransform.position = Vector3.Lerp(this.mytransform.position, this.finditem.position, Time.deltaTime * 2f);
                if (this.directionVector != Vector3.zero)
                {
                    this.mytransform.rotation = Quaternion.LookRotation(this.directionVector);
                }
            }
            else
            {
                this.itembehaviour = 0;
            }
        }
        else if (this.itembehaviour == 2)
        {
            if (this.finditem.gameObject.active)
            {
                this.getitem_delay += Time.deltaTime;
                if (this.getitem_delay > 2f)
                {
                    this.itembehaviour = 0;
                    this.getitem_delay = 0f;
                }
                else if (this.getitem_delay > 1f)
                {
                    this.finditem.position = Vector3.MoveTowards(this.finditem.position, this.cha1.position, Time.deltaTime * 1.2f);
                    this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * 0.8f);
                }
                else
                {
                    this.directionVector = this.cha1.position - this.mytransform.position;
                    this.directionVector[1] = 0f;
                    if (this.directionVector != Vector3.zero)
                    {
                        this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, Quaternion.LookRotation(this.directionVector), Time.deltaTime * 3f);
                    }
                    this.mytransform.position = Vector3.Lerp(this.mytransform.position, this.cha1.position + ((Vector3) (Vector3.up * 0.3f)), Time.deltaTime * 2f);
                    this.finditem.position = this.mytransform.position - ((Vector3) (Vector3.up * 0.1f));
                }
            }
            else
            {
                this.itembehaviour = 0;
            }
        }
        else
        {
            this.finishdelay += Time.deltaTime;
            if (this.finishdelay > 8f)
            {
                this.flyspeed = 1f;
                base.CancelInvoke("LoadDir");
                base.CancelInvoke("SetRndPosition");
                if (this.finishdelay > 9.5f)
                {
                    base.gameObject.active = false;
                    this.mytransform.position = (Vector3) (Vector3.one * 8f);
                }
            }
            if (this.anispeedchange)
            {
                this.myanimation["fly_flap"].speed = 0.4f;
                this.anispeedchange = false;
            }
            this.skilldelay = 2f;
            this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, this.rotate, Time.deltaTime * 1.6f);
            this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * this.flyspeed);
        }
    }
}


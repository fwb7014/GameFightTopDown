using System;
using UnityEngine;

public class Dun_Snake : MonoBehaviour
{
    private float delay = 3f;
    public Transform holes;
    private Animation myanimation;
    private Transform mytransform;
    private Trap_Extreme script_trap1;
    private Trap_Extreme script_trap2;
    private float speed;
    private Vector3 startpos;
    private Vector3 targetpos;
    public Transform trap1;
    public Transform trap2;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myanimation = base.animation;
        base.animation["snake_move"].speed = 0.3f;
        this.script_trap1 = this.trap1.GetComponent<Trap_Extreme>();
        this.script_trap2 = this.trap2.GetComponent<Trap_Extreme>();
    }

    public void FisnishShoot()
    {
        this.myanimation.Stop();
    }

    private void OnEnable()
    {
    }

    private void PtOn2()
    {
        this.script_trap2.DirectFire(this.targetpos);
        this.trap2.GetChild(0).particleEmitter.emit = true;
    }

    public void SetDamage(int _damage)
    {
        this.script_trap1.SetDamage(_damage);
        this.script_trap2.SetDamage(_damage);
    }

    private void Start()
    {
        this.mytransform.position = (Vector3) (Vector3.up * 25f);
        this.delay = 2f;
    }

    public void StartShoot()
    {
        this.delay = UnityEngine.Random.Range((float) 2f, (float) 3.6f);
        int index = UnityEngine.Random.Range(0, 7);
        this.startpos = this.holes.GetChild(index).position;
        int num2 = 0;
        if (index == 0)
        {
            num2 = UnityEngine.Random.Range(1, 7);
        }
        else
        {
            int num3 = UnityEngine.Random.Range(0, 5);
            if (num3 == 0)
            {
                num2 = 0;
            }
            else if ((num3 % 2) == 0)
            {
                num2 = (index + 1) % 7;
            }
            else
            {
                num2 = (index - 1) % 7;
            }
        }
        this.targetpos = this.holes.GetChild(num2).position;
        Vector3 vector = this.startpos - this.targetpos;
        this.mytransform.position = this.startpos;
        this.mytransform.forward = vector;
        this.myanimation.Play("snake_move");
        this.script_trap1.DirectFire(this.startpos);
        this.trap1.GetChild(0).particleEmitter.emit = true;
        base.Invoke("PtOn2", 0.6f);
    }

    private void Update()
    {
    }
}


using System;
using UnityEngine;

public class Wing : MonoBehaviour
{
    private float delay;
    private Animation myanimation;
    private Transform mytransform;
    private Transform wingmesh;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myanimation = base.animation;
        this.wingmesh = this.mytransform.GetChild(2);
    }

    private void OnEnable()
    {
        this.wingmesh.gameObject.active = true;
        this.myanimation.Play("wing_start");
        this.delay = 0f;
    }

    private void Start()
    {
        this.myanimation["wing_fly"].speed = 0.5f;
        this.myanimation["wing_attack"].speed = 0.25f;
        this.myanimation["wing_start"].speed = 2.2f;
    }

    private void Update()
    {
        this.delay += Time.deltaTime;
        if (this.delay > 4f)
        {
            base.gameObject.active = false;
            this.wingmesh.gameObject.active = false;
            this.myanimation.Stop();
        }
        else if (this.delay > 3f)
        {
            this.myanimation.CrossFade("wing_attack");
        }
        else if (this.delay > 0.6f)
        {
            this.myanimation.Play("wing_fly");
        }
    }
}


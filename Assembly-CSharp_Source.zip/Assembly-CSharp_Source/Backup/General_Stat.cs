using System;
using UnityEngine;

public class General_Stat : MonoBehaviour
{
    public float g_atkspd;
    public short g_def;
    public short g_grade;
    public short g_level;
    public short g_maxatk;
    public short g_maxhp;
    public short g_unique = -1;
    public short general_index;
    public short general_kind;
    private const int GENERALKIND = 5;
    private int[] rndkey = new int[8];
    private int[] rndkey_og = new int[8];

    public void SetGeneral(int _seed)
    {
        this.general_index = (short) ((_seed % 0x989680) / 0x186a0);
        this.general_kind = (short) (this.general_index % 5);
        this.g_level = (short) (((float) _seed) / 1E+07f);
        if (this.general_index < 10)
        {
            this.g_unique = this.general_index;
        }
        else
        {
            this.g_unique = -1;
        }
        for (int i = 0; i < 8; i++)
        {
            this.rndkey_og[i] = _seed % 10;
            _seed /= 10;
            this.rndkey[i] = this.rndkey_og[i];
        }
        this.g_grade = (short) this.rndkey_og[4];
        for (int j = 0; j < (this.g_level - 1); j++)
        {
            this.rndkey[j % 4]++;
            if ((j != 0) && ((j % 4) == 0))
            {
                this.rndkey[(this.rndkey_og[j % 4] + this.general_index) % 4]++;
            }
        }
        this.g_maxatk = (short) (((((this.rndkey_og[0] * 0.5f) + (this.rndkey[0] - this.rndkey_og[0])) + this.g_level) + 3f) + (this.g_grade * 2));
        this.g_def = (short) ((((this.rndkey_og[1] * 0.5f) + 1f) + (this.rndkey[1] - this.rndkey_og[1])) + (this.g_grade * 2));
        this.g_maxhp = (short) (((this.rndkey[2] * 10) + 60) + (this.g_grade * 10));
        this.g_atkspd = (0.01f + (this.rndkey[3] * 0.002f)) + (this.g_grade * 0.004f);
    }
}


using System;
using UnityEngine;

public class GiftBox_extreme : MonoBehaviour
{
    private bool drop_impact;
    public Transform ef_risingitem;
    private int itemrate = 70;
    private bool itemrising;
    private UI_Ingame script_ingameUI;
    public AudioClip snd_drop;
    public AudioClip snd_open;

    private void Awake()
    {
        base.animation["invisible"].speed = 0.06f;
        base.animation["open_box"].speed = 0.25f;
        base.animation["drop"].speed = 0.3f;
        base.animation.Play("invisible");
        base.gameObject.active = false;
        this.script_ingameUI = GameObject.Find("UI_Ingame").GetComponent<UI_Ingame>();
    }

    private void OnEnable()
    {
        this.drop_impact = false;
        base.animation.Play("drop");
        base.animation.PlayQueued("drop_i").speed = 0.3f;
        this.ef_risingitem.position = base.transform.position;
    }

    private void OnTriggerEnter(Collider other)
    {
        this.OpenBox();
        base.collider.enabled = false;
    }

    private void OpenBox()
    {
        base.audio.PlayOneShot(this.snd_open);
        base.animation.Play("open_box");
        this.itemrising = true;
        this.ef_risingitem.particleEmitter.emit = true;
        if (this.script_ingameUI.angelOn)
        {
            this.script_ingameUI.GetAngel();
        }
        else if (UnityEngine.Random.Range(0, 100) > this.itemrate)
        {
            this.itemrate = 70;
            this.script_ingameUI.GetGeneral();
        }
        else
        {
            this.itemrate -= 10;
            this.script_ingameUI.GetCoin();
        }
        this.script_ingameUI.IntermissionOff();
    }

    private void Update()
    {
        if (!this.drop_impact)
        {
            if (base.animation.IsPlaying("drop_i"))
            {
                this.drop_impact = true;
                base.audio.PlayOneShot(this.snd_drop);
                base.collider.enabled = true;
            }
        }
        else if (this.itemrising)
        {
            if (this.ef_risingitem.position.y < 1f)
            {
                this.ef_risingitem.position += (Vector3) (Vector3.up * Time.deltaTime);
            }
            else
            {
                this.itemrising = false;
                this.ef_risingitem.particleEmitter.emit = false;
            }
        }
    }
}


using System;
using UnityEngine;

public class MeshExchange : MonoBehaviour
{
    public Transform getcha;
    private SkinnedMeshRenderer getskin;
    private Matrix4x4[] mybindPoses = new Matrix4x4[0x18];
    private SkinnedMeshRenderer myskin;

    private void Start()
    {
        this.getskin = this.getcha.GetComponent<SkinnedMeshRenderer>();
        this.myskin = base.GetComponent<SkinnedMeshRenderer>();
        this.myskin.sharedMesh = this.getskin.sharedMesh;
        for (int i = 0; i < 0x18; i++)
        {
            this.mybindPoses[i] = this.myskin.bones[i].worldToLocalMatrix * this.getcha.localToWorldMatrix;
        }
        this.myskin.sharedMesh.bindposes = this.mybindPoses;
        this.myskin.sharedMesh.boneWeights = this.getskin.sharedMesh.boneWeights;
        Debug.Log("renderer.sharedMesh.bindposes.Length = " + this.myskin.sharedMesh.bindposes.Length.ToString());
        Debug.Log("renderer.bones.Length = " + this.myskin.bones.Length.ToString());
    }

    private void Update()
    {
    }
}


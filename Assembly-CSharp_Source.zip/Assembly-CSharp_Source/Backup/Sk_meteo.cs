using System;
using UnityEngine;

public class Sk_meteo : MonoBehaviour
{
    private Vector3 currentpos;
    private Vector3 directionVector;
    private bool falldown;
    private float finish_delay;
    private Collider mycollider;
    private Transform mytransform;
    private Ef_boom script_boom;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
        this.script_boom = GameObject.FindWithTag("skill").GetComponent<Ef_boom>();
    }

    private void OnEnable()
    {
        this.mytransform.GetChild(0).particleEmitter.emit = true;
        this.mytransform.GetChild(1).particleEmitter.emit = true;
        this.falldown = true;
        this.finish_delay = 0f;
        this.directionVector = this.mytransform.forward - ((Vector3) (Vector3.up * 0.7f));
        this.mytransform.up = -this.directionVector;
        this.currentpos = this.mytransform.position;
    }

    private void Update()
    {
        if (this.falldown)
        {
            if (this.mytransform.position.y > 0f)
            {
                this.currentpos += (Vector3) (this.directionVector * 0.08f);
            }
            else
            {
                this.mycollider.enabled = true;
                this.falldown = false;
                this.currentpos[1] = 0f;
                this.script_boom.SetTex(0, this.currentpos, true);
            }
            this.mytransform.position = this.currentpos;
        }
        else if (this.finish_delay > 2f)
        {
            this.mytransform.GetChild(0).particleEmitter.emit = false;
            this.mytransform.GetChild(1).particleEmitter.emit = false;
            base.gameObject.active = false;
            this.mycollider.enabled = false;
        }
        else
        {
            this.finish_delay += Time.deltaTime;
        }
    }
}


using System;
using UnityEngine;

public class Cart : MonoBehaviour
{
    public Transform cart_destroy;
    private short cur_stage_index;
    private int damage;
    private float delay;
    private Gauge_UV gauge_hp;
    public Transform horse;
    private int hp;
    private float hp_length;
    private bool life = true;
    private int maxhp;
    private Animation myanimation;
    private Transform mytransform;
    private Transform navi_gauge;
    public Transform pt_hit;
    private MakeUI script_pack;
    private UI_Ingame script_ui;
    public AudioClip snd_break;
    private bool super;

    private void Awake()
    {
        this.cur_stage_index = (short) Crypto.Load_int_key("cur_stage_index");
        this.maxhp = 0x7d0 + (150 * this.cur_stage_index);
        this.hp = this.maxhp;
        this.mytransform = base.transform;
        this.myanimation = base.animation;
        this.mytransform.position = (Vector3) (Vector3.forward * 0.5f);
        this.script_ui = GameObject.FindWithTag("ui").GetComponent<UI_Ingame>();
        this.script_pack = GameObject.FindWithTag("p_plan").GetComponent<MakeUI>();
    }

    public void Damaged(Vector3 _damageVector)
    {
        if (this.life && !this.super)
        {
            this.damage = (int) _damageVector.y;
            _damageVector[1] = 0f;
            this.hp = Mathf.Max(0, this.hp - this.damage);
            this.HPgaugeSet();
            this.myanimation.Stop();
            this.myanimation.Play("cart_damage");
            this.horse.animation.Stop();
            this.delay = 2f;
            base.audio.Stop();
            base.audio.PlayOneShot(this.snd_break);
            this.pt_hit.particleEmitter.emit = true;
            if (this.hp <= 0)
            {
                Transform transform = (Transform) UnityEngine.Object.Instantiate(this.cart_destroy, this.mytransform.position, this.mytransform.rotation);
                transform.animation["cart_destroy"].speed = 0.2f;
                base.Invoke("FailStage", 1.5f);
                this.horse.parent = null;
                this.horse.animation["horse_run"].speed = 0.6f;
                this.horse.animation.Play("horse_run");
                this.mytransform.position = (Vector3) (Vector3.up * 16f);
                this.life = false;
                Camera.main.GetComponent<Cam_Move>().LookTarget(transform, 30, 0f);
            }
        }
    }

    private void FailStage()
    {
        this.script_ui.WaveSet(-1);
    }

    public void HPgaugeSet()
    {
        this.hp_length = (1f - (((float) this.hp) / ((float) this.maxhp))) * 0.125f;
        this.gauge_hp.UvMove((Vector2) (Vector2.right * this.hp_length));
    }

    public void ShowDistance()
    {
        if (this.mytransform.position.z > 16.8f)
        {
            this.script_ui.WaveSet(100);
            this.super = true;
            base.CancelInvoke("ShowDistance");
        }
    }

    private void Start()
    {
        this.gauge_hp = this.script_pack.CreatCustomPlane(new Vector2(0.2f, 0.06f), 0f, new Vector3(-1.4f, 2.36f, 1.8f), new Vector2(0.75f, 0.625f), new Vector2(0.875f, 0.6875f), "general_hp", "Gauge_UV", 0.1f, 0).GetComponent<Gauge_UV>();
        this.hp = this.maxhp;
        this.HPgaugeSet();
        this.navi_gauge = this.script_pack.CreatCustomPlane((Vector2) (Vector2.one * 0.12f), 0f, new Vector3(-0.72f, 1.06f, 1.5f), new Vector2(0.8125f, 0.9375f), new Vector2(0.875f, 1f), "navi_gauge", null, 0f, 0);
        this.script_pack.CreatCustomPlane(new Vector2(1.6f, 0.1f), 0f, new Vector3(0f, 1.06f, 1.8f), new Vector2(0f, 0.375f), new Vector2(1f, 0.4375f), "navi", null, 0f, 0);
        this.myanimation["cart_run"].speed = 0.3f;
        this.myanimation["cart_damage"].speed = 0.3f;
        this.horse.animation["horse_walk"].speed = 0.4f;
        base.audio.Play();
        base.InvokeRepeating("ShowDistance", 0.1f, 1f);
    }

    private void Update()
    {
        if (!this.life)
        {
            this.horse.position += (Vector3) ((Vector3.forward * Time.deltaTime) * 1f);
        }
        else if (this.delay > 0f)
        {
            this.delay -= Time.deltaTime;
            if (this.delay <= 0f)
            {
                this.myanimation.CrossFade("cart_run");
                this.horse.animation.CrossFade("horse_walk");
                base.audio.Play();
            }
            else if (this.delay < 1.5f)
            {
                this.pt_hit.particleEmitter.emit = false;
            }
        }
        else if (this.life)
        {
            this.mytransform.position += (Vector3) ((Vector3.forward * Time.deltaTime) * 0.1f);
            this.navi_gauge.position += (Vector3) ((Vector3.right * Time.deltaTime) * 0.009f);
        }
    }
}


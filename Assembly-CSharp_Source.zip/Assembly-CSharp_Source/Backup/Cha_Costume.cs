using System;
using UnityEngine;

public class Cha_Costume : MonoBehaviour
{
    private GameObject curCostum;
    private int current_costume;
    private GameObject prevCostum;

    public void Appear()
    {
        this.curCostum.active = true;
    }

    private void Awake()
    {
        this.current_costume = Crypto.Load_int_key("n43");
    }

    public void Costume(int _costume)
    {
        if ((_costume + 1) < base.transform.GetChildCount())
        {
            this.curCostum = base.transform.GetChild(_costume + 1).gameObject;
            if (this.prevCostum != null)
            {
                this.prevCostum.active = false;
            }
            this.curCostum.active = true;
            this.prevCostum = this.curCostum;
        }
    }

    public void Disappear()
    {
        this.curCostum.active = false;
    }

    public void OpenGiftBox()
    {
        base.animation["open"].speed = 0.25f;
        base.animation["open"].layer = 1;
        base.animation.Play("open");
        AnimationState state = base.animation.CrossFadeQueued("costume", 0.01f, QueueMode.CompleteOthers);
        state.speed = 0.24f;
        state.layer = 1;
    }

    public void OpenImpact()
    {
        GameObject.Find("giftbox").GetComponent<GiftBox>().OpenBox();
    }

    public void ResetCostume()
    {
        this.Costume(this.current_costume);
    }

    private void Start()
    {
        if (Application.loadedLevelName == "Result")
        {
            if (GameObject.Find("ui_result").GetComponent<UI_result>().isclear > 0)
            {
                base.animation["costume"].speed = 0.24f;
                base.animation.Play("costume");
            }
            else
            {
                base.animation["fail"].speed = 0.24f;
                base.animation.Play("fail");
                base.animation.PlayQueued("fail_loop").speed = 0.2f;
            }
        }
        this.Costume(this.current_costume);
    }
}


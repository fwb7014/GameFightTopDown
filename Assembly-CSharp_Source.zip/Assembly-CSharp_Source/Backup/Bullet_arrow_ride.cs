using System;
using UnityEngine;

public class Bullet_arrow_ride : MonoBehaviour
{
    public float bullet_speed;
    private Transform cha1;
    private Transform mytransform;
    private Cha_Control_ride_cha script_cha;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.transform.IsChildOf(this.cha1))
        {
            base.gameObject.active = false;
            this.mytransform.position = (Vector3) (Vector3.one * 12f);
            this.script_cha.Damaged();
        }
    }

    private void Start()
    {
        this.cha1 = GameObject.FindWithTag("Player").transform;
        this.script_cha = this.cha1.GetComponent<Cha_Control_ride_cha>();
    }

    private void Update()
    {
        this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * this.bullet_speed);
    }
}


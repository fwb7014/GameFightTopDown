using System;
using System.IO;
using UnityEngine;

public class UI_cashshop : MonoBehaviour
{
    private int[] accessory = new int[6];
    public GUISkin basicSkin;
    public Texture2D bg_asset;
    public Texture2D bg_black;
    public Texture2D bg_cashlist;
    public Texture2D bg_item;
    public Texture2D bg_item_0;
    private float bg_posX_l = -380f;
    private float bg_posX_r = 480f;
    public GUIStyle bt_back;
    public GUIStyle bt_empty;
    public GUIStyle bt_history;
    public GUIStyle bt_yesno;
    private int cashing;
    private int chalv;
    private int coin;
    private short confirm;
    private int[] cost_acce = new int[] { 50, 50, 15, 20, 30, 20 };
    private int[] cost_armor = new int[] { 40, 80, 80, 70, 150, 150, 100, 290, 290, 150 };
    private int[] cost_coin = new int[] { 10, 20, 40, 80, 160, 320 };
    private int[] cost_etc = new int[] { 3, 1, 5, 9, 0, 0 };
    private float[] cost_jade = new float[] { 3f, 5f, 10f, 15f, 20f, 30f, 60f, 120f, 0f };
    private int[] cost_weapon = new int[10];
    private int[] costume_seed = new int[0x1a];
    private int[] CT_ID = new int[] { 0x1cb78, 0x1cb77, 0x1cb79, 0x1cb7a, 0x1cb76, 0x4ce539, 0, 0 };
    private int cur_equip = -1;
    private int cur_weapon = -1;
    private float curMousePosY;
    private float currentX;
    private bool dragOn;
    private float dragposX;
    private float dragrange;
    private string eventName = "consumeJade";
    private bool freecash;
    public Texture2D freejade;
    private int[] gem_inven = new int[5];
    private int[] get_jade_amount = new int[] { 9, 0x10, 0x24, 60, 120, 200, 360, 900, 0 };
    private bool getItem = true;
    private int[] goods_coin = new int[] { 0x3e8, 0x834, 0x10cc, 0x21fc, 0x4524, 0x8ca0 };
    private Texture2D icon_cashcost;
    public Texture2D icon_coin;
    public Texture2D icon_doller;
    private Texture2D icon_gem;
    public Texture2D icon_jade;
    private float icon_posY = 340f;
    public Texture2D icon_won;
    public Texture2D icon_yen;
    public Texture2D[] img_acce = new Texture2D[7];
    public Texture2D[] img_armor = new Texture2D[10];
    public Texture2D[] img_coin = new Texture2D[6];
    public Texture2D[] img_etc = new Texture2D[6];
    public Texture2D[] img_jade = new Texture2D[8];
    public Texture2D[] img_menu = new Texture2D[6];
    public Texture2D[] img_pr = new Texture2D[6];
    public Texture2D[] img_weapon = new Texture2D[10];
    private string[] itemindex = new string[9];
    private int jade;
    private int kakao;
    private short kind_cash;
    private int language;
    public Texture2D limitedSale;
    private int linecount = 10;
    private string log_string;
    private short margin;
    public Texture2D percent_image;
    public Texture2D pop_blank2;
    public Texture2D pop_blank3;
    private bool popupOn;
    private Vector2 prev_scrollPosition = Vector2.zero;
    private float prevposX;
    public Texture2D prt_shop;
    private int[] reqLvFactor_equip = new int[] { 0, 10, 10, 20, 20, 30, 30, 40, 40, 50 };
    private int[] reqLvFactor_weapon = new int[] { 0, 10, 10, 30, 30, 30, 40, 40, 40, 50 };
    private int review;
    private string reviewURL;
    private short scene_kind;
    private Cha_Costume_shop script_costume;
    private Language_Costume script_name;
    private Cha_Weapon script_weapon;
    private WeaponStat script_weaponstat;
    private bool scrollOn;
    private Vector2 scrollPosition = Vector2.zero;
    private int select_itemidx;
    private int selectequip = -1;
    private int selectweapon = -1;
    private int selequip_hp;
    private int selequip_index;
    private int selequip_special;
    private int selweapon_grade;
    private int selweapon_kind;
    private int selweapon_maxatk;
    private int selweapon_meshkind;
    private int selweapon_minatk;
    private int selweapon_name;
    private float selweapon_spd;
    private int selweapon_special;
    private int selweapon_special_txt;
    public Texture2D soldout;
    public Transform spine_dummy;
    private string st_cashkind = "$";
    private float startMousePosY;
    private float starttime;
    public Texture2D titlebase;
    public Texture2D titlebase_w;
    public Texture2D[] txt_amount = new Texture2D[8];
    private GameObject ui;
    private GameObject ui2;
    private int[] unlock_costume = new int[20];
    private int[] unlock_weapon = new int[20];
    public Transform weapon_dummy;
    public Texture2D[] weapon_kindicon = new Texture2D[3];
    private int[] weapon_seed = new int[0x1a];
    private bool webshop;

    private void Awake()
    {
        this.script_weaponstat = base.GetComponent<WeaponStat>();
        this.script_name = base.GetComponent<Language_Costume>();
        this.script_costume = base.transform.GetChild(0).GetChild(0).GetComponent<Cha_Costume_shop>();
        this.script_weapon = this.weapon_dummy.GetComponent<Cha_Weapon>();
        this.cur_equip = Crypto.Load_int_key("n05");
        this.cur_weapon = Crypto.Load_int_key("n44");
        this.chalv = Crypto.Load_int_key("n47");
    }

    public void ItemDelivery(string _itemindex)
    {
        for (int i = 0; i < 6; i++)
        {
            if (this.itemindex[i] == _itemindex)
            {
                this.cashing += (int) (this.cost_jade[i] + 0.1f);
                Crypto.Save_int_key("cashing", this.cashing);
                this.jade += this.get_jade_amount[i];
                Crypto.Property_change(this.get_jade_amount[i], true);
                PurchaseLog.LogOn(Language.intxt[this.language, 0xe9] + " (" + this.get_jade_amount[i].ToString() + ")\t" + this.cost_jade[i].ToString() + this.st_cashkind);
                break;
            }
        }
    }

    private void OnApplicationPause(bool pocus)
    {
        if (pocus)
        {
            this.coin = Crypto.Load_int_key("n17");
            this.jade = Crypto.Load_int_key("n24");
        }
    }

    public void OnBillingResult(string _itemindex)
    {
        this.ItemDelivery(_itemindex);
    }

    private void OnEnable()
    {
        this.starttime = Time.realtimeSinceStartup;
        base.transform.GetChild(0).GetChild(0).position = new Vector3(0f, 2f, 2f);
        base.transform.GetChild(0).GetChild(1).position = new Vector3(0f, 2f, 2f);
        this.unlock_costume = PlayerPrefsX.GetIntArray("n18");
        this.unlock_weapon = PlayerPrefsX.GetIntArray("n40");
        this.weapon_seed = PlayerPrefsX.GetIntArray("n41");
        this.costume_seed = PlayerPrefsX.GetIntArray("n45");
    }

    private void OnGUI()
    {
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.skin = this.basicSkin;
        GUI.depth = -10;
        GUI.DrawTexture(Crypto.Rect2(112f, 0f, 256f, 32f), this.bg_asset);
        GUI.Label(Crypto.Rect2(146f, 6f, 80f, 14f), string.Empty + this.coin, "txt12_w");
        GUI.Label(Crypto.Rect2(280f, 6f, 64f, 14f), string.Empty + this.jade, "txt12_w");
        if (GUI.Button(Crypto.Rect2(144f, 2f, 100f, 24f), string.Empty, this.bt_empty))
        {
            this.kind_cash = 2;
            this.popupOn = false;
            base.transform.GetChild(0).GetChild(0).position = new Vector3(0f, 2f, 2f);
            base.transform.GetChild(0).GetChild(1).position = new Vector3(0f, 2f, 2f);
        }
        if (GUI.Button(Crypto.Rect2(272f, 2f, 88f, 24f), string.Empty, this.bt_empty))
        {
            this.kind_cash = 1;
            this.popupOn = false;
            base.transform.GetChild(0).GetChild(0).position = new Vector3(0f, 2f, 2f);
            base.transform.GetChild(0).GetChild(1).position = new Vector3(0f, 2f, 2f);
        }
        GUI.DrawTexture(Crypto.Rect2(this.bg_posX_l, 0f, 320f, 320f), this.prt_shop);
        if (this.confirm > 0)
        {
            GUI.enabled = false;
        }
        if (this.kind_cash == 0)
        {
            GUI.DrawTexture(Crypto.Rect2(200f, 84f, 256f, 256f), this.pop_blank3);
            for (short i = 0; i < 6; i = (short) (i + 1))
            {
                GUI.DrawTexture(Crypto.Rect2((float) (220 + (0x4c * (i % 3))), (float) (0x74 + (90 * (i / 3))), 64f, 64f), this.img_menu[i]);
                if (GUI.Button(Crypto.Rect2((float) (220 + (0x4c * (i % 3))), (float) (0x74 + (90 * (i / 3))), 64f, 64f), string.Empty, this.bt_empty))
                {
                    this.starttime = Time.realtimeSinceStartup;
                    this.kind_cash = (short) (i + 1);
                    if (this.kind_cash == 4)
                    {
                        this.popupOn = true;
                        if (this.cur_weapon >= 6)
                        {
                            this.selectweapon = this.cur_weapon - 6;
                        }
                        base.transform.GetChild(0).GetChild(0).position = new Vector3(0f, -0.1f, -2f);
                        base.transform.GetChild(0).GetChild(1).position = new Vector3(-0.6f, 0.3f, -3f);
                        base.transform.GetChild(0).GetChild(0).forward = -Vector3.forward;
                    }
                    else if (this.kind_cash == 5)
                    {
                        this.popupOn = true;
                        base.transform.GetChild(0).GetChild(0).position = new Vector3(0f, -0.1f, -2f);
                        base.transform.GetChild(0).GetChild(1).position = new Vector3(-0.6f, 0.3f, -3f);
                        base.transform.GetChild(0).GetChild(0).forward = Vector3.forward;
                    }
                }
            }
            GUI.Box(Crypto.Rect2(220f, 98f, 64f, 20f), Language.intxt[this.language, 0xe9]);
            GUI.Box(Crypto.Rect2(296f, 98f, 64f, 20f), Language.intxt[this.language, 0xed]);
            GUI.Box(Crypto.Rect2(372f, 98f, 64f, 20f), Language.intxt[this.language, 370]);
            GUI.Box(Crypto.Rect2(220f, 188f, 64f, 20f), Language.intxt[this.language, 0x171]);
            GUI.Box(Crypto.Rect2(296f, 188f, 64f, 20f), Language.intxt[this.language, 0xc7]);
            GUI.Box(Crypto.Rect2(372f, 188f, 64f, 20f), Language.intxt[this.language, 0x108]);
            if (GUI.Button(Crypto.Rect2(416f, 0f, 64f, 64f), string.Empty, this.bt_back))
            {
                UnityEngine.Object.Destroy(base.gameObject);
                this.ui.active = true;
                if (this.ui2 != null)
                {
                    this.ui2.active = true;
                }
                Time.timeScale = 1f;
            }
            if (GUI.Button(Crypto.Rect2(188f, 32f, 128f, 32f), Language.intxt[this.language, 0x166], this.bt_history))
            {
                string str;
                this.linecount = 0;
                this.log_string = string.Empty;
                StreamReader reader = new StreamReader(Application.persistentDataPath + "/purchaselog.txt");
                while ((str = reader.ReadLine()) != null)
                {
                    this.log_string = this.log_string + "\r\n" + str;
                    this.linecount++;
                }
                this.kind_cash = 10;
            }
        }
        else
        {
            if (!this.popupOn && GUI.Button(Crypto.Rect2(416f, 0f, 64f, 64f), string.Empty, this.bt_back))
            {
                this.kind_cash = 0;
                base.transform.GetChild(0).GetChild(0).position = new Vector3(0f, 2f, 2f);
                base.transform.GetChild(0).GetChild(1).position = new Vector3(0f, 2f, 2f);
            }
            if (this.kind_cash == 1)
            {
                GUI.DrawTexture(Crypto.Rect2(this.bg_posX_r, 200f, 480f, 120f), this.bg_black);
                if (this.freecash && GUI.Button(Crypto.Rect2(250f, 120f, 128f, 32f), Language.intxt[this.language, 0x173], this.bt_history))
                {
                    this.kind_cash = 11;
                }
                bool flag = false;
                int num2 = 8;
                if (flag)
                {
                    num2 = 6;
                }
                for (int j = 0; j < num2; j++)
                {
                    GUI.DrawTexture(Crypto.Rect2(((j * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 84f), this.bg_item);
                    if (GUI.Button(Crypto.Rect2(((j * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 84f), string.Empty, this.bt_empty) && !this.scrollOn)
                    {
                        this.select_itemidx = j;
                        bool flag2 = false;
                        if ((Crypto.usimsIndex != "NONE") && (this.select_itemidx >= 5))
                        {
                            flag2 = true;
                        }
                        int num4 = 0;
                        if (this.select_itemidx >= 5)
                        {
                            num4 = this.select_itemidx + 2;
                        }
                        else
                        {
                            num4 = this.select_itemidx + 1;
                        }
                        AndroidScript.i.pay(string.Empty + this.itemindex[this.select_itemidx], this.get_jade_amount[this.select_itemidx] + string.Empty, this.cost_jade[this.select_itemidx], this.get_jade_amount[this.select_itemidx], "pay_offline", "00" + num4, this.CT_ID[this.select_itemidx] + string.Empty, "00" + num4, "3000074462250" + num4, string.Empty + num4);
                        Crypto.Save_string_key(string.Empty + this.itemindex[this.select_itemidx], string.Empty + this.get_jade_amount[this.select_itemidx]);
                    }
                    GUI.DrawTexture(Crypto.Rect2(((j * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 64f), this.img_jade[j]);
                    GUI.Label(Crypto.Rect2(((j * 0x4c) + this.dragposX) + 8f, this.icon_posY + 62f, 64f, 20f), string.Empty + this.cost_jade[j], "txt12_w");
                    GUI.DrawTexture(Crypto.Rect2(((j * 0x4c) + this.dragposX) + 62f, this.icon_posY + 64f, 16f, 16f), this.icon_cashcost);
                    GUI.DrawTexture(Crypto.Rect2(((j * 0x4c) + this.dragposX) + 18f, this.icon_posY - 30f, 64f, 64f), this.txt_amount[j]);
                }
            }
            else if (this.kind_cash == 2)
            {
                GUI.DrawTexture(Crypto.Rect2(this.bg_posX_r, 200f, 480f, 120f), this.bg_black);
                for (int k = 0; k < 6; k++)
                {
                    GUI.DrawTexture(Crypto.Rect2((float) ((k * 0x4c) + 0x12), this.icon_posY, 64f, 84f), this.bg_item);
                    if (GUI.Button(Crypto.Rect2((float) ((k * 0x4c) + 0x12), this.icon_posY, 64f, 84f), string.Empty, this.bt_empty))
                    {
                        if (this.jade >= this.cost_coin[k])
                        {
                            this.select_itemidx = k;
                            this.confirm = 2;
                        }
                        else
                        {
                            this.confirm = 3;
                        }
                    }
                    GUI.DrawTexture(Crypto.Rect2((float) ((k * 0x4c) + 0x12), this.icon_posY, 64f, 64f), this.img_coin[k]);
                    GUI.DrawTexture(Crypto.Rect2((float) ((k * 0x4c) + 20), this.icon_posY - 17f, 16f, 16f), this.icon_coin);
                    GUI.DrawTexture(Crypto.Rect2((float) ((k * 0x4c) + 0x15), this.icon_posY + 64f, 16f, 16f), this.icon_jade);
                    GUI.Label(Crypto.Rect2((float) ((k * 0x4c) + 0x1a), this.icon_posY + 62f, 64f, 20f), string.Empty + this.cost_coin[k], "txt12_w");
                    GUI.Label(Crypto.Rect2((float) ((k * 0x4c) + 0x17), this.icon_posY - 20f, 64f, 20f), string.Empty + this.goods_coin[k], "txt12_w");
                }
            }
            else if (this.kind_cash == 11)
            {
                if (this.freecash)
                {
                    if (this.kakao > 0)
                    {
                        if (GUI.Button(Crypto.Rect2(200f, this.icon_posY - 150f, 256f, 64f), string.Empty, this.bt_empty))
                        {
                            Application.OpenURL("kakaolink://sendurl?msg=%5B%EC%96%B8%EB%8D%B0%EB%93%9C%EC%8A%AC%EB%A0%88%EC%9D%B4%EC%96%B4%5D%20%0A%EC%9D%B4%EC%A0%9C%EA%BB%8F%20%EB%8A%90%EA%BB%B4%20%EB%B3%B8%20%EC%A0%81%20%EC%97%86%EB%8A%94%20%EC%83%88%EB%A1%9C%EC%9A%B4%20%EC%95%A1%EC%85%98%20%EC%BE%8C%EA%B0%90%EC%9D%84%20%EB%A7%9B%EB%B3%B4%EA%B3%A0%20%EC%8B%B6%EB%8B%A4%EB%A9%B4%20%0A%EC%A7%80%EA%B8%88%20%EB%AC%B4%EB%A3%8C%20%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%ED%95%98%EC%84%B8%EC%9A%94.%20%0Ahttp%3A%2F%2Fhgurl.me%2F9as&url=http://hgurl.me/9as&appid=com.nhncorp.skundead&appver=2.0");
                            this.kakao *= -1;
                            Crypto.Save_int_key("n16", this.kakao);
                        }
                        GUI.DrawTexture(Crypto.Rect2(200f, this.icon_posY - 150f, 256f, 64f), this.img_pr[0]);
                    }
                    if (this.review > 0)
                    {
                        if (GUI.Button(Crypto.Rect2(200f, this.icon_posY - 70f, 256f, 64f), string.Empty, this.bt_empty))
                        {
                            Application.OpenURL(this.reviewURL);
                            this.review = -1;
                            Crypto.Save_int_key("n12", -1);
                            Crypto.Property_change(2, true);
                        }
                        GUI.DrawTexture(Crypto.Rect2(200f, this.icon_posY - 70f, 256f, 64f), this.img_pr[1]);
                        GUI.Label(Crypto.Rect2(200f, this.icon_posY - 70f, 256f, 64f), Language.intxt[this.language, 0x178], "txt12_0");
                    }
                }
            }
            else if (this.kind_cash == 4)
            {
                GUI.DrawTexture(Crypto.Rect2(this.bg_posX_r, 200f, 480f, 120f), this.bg_black);
                for (int m = 0; m < 10; m++)
                {
                    if (this.unlock_weapon[m] == 0)
                    {
                        GUI.DrawTexture(Crypto.Rect2(((m * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 84f), this.bg_item);
                        GUI.DrawTexture(Crypto.Rect2(((m * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 64f), this.img_weapon[m]);
                        GUI.Box(Crypto.Rect2(((m * 0x4c) + this.dragposX) + 18f, this.icon_posY - 30f, 64f, 28f), this.script_name.txt_cos[this.language, 0x47 + m]);
                        GUI.DrawTexture(Crypto.Rect2(((m * 0x4c) + this.dragposX) + 21f, this.icon_posY + 64f, 16f, 16f), this.icon_jade);
                        GUI.Label(Crypto.Rect2(((m * 0x4c) + this.dragposX) + 26f, this.icon_posY + 62f, 64f, 20f), string.Empty + this.cost_weapon[m], "txt12_w");
                    }
                    else
                    {
                        GUI.DrawTexture(Crypto.Rect2(((m * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 84f), this.bg_item_0);
                        GUI.DrawTexture(Crypto.Rect2(((m * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 64f), this.img_weapon[m]);
                        GUI.DrawTexture(Crypto.Rect2(((m * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 64f), this.soldout);
                    }
                    if (GUI.Button(Crypto.Rect2(((m * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 84f), string.Empty, this.bt_empty) && !this.scrollOn)
                    {
                        this.popupOn = true;
                        base.transform.GetChild(0).GetChild(0).position = new Vector3(0f, -0.1f, -2f);
                        base.transform.GetChild(0).GetChild(1).position = new Vector3(-0.6f, 0.3f, -3f);
                        this.selectweapon = m;
                        this.SetUpWeapon(this.weapon_seed[this.selectweapon + 6]);
                        this.script_weapon.SetWeapon(this.selweapon_meshkind, this.selweapon_kind);
                        for (int n = 0; n < this.spine_dummy.GetChildCount(); n++)
                        {
                            this.spine_dummy.GetChild(n).gameObject.layer = 2;
                        }
                    }
                    if (m == (this.cur_weapon - 6))
                    {
                        GUI.Box(Crypto.Rect2(((m * 0x4c) + this.dragposX) + 18f, this.icon_posY - 30f, 64f, 20f), Language.intxt[this.language, 0x59]);
                    }
                    if ((m % 3) == 0)
                    {
                        GUI.DrawTexture(Crypto.Rect2(((m * 0x4c) + this.dragposX) + 6f, this.icon_posY - 12f, 48f, 48f), this.limitedSale);
                    }
                }
                if (this.popupOn)
                {
                    GUI.Label(Crypto.Rect2(266f, 46f, 128f, 14f), this.script_name.txt_cos[this.language, this.selweapon_name], "txt12_w");
                    GUI.DrawTexture(Crypto.Rect2(410f, 40f, 26f, 26f), this.weapon_kindicon[this.selweapon_kind]);
                    for (int num8 = 0; num8 < 3; num8++)
                    {
                        GUI.DrawTexture(Crypto.Rect2(302f, (float) (0x4c + (num8 * 20)), 140f, 16f), this.titlebase_w);
                    }
                    if (this.selectweapon < 0)
                    {
                        GUI.Label(Crypto.Rect2(306f, 116f, 128f, 16f), this.script_name.txt_cos[this.language, this.selweapon_special_txt], "txt12_b");
                    }
                    else
                    {
                        GUI.DrawTexture(Crypto.Rect2(302f, 136f, 140f, 16f), this.titlebase_w);
                        GUI.Label(Crypto.Rect2(306f, 116f, 128f, 16f), this.script_name.txt_cos[this.language, 120], "txt12_b");
                        GUI.Label(Crypto.Rect2(306f, 136f, 128f, 16f), this.script_name.txt_cos[this.language, this.selweapon_special_txt], "txt12_b");
                    }
                    GUI.Label(Crypto.Rect2(300f, 76f, 128f, 16f), string.Concat(new object[] { Language.intxt[this.language, 0x8d], "   ", this.selweapon_minatk, " - ", this.selweapon_maxatk }), "txt12_0");
                    GUI.Label(Crypto.Rect2(306f, 96f, 128f, 16f), Language.intxt[this.language, 0x99] + "   " + ((this.selweapon_spd * 100f)).ToString("F1"), "txt12_0");
                    if (this.selectweapon >= 0)
                    {
                        if (this.unlock_weapon[this.selectweapon] == 0)
                        {
                            if (this.chalv >= this.reqLvFactor_weapon[this.selectweapon])
                            {
                                if (GUI.Button(Crypto.Rect2(308f, 156f, 64f, 32f), Language.intxt[this.language, 6], this.bt_yesno))
                                {
                                    this.select_itemidx = this.selectweapon;
                                    this.confirm = 5;
                                }
                            }
                            else
                            {
                                GUI.Label(Crypto.Rect2(308f, 156f, 64f, 32f), Language.intxt[this.language, 0x10a] + this.reqLvFactor_weapon[this.selectweapon], "txt12_r");
                            }
                        }
                        else if (((this.cur_weapon != (this.selectweapon + 6)) && (this.scene_kind <= 0)) && GUI.Button(Crypto.Rect2(308f, 156f, 64f, 32f), Language.intxt[this.language, 10], this.bt_yesno))
                        {
                            this.cur_weapon = this.selectweapon + 6;
                            Crypto.Save_int_key("n44", this.selectweapon + 6);
                            Crypto.Save_int_key("n34", this.selweapon_meshkind + (this.selweapon_kind * 100));
                            Crypto.Save_int_key("n31", this.selweapon_maxatk);
                            Crypto.Save_int_key("n04", this.selweapon_minatk);
                            Crypto.Save_int_key("n35", (int) (this.selweapon_spd * 100f));
                            Crypto.Save_int_key("n38", (this.selweapon_grade * 10) + this.selweapon_special);
                        }
                    }
                    if (GUI.Button(Crypto.Rect2(378f, 156f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                    {
                        this.popupOn = false;
                        base.transform.GetChild(0).GetChild(0).position = new Vector3(0f, 2f, 2f);
                        base.transform.GetChild(0).GetChild(1).position = new Vector3(0f, 2f, 2f);
                    }
                }
            }
            else if (this.kind_cash == 5)
            {
                GUI.DrawTexture(Crypto.Rect2(this.bg_posX_r, 200f, 480f, 120f), this.bg_black);
                for (int num9 = 0; num9 < 10; num9++)
                {
                    if (this.unlock_costume[num9] == 0)
                    {
                        GUI.DrawTexture(Crypto.Rect2(((num9 * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 84f), this.bg_item);
                        GUI.DrawTexture(Crypto.Rect2(((num9 * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 64f), this.img_armor[num9]);
                        GUI.Box(Crypto.Rect2(((num9 * 0x4c) + this.dragposX) + 18f, this.icon_posY - 30f, 64f, 28f), this.script_name.txt_cos[this.language, 8 + num9]);
                        GUI.DrawTexture(Crypto.Rect2(((num9 * 0x4c) + this.dragposX) + 21f, this.icon_posY + 64f, 16f, 16f), this.icon_jade);
                        GUI.Label(Crypto.Rect2(((num9 * 0x4c) + this.dragposX) + 26f, this.icon_posY + 62f, 64f, 20f), string.Empty + this.cost_armor[num9], "txt12_w");
                    }
                    else
                    {
                        GUI.DrawTexture(Crypto.Rect2(((num9 * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 84f), this.bg_item_0);
                        GUI.DrawTexture(Crypto.Rect2(((num9 * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 64f), this.img_armor[num9]);
                        GUI.DrawTexture(Crypto.Rect2(((num9 * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 64f), this.soldout);
                    }
                    if (GUI.Button(Crypto.Rect2(((num9 * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 84f), string.Empty, this.bt_empty) && !this.scrollOn)
                    {
                        this.popupOn = true;
                        base.transform.GetChild(0).GetChild(0).position = new Vector3(0f, -0.1f, -2f);
                        base.transform.GetChild(0).GetChild(1).position = new Vector3(-0.6f, 0.3f, -3f);
                        this.selectequip = num9;
                        this.SetUpArmor(this.costume_seed[this.selectequip + 6]);
                        this.script_costume.Costume(this.selequip_index);
                    }
                    if (num9 == (this.cur_equip - 6))
                    {
                        GUI.Box(Crypto.Rect2(((num9 * 0x4c) + this.dragposX) + 18f, this.icon_posY - 30f, 64f, 20f), Language.intxt[this.language, 0x59]);
                    }
                    if ((num9 % 3) == 0)
                    {
                        GUI.DrawTexture(Crypto.Rect2(((num9 * 0x4c) + this.dragposX) + 6f, this.icon_posY - 12f, 48f, 48f), this.limitedSale);
                    }
                }
                if (this.popupOn)
                {
                    for (int num10 = 0; num10 < 2; num10++)
                    {
                        GUI.DrawTexture(Crypto.Rect2(302f, (float) (80 + (num10 * 20)), 140f, 16f), this.titlebase_w);
                    }
                    GUI.Label(Crypto.Rect2(266f, 46f, 128f, 16f), this.script_name.txt_cos[this.language, this.selequip_index + 1], "txt12_w");
                    GUI.Label(Crypto.Rect2(292f, 80f, 150f, 16f), Language.intxt[this.language, 0x8e] + " + " + this.selequip_hp, "txt12_0");
                    if (this.selectequip < 0)
                    {
                        GUI.Label(Crypto.Rect2(292f, 100f, 150f, 16f), string.Empty + this.script_name.txt_cos[this.language, this.selequip_special + 0x15], "txt12_b");
                    }
                    else
                    {
                        GUI.DrawTexture(Crypto.Rect2(302f, 120f, 140f, 16f), this.titlebase_w);
                        GUI.Label(Crypto.Rect2(292f, 100f, 150f, 16f), string.Empty + this.script_name.txt_cos[this.language, 0x23], "txt12_b");
                        GUI.Label(Crypto.Rect2(292f, 120f, 150f, 16f), string.Empty + this.script_name.txt_cos[this.language, this.selequip_special + 0x15], "txt12_b");
                    }
                    if (this.selectequip >= 0)
                    {
                        if (this.unlock_costume[this.selectequip] == 0)
                        {
                            if (this.chalv >= this.reqLvFactor_equip[this.selectequip])
                            {
                                if (GUI.Button(Crypto.Rect2(308f, 156f, 64f, 32f), Language.intxt[this.language, 6], this.bt_yesno))
                                {
                                    this.select_itemidx = this.selectweapon;
                                    this.confirm = 8;
                                }
                            }
                            else
                            {
                                GUI.Label(Crypto.Rect2(308f, 156f, 64f, 32f), Language.intxt[this.language, 0x10a] + this.reqLvFactor_equip[this.selectequip], "txt12_r");
                            }
                        }
                        else if (((this.cur_equip != (this.selectequip + 6)) && (this.scene_kind <= 0)) && GUI.Button(Crypto.Rect2(308f, 156f, 64f, 32f), Language.intxt[this.language, 10], this.bt_yesno))
                        {
                            this.cur_equip = this.selectequip + 6;
                            Crypto.Save_int_key("n05", this.selectequip + 6);
                            Crypto.Save_int_key("n43", this.selequip_index);
                        }
                    }
                    if (GUI.Button(Crypto.Rect2(378f, 156f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                    {
                        this.popupOn = false;
                        base.transform.GetChild(0).GetChild(0).position = new Vector3(0f, 2f, 2f);
                        base.transform.GetChild(0).GetChild(1).position = new Vector3(0f, 2f, 2f);
                    }
                }
            }
            else if (this.kind_cash != 6)
            {
                if (this.kind_cash == 3)
                {
                    GUI.DrawTexture(Crypto.Rect2(this.bg_posX_r, 200f, 480f, 120f), this.bg_black);
                    for (int num13 = 0; num13 < 4; num13++)
                    {
                        GUI.DrawTexture(Crypto.Rect2((float) ((num13 * 0x4c) + 0x12), this.icon_posY, 64f, 84f), this.bg_item);
                        if (this.img_etc[num13] != null)
                        {
                            GUI.DrawTexture(Crypto.Rect2((float) ((num13 * 0x4c) + 0x12), this.icon_posY, 64f, 64f), this.img_etc[num13]);
                            if (GUI.Button(Crypto.Rect2((float) ((num13 * 0x4c) + 0x12), this.icon_posY, 64f, 84f), string.Empty, this.bt_empty))
                            {
                                this.select_itemidx = num13;
                                if (this.select_itemidx == 0)
                                {
                                    this.confirm = 6;
                                }
                                else
                                {
                                    this.confirm = 7;
                                }
                            }
                            GUI.DrawTexture(Crypto.Rect2((float) ((num13 * 0x4c) + 0x15), this.icon_posY + 64f, 16f, 16f), this.icon_jade);
                            GUI.Label(Crypto.Rect2((float) ((num13 * 0x4c) + 0x1a), this.icon_posY + 62f, 64f, 20f), string.Empty + this.cost_etc[num13], "txt12_w");
                        }
                        else
                        {
                            GUI.DrawTexture(Crypto.Rect2((float) ((num13 * 0x4c) + 0x12), this.icon_posY, 64f, 84f), this.bg_item_0);
                        }
                    }
                    GUI.Box(Crypto.Rect2(18f, this.icon_posY - 30f, 64f, 28f), string.Empty + Language.intxt[this.language, 0xfd]);
                    GUI.Box(Crypto.Rect2(94f, this.icon_posY - 30f, 64f, 28f), Language.intxt[this.language, 0xff] + "\r\nx 1");
                    GUI.Box(Crypto.Rect2(170f, this.icon_posY - 30f, 64f, 28f), Language.intxt[this.language, 0xff] + "\r\nx 5");
                    GUI.Box(Crypto.Rect2(246f, this.icon_posY - 30f, 64f, 28f), Language.intxt[this.language, 0xff] + "\r\nx 10");
                }
                else if (this.kind_cash == 10)
                {
                    GUI.DrawTexture(Crypto.Rect2(210f, 60f, 256f, 256f), this.bg_cashlist);
                    if (Input.GetMouseButtonDown(0))
                    {
                        this.startMousePosY = Input.mousePosition.y;
                        this.prev_scrollPosition = this.scrollPosition;
                    }
                    if (Input.GetMouseButton(0) && Crypto.Rect2(230f, 70f, 220f, 224f).Contains(Event.current.mousePosition))
                    {
                        this.curMousePosY = Input.mousePosition.y;
                        this.scrollPosition = this.prev_scrollPosition + ((Vector2) ((Vector2.up * (this.curMousePosY - this.startMousePosY)) * (320f / ((float) Screen.height))));
                    }
                    this.scrollPosition = GUI.BeginScrollView(Crypto.Rect2(230f, 70f, 240f, 224f), this.scrollPosition, Crypto.Rect2(0f, 0f, 220f, (this.linecount * 14.5f) + 10f));
                    if (this.linecount == 0)
                    {
                        GUI.Label(Crypto.Rect2(0f, 0f, 220f, 64f), Language.intxt[this.language, 0x9f], "txt12_0");
                    }
                    else
                    {
                        GUI.Label(Crypto.Rect2(0f, 0f, 220f, (this.linecount * 14.5f) + 10f), this.log_string);
                    }
                    GUI.EndScrollView();
                }
            }
            else
            {
                GUI.DrawTexture(Crypto.Rect2(this.bg_posX_r, 200f, 480f, 120f), this.bg_black);
                this.dragposX = Mathf.Max(this.dragposX, -100f);
                GUI.DrawTexture(Crypto.Rect2(this.dragposX + 18f, this.icon_posY, 64f, 84f), this.bg_item);
                GUI.DrawTexture(Crypto.Rect2(this.dragposX + 18f, this.icon_posY, 64f, 64f), this.img_acce[0]);
                GUI.DrawTexture(Crypto.Rect2(this.dragposX + 50f, this.icon_posY, 32f, 32f), this.percent_image);
                if (GUI.Button(Crypto.Rect2(this.dragposX + 18f, this.icon_posY, 64f, 84f), string.Empty, this.bt_empty) && !this.scrollOn)
                {
                    int[] intArray = PlayerPrefsX.GetIntArray("n36");
                    bool flag3 = false;
                    for (int num11 = 0; num11 < 6; num11++)
                    {
                        if (intArray[num11] == 0)
                        {
                            flag3 = true;
                            break;
                        }
                    }
                    if (flag3)
                    {
                        this.confirm = 15;
                    }
                }
                GUI.DrawTexture(Crypto.Rect2(this.dragposX + 21f, this.icon_posY + 64f, 16f, 16f), this.icon_jade);
                GUI.Label(Crypto.Rect2(this.dragposX + 26f, this.icon_posY + 62f, 64f, 20f), "150", "txt12_w");
                GUI.Box(Crypto.Rect2(this.dragposX + 18f, this.icon_posY - 30f, 64f, 28f), string.Empty + Language.intxt[this.language, 460]);
                for (int num12 = 0; num12 < 6; num12++)
                {
                    if (this.accessory[num12] > 0)
                    {
                        GUI.DrawTexture(Crypto.Rect2((((num12 + 1) * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 84f), this.bg_item_0);
                        GUI.DrawTexture(Crypto.Rect2((((num12 + 1) * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 64f), this.img_acce[num12 + 1]);
                        GUI.DrawTexture(Crypto.Rect2((((num12 + 1) * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 64f), this.soldout);
                    }
                    else
                    {
                        GUI.DrawTexture(Crypto.Rect2((((num12 + 1) * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 84f), this.bg_item);
                        GUI.DrawTexture(Crypto.Rect2((((num12 + 1) * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 64f), this.img_acce[num12 + 1]);
                        if (GUI.Button(Crypto.Rect2((((num12 + 1) * 0x4c) + this.dragposX) + 18f, this.icon_posY, 64f, 84f), string.Empty, this.bt_empty) && !this.scrollOn)
                        {
                            this.select_itemidx = num12;
                            this.confirm = 4;
                        }
                        GUI.DrawTexture(Crypto.Rect2((((num12 + 1) * 0x4c) + this.dragposX) + 21f, this.icon_posY + 64f, 16f, 16f), this.icon_jade);
                        GUI.Label(Crypto.Rect2((((num12 + 1) * 0x4c) + this.dragposX) + 26f, this.icon_posY + 62f, 64f, 20f), string.Empty + this.cost_acce[num12], "txt12_w");
                    }
                    GUI.Box(Crypto.Rect2((((num12 + 1) * 0x4c) + this.dragposX) + 18f, this.icon_posY - 30f, 64f, 28f), string.Empty + Language.intxt[this.language, 0x14b + num12]);
                }
            }
        }
        GUI.enabled = true;
        if (this.confirm == 2)
        {
            GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
            GUI.Box(Crypto.Rect2(176f, 96f, 128f, 20f), Language.intxt[this.language, 0xed] + "  " + this.goods_coin[this.select_itemidx]);
            GUI.DrawTexture(Crypto.Rect2(204f, 120f, 16f, 16f), this.icon_jade);
            GUI.Label(Crypto.Rect2(208f, 120f, 64f, 16f), string.Empty + this.cost_coin[this.select_itemidx], "txt12_b");
            GUI.Label(Crypto.Rect2(120f, 140f, 230f, 16f), Language.intxt[this.language, 350], "txt12_b");
            GUI.Label(Crypto.Rect2(120f, 160f, 230f, 16f), Language.intxt[this.language, 310], "txt12_0");
            if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
            {
                if (Crypto.Property_change(-this.cost_coin[this.select_itemidx], true))
                {
                    this.jade -= this.cost_coin[this.select_itemidx];
                    this.coin += this.goods_coin[this.select_itemidx];
                    Crypto.Property_change(this.goods_coin[this.select_itemidx], false);
                    PurchaseLog.LogOn(Language.intxt[this.language, 0xea] + " (" + this.cost_coin[this.select_itemidx].ToString() + ")\t" + Language.intxt[this.language, 0xed]);
                    string jsonValue = "{jade:" + this.cost_coin[this.select_itemidx] + ",type: buycoin}";
                    AndroidScript.i.LogEvent(this.eventName, jsonValue);
                }
                this.confirm = 0;
            }
            else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
            {
                this.confirm = 0;
            }
        }
        else if (this.confirm == 3)
        {
            GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
            GUI.Label(Crypto.Rect2(120f, 130f, 230f, 16f), Language.intxt[this.language, 0x15], "txt12_0");
            if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
            {
                this.starttime = Time.realtimeSinceStartup;
                this.popupOn = false;
                base.transform.GetChild(0).GetChild(0).position = new Vector3(0f, 2f, 2f);
                base.transform.GetChild(0).GetChild(1).position = new Vector3(0f, 2f, 2f);
                this.kind_cash = 1;
                this.confirm = 0;
            }
            else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
            {
                this.confirm = 0;
            }
        }
        else if (this.confirm == 4)
        {
            GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
            GUI.Box(Crypto.Rect2(176f, 96f, 128f, 20f), Language.intxt[this.language, 0x14b + this.select_itemidx]);
            GUI.Label(Crypto.Rect2(120f, 122f, 240f, 16f), Language.intxt[this.language, 0x15f + this.select_itemidx], "txt12_0");
            GUI.DrawTexture(Crypto.Rect2((float) (0xa4 + this.margin), 144f, 16f, 16f), this.icon_jade);
            GUI.Label(Crypto.Rect2(120f, 144f, 240f, 16f), string.Concat(new object[] { string.Empty, this.cost_acce[this.select_itemidx], "   ", Language.intxt[this.language, 350] }), "txt12_b");
            GUI.Label(Crypto.Rect2(120f, 162f, 240f, 16f), Language.intxt[this.language, 310], "txt12_0");
            if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
            {
                if (this.jade >= this.cost_acce[this.select_itemidx])
                {
                    if (Crypto.Property_change(-this.cost_acce[this.select_itemidx], true))
                    {
                        this.accessory[this.select_itemidx] = 1;
                        this.jade -= this.cost_acce[this.select_itemidx];
                        PlayerPrefsX.SetIntArray("n36", this.accessory);
                        this.confirm = 0;
                        PurchaseLog.LogOn(Language.intxt[this.language, 0xea] + " (" + this.cost_acce[this.select_itemidx].ToString() + ")\t" + Language.intxt[this.language, 0x14b + this.select_itemidx]);
                        string str3 = "{jade:" + this.cost_acce[this.select_itemidx] + ",type: buyAcce}";
                        AndroidScript.i.LogEvent(this.eventName, str3);
                    }
                }
                else
                {
                    this.confirm = 3;
                }
            }
            else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
            {
                this.confirm = 0;
            }
        }
        else if (this.confirm == 5)
        {
            GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
            GUI.Box(Crypto.Rect2(176f, 96f, 128f, 20f), this.script_name.txt_cos[this.language, this.selweapon_name]);
            GUI.DrawTexture(Crypto.Rect2(200f, 124f, 16f, 16f), this.icon_jade);
            GUI.Label(Crypto.Rect2(120f, 124f, 230f, 16f), string.Empty + this.cost_weapon[this.select_itemidx], "txt12_b");
            GUI.Label(Crypto.Rect2(120f, 144f, 230f, 16f), string.Empty + Language.intxt[this.language, 350], "txt12_b");
            GUI.Label(Crypto.Rect2(120f, 162f, 230f, 16f), Language.intxt[this.language, 310], "txt12_0");
            if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
            {
                if (this.jade >= this.cost_weapon[this.selectweapon])
                {
                    if (Crypto.Property_change(-this.cost_weapon[this.selectweapon], true))
                    {
                        this.jade -= this.cost_weapon[this.selectweapon];
                        this.unlock_weapon[this.selectweapon] = 1;
                        PlayerPrefsX.SetIntArray("n40", this.unlock_weapon);
                        this.confirm = 0;
                        PurchaseLog.LogOn(Language.intxt[this.language, 0xea] + " (" + this.cost_weapon[this.selectweapon].ToString() + ")\t" + this.script_name.txt_cos[this.language, this.selweapon_name]);
                        string str4 = "{jade:" + this.cost_weapon[this.selectweapon] + ",type: buyWeapon}";
                        AndroidScript.i.LogEvent(this.eventName, str4);
                    }
                }
                else
                {
                    this.confirm = 3;
                }
            }
            else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
            {
                this.confirm = 0;
            }
        }
        else if (this.confirm == 6)
        {
            GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
            if (this.select_itemidx == 0)
            {
                GUI.Box(Crypto.Rect2(160f, 96f, 160f, 22f), Language.intxt[this.language, 0xfd] + " (???) x 1");
            }
            GUI.DrawTexture(Crypto.Rect2(204f, 120f, 16f, 16f), this.icon_jade);
            GUI.Label(Crypto.Rect2(208f, 120f, 64f, 16f), string.Empty + this.cost_etc[this.select_itemidx], "txt12_b");
            GUI.Label(Crypto.Rect2(120f, 140f, 230f, 16f), Language.intxt[this.language, 350], "txt12_b");
            GUI.Label(Crypto.Rect2(120f, 162f, 230f, 16f), Language.intxt[this.language, 310], "txt12_0");
            if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
            {
                if (this.jade >= this.cost_etc[this.select_itemidx])
                {
                    if (Crypto.Property_change(-this.cost_etc[this.select_itemidx], true))
                    {
                        this.gem_inven = PlayerPrefsX.GetIntArray("n39");
                        if (this.select_itemidx == 0)
                        {
                            int num14 = UnityEngine.Random.Range(0, 100);
                            int index = 0;
                            if (num14 > 0x60)
                            {
                                index = 4;
                            }
                            else if (num14 > 0x58)
                            {
                                index = 3;
                            }
                            else if (num14 > 0x44)
                            {
                                index = 2;
                            }
                            else if (num14 > 40)
                            {
                                index = 1;
                            }
                            else
                            {
                                index = 0;
                            }
                            this.gem_inven[index]++;
                            int num19 = index + 1;
                            this.icon_gem = Resources.Load("jewel0" + num19.ToString() + "a") as Texture2D;
                            this.confirm = 9;
                        }
                        else if (this.select_itemidx == 1)
                        {
                            this.gem_inven[4]++;
                            this.confirm = 0;
                        }
                        else
                        {
                            this.gem_inven[4] += 5;
                            this.confirm = 0;
                        }
                        PlayerPrefsX.SetIntArray("n39", this.gem_inven);
                        this.jade -= this.cost_etc[this.select_itemidx];
                        PurchaseLog.LogOn(Language.intxt[this.language, 0xea] + " (" + this.cost_etc[this.select_itemidx].ToString() + ")\t" + Language.intxt[this.language, 0xfd]);
                        string str5 = "{jade:" + this.cost_etc[this.select_itemidx] + ",type: buyGem}";
                        AndroidScript.i.LogEvent(this.eventName, str5);
                    }
                }
                else
                {
                    this.confirm = 3;
                }
            }
            else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
            {
                this.confirm = 0;
            }
        }
        else if (this.confirm == 7)
        {
            GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
            if (this.select_itemidx == 1)
            {
                GUI.Box(Crypto.Rect2(160f, 96f, 160f, 22f), Language.intxt[this.language, 0xff] + " x 1");
            }
            else if (this.select_itemidx == 2)
            {
                GUI.Box(Crypto.Rect2(160f, 96f, 160f, 22f), Language.intxt[this.language, 0xff] + " x 5");
            }
            else
            {
                GUI.Box(Crypto.Rect2(160f, 96f, 160f, 22f), Language.intxt[this.language, 0xff] + " x 10");
            }
            GUI.DrawTexture(Crypto.Rect2(204f, 120f, 16f, 16f), this.icon_jade);
            GUI.Label(Crypto.Rect2(208f, 120f, 64f, 16f), string.Empty + this.cost_etc[this.select_itemidx], "txt12_b");
            GUI.Label(Crypto.Rect2(120f, 140f, 230f, 16f), Language.intxt[this.language, 350], "txt12_b");
            GUI.Label(Crypto.Rect2(120f, 162f, 230f, 16f), Language.intxt[this.language, 310], "txt12_0");
            if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
            {
                if (this.jade >= this.cost_etc[this.select_itemidx])
                {
                    if (Crypto.Property_change(-this.cost_etc[this.select_itemidx], true))
                    {
                        int num16 = Crypto.Load_int_key("n10");
                        if (this.select_itemidx == 1)
                        {
                            num16++;
                        }
                        else if (this.select_itemidx == 2)
                        {
                            num16 += 5;
                        }
                        else
                        {
                            num16 += 10;
                        }
                        Crypto.Save_int_key("n10", num16);
                        this.jade -= this.cost_etc[this.select_itemidx];
                        PurchaseLog.LogOn(Language.intxt[this.language, 0xea] + " (" + this.cost_etc[this.select_itemidx].ToString() + ")\t" + Language.intxt[this.language, 0xff]);
                        string str6 = "{jade:" + this.cost_etc[this.select_itemidx] + ",type: buyKey}";
                        AndroidScript.i.LogEvent(this.eventName, str6);
                    }
                    this.confirm = 0;
                }
                else
                {
                    this.confirm = 3;
                }
            }
            else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
            {
                this.confirm = 0;
            }
        }
        else if (this.confirm == 8)
        {
            GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
            GUI.Box(Crypto.Rect2(176f, 96f, 128f, 20f), this.script_name.txt_cos[this.language, this.selectequip + 8]);
            GUI.DrawTexture(Crypto.Rect2(200f, 124f, 16f, 16f), this.icon_jade);
            GUI.Label(Crypto.Rect2(120f, 124f, 230f, 16f), string.Empty + this.cost_armor[this.selectequip], "txt12_b");
            GUI.Label(Crypto.Rect2(120f, 144f, 230f, 16f), string.Empty + Language.intxt[this.language, 350], "txt12_b");
            GUI.Label(Crypto.Rect2(120f, 162f, 230f, 16f), Language.intxt[this.language, 310], "txt12_0");
            if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
            {
                if (this.jade >= this.cost_armor[this.selectequip])
                {
                    if (Crypto.Property_change(-this.cost_armor[this.selectequip], true))
                    {
                        this.jade -= this.cost_armor[this.selectequip];
                        this.unlock_costume[this.selectequip] = 1;
                        PlayerPrefsX.SetIntArray("n18", this.unlock_costume);
                        PurchaseLog.LogOn(Language.intxt[this.language, 0xea] + " (" + this.cost_armor[this.selectequip].ToString() + ")\t" + this.script_name.txt_cos[this.language, this.selectequip + 8]);
                        string str7 = "{jade:" + this.cost_armor[this.selectequip] + ",type: buyCostume}";
                        AndroidScript.i.LogEvent(this.eventName, str7);
                    }
                    this.confirm = 0;
                }
                else
                {
                    this.confirm = 3;
                }
            }
            else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
            {
                this.confirm = 0;
            }
        }
        else if (this.confirm == 9)
        {
            GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
            GUI.Label(Crypto.Rect2(120f, 110f, 230f, 16f), Language.intxt[this.language, 0x177], "txt12_0");
            if (this.icon_gem != null)
            {
                GUI.DrawTexture(Crypto.Rect2(224f, 130f, 32f, 32f), this.icon_gem);
            }
            if (GUI.Button(Crypto.Rect2(208f, 180f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
            {
                this.confirm = 0;
            }
        }
        else if (this.confirm == 15)
        {
            GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
            GUI.Box(Crypto.Rect2(176f, 96f, 128f, 20f), Language.intxt[this.language, 460]);
            GUI.Label(Crypto.Rect2(120f, 122f, 240f, 16f), Language.intxt[this.language, 0x1cd], "txt12_0");
            GUI.DrawTexture(Crypto.Rect2((float) (0xa4 + this.margin), 144f, 16f, 16f), this.icon_jade);
            GUI.Label(Crypto.Rect2(120f, 144f, 240f, 16f), string.Concat(new object[] { string.Empty, 150, "   ", Language.intxt[this.language, 350] }), "txt12_b");
            GUI.Label(Crypto.Rect2(120f, 162f, 240f, 16f), Language.intxt[this.language, 310], "txt12_0");
            if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
            {
                if (this.jade >= 150)
                {
                    if (Crypto.Property_change(-150, true))
                    {
                        for (int num17 = 0; num17 < 6; num17++)
                        {
                            this.accessory[num17] = 1;
                        }
                        this.jade -= 150;
                        PlayerPrefsX.SetIntArray("n36", this.accessory);
                        this.confirm = 0;
                        PurchaseLog.LogOn(string.Concat(new object[] { Language.intxt[this.language, 0xea], " (", 150, ")\t", Language.intxt[this.language, 460] }));
                        string str8 = "{jade:" + 150 + ",type: buyAllAcce}";
                        AndroidScript.i.LogEvent(this.eventName, str8);
                    }
                }
                else
                {
                    this.confirm = 3;
                }
            }
            else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
            {
                this.confirm = 0;
            }
        }
    }

    private void PayCallBack(string jsonValue)
    {
        char[] separator = new char[] { ',' };
        string[] strArray = jsonValue.Substring(1, jsonValue.Length - 2).Split(separator);
        string str2 = strArray[0];
        char[] chArray2 = new char[] { ':' };
        string[] strArray2 = str2.Split(chArray2);
        int num = int.Parse(strArray2[1].Substring(1, strArray2[1].Length - 2));
        string str3 = strArray[2];
        char[] chArray3 = new char[] { ':' };
        string[] strArray3 = str3.Split(chArray3);
        int num2 = int.Parse(strArray3[1].Substring(1, strArray3[1].Length - 2));
        if (num == 1)
        {
            if (num2 == 100)
            {
                int[] intArray = new int[20];
                intArray = PlayerPrefsX.GetIntArray("n22");
                int num3 = intArray[14];
                if (num3 > 0)
                {
                    Crypto.Property_change(0x2710, false);
                }
                else
                {
                    intArray[14] = 0;
                    PlayerPrefsX.SetIntArray("n22", intArray);
                    Crypto.Property_change(0x1f40, false);
                }
                PlayerPrefs.SetInt("haveDrawedGift", 1);
            }
            if (num2 > 0)
            {
                int num4 = int.Parse(Crypto.Load_string_key(string.Empty + num2));
                if (num4 > 0)
                {
                    Crypto.Property_change(num4, true);
                    PlayerPrefs.SetString("charge", "true");
                }
            }
        }
    }

    public void SetUpArmor(int _index)
    {
        this.selequip_index = _index % 100;
        _index /= 100;
        int[] numArray = new int[2];
        for (int i = 0; i < 2; i++)
        {
            numArray[i] = _index % 10;
            _index /= 10;
        }
        this.selequip_special = numArray[1];
        this.selequip_hp = _index;
    }

    public void SetUpWeapon(int _index)
    {
        this.script_weaponstat.SetStat(_index);
        this.selweapon_meshkind = this.script_weaponstat.weapon_meshkind;
        this.selweapon_kind = this.script_weaponstat.weapon_kind;
        this.selweapon_grade = this.script_weaponstat.weapon_grade;
        this.selweapon_name = this.script_weaponstat.weapon_name;
        this.selweapon_maxatk = this.script_weaponstat.weapon_maxatk;
        this.selweapon_minatk = this.script_weaponstat.weapon_minatk;
        this.selweapon_spd = this.script_weaponstat.weapon_spd;
        this.selweapon_special = this.script_weaponstat.weapon_special;
        this.selweapon_special_txt = this.script_weaponstat.weapon_special_txt;
    }

    private void Start()
    {
        this.dragrange = Screen.height * 0.375f;
        this.kind_cash = (short) Crypto.Load_int_key("cashshopkind");
        this.accessory = PlayerPrefsX.GetIntArray("n36");
        this.language = PlayerPrefs.GetInt("language");
        this.cashing = Crypto.Load_int_key("cashing");
        this.st_cashkind = Language.intxt[this.language, 0x3e];
        if (GameObject.Find("UI_Ingame_GUI") != null)
        {
            this.ui = GameObject.Find("UI_Ingame_GUI");
            this.scene_kind = 2;
        }
        else if (Application.loadedLevelName == "Result")
        {
            this.ui = GameObject.FindWithTag("ui");
            this.ui2 = GameObject.FindWithTag("dummy");
            this.scene_kind = 2;
        }
        else
        {
            this.ui = GameObject.FindWithTag("ui");
        }
        this.ui.active = false;
        if (this.ui2 != null)
        {
            this.ui2.active = false;
        }
        this.coin = Crypto.Load_int_key("n17");
        this.jade = Crypto.Load_int_key("n24");
        Time.timeScale = 0f;
        this.review = Crypto.Load_int_key("n12");
        this.icon_cashcost = this.icon_doller;
        this.reviewURL = "https://play.google.com/store/apps/details?id=com.nhncorp.skundeadgr";
        this.itemindex = new string[] { "1", "2", "3", "4", "5", "7", "60", "120", string.Empty };
        for (int i = 0; i < 10; i++)
        {
            this.cost_weapon[i] = this.script_weaponstat.Cost_only(this.weapon_seed[i + 6]);
        }
        this.SetUpWeapon(this.weapon_seed[this.cur_weapon]);
        this.SetUpArmor(this.costume_seed[this.cur_equip]);
        this.selectequip = this.cur_equip - 6;
        this.script_weapon.SetWeapon(this.selweapon_meshkind, this.selweapon_kind);
        for (int j = 0; j < this.spine_dummy.GetChildCount(); j++)
        {
            this.spine_dummy.GetChild(j).gameObject.layer = 2;
        }
    }

    private void Update()
    {
        this.bg_posX_l = Mathf.MoveTowards(this.bg_posX_l, -64f, (Time.realtimeSinceStartup - this.starttime) * 500f);
        this.bg_posX_r = Mathf.MoveTowards(480f, 0f, (Time.realtimeSinceStartup - this.starttime) * 1500f);
        this.icon_posY = Mathf.MoveTowards(340f, 230f, (Time.realtimeSinceStartup - this.starttime) * 500f);
        if (Input.GetMouseButtonDown(0))
        {
            if (Input.mousePosition.y < this.dragrange)
            {
                this.dragOn = true;
                this.prevposX = Input.mousePosition.x;
                this.currentX = this.dragposX;
            }
        }
        else if (Input.GetMouseButtonUp(0))
        {
            this.dragOn = false;
            this.scrollOn = false;
        }
        if (this.dragOn)
        {
            if (Mathf.Abs((float) (Input.mousePosition.x - this.prevposX)) > 200f)
            {
                this.scrollOn = true;
            }
            this.dragposX = ((Input.mousePosition.x - this.prevposX) * (480f / ((float) Screen.width))) + this.currentX;
            this.dragposX = Mathf.Min(this.dragposX, 0f);
            this.dragposX = Mathf.Max(this.dragposX, -300f);
        }
        if (PlayerPrefs.GetString("charge").CompareTo("true") == 0)
        {
            this.coin = Crypto.Load_int_key("n17");
            this.jade = Crypto.Load_int_key("n24");
            PlayerPrefs.SetString("charge", "false");
        }
    }
}


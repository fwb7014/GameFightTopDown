using System;
using UnityEngine;

public class BossWing : MonoBehaviour
{
    private void Start()
    {
        base.animation["wing_fly"].speed = 0.24f;
        base.animation["wing_attack"].speed = 0.24f;
    }
}


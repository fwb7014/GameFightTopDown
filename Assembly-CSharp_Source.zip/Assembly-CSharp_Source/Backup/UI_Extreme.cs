using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class UI_Extreme : MonoBehaviour
{
    public Texture2D arrow_next;
    private bool b_delay;
    public GUIStyle bar_slide;
    public GUISkin basicSkin;
    private GUIStyle bb = new GUIStyle();
    public Texture2D bg_asset;
    public Texture2D bg_asset_key;
    public Texture2D bg_asset_lv;
    private Transform bg_dun;
    private Transform bg_dun_below;
    private Transform bg_dun_cover;
    public Texture2D bg_item;
    public Texture2D bg_option;
    public Texture2D bg_red;
    public Texture2D bg_speech;
    public Texture2D bg_title;
    public Texture2D bg_title_me;
    public Texture2D black;
    public Texture2D black_all;
    public GUIStyle bt_arrow_l;
    public GUIStyle bt_arrow_r;
    public GUIStyle bt_back;
    public GUIStyle bt_empty;
    public GUIStyle bt_general_small;
    public GUIStyle bt_gift;
    public Texture2D bt_lockmenu;
    public Texture2D bt_lockmenu2;
    public GUIStyle bt_menu;
    public GUIStyle bt_plus;
    public GUIStyle bt_rank;
    public GUIStyle bt_shop;
    public GUIStyle bt_start;
    public Texture2D[] bt_unlockstage = new Texture2D[3];
    public GUIStyle bt_yesno;
    private GameObject cashshop;
    private int chalv;
    private bool changescene;
    private int coin;
    private short confirm;
    private int cur_general = -1;
    private float cur_generalmaxhp = 1500f;
    private int[] cur_workdelay = new int[2];
    private float curMousePosY;
    private float curMousePosY_rank;
    private int currentStage;
    public Texture2D empty;
    public Texture2D errorimg;
    private int expand_height;
    private int expand_height2;
    private int extreme_point;
    private float f_delay;
    public Transform[] flag_icon = new Transform[3];
    public Texture2D gauge_exp;
    public Texture2D gauge_hp;
    private int general_cur_hp;
    private int general_hp;
    private int general_seed;
    public Texture2D gift_bg_item;
    public Texture2D gift_coin;
    public Texture2D gift_five_percnt;
    public Texture2D gift_skill;
    public Texture2D gift_skill_bg;
    public Texture2D gift_title;
    public Transform gifticon;
    private int[] grade_extreme = new int[100];
    public GUIStyle guiTest;
    private int haveGiftBox;
    private Transform hiticon;
    public Texture2D ico_slide;
    public Texture2D ico_warn;
    public Texture2D icon_coin;
    public Texture2D icon_friend_plus;
    public Texture2D icon_info;
    public Texture2D icon_jade;
    public Texture2D icon_key;
    public Texture2D[] icon_ranktab = new Texture2D[3];
    private int icon_size;
    public Transform icon_stage;
    public Texture2D icon_table;
    public Texture2D[] icon_toprank = new Texture2D[3];
    public Texture2D[] img_consumeItem = new Texture2D[6];
    public Texture2D[] img_menu = new Texture2D[5];
    public Texture2D img_skill_slot;
    private Rect inputrect = new Rect(84f, 118f, 320f, 180f);
    private bool invitefriend;
    private bool isSend = true;
    private int[] item_price = new int[] { 100, 120, 130, 140, 150, 0x9b };
    private int[] item_slot = new int[3];
    private int jade;
    private int key_cave;
    private int language;
    private float length_exp;
    private bool loadfinish;
    private int max_stage_index;
    private short MAXRANKING = 50;
    private int maxStage = 1;
    private const int MAXSTAGE = 0x40;
    private const int MAXWORK = 2;
    private int[] menuarray = new int[] { 1, 2, 3, 4, 6 };
    private short menuopen = 1;
    public Texture2D menutray;
    private Texture2D myimage;
    private bool newarchive;
    private bool newtreasure;
    public Transform num_stage_index;
    private bool option;
    private bool pause;
    public GUIStyle pausemenu;
    public Transform plane_friend;
    public Texture2D pop_blank;
    public Texture2D pop_blank2;
    private float posX;
    private float posX_r;
    private float posY;
    private Vector2 prev_scrollPosition;
    private Texture2D prt_general;
    public Texture2D rank_bg;
    public Texture2D rank_item_bg;
    private Vector2 rank_prev_scrollPosition = Vector2.zero;
    private Vector2 rank_scrollPosition = Vector2.zero;
    private GameObject rankobj;
    private bool readyOn;
    public Transform ring_active;
    private short scopemode = -1;
    private LoopArchive script_archive;
    private CamScroll_Extreme script_cam;
    private General_Stat script_generalstat;
    private SoundEf_UI script_soundUI;
    private Vector2 scrollPosition;
    public GUIStyle sel_lang;
    private int selectblank = -1;
    private int selectItem = -1;
    private int[] skill_slot = new int[5];
    private Texture2D[] skillicon = new Texture2D[5];
    private bool slideon;
    private bool slideon2;
    public Transform sound_dummy;
    private Transform sound_UI;
    private float startMousePosY;
    private float startMousePosY_rank;
    public Texture2D tex_currentStage;
    private int time_hour;
    private int time_min;
    public Texture2D toggle_active;
    private int totalprice;
    public Texture2D txt_extreme;
    public Texture2D txt_loading;
    public Texture2D txt_start;
    private bool uploadprofile = true;
    private float vol_bgm;
    private float vol_master;

    private void Awake()
    {
        this.language = PlayerPrefs.GetInt("language");
        this.cur_general = Crypto.Load_int_key("cur_general");
        if (this.cur_general >= 0)
        {
            int[] intArray = PlayerPrefsX.GetIntArray("n13");
            this.general_seed = intArray[this.cur_general];
            int[] numArray2 = PlayerPrefsX.GetIntArray("n33");
            this.general_hp = numArray2[this.cur_general];
        }
        this.script_generalstat = base.GetComponent<General_Stat>();
        this.grade_extreme = PlayerPrefsX.GetIntArray("n52");
        this.maxStage = Crypto.Load_int_key("n48");
        this.maxStage = Mathf.Clamp(this.maxStage, 1, 0x40);
        this.currentStage = Crypto.Load_int_key("n49");
        this.currentStage = Mathf.Max(this.currentStage, 1);
        this.extreme_point = Crypto.Load_int_key("n54");
        this.skill_slot = PlayerPrefsX.GetIntArray("skill_slot");
        this.posX = 84f;
        this.posX_r = 480f;
        this.posY = -100f;
        this.haveGiftBox = PlayerPrefs.GetInt("haveDrawedGift", 0);
        this.script_cam = Camera.main.GetComponent<CamScroll_Extreme>();
    }

    public void BattleStart()
    {
        if (this.sound_UI != null)
        {
            UnityEngine.Object.Destroy(this.sound_UI.gameObject);
        }
        UnityEngine.Object.Destroy(this.rankobj);
        UnityEngine.Object.Destroy(this.bg_dun.gameObject);
        UnityEngine.Object.Destroy(this.bg_dun_cover.gameObject);
        UnityEngine.Object.Destroy(this.bg_dun_below.gameObject);
        Crypto.Save_int_key("n49", this.currentStage);
        int num = Crypto.Load_int_key("caveplay") + 1;
        Crypto.Save_int_key("caveplay", num);
        this.key_cave--;
        Crypto.Save_int_key("n10", this.key_cave);
        this.changescene = true;
        Application.LoadLevel("Loading2");
        if (this.key_cave >= 5)
        {
            TimeControl.SetDelay(0);
        }
        Crypto.Save_int_key("cur_stage_index", 100);
        Crypto.Save_int_key("cur_stage_kind", 11);
        Crypto.Save_int_key("play_kind", 0);
        PlayerPrefsX.SetIntArray("n50", this.item_slot);
    }

    public void CashshopOpen()
    {
        this.script_cam.DisableMove();
        if (this.cashshop == null)
        {
            this.cashshop = Resources.Load("CashShop") as GameObject;
        }
        UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
    }

    public void CurGeneralStat(bool _start)
    {
        if (_start && (this.cur_general != -1))
        {
            this.script_generalstat.SetGeneral(this.general_seed);
            this.cur_generalmaxhp = this.script_generalstat.g_maxhp;
        }
    }

    public void Delay(float t)
    {
        this.b_delay = true;
        this.f_delay = t;
    }

    public void DelayWorkTime()
    {
        for (int i = 0; i < 2; i++)
        {
            this.cur_workdelay[i] = TimeControl.SubtractDelay(i);
        }
        this.general_cur_hp = this.general_hp + ((int) (this.cur_workdelay[1] * 0.2f));
        this.general_cur_hp = Mathf.Min(this.general_cur_hp, (int) this.cur_generalmaxhp);
        if (this.cur_workdelay[0] > 360)
        {
            this.key_cave += this.cur_workdelay[0] / 360;
            this.key_cave = Mathf.Clamp(this.key_cave, 0, 5);
            TimeControl.SetDelay(0);
            this.cur_workdelay[0] = this.cur_workdelay[0] % 360;
        }
        this.time_hour = (360 - this.cur_workdelay[0]) / 60;
        this.time_min = (360 - this.cur_workdelay[0]) % 60;
    }

    public void GeneralKindOnly()
    {
        int num = (this.general_seed % 0x989680) / 0x186a0;
        int num2 = num + 1;
        this.prt_general = Resources.Load("prt_general" + num2.ToString()) as Texture2D;
    }

    [DebuggerHidden]
    private IEnumerator ImageLoading(string _url)
    {
        return new <ImageLoading>c__Iterator18 { _url = _url, <$>_url = _url, <>f__this = this };
    }

    public bool ItemKeep(int _index)
    {
        bool flag = false;
        for (int i = 0; i < 3; i++)
        {
            if (this.item_slot[i] == 0)
            {
                this.item_slot[i] = _index + 1;
                flag = true;
                this.totalprice += this.item_price[_index];
                return flag;
            }
        }
        return flag;
    }

    private bool ItemOver(int _index)
    {
        for (int i = 0; i < 3; i++)
        {
            if (this.item_slot[i] == (_index + 1))
            {
                return true;
            }
        }
        return false;
    }

    private void OnEnable()
    {
        this.coin = Crypto.Load_int_key("n17");
        this.jade = Crypto.Load_int_key("n24");
        this.key_cave = Crypto.Load_int_key("n10");
        this.script_cam.EnableMove();
    }

    private void OnGUI()
    {
        GUI.skin = this.basicSkin;
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.DrawTexture(Crypto.Rect2(112f, 0f, 256f, 32f), this.bg_asset);
        GUI.Label(Crypto.Rect2(146f, 6f, 80f, 14f), string.Empty + this.coin, "txt12_w");
        GUI.Label(Crypto.Rect2(280f, 6f, 64f, 14f), string.Empty + this.jade, "txt12_w");
        GUI.DrawTexture(Crypto.Rect2(50f, 0f, 64f, 32f), this.bg_asset_lv);
        GUI.Label(Crypto.Rect2(52f, 3f, 80f, 14f), string.Empty + this.chalv, "txt12_w");
        if (this.confirm > 0)
        {
            GUI.enabled = false;
        }
        GUI.DrawTexture(Crypto.Rect2(57f, 20f, this.length_exp, 3f), this.gauge_exp);
        if (this.option)
        {
            if (this.slideon)
            {
                this.vol_bgm = ((Input.mousePosition.x * (480f / ((float) Screen.width))) - 214f) / 126f;
                this.vol_bgm = Mathf.Clamp(this.vol_bgm, 0f, 1f);
            }
            else if (this.slideon2)
            {
                this.vol_master = ((Input.mousePosition.x * (480f / ((float) Screen.width))) - 214f) / 126f;
                this.vol_master = Mathf.Clamp(this.vol_master, 0f, 1f);
            }
            GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.black);
            GUI.DrawTexture(Crypto.Rect2(112f, 85f, 256f, 256f), this.bg_option);
            GUI.Label(Crypto.Rect2(128f, 108f, 70f, 16f), Language.intxt[this.language, 0x12e], "txt12_w");
            GUI.Label(Crypto.Rect2(128f, 143f, 70f, 16f), Language.intxt[this.language, 0xf4], "txt12_w");
            GUI.Label(Crypto.Rect2(128f, 180f, 70f, 16f), Language.intxt[this.language, 0xf5], "txt12_w");
            if (GUI.Button(Crypto.Rect2(212f, 172f, 128f, 32f), Language.intxt[this.language, 0xf6], this.sel_lang))
            {
                short num = 2;
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(0);
                }
                this.language = (this.language + 1) % num;
                PlayerPrefs.SetInt("language", this.language);
            }
            if (GUI.RepeatButton(Crypto.Rect2(200f, 101f, 152f, 32f), string.Empty, this.bar_slide))
            {
                this.slideon2 = true;
            }
            else if (this.slideon2)
            {
                AudioListener.volume = this.vol_master;
                this.slideon2 = false;
            }
            GUI.DrawTexture(Crypto.Rect2((this.vol_master * 126f) + 206f, 109f, 16f, 16f), this.ico_slide);
            if (GUI.RepeatButton(Crypto.Rect2(200f, 136f, 152f, 32f), string.Empty, this.bar_slide))
            {
                this.slideon = true;
            }
            else if (this.slideon)
            {
                this.script_soundUI.SetBGM(this.vol_bgm);
                this.slideon = false;
            }
            GUI.DrawTexture(Crypto.Rect2((this.vol_bgm * 126f) + 206f, 144f, 16f, 16f), this.ico_slide);
            if (GUI.Button(Crypto.Rect2(208f, 210f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(0);
                }
                this.option = false;
                PlayerPrefs.SetFloat("vol_bgm", this.vol_bgm);
                PlayerPrefs.SetFloat("vol_master", this.vol_master);
            }
        }
        else if (this.pause)
        {
            GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.black);
            if (GUI.Button(Crypto.Rect2(112f, 80f, 256f, 64f), Language.intxt[this.language, 30], this.pausemenu))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(0);
                }
                this.pause = false;
                Input.multiTouchEnabled = true;
            }
            if (GUI.Button(Crypto.Rect2(112f, 140f, 256f, 64f), Language.intxt[this.language, 0x1f], this.pausemenu))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(0);
                }
                this.option = true;
            }
            if (GUI.Button(Crypto.Rect2(112f, 200f, 256f, 64f), Language.intxt[this.language, 0x20], this.pausemenu))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(0);
                }
                this.pause = false;
                this.changescene = true;
                Application.LoadLevel("Intro");
                UnityEngine.Object.Destroy(this.sound_UI.gameObject);
                UnityEngine.Object.Destroy(this.rankobj);
                UnityEngine.Object.Destroy(this.bg_dun.gameObject);
                UnityEngine.Object.Destroy(this.bg_dun_cover.gameObject);
                UnityEngine.Object.Destroy(this.bg_dun_below.gameObject);
            }
        }
        else
        {
            if (GUI.Button(Crypto.Rect2(144f, 2f, 100f, 24f), string.Empty, this.bt_empty))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(0);
                }
                Crypto.Save_int_key("cashshopkind", 2);
                this.CashshopOpen();
            }
            if (GUI.Button(Crypto.Rect2(272f, 2f, 88f, 24f), string.Empty, this.bt_empty))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(0);
                }
                Crypto.Save_int_key("cashshopkind", 1);
                this.CashshopOpen();
            }
            if (Input.anyKeyDown)
            {
                if (Crypto.Rect2(this.inputrect.x, this.inputrect.y, this.inputrect.width, this.inputrect.height).Contains(Event.current.mousePosition))
                {
                    this.startMousePosY = Input.mousePosition.y;
                    this.prev_scrollPosition = this.scrollPosition;
                }
            }
            else if (Input.anyKey && Crypto.Rect2(this.inputrect.x, this.inputrect.y, this.inputrect.width, this.inputrect.height).Contains(Event.current.mousePosition))
            {
                this.curMousePosY = Input.mousePosition.y;
                this.scrollPosition = this.prev_scrollPosition + ((Vector2) ((Vector2.up * (this.curMousePosY - this.startMousePosY)) * (640f / ((float) Screen.height))));
            }
            if (this.readyOn)
            {
                GUI.Box(Crypto.Rect2(this.posX_r + 4f, this.posY - 42f, 184f, 196f), string.Empty, "blank_box");
                GUI.Box(Crypto.Rect2(this.posX_r + 4f, 274f, 184f, 38f), string.Empty, "blank_box");
                GUI.Box(Crypto.Rect2(this.posX_r + 14f, 76f, 164f, 16f), "TOTAL  :  " + this.totalprice, "blank_red");
                GUI.DrawTexture(Crypto.Rect2(this.posX_r + 40f, 77f, 14f, 14f), this.icon_coin);
                GUI.Box(Crypto.Rect2(this.posX_r + 14f, 228f, 164f, 34f), string.Empty, "blank_white");
                if (this.selectItem >= 0)
                {
                    GUI.DrawTexture(Crypto.Rect2(this.posX_r + 16f, 229f, 32f, 32f), this.img_consumeItem[this.selectItem]);
                    GUI.Label(Crypto.Rect2(this.posX_r + 46f, 229f, 124f, 32f), Language.intxt[this.language, 0x19b + this.selectItem], "txt12_0");
                }
                else
                {
                    GUI.DrawTexture(Crypto.Rect2(this.posX_r + 22f, 234f, 20f, 20f), this.icon_info);
                    GUI.Label(Crypto.Rect2(this.posX_r + 46f, 229f, 124f, 32f), Language.intxt[this.language, 420], "txt12_0");
                }
                for (int i = 0; i < 6; i++)
                {
                    if (!this.ItemOver(i))
                    {
                        int num3 = (i / 3) * 0x42;
                        GUI.DrawTexture(Crypto.Rect2((this.posX_r + (0x34 * (i % 3))) + 20f, (float) (0x5e + num3), 48f, 63f), this.bg_item);
                        GUI.DrawTexture(Crypto.Rect2((this.posX_r + (0x34 * (i % 3))) + 20f, (float) (0x5e + num3), 48f, 48f), this.img_consumeItem[i]);
                        GUI.DrawTexture(Crypto.Rect2((this.posX_r + (0x34 * (i % 3))) + 22f, (float) (0x8d + num3), 14f, 14f), this.icon_coin);
                        GUI.Label(Crypto.Rect2((this.posX_r + (0x34 * (i % 3))) + 18f, (float) (0x8b + num3), 64f, 16f), string.Empty + this.item_price[i], "txt12_w");
                        if (GUI.Button(Crypto.Rect2((this.posX_r + (0x34 * (i % 3))) + 20f, (float) (0x5e + num3), 48f, 48f), string.Empty, this.bt_empty))
                        {
                            if (this.coin >= this.item_price[i])
                            {
                                if (this.ItemKeep(i))
                                {
                                    this.coin -= this.item_price[i];
                                }
                            }
                            else
                            {
                                this.confirm = 1;
                            }
                            this.selectItem = i;
                        }
                    }
                }
                for (int j = 0; j < 3; j++)
                {
                    GUI.Box(Crypto.Rect2((this.posX_r + 14f) + (40 * j), 36f, 32f, 32f), string.Empty, "blank_white");
                    if (this.item_slot[j] > 0)
                    {
                        GUI.DrawTexture(Crypto.Rect2((this.posX_r + 14f) + (40 * j), 36f, 32f, 32f), this.img_consumeItem[this.item_slot[j] - 1]);
                    }
                    if (GUI.Button(Crypto.Rect2((this.posX_r + 14f) + (40 * j), 36f, 32f, 32f), string.Empty, this.bt_empty) && (this.item_slot[j] > 0))
                    {
                        this.coin += this.item_price[this.item_slot[j] - 1];
                        this.totalprice -= this.item_price[this.item_slot[j] - 1];
                        this.item_slot[j] = 0;
                    }
                }
                if (GUI.Button(Crypto.Rect2(0f, 30f, 280f, 280f), string.Empty, this.bt_back))
                {
                    this.posX = 84f;
                    this.posY = -100f;
                    this.readyOn = false;
                    this.inputrect = new Rect(84f, 118f, 320f, 180f);
                    this.selectItem = -1;
                    this.coin += this.totalprice;
                    this.totalprice = 0;
                    this.script_cam.EnableMove();
                }
                if (GUI.Button(Crypto.Rect2(this.posX_r + 10f, 276f, 172f, 48f), string.Empty, this.bt_start))
                {
                    if (this.key_cave > 0)
                    {
                        if (Crypto.Property_change(-this.totalprice, false))
                        {
                            this.BattleStart();
                        }
                    }
                    else
                    {
                        this.confirm = 4;
                    }
                }
                GUI.Box(Crypto.Rect2(this.posX_r + 26f, 283f, 70f, 20f), "STAGE " + this.currentStage, "blank_box");
                GUI.DrawTexture(Crypto.Rect2(this.posX_r + 98f, 276f, 64f, 32f), this.txt_start);
            }
            else
            {
                for (int k = 0; k < 5; k++)
                {
                    if (this.skill_slot[k] >= 0)
                    {
                        GUI.DrawTexture(Crypto.Rect2(446f, (float) (0x44 + (k * 0x24)), 28f, 28f), this.skillicon[k]);
                    }
                    else
                    {
                        GUI.DrawTexture(Crypto.Rect2(446f, (float) (0x44 + (k * 0x24)), 28f, 28f), this.black);
                    }
                    GUI.DrawTexture(Crypto.Rect2(444f, (float) (0x42 + (k * 0x24)), 32f, 32f), this.img_skill_slot);
                }
                for (int m = 0; m < 5; m++)
                {
                    if (m < this.menuopen)
                    {
                        GUI.DrawTexture(Crypto.Rect2((float) (10 + (80 * m)), this.posY - 84f, 64f, 64f), this.img_menu[m]);
                        if (GUI.Button(Crypto.Rect2((float) (10 + (80 * m)), this.posY - 84f, 64f, 64f), Language.intxt[this.language, 0x18b + m], this.bt_empty))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            PlayerPrefsX.SetVector3("uiCampos2", Camera.main.transform.position);
                            switch (m)
                            {
                                case 0:
                                    Application.LoadLevel("Skill");
                                    break;

                                case 1:
                                    Application.LoadLevel("Archive");
                                    break;

                                case 2:
                                    Application.LoadLevel("Status");
                                    break;

                                case 3:
                                    Application.LoadLevel("Forge");
                                    break;

                                case 4:
                                    Application.LoadLevel("Pet");
                                    break;
                            }
                        }
                        if ((this.newarchive || this.newtreasure) && (m == 1))
                        {
                            GUI.DrawTexture(Crypto.Rect2(130f, this.posY - 92f, (float) (this.icon_size * 0x20), (float) (this.icon_size * 0x20)), this.ico_warn);
                        }
                        continue;
                    }
                    GUI.DrawTexture(Crypto.Rect2((float) (10 + (80 * m)), this.posY - 84f, 64f, 64f), this.bt_lockmenu);
                    GUI.Label(Crypto.Rect2((float) (10 + (80 * m)), this.posY - 37f, 64f, 16f), Language.intxt[this.language, 0x40] + this.menuarray[m] + Language.intxt[this.language, 0x1af], "txt12_r");
                }
                GUI.Box(Crypto.Rect2(372f, 266f, 92f, 40f), string.Empty, "blank_box");
                GUI.DrawTexture(Crypto.Rect2(384f, 267f, 20f, 20f), this.icon_key);
                GUI.Label(Crypto.Rect2(392f, 268f, 48f, 20f), string.Empty + this.key_cave, "txt14_w");
                if (this.key_cave < 5)
                {
                    GUI.Box(Crypto.Rect2(376f, 288f, 84f, 14f), string.Concat(new object[] { string.Empty, this.time_hour, " h  ", this.time_min, " m" }), "blank_red");
                }
                else
                {
                    GUI.Box(Crypto.Rect2(376f, 288f, 84f, 14f), Language.intxt[this.language, 60]);
                }
                if (GUI.Button(Crypto.Rect2(431f, 261f, 34f, 34f), string.Empty, this.bt_plus))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    Crypto.Save_int_key("cashshopkind", 3);
                    this.CashshopOpen();
                }
                if (GUI.Button(Crypto.Rect2(448f, -1f, 32f, 32f), string.Empty, this.bt_menu))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    this.pause = true;
                    if (ChannelMgr.GetInstance().getChannelId() == "000116")
                    {
                        AndroidScript.i.loadWDJAds();
                    }
                    Input.multiTouchEnabled = false;
                }
                if (GUI.Button(Crypto.Rect2(366f, 0f, 64f, 28f), string.Empty, this.bt_empty))
                {
                    Crypto.Save_int_key("gamemode", 0);
                    Application.LoadLevel("Map");
                    this.changescene = true;
                    UnityEngine.Object.Destroy(this.rankobj);
                    UnityEngine.Object.Destroy(this.bg_dun.gameObject);
                    UnityEngine.Object.Destroy(this.bg_dun_cover.gameObject);
                    UnityEngine.Object.Destroy(this.bg_dun_below.gameObject);
                }
                GUI.DrawTexture(Crypto.Rect2(366f, 1f, 64f, 26f), this.txt_extreme);
            }
            if ((this.haveGiftBox == 0) && GUI.Button(Crypto.Rect2(4f, 175f, 64f, 64f), string.Empty, this.bt_gift))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(0);
                }
                this.confirm = 0x12;
            }
            if (this.cur_general != -1)
            {
                GUI.DrawTexture(Crypto.Rect2(16f, 118f, 40f, 40f), this.prt_general);
                GUI.DrawTexture(Crypto.Rect2(18f, 161f, 36f * (((float) this.general_cur_hp) / this.cur_generalmaxhp), 4f), this.gauge_hp);
                if (this.general_cur_hp < 20)
                {
                    GUI.DrawTexture(Crypto.Rect2(16f, 118f, (float) (this.icon_size * 40), 40f), this.bg_red);
                }
            }
            else
            {
                GUI.DrawTexture(Crypto.Rect2(16f, 118f, (float) (this.icon_size * 40), 40f), this.empty);
            }
            if (GUI.Button(Crypto.Rect2(4f, 254f, 64f, 64f), Language.intxt[this.language, 400], this.bt_shop))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(0);
                }
                Crypto.Save_int_key("cashshopkind", 0);
                this.CashshopOpen();
            }
            if (this.confirm > 0)
            {
                GUI.enabled = true;
                switch (this.confirm)
                {
                    case 15:
                        GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                        GUI.Label(Crypto.Rect2(120f, 110f, 240f, 64f), Language.intxt[this.language, 0x5d], "txt12_0");
                        if (this.f_delay == 0f)
                        {
                            this.confirm = 0;
                        }
                        break;

                    case 0x12:
                        GUI.DrawTexture(Crypto.Rect2(90f, 80f, 300f, 230f), this.pop_blank2);
                        GUI.DrawTexture(Crypto.Rect2(140f, 56f, 200f, 42f), this.gift_title);
                        GUI.DrawTexture(Crypto.Rect2(350f, 70f, 40f, 48f), this.gift_five_percnt);
                        GUI.DrawTexture(Crypto.Rect2(240f, 110f, 64f, 84f), this.gift_skill);
                        GUI.DrawTexture(Crypto.Rect2(240f, 110f, 64f, 84f), this.gift_skill_bg);
                        GUI.DrawTexture(Crypto.Rect2(170f, 110f, 64f, 84f), this.gift_bg_item);
                        GUI.DrawTexture(Crypto.Rect2(170f, 110f, 64f, 64f), this.gift_coin);
                        GUI.DrawTexture(Crypto.Rect2(170f, 174f, 16f, 16f), this.icon_coin);
                        GUI.Label(Crypto.Rect2(176f, 172f, 64f, 20f), "8000", "txt12_w");
                        GUI.Label(Crypto.Rect2(120f, 220f, 240f, 16f), Language.intxt[this.language, 0x1d2], "txt12_0");
                        if (!GUI.Button(Crypto.Rect2(160f, 256f, 80f, 32f), Language.intxt[this.language, 0x1d3], this.bt_yesno))
                        {
                            if (GUI.Button(Crypto.Rect2(245f, 256f, 80f, 32f), Language.intxt[this.language, 0x1d4], this.bt_yesno))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(0);
                                }
                                AndroidScript.i.pay("100", "0", 15f, 0, "pay_offline", "010", "5104768", "010", "30000744622508", "10");
                                this.confirm = 0;
                            }
                        }
                        else
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            this.confirm = 0;
                        }
                        break;

                    case 0x13:
                        if (this.isSend)
                        {
                            HttpMsgManager manager = (HttpMsgManager) UnityEngine.Object.FindObjectOfType(typeof(HttpMsgManager));
                            if (manager != null)
                            {
                                manager.getRankList();
                            }
                            this.isSend = false;
                        }
                        GUI.DrawTexture(Crypto.Rect2(50f, 20f, 360f, 290f), this.rank_bg);
                        if (Input.GetMouseButtonDown(0))
                        {
                            this.startMousePosY = Input.mousePosition.y;
                            this.prev_scrollPosition = this.scrollPosition;
                        }
                        if (Input.GetMouseButton(0) && Crypto.Rect2(200f, 80f, 256f, 224f).Contains(Event.current.mousePosition))
                        {
                            this.curMousePosY = Input.mousePosition.y;
                            this.scrollPosition = this.prev_scrollPosition + ((Vector2) ((Vector2.up * (this.curMousePosY - this.startMousePosY)) * (640f / ((float) Screen.height))));
                        }
                        this.rank_scrollPosition = GUI.BeginScrollView(Crypto.Rect2(54f, 89f, 340f, 160f), this.rank_scrollPosition, Crypto.Rect2(54f, 89f, 330f, 1600f));
                        for (int n = 0; n < 50; n++)
                        {
                            if (this.selectblank == n)
                            {
                                this.expand_height = 40;
                            }
                            else
                            {
                                this.expand_height = 0;
                            }
                            if ((this.selectblank != -1) && (n > this.selectblank))
                            {
                                this.expand_height2 = 40;
                            }
                            else
                            {
                                this.expand_height2 = 0;
                            }
                            GUI.DrawTexture(Crypto.Rect2(66f, (float) (0x59 + (n * 0x20)), 320f, 32f), this.rank_item_bg);
                            GUI.Label(Crypto.Rect2(53f, (float) (0x63 + (n * 0x20)), 64f, 16f), string.Empty + (1 + n), "txt12_0");
                            GUI.Label(Crypto.Rect2(107f, (float) (0x63 + (n * 0x20)), 64f, 16f), "HelloWorld" + n, "txt12_0");
                            GUI.Label(Crypto.Rect2(157f, (float) (0x63 + (n * 0x20)), 64f, 16f), "90", "txt12_0");
                            GUI.Label(Crypto.Rect2(204f, (float) (0x63 + (n * 0x20)), 64f, 16f), "10000", "txt12_0");
                            GUI.Label(Crypto.Rect2(263f, (float) (0x63 + (n * 0x20)), 64f, 16f), "108", "txt12_0");
                            GUI.Label(Crypto.Rect2(325f, (float) (0x63 + (n * 0x20)), 64f, 16f), "10000", "txt12_0");
                        }
                        GUI.EndScrollView();
                        GUI.Label(Crypto.Rect2(335f, 54f, 64f, -16f), "1000", "txt12_0");
                        if (GUI.Button(Crypto.Rect2(305f, 260f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            this.confirm = 0;
                        }
                        break;

                    case 1:
                        GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                        GUI.Label(Crypto.Rect2(120f, 130f, 240f, 16f), Language.intxt[this.language, 0x16], "txt12_0");
                        if (!GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                        {
                            if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(1);
                                }
                                this.confirm = 0;
                            }
                            break;
                        }
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        Crypto.Save_int_key("cashshopkind", 2);
                        this.confirm = 0;
                        this.CashshopOpen();
                        break;

                    case 2:
                        GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                        GUI.Label(Crypto.Rect2(120f, 130f, 240f, 16f), Language.intxt[this.language, 0x15], "txt12_0");
                        if (!GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                        {
                            if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(1);
                                }
                                this.confirm = 0;
                            }
                            break;
                        }
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        Crypto.Save_int_key("cashshopkind", 1);
                        this.confirm = 0;
                        this.CashshopOpen();
                        break;

                    case 3:
                        GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                        GUI.Label(Crypto.Rect2(120f, 110f, 240f, 64f), Language.intxt[this.language, 0x10b], "txt12_0");
                        break;

                    case 4:
                        GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                        GUI.Label(Crypto.Rect2(120f, 130f, 240f, 16f), Language.intxt[this.language, 0x192], "txt12_0");
                        if (!GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                        {
                            if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(1);
                                }
                                this.confirm = 0;
                            }
                            break;
                        }
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        Crypto.Save_int_key("cashshopkind", 3);
                        this.confirm = 0;
                        this.CashshopOpen();
                        break;
                }
            }
            if (this.changescene)
            {
                GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.black_all);
                GUI.DrawTexture(Crypto.Rect2(370f, 292f, 100f, 25f), this.txt_loading);
            }
        }
    }

    public void PopUpOff()
    {
        this.confirm = 0;
    }

    public void SetMenuOpen()
    {
        this.max_stage_index = Crypto.Load_int_key("n06");
        if (this.max_stage_index >= 7)
        {
            this.menuopen = 5;
        }
        else if (this.max_stage_index >= 6)
        {
            this.menuopen = 5;
        }
        else if (this.max_stage_index >= 4)
        {
            this.menuopen = 4;
        }
        else if (this.max_stage_index >= 3)
        {
            this.menuopen = 4;
        }
        else if (this.max_stage_index >= 2)
        {
            this.menuopen = 3;
        }
        else if (this.max_stage_index >= 1)
        {
            this.menuopen = 2;
        }
        else
        {
            this.menuopen = 1;
        }
    }

    private void SetServerTime()
    {
        TimeControl.RequestServerTime();
        this.DelayWorkTime();
    }

    public void SetStage(int _index)
    {
        this.item_slot = new int[3];
        this.readyOn = true;
        this.inputrect = new Rect(10f, 120f, 242f, 180f);
        this.posX = -200f;
        this.posX_r = 550f;
        this.currentStage = _index + 1;
    }

    private void Start()
    {
        int num = Crypto.Load_int_key("n58");
        int num2 = Crypto.Load_int_key("n59");
        if (num != 0)
        {
            Crypto.Property_change(num, true);
            Crypto.Save_int_key("n58", 0);
        }
        else if (num2 != 0)
        {
            Crypto.Property_change(num2, false);
            Crypto.Save_int_key("n59", 0);
        }
        this.script_archive = GameObject.FindWithTag("Finish").GetComponent<LoopArchive>();
        this.newarchive = this.script_archive.FindArchive();
        this.newtreasure = this.script_archive.FindTreasure();
        GameObject obj2 = GameObject.Find("bg_dun");
        Vector3 zero = Vector3.zero;
        bool flag = false;
        if (obj2 == null)
        {
            GameObject obj3 = Resources.Load("bg_dun") as GameObject;
            GameObject obj4 = Resources.Load("bg_dun_cover") as GameObject;
            GameObject obj5 = Resources.Load("bg_dun_below") as GameObject;
            this.bg_dun = (Transform) UnityEngine.Object.Instantiate(obj3.transform, new Vector3(0f, -0.15f, -1f), Quaternion.identity);
            this.bg_dun_cover = (Transform) UnityEngine.Object.Instantiate(obj4.transform, new Vector3(0f, -0.15f, -0.5f), Quaternion.identity);
            this.bg_dun_below = (Transform) UnityEngine.Object.Instantiate(obj5.transform, new Vector3(0f, -0.15f, -1f), Quaternion.identity);
            this.bg_dun.name = "bg_dun";
            this.bg_dun_cover.name = "bg_dun_cover";
            this.bg_dun_below.name = "bg_dun_below";
            if (this.maxStage < 0x40)
            {
                zero = new Vector3(this.icon_stage.GetChild(this.maxStage).position.x, 0f, 1f);
            }
            else
            {
                zero = new Vector3(this.icon_stage.GetChild(this.maxStage - 1).position.x, 0f, 1f);
            }
            flag = true;
        }
        else
        {
            zero = PlayerPrefsX.GetVector3("uiCampos2");
            this.bg_dun = obj2.transform;
            this.bg_dun_cover = GameObject.Find("bg_dun_cover").transform;
            this.bg_dun_below = GameObject.Find("bg_dun_below").transform;
            flag = false;
        }
        this.script_cam.SetCover(this.bg_dun_cover, this.bg_dun_below, zero.x, flag, 1.4f + (this.maxStage * 0.05f));
        this.rankobj = GameObject.FindWithTag("ranking");
        if (this.rankobj == null)
        {
            GameObject original = Resources.Load("RankingManager") as GameObject;
            this.rankobj = (GameObject) UnityEngine.Object.Instantiate(original, Vector3.zero, Quaternion.identity);
        }
        if (GameObject.FindWithTag("sound") == null)
        {
            this.sound_UI = (Transform) UnityEngine.Object.Instantiate(this.sound_dummy, Vector3.zero, Quaternion.identity);
        }
        else
        {
            this.sound_UI = GameObject.FindWithTag("sound").transform;
        }
        this.script_soundUI = this.sound_UI.GetComponent<SoundEf_UI>();
        this.vol_bgm = PlayerPrefs.GetFloat("vol_bgm");
        this.vol_master = PlayerPrefs.GetFloat("vol_master");
        AudioListener.volume = this.vol_master;
        TimeControl.InitStart();
        this.chalv = Crypto.Load_int_key("n47");
        int num3 = Crypto.Load_int_key("n11");
        this.length_exp = (((float) num3) / ((float) (this.chalv * 100))) * 50f;
        for (int i = 0; i < this.maxStage; i++)
        {
            if (i >= 0x40)
            {
                break;
            }
            Vector3 position = this.icon_stage.GetChild(i).position;
            Transform transform = (Transform) UnityEngine.Object.Instantiate(this.num_stage_index, position, this.num_stage_index.rotation);
            transform.GetComponent<TextMesh>().text = (i + 1).ToString();
            if (this.grade_extreme[i] > 0)
            {
                UnityEngine.Object.Instantiate(this.flag_icon[this.grade_extreme[i] - 1], position + new Vector3(0f, 0.12f, -0.1f), Quaternion.identity);
            }
            else
            {
                this.icon_stage.GetChild(i).renderer.material.mainTexture = this.tex_currentStage;
                this.ring_active.position = position + new Vector3(0f, -0.044f, -0.1f);
                if (((i + 1) % 8) == 0)
                {
                    UnityEngine.Object.Instantiate(this.gifticon, position, Quaternion.identity);
                }
            }
        }
        for (int j = this.maxStage; j < 0x40; j++)
        {
            this.icon_stage.GetChild(j).localScale = Vector3.zero;
            if (((j + 1) % 8) == 0)
            {
                Vector3 vector3 = this.icon_stage.GetChild(j).position;
                UnityEngine.Object.Instantiate(this.gifticon, vector3, Quaternion.identity);
            }
        }
        this.GeneralKindOnly();
        this.CurGeneralStat(true);
        this.SetMenuOpen();
        this.SetServerTime();
        base.InvokeRepeating("Warning_iconsize", 1f, 0.34f);
        base.InvokeRepeating("SetServerTime", 29f, 30f);
        for (int k = 0; k < 5; k++)
        {
            if (this.skill_slot[k] >= 0)
            {
                int num8 = this.skill_slot[k] + 1;
                this.skillicon[k] = Resources.Load("sk_" + num8.ToString()) as Texture2D;
            }
        }
        this.SetMenuOpen();
    }

    private void Update()
    {
        if (this.b_delay)
        {
            this.f_delay -= Time.deltaTime;
            if (this.f_delay <= 0f)
            {
                this.b_delay = false;
                this.f_delay = 0f;
            }
        }
        if (!this.readyOn)
        {
            if (Input.GetMouseButtonDown(0))
            {
                RaycastHit hit;
                if (!this.script_cam.drag && Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit))
                {
                    this.hiticon = hit.transform;
                    this.hiticon.localScale = (Vector3) (Vector3.one * 0.8f);
                }
            }
            else if (Input.GetMouseButtonUp(0) && (this.hiticon != null))
            {
                if (!this.script_cam.drag)
                {
                    this.hiticon.GetComponent<Icon_Stage_Extreme>().IconDown();
                }
                this.hiticon.localScale = (Vector3) (Vector3.one * 0.7f);
                this.hiticon = null;
            }
        }
        this.posX = Mathf.MoveTowards(this.posX, 84f, Time.deltaTime * 1000f);
        this.posX_r = Mathf.MoveTowards(this.posX_r, 280f, Time.deltaTime * 1000f);
        this.posY = Mathf.MoveTowards(this.posY, 114f, Time.deltaTime * 1000f);
        this.haveGiftBox = PlayerPrefs.GetInt("haveDrawedGift", 0);
        if (PlayerPrefs.GetString("charge").CompareTo("true") == 0)
        {
            this.coin = Crypto.Load_int_key("n17");
            this.jade = Crypto.Load_int_key("n24");
            PlayerPrefs.SetString("charge", "false");
        }
    }

    public void Warning_iconsize()
    {
        this.icon_size = (this.icon_size + 1) % 2;
    }

    [CompilerGenerated]
    private sealed class <ImageLoading>c__Iterator18 : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal string _url;
        internal string <$>_url;
        internal UI_Extreme <>f__this;
        internal WWW <www>__0;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<www>__0 = new WWW(this._url);
                    this.$current = this.<www>__0;
                    this.$PC = 1;
                    return true;

                case 1:
                    if (this.<www>__0.texture.height > 8)
                    {
                        this.<>f__this.myimage = this.<www>__0.texture;
                    }
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }
}


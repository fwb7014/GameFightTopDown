using System;
using UnityEngine;

public class UI_result_extreme : MonoBehaviour
{
    private bool b_openshop;
    public GUISkin basicSkin;
    public Texture2D bg_asset;
    public GUIStyle bt_empty;
    private GameObject cashshop;
    private int chalv;
    private int changelevel;
    private int coin;
    private bool gonext = true;
    private short icon_pluspos;
    public Texture2D[] img_bts = new Texture2D[5];
    public int isclear;
    private int jade;
    private int language;
    public int max_stage_index;

    private void Awake()
    {
    }

    public void CashshopOpen(int _kind)
    {
        Crypto.Save_int_key("cashshopkind", _kind);
        if (this.cashshop == null)
        {
            this.cashshop = Resources.Load("CashShop") as GameObject;
        }
        UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
    }

    private void GoNext()
    {
        this.gonext = true;
    }

    private void OnEnable()
    {
        this.coin = Crypto.Load_int_key("n17");
        this.jade = Crypto.Load_int_key("n24");
    }

    private void OnGUI()
    {
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.skin = this.basicSkin;
        if (this.b_openshop)
        {
            GUI.DrawTexture(Crypto.Rect2(112f, 0f, 256f, 32f), this.bg_asset);
            GUI.Label(Crypto.Rect2(146f, 6f, 80f, 14f), string.Empty + this.coin, "txt12_w");
            GUI.Label(Crypto.Rect2(280f, 6f, 64f, 14f), string.Empty + this.jade, "txt12_w");
            if (GUI.Button(Crypto.Rect2(144f, 2f, 100f, 24f), string.Empty, this.bt_empty))
            {
                this.CashshopOpen(2);
            }
            if (GUI.Button(Crypto.Rect2(272f, 2f, 88f, 24f), string.Empty, this.bt_empty))
            {
                this.CashshopOpen(1);
            }
        }
        if (this.gonext)
        {
            GUI.DrawTexture(Crypto.Rect2(400f, 250f, 64f, 64f), this.img_bts[0]);
            if (GUI.Button(Crypto.Rect2(400f, 250f, 64f, 64f), Language.intxt[this.language, 0xca], this.bt_empty))
            {
                Application.LoadLevel("Extreme");
            }
            if ((this.isclear == 2) && (this.max_stage_index >= 3))
            {
                this.icon_pluspos = 0x4c;
                GUI.DrawTexture(Crypto.Rect2(324f, 250f, 64f, 64f), this.img_bts[3]);
                if (GUI.Button(Crypto.Rect2(324f, 250f, 64f, 64f), Language.intxt[this.language, 0x18e], this.bt_empty))
                {
                    Application.LoadLevel("Forge");
                }
            }
            if (this.changelevel == 1)
            {
                GUI.DrawTexture(Crypto.Rect2((float) (0x144 - this.icon_pluspos), 250f, 64f, 64f), this.img_bts[2]);
                if (GUI.Button(Crypto.Rect2((float) (0x144 - this.icon_pluspos), 250f, 64f, 64f), Language.intxt[this.language, 0x18b], this.bt_empty))
                {
                    Application.LoadLevel("Skill");
                }
            }
        }
    }

    public void OpenShop()
    {
        this.b_openshop = true;
    }

    private void Start()
    {
        this.language = PlayerPrefs.GetInt("language");
        base.audio.volume = PlayerPrefs.GetFloat("vol_bgm");
        AudioListener.volume = PlayerPrefs.GetFloat("vol_master");
        this.chalv = Crypto.Load_int_key("n47");
        if (this.chalv < 0x13)
        {
            this.changelevel = Crypto.Load_int_key("changelevel");
            if ((this.changelevel == 1) && ((this.chalv % 2) == 1))
            {
                this.changelevel = 1;
            }
            else
            {
                this.changelevel = 0;
            }
        }
        Crypto.Save_int_key("changelevel", 0);
    }

    private void Update()
    {
    }
}


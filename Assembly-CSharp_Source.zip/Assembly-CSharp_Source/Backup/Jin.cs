using System;
using UnityEngine;

public class Jin : MonoBehaviour
{
    public Transform cyl;
    private Material cyl_mat;
    private float finish_delay;
    private Transform mytransform;
    private float tune_time;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.cyl_mat = this.cyl.renderer.sharedMaterial;
        base.gameObject.active = false;
        this.cyl.gameObject.active = false;
    }

    private void OnEnable()
    {
        this.mytransform.localScale = Vector3.zero;
        this.cyl.gameObject.active = true;
    }

    private void Update()
    {
        if (Time.timeScale != 0f)
        {
            this.tune_time = Time.deltaTime / Time.timeScale;
        }
        this.finish_delay += this.tune_time;
        this.cyl_mat.mainTextureOffset += (Vector2) ((Vector2.up * this.tune_time) * 3f);
        if (this.finish_delay > 4f)
        {
            base.gameObject.active = false;
            this.cyl.gameObject.active = false;
            this.finish_delay = 0f;
        }
        else if (this.finish_delay > 3f)
        {
            this.mytransform.localScale = Vector3.Lerp(this.mytransform.localScale, Vector3.zero, this.tune_time * 3f);
        }
        else
        {
            this.mytransform.localScale = Vector3.Lerp(this.mytransform.localScale, (Vector3) (Vector3.one * 1.1f), this.tune_time * 3f);
        }
    }
}


using System;
using UnityEngine;

public class Ef_rapidstab : MonoBehaviour
{
    private int count;
    public int damagerate = 2;
    public int framesPerSecond = 0x12;
    private int index;
    private int lastframe;
    public int loopcount;
    private Collider mycollider;
    private Renderer myrenderer;
    private Transform mytransform;
    private Vector2 offset;
    private int oldindex = -1;
    private bool show;
    public float showtime = 0.15f;
    private Vector2 size;
    private float starttime;
    public int uvAnimationTileX = 4;
    public int uvAnimationTileY = 4;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myrenderer = base.renderer;
        this.mycollider = base.collider;
        this.mycollider.enabled = false;
    }

    private void Start()
    {
        this.myrenderer.enabled = false;
        this.size = new Vector2(1f / ((float) this.uvAnimationTileX), 1f / ((float) this.uvAnimationTileY));
        this.lastframe = this.uvAnimationTileX * this.uvAnimationTileY;
    }

    private void Update()
    {
        if (!this.show)
        {
            if (this.starttime < this.showtime)
            {
                this.starttime += Time.deltaTime;
            }
            else
            {
                this.myrenderer.enabled = true;
                this.starttime = 0f;
                this.show = true;
            }
        }
        else
        {
            this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * 0.1f);
            this.starttime += Time.deltaTime;
            this.index = (int) (this.starttime * this.framesPerSecond);
            float num = this.index % this.uvAnimationTileX;
            int num2 = this.index / this.uvAnimationTileX;
            if (this.index != this.oldindex)
            {
                if ((this.index % this.damagerate) == 1)
                {
                    this.mycollider.enabled = true;
                }
                else
                {
                    this.mycollider.enabled = false;
                }
                if (this.index >= this.lastframe)
                {
                    if (this.count >= this.loopcount)
                    {
                        this.myrenderer.enabled = false;
                        this.mycollider.enabled = false;
                        base.gameObject.active = false;
                        this.mytransform.position = (Vector3) (Vector3.one * 10f);
                        this.oldindex = -1;
                        this.starttime = 0f;
                        this.count = 0;
                        this.show = false;
                    }
                    else
                    {
                        this.count++;
                    }
                    this.index = 0;
                    this.oldindex = -1;
                    this.starttime = 0f;
                }
                this.offset = new Vector2(num * this.size.x, (1f - this.size.y) - (num2 * this.size.y));
                this.myrenderer.sharedMaterial.SetTextureOffset("_MainTex", this.offset);
                this.myrenderer.sharedMaterial.SetTextureScale("_MainTex", this.size);
                this.oldindex = this.index;
            }
        }
    }
}


using System;
using UnityEngine;

public class Ef_split1 : MonoBehaviour
{
    private float alphadelay;
    private float destroydelay;
    private Mesh mymesh;
    private Transform mytransform;
    private Color p_color = Color.white;
    private Color[] temp = new Color[4];

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mymesh = base.GetComponent<MeshFilter>().mesh;
    }

    public void FinishNow()
    {
        this.destroydelay = 5f;
    }

    private void Start()
    {
        base.gameObject.active = false;
    }

    private void Update()
    {
        this.destroydelay += Time.deltaTime;
        if (this.destroydelay > 4f)
        {
            this.mytransform.position = (Vector3) (Vector3.one * 3f);
            this.p_color = Color.white;
            this.destroydelay = 0f;
            for (int i = 0; i < 4; i++)
            {
                this.temp[i] = Color.white;
            }
            this.mymesh.colors = this.temp;
            base.gameObject.active = false;
        }
        else if (this.destroydelay > 3f)
        {
            this.p_color = Color.Lerp(this.p_color, Color.clear, Time.deltaTime * 5f);
            if (this.alphadelay > 0.1f)
            {
                for (int j = 0; j < 4; j++)
                {
                    this.temp[j] = this.p_color;
                }
                this.alphadelay = 0f;
                this.mymesh.colors = this.temp;
            }
            else
            {
                this.alphadelay += Time.deltaTime;
            }
        }
    }
}


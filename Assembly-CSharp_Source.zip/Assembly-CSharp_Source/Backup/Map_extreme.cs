using System;
using UnityEngine;

public class Map_extreme : MonoBehaviour
{
    public Transform trap;

    public void SetWave(int _wave)
    {
        if (this.trap != null)
        {
            this.trap.SendMessage("SetDamage", _wave * 5);
        }
    }

    public void TrapStop()
    {
        if (this.trap != null)
        {
            this.trap.SendMessage("StopActive");
        }
    }
}


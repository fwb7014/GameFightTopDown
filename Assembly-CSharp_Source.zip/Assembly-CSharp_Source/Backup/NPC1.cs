using System;
using UnityEngine;

public class NPC1 : MonoBehaviour
{
    public Transform blood;
    private Transform ef_split;
    private float neo_delay;
    private Monster_efs script_mon;
    public AudioClip snd_scream;
    private bool startcounter;

    public void Behit()
    {
        base.animation.Play("hurted2_i");
        Vector3 vector = (Vector3) ((base.transform.position + (base.transform.forward * 0.02f)) - (Vector3.up * 0.07f));
        this.script_mon.CreatGrabBlood(vector, Quaternion.Euler(70f, (float) UnityEngine.Random.Range(0, 360), 0f));
    }

    private void OnTriggerEnter(Collider other)
    {
        base.audio.Stop();
        base.audio.PlayOneShot(this.snd_scream);
        if (base.animation.IsPlaying("hurted1"))
        {
            this.startcounter = true;
            base.rigidbody.AddForce((Vector3) (base.transform.forward * 120f));
            UnityEngine.Object.Destroy(base.collider);
        }
        base.animation.Play("hurted2");
    }

    private void Start()
    {
        base.animation["hurted1"].speed = 0.35f;
        base.animation["hurted2"].speed = 0.3f;
        base.animation["hurted2_i"].speed = 0.4f;
        base.animation["hurted2_i"].layer = 1;
        Camera.main.GetComponent<Cam_Move>().LookTarget(base.transform, 0x10, 100f);
        this.ef_split = base.transform.Find("ef_split1");
        this.script_mon = GameObject.FindWithTag("efs_mon").GetComponent<Monster_efs>();
    }

    private void Update()
    {
        if (base.animation.IsPlaying("hurted1"))
        {
            base.transform.position = Vector3.MoveTowards(base.transform.position, Vector3.zero, Time.deltaTime * 0.08f);
        }
        if (this.startcounter)
        {
            this.neo_delay += Time.deltaTime;
            if (this.neo_delay >= 2f)
            {
                GameObject.FindWithTag("Player").GetComponent<Cha_Control>().WakToward(base.transform.position, true, false);
                this.ef_split.renderer.material.SetTextureScale("_MainTex", (Vector2) (Vector2.one * 0.5f));
                this.ef_split.renderer.enabled = true;
                this.startcounter = false;
            }
        }
    }
}


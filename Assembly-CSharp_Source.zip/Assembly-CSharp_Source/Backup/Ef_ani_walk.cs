using System;
using UnityEngine;

public class Ef_ani_walk : MonoBehaviour
{
    private Texture2D ani_img;
    private int ani_index;
    private bool anistart;
    private int framesPerSecond = 0x10;
    private int index;
    private int lastframe;
    private int loopcount;
    private Material mymaterial;
    private Transform mytransform;
    private Vector2 offset;
    private int oldindex = -1;
    private UI_map script_ui;
    private Vector2 size;
    private float starttime;
    private int targetloopcount;
    private float uIndex;
    private int uvAnimationTileX = 4;
    private int uvAnimationTileY = 4;
    private int vIndex;

    public void AniStart(int _index)
    {
        base.gameObject.active = true;
        this.ani_index = _index;
        this.starttime = 0f;
        this.index = 0;
        this.oldindex = -1;
        this.offset = (Vector2) (Vector2.up * (1f - this.size.y));
        this.mymaterial.SetTextureOffset("_MainTex", this.offset);
        if (_index == 0)
        {
            this.ani_img = Resources.Load("ani_explore_cha") as Texture2D;
            base.renderer.material.mainTexture = this.ani_img;
            this.mytransform.localScale = Vector3.zero;
            this.targetloopcount = 3;
        }
        else if (_index == 2)
        {
            this.ani_img = Resources.Load("ani_explore_cha_suc") as Texture2D;
            base.renderer.material.mainTexture = this.ani_img;
            this.mytransform.localScale = (Vector3) (Vector3.one * 2f);
            this.targetloopcount = 0;
        }
        else if (_index == 3)
        {
            this.ani_img = Resources.Load("ani_explore_cha_fail") as Texture2D;
            base.renderer.material.mainTexture = this.ani_img;
            this.mytransform.localScale = (Vector3) (Vector3.one * 2f);
            this.targetloopcount = 0;
        }
        else if (_index == 1)
        {
            this.ani_img = Resources.Load("ani_explore_treasure") as Texture2D;
            base.renderer.material.mainTexture = this.ani_img;
            this.mytransform.localScale = (Vector3) (Vector3.one * 2f);
            this.targetloopcount = 1;
        }
        else if (_index == 4)
        {
            this.ani_img = Resources.Load("ef_perfect") as Texture2D;
            base.renderer.material.mainTexture = this.ani_img;
            this.mytransform.localScale = (Vector3) (Vector3.one * 2f);
            this.targetloopcount = 100;
        }
        this.anistart = true;
    }

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mymaterial = base.renderer.material;
        this.script_ui = GameObject.FindWithTag("ui").GetComponent<UI_map>();
    }

    private void Start()
    {
        this.starttime = 0f;
        this.lastframe = this.uvAnimationTileX * this.uvAnimationTileY;
        this.size = new Vector2(1f / ((float) this.uvAnimationTileX), 1f / ((float) this.uvAnimationTileY));
        base.gameObject.active = false;
    }

    private void Update()
    {
        this.mytransform.localScale = Vector3.MoveTowards(this.mytransform.localScale, (Vector3) (Vector3.one * 2f), Time.deltaTime * 15f);
        if (this.anistart)
        {
            this.starttime += Time.deltaTime;
            this.index = (int) (this.starttime * this.framesPerSecond);
            this.uIndex = this.index % this.uvAnimationTileX;
            this.vIndex = this.index / this.uvAnimationTileY;
            if (this.index != this.oldindex)
            {
                if (this.index >= this.lastframe)
                {
                    if (this.loopcount >= this.targetloopcount)
                    {
                        this.anistart = false;
                        this.loopcount = 0;
                        if (this.ani_index == 0)
                        {
                            if (this.script_ui.GetGeneral())
                            {
                                this.AniStart(2);
                            }
                            else
                            {
                                this.AniStart(3);
                            }
                        }
                        else if (this.ani_index == 1)
                        {
                            this.script_ui.GetTreasure();
                        }
                        else if (this.ani_index == 2)
                        {
                            this.script_ui.AniFinish(true);
                        }
                        else if (this.ani_index == 3)
                        {
                            this.script_ui.AniFinish(false);
                        }
                    }
                    else
                    {
                        this.loopcount++;
                        this.index = 0;
                        this.starttime = 0f;
                    }
                }
                else
                {
                    this.offset = (Vector2) (((Vector2.right * this.uIndex) * this.size.x) + (Vector2.up * ((1f - this.size.y) - (this.vIndex * this.size.y))));
                    this.mymaterial.SetTextureOffset("_MainTex", this.offset);
                    this.mymaterial.SetTextureScale("_MainTex", this.size);
                    this.oldindex = this.index;
                }
            }
        }
    }
}


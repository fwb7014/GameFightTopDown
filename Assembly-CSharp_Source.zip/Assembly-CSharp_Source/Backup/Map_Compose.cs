using System;
using UnityEngine;

public class Map_Compose : MonoBehaviour
{
    public Transform barricate;
    private float barricate_posX;
    private Transform[] c_barricate = new Transform[7];
    private Transform[] c_enemy = new Transform[3];
    private Transform[] c_soulstone = new Transform[14];
    private Transform clone_obj;
    private Transform[] clone_pmap = new Transform[2];
    private int count_barricate;
    private int count_soulstone;
    public Transform dummy_gui;
    public Transform enemy;
    public int finalmap = 1;
    public Transform[] map = new Transform[5];
    private short maplength;
    private float[] mapposZ = new float[2];
    private const int MAXCOIN = 14;
    private const int MAXENEMY = 3;
    private const int MAXOBJ = 7;
    private int negative_factor;
    public Transform soulstone;
    private float ss_creat_delay;
    private float ss_creat_time = 100f;
    private float ss_posX;
    private int tutorial = -1;

    private void Awake()
    {
        if (GameObject.Find("Loading_f") == null)
        {
            this.LoadingFinish();
            Camera.main.transform.GetChild(0).gameObject.active = true;
        }
    }

    public void LoadingFinish()
    {
        this.ss_creat_time = UnityEngine.Random.Range((float) 1.5f, (float) 2f);
        this.ss_creat_delay = 0f;
        this.tutorial = Crypto.Load_int_key("tutorial");
        if (this.tutorial == 5)
        {
            this.dummy_gui.gameObject.active = true;
            Time.timeScale = 1E-06f;
            Crypto.Save_int_key("tutorial", -1);
            GameObject.Find("pet_horse_riding").audio.Stop();
        }
    }

    private void Start()
    {
        base.audio.volume = PlayerPrefs.GetFloat("vol_bgm");
        AudioListener.volume = PlayerPrefs.GetFloat("vol_master");
        float num = 0f;
        int num2 = Crypto.Load_int_key("cur_stage_kind");
        for (int i = 0; i < 2; i++)
        {
            this.mapposZ[i] += num;
            num += 40f;
            this.clone_pmap[i] = (Transform) UnityEngine.Object.Instantiate(this.map[num2 - 1], (Vector3) (Vector3.forward * this.mapposZ[i]), Quaternion.identity);
        }
        for (int j = 0; j < 3; j++)
        {
            this.c_enemy[j] = (Transform) UnityEngine.Object.Instantiate(this.enemy, (Vector3) ((3 + j) * Vector3.one), Quaternion.identity);
        }
        for (int k = 0; k < 7; k++)
        {
            this.c_barricate[k] = (Transform) UnityEngine.Object.Instantiate(this.barricate, (Vector3) (-2f * Vector3.forward), Quaternion.identity);
        }
        for (int m = 0; m < 14; m++)
        {
            this.c_soulstone[m] = (Transform) UnityEngine.Object.Instantiate(this.soulstone, (Vector3) (-2f * Vector3.forward), Quaternion.identity);
        }
    }

    private void Update()
    {
        this.ss_creat_delay += Time.deltaTime;
        if (this.ss_creat_delay >= this.ss_creat_time)
        {
            int num = UnityEngine.Random.Range(0, 20);
            if (num < 2)
            {
                num = 2;
            }
            if (num >= 12)
            {
                this.barricate_posX = UnityEngine.Random.Range((float) -0.06f, (float) 0.06f);
                this.ss_posX = UnityEngine.Random.Range((float) -0.3f, (float) 0.3f);
                for (int j = 0; j < 8; j++)
                {
                    this.c_soulstone[this.count_soulstone].position = (Vector3) ((Vector3.right * (this.ss_posX + (this.barricate_posX * j))) + (Vector3.forward * (2f + (0.3f * j))));
                    this.count_soulstone = (this.count_soulstone + 1) % 14;
                }
            }
            else if (num >= 6)
            {
                for (int k = 0; k < 3; k++)
                {
                    if (!this.c_enemy[k].gameObject.active)
                    {
                        int num4 = (UnityEngine.Random.Range(0, 2) * 2) - 1;
                        this.c_enemy[k].gameObject.active = true;
                        this.c_enemy[k].position = new Vector3(num4 * 1.4f, 0f, UnityEngine.Random.Range((float) -0.2f, (float) 0.7f));
                        break;
                    }
                }
            }
            else
            {
                this.ss_posX = UnityEngine.Random.Range((float) -0.3f, (float) 0.3f);
                this.c_soulstone[this.count_soulstone].position = (Vector3) ((Vector3.right * this.ss_posX) + (Vector3.forward * 3f));
                this.count_soulstone = (this.count_soulstone + 1) % 14;
                this.barricate_posX = this.ss_posX - ((0.18f * num) * 0.5f);
                this.negative_factor = 0;
                for (int m = 0; m < (num + 2); m++)
                {
                    this.c_barricate[this.count_barricate].position = (Vector3) ((Vector3.right * this.barricate_posX) + (Vector3.forward * (2.2f + UnityEngine.Random.Range((float) -0.1f, (float) 0.1f))));
                    this.c_barricate[this.count_barricate].rotation = Quaternion.Euler(0f, (float) (this.negative_factor + UnityEngine.Random.Range(-24, 0x18)), 0f);
                    this.barricate_posX += 0.18f;
                    this.negative_factor += 180;
                    this.count_barricate = (this.count_barricate + 1) % 7;
                }
            }
            this.ss_creat_time = UnityEngine.Random.Range((float) 1.6f, (float) 2f);
            this.ss_creat_time = 1.6f;
            this.ss_creat_delay = 0f;
        }
        for (int i = 0; i < 2; i++)
        {
            this.mapposZ[i] += -1.8f * Time.deltaTime;
            if (this.mapposZ[i] < -40f)
            {
                this.mapposZ[i] += 80f;
                this.clone_pmap[i].position = (Vector3) (Vector3.forward * this.mapposZ[i]);
                this.maplength = (short) (this.maplength + 1);
                if (this.maplength >= this.finalmap)
                {
                    GameObject.Find("pet_horse_riding").GetComponent<Cha_Control_ride_horse>().RidingFinish();
                }
            }
            this.clone_pmap[i].position = (Vector3) (Vector3.forward * this.mapposZ[i]);
        }
    }
}


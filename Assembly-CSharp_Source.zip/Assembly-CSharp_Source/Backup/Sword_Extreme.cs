using System;
using UnityEngine;

public class Sword_Extreme : MonoBehaviour
{
    private Transform cha1;
    private float delay;
    private bool efOn;
    private Collider mycollider;
    private Transform mytransform;
    private Vector3 startPos;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.cha1 = GameObject.FindWithTag("Player").transform;
        this.mycollider = base.collider;
    }

    private void ColliderOn()
    {
        this.mycollider.enabled = false;
        this.mycollider.enabled = true;
    }

    private void OnEnable()
    {
        this.delay = 1.5f;
        this.efOn = false;
        base.gameObject.layer = 0x10;
        this.mycollider.enabled = true;
        this.startPos = this.mytransform.position;
    }

    public void SetPower(int _amount)
    {
        base.rigidbody.mass = _amount * 0.4f;
    }

    private void Update()
    {
        this.delay -= Time.deltaTime;
        if (this.delay < -1.5)
        {
            base.particleSystem.Clear();
            base.gameObject.active = false;
        }
        else if (this.delay < -1f)
        {
            base.CancelInvoke();
        }
        else if (this.delay < 0f)
        {
            this.mytransform.position = Vector3.Lerp(this.mytransform.position, this.cha1.position + ((Vector3) (Vector3.up * 0.2f)), Time.deltaTime * 3.5f);
            if (!this.efOn)
            {
                this.mytransform.position = this.startPos;
                base.gameObject.layer = 0x11;
                base.InvokeRepeating("ColliderOn", 0.01f, 0.1f);
                this.efOn = true;
                base.particleSystem.Play();
            }
        }
        else
        {
            this.mytransform.position = this.cha1.position;
        }
    }
}


using System;
using UnityEngine;

public class PickParent : MonoBehaviour
{
    private Renderer myrenderer;
    private Transform mytransform;
    private Transform parentdummy;
    private Transform split;

    private void Awake()
    {
        this.split = base.transform.GetChild(0);
        this.mytransform = base.transform;
        this.myrenderer = base.renderer;
        this.parentdummy = GameObject.FindWithTag("dummy").transform;
        base.transform.parent = this.parentdummy;
    }

    private void OnEnable()
    {
        this.mytransform.position = this.parentdummy.position + ((Vector3) (Vector3.up * 0.1f));
        this.mytransform.rotation = Quaternion.Euler(0f, this.parentdummy.eulerAngles.y, 0f);
        this.mytransform.localScale = Vector3.zero;
        this.split.gameObject.active = false;
    }

    private void Update()
    {
        if (this.myrenderer.enabled && (this.mytransform.localScale.x < 1f))
        {
            this.mytransform.localScale += (Vector3) ((Vector3.one * Time.deltaTime) * 2f);
            this.split.gameObject.active = true;
        }
    }
}


using System;
using UnityEngine;

public class Cha_Costume_shop : MonoBehaviour
{
    private GameObject curCostum;
    private int current_costume;
    private Transform mytransform;
    private GameObject prevCostum;
    private AnimationState tt;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.current_costume = Crypto.Load_int_key("n43");
    }

    public void Costume(int _costume)
    {
        if ((_costume + 1) < base.transform.GetChildCount())
        {
            this.curCostum = base.transform.GetChild(_costume + 1).gameObject;
            if (this.prevCostum != null)
            {
                this.prevCostum.active = false;
            }
            this.curCostum.active = true;
            this.prevCostum = this.curCostum;
        }
    }

    private void Start()
    {
        this.tt = base.animation["costume"];
        int childCount = base.transform.childCount;
        for (int i = 1; i < childCount; i++)
        {
            this.mytransform.GetChild(i).gameObject.active = false;
        }
        this.Costume(this.current_costume);
    }

    private void Update()
    {
        this.tt.time = Time.realtimeSinceStartup * 0.24f;
    }
}


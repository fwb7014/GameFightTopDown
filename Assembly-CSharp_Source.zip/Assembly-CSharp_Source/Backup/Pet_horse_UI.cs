using System;
using UnityEngine;

public class Pet_horse_UI : MonoBehaviour
{
    private void Start()
    {
        base.animation["horse_run"].speed = 0.5f;
        base.animation["horse_stand"].speed = 0.16f;
        base.animation["horse_cry"].speed = 0.32f;
        base.animation["horse_jump"].speed = 0.3f;
    }

    private void Update()
    {
    }
}


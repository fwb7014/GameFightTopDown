using System;
using UnityEngine;

public class Cam_intro : MonoBehaviour
{
    public Transform cha;
    private float dx = 0.1f;
    public Transform gate;
    public Transform mon1;
    public Transform mon2;
    private bool startui;
    private Color tintcolor;
    private Color tintcolor2;
    public Transform UI_intro;

    private void Awake()
    {
    }

    private void Start()
    {
        base.camera.orthographicSize = this.dx;
        this.tintcolor = Color.clear;
        this.tintcolor2 = Color.black;
        this.cha.renderer.material.SetColor("_TintColor", this.tintcolor);
        this.mon1.renderer.material.SetColor("_TintColor", this.tintcolor2);
        this.mon2.renderer.material.SetColor("_TintColor", this.tintcolor2);
    }

    private void StartGUI()
    {
        this.UI_intro.GetComponent<UI_intro>().StartGUI();
    }

    private void Update()
    {
        this.dx = Mathf.Lerp(this.dx, 1f, Time.deltaTime);
        base.camera.projectionMatrix = Matrix4x4.Ortho(-1.5f * this.dx, 1.5f * this.dx, -this.dx, this.dx, 0.3f, 5f);
        this.gate.localScale = Vector3.Lerp(this.gate.localScale, new Vector3(6f, 12f, 0f), Time.deltaTime * 1f);
        this.gate.position = Vector3.Lerp(this.gate.position, new Vector3(0f, 0f, 2.5f), Time.deltaTime * 1f);
        if (this.dx > 0.85f)
        {
            if (!this.startui)
            {
                base.Invoke("StartGUI", 0.5f);
                this.startui = true;
            }
            this.cha.position = Vector3.Lerp(this.cha.position, new Vector3(0f, -0.22f, 2f), Time.deltaTime * 3f);
            this.cha.localScale = Vector3.Lerp(this.cha.localScale, (Vector3) (Vector3.one * 5f), Time.deltaTime * 3f);
            this.tintcolor = Color.Lerp(this.tintcolor, Color.gray, Time.deltaTime * 2f);
            this.tintcolor2 = Color.Lerp(this.tintcolor2, Color.gray, Time.deltaTime * 2f);
            this.cha.renderer.material.SetColor("_TintColor", this.tintcolor);
        }
        if (this.dx > 0.4f)
        {
            this.mon1.renderer.material.SetColor("_TintColor", this.tintcolor2);
            this.mon2.renderer.material.SetColor("_TintColor", this.tintcolor2);
            this.mon1.position = Vector3.Lerp(this.mon1.position, new Vector3(1.2f, -0.32f, 2f), Time.deltaTime * 3f);
            this.mon1.localScale = Vector3.Lerp(this.mon1.localScale, new Vector3(2f, 4f, 0f), Time.deltaTime * 3f);
            this.mon2.position = Vector3.Lerp(this.mon2.position, new Vector3(-1.2f, -0.32f, 2f), Time.deltaTime * 3f);
            this.mon2.localScale = Vector3.Lerp(this.mon2.localScale, new Vector3(2f, 4f, 0f), Time.deltaTime * 3f);
        }
    }
}


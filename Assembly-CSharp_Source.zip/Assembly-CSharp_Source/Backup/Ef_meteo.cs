using System;
using UnityEngine;

public class Ef_meteo : MonoBehaviour
{
    public Transform meteosplash;
    private bool splash;
    private bool thisIsOrigin;

    private void Start()
    {
        if (base.transform.position.y > 4.6f)
        {
            this.thisIsOrigin = true;
            base.renderer.enabled = false;
        }
        else
        {
            base.renderer.enabled = true;
        }
    }

    private void Update()
    {
        if (!this.thisIsOrigin)
        {
            if (base.transform.position.y > 0f)
            {
                Transform transform1 = base.transform;
                transform1.eulerAngles -= (Vector3) (new Vector3(0f, 400f, 0f) * Time.deltaTime);
                Transform transform2 = base.transform;
                transform2.position += (Vector3) (new Vector3(0f, -2.4f, 0f) * Time.deltaTime);
            }
            else if (!this.splash)
            {
                base.transform.localScale = new Vector3(0f, 0f, 0f);
                GameObject.Find("MainCamera").GetComponent<Cam_Move>().Hitcam();
                Transform transform = (Transform) UnityEngine.Object.Instantiate(this.meteosplash, new Vector3(base.transform.position.x, 0.05f, base.transform.position.z), Quaternion.identity);
                UnityEngine.Object.Destroy(transform.gameObject, 0.3f);
                this.splash = true;
            }
        }
    }
}


using System;
using UnityEngine;

public class UI_Ingame_GUI : MonoBehaviour
{
    public Transform angel;
    private bool angelOn;
    public GUIStyle bar_slide;
    public GUISkin basicSkin;
    public Texture2D bg_option;
    public Texture2D bg_pause;
    public GUIStyle bt_yesno;
    private GameObject cashshop;
    private bool cashshopOn;
    private bool chance;
    private float color_alpha;
    private int count = 10;
    private int getAngelIndex;
    private int guide_curent_subindex;
    private Texture2D guide_img;
    private Rect guide_img_rect;
    private int guide_index;
    private int guide_maxindex = 1;
    private bool guide_point;
    private Vector2 guide_point_pos = Vector2.zero;
    private short guide_txt;
    private bool guidestart;
    public Texture2D ico_slide;
    public Texture2D icon_jade;
    private bool infinitymode;
    private int jade;
    private int language;
    private bool option;
    private bool pause;
    public GUIStyle pausemenu;
    public Texture2D pop_blank;
    private int require_jade = 1;
    private Cha_Control script_cha;
    private General_Stat script_generalstat;
    private Spawn script_spawn;
    private UI_Ingame script_UI;
    public GUIStyle sel_lang;
    private bool showAds;
    private bool slideon;
    private bool slideon2;
    private int tempcamfov;
    public Texture2D touchthis;
    private float vol_bgm;
    private float vol_master;
    public GUIStyle zoom;

    public void ChanceOn()
    {
        Time.timeScale = 0.5f;
        this.chance = true;
        base.InvokeRepeating("CountDown", 0.5f, 0.5f);
    }

    public void CountDown()
    {
        this.count--;
        if (this.count <= 0)
        {
            this.chance = false;
            Time.timeScale = 1f;
            this.script_UI.WaveSet(-1);
        }
    }

    public void GetAngel(int _index)
    {
        this.getAngelIndex = _index;
        Crypto.Save_int_key("n61", this.getAngelIndex);
        this.angelOn = true;
        base.Invoke("GetAngelFinish", 2.4f);
        this.angel.gameObject.active = true;
        this.angel.GetComponent<AI_Asist>().SetIndex(this.getAngelIndex);
    }

    private void GetAngelFinish()
    {
        this.angelOn = false;
        base.gameObject.active = false;
        GC.Collect();
    }

    private void OnEnable()
    {
        this.jade = Crypto.Load_int_key("n24");
    }

    private void OnGUI()
    {
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.skin = this.basicSkin;
        GUI.depth = 0;
        if (this.chance)
        {
            if (this.infinitymode && (this.require_jade > 15))
            {
                this.chance = false;
                Time.timeScale = 1f;
                this.script_UI.WaveSet(-1);
                return;
            }
            this.color_alpha += Time.deltaTime;
            this.color_alpha = Mathf.Clamp(this.color_alpha, 0f, 1f);
            GUI.color = (Color) (Color.black * this.color_alpha);
            GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.bg_pause);
            if (this.count <= 9)
            {
                GUI.color = Color.white;
                GUI.Label(Crypto.Rect2(0f, 130f, 480f, 16f), Language.intxt[this.language, 0xcb] + "...  " + this.count, "txt14_w");
                GUI.Label(Crypto.Rect2(246f, 150f, 32f, 16f), string.Empty + this.require_jade, "txt14_w");
                GUI.DrawTexture(Crypto.Rect2(230f, 150f, 16f, 16f), this.icon_jade);
                if (this.jade >= this.require_jade)
                {
                    GUI.Label(Crypto.Rect2(112f, 170f, 256f, 16f), string.Concat(new object[] { "(", Language.intxt[this.language, 0xcc], "    ", this.jade, ")" }), "txt12_w");
                    if (GUI.Button(Crypto.Rect2(170f, 190f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                    {
                        if (Crypto.Property_change(-this.require_jade, true))
                        {
                            this.chance = false;
                            this.color_alpha = 0f;
                            this.count = 10;
                            Time.timeScale = 1f;
                            this.script_cha.Resurection();
                            this.script_UI.Resurrection();
                            base.gameObject.active = false;
                            this.cashshopOn = false;
                            base.CancelInvoke();
                            int num = this.require_jade;
                            PurchaseLog.LogOn(Language.intxt[this.language, 0xea] + " (" + this.require_jade.ToString() + ")\t" + Language.intxt[this.language, 0xef]);
                            this.jade -= this.require_jade;
                            if (this.infinitymode)
                            {
                                this.require_jade += 3;
                            }
                            else
                            {
                                this.require_jade *= 2;
                            }
                            string jsonValue = "{jade:" + num + ",type: revive}";
                            AndroidScript.i.LogEvent("consumeJade", jsonValue);
                        }
                        GC.Collect();
                    }
                }
                else
                {
                    GUI.Label(Crypto.Rect2(112f, 170f, 256f, 16f), string.Concat(new object[] { "(", Language.intxt[this.language, 0xcc], "    ", this.jade, ")" }), "txt12_r");
                    if (GUI.Button(Crypto.Rect2(170f, 190f, 64f, 32f), Language.intxt[this.language, 0xcf], this.bt_yesno))
                    {
                        Crypto.Save_int_key("cashshopkind", 1);
                        if (this.cashshop == null)
                        {
                            this.cashshop = Resources.Load("CashShop") as GameObject;
                        }
                        UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
                        this.cashshopOn = true;
                    }
                }
                if (GUI.Button(Crypto.Rect2(246f, 190f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                {
                    this.chance = false;
                    Time.timeScale = 1f;
                    this.script_UI.WaveSet(-1);
                }
            }
        }
        else if (this.angelOn)
        {
            GUI.Box(Crypto.Rect2(112f, 90f, 256f, 14f), Language.intxt[this.language, 0x1b2]);
            GUI.Box(Crypto.Rect2(112f, 176f, 256f, 36f), Language.intxt[this.language, 0x1b3]);
        }
        else if (this.option)
        {
            if (this.slideon)
            {
                this.vol_bgm = ((Input.mousePosition.x * (480f / ((float) Screen.width))) - 214f) / 126f;
                this.vol_bgm = Mathf.Clamp(this.vol_bgm, 0f, 1f);
            }
            else if (this.slideon2)
            {
                this.vol_master = ((Input.mousePosition.x * (480f / ((float) Screen.width))) - 214f) / 126f;
                this.vol_master = Mathf.Clamp(this.vol_master, 0f, 1f);
            }
            GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.bg_pause);
            GUI.DrawTexture(Crypto.Rect2(112f, 60f, 256f, 256f), this.bg_option);
            GUI.Label(Crypto.Rect2(128f, 83f, 70f, 16f), Language.intxt[this.language, 0x12e], "txt12_w");
            GUI.Label(Crypto.Rect2(128f, 118f, 70f, 16f), Language.intxt[this.language, 0xf4], "txt12_w");
            GUI.Label(Crypto.Rect2(128f, 155f, 70f, 16f), Language.intxt[this.language, 90], "txt12_w");
            GUI.Label(Crypto.Rect2(128f, 194f, 70f, 16f), Language.intxt[this.language, 0xf5], "txt12_w");
            if (GUI.Button(Crypto.Rect2(212f, 186f, 128f, 32f), Language.intxt[this.language, 0xf6], this.sel_lang))
            {
                short num2 = 2;
                this.language = (this.language + 1) % num2;
                PlayerPrefs.SetInt("language", this.language);
            }
            if (GUI.RepeatButton(Crypto.Rect2(200f, 76f, 152f, 32f), string.Empty, this.bar_slide))
            {
                this.slideon2 = true;
            }
            else if (this.slideon2)
            {
                AudioListener.volume = this.vol_master;
                this.slideon2 = false;
            }
            GUI.DrawTexture(Crypto.Rect2((this.vol_master * 126f) + 206f, 84f, 16f, 16f), this.ico_slide);
            if (GUI.RepeatButton(Crypto.Rect2(200f, 111f, 152f, 32f), string.Empty, this.bar_slide))
            {
                this.slideon = true;
            }
            else if (this.slideon)
            {
                this.script_spawn.SetBGM(this.vol_bgm);
                this.slideon = false;
            }
            GUI.DrawTexture(Crypto.Rect2((this.vol_bgm * 126f) + 206f, 119f, 16f, 16f), this.ico_slide);
            if (GUI.Button(Crypto.Rect2(208f, 223f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
            {
                this.option = false;
                PlayerPrefs.SetFloat("vol_bgm", this.vol_bgm);
                PlayerPrefs.SetFloat("vol_master", this.vol_master);
            }
            if (GUI.Button(Crypto.Rect2(214f, 147f, 32f, 32f), "-", this.zoom))
            {
                if (this.tempcamfov > 0)
                {
                    this.tempcamfov--;
                    Camera.main.GetComponent<Cam_Move>().FovTest((float) ((this.tempcamfov * -2) + 30));
                    Crypto.Save_int_key("camfov", this.tempcamfov);
                }
            }
            else if (GUI.Button(Crypto.Rect2(308f, 147f, 32f, 32f), "+", this.zoom) && (this.tempcamfov < 5))
            {
                this.tempcamfov++;
                Camera.main.GetComponent<Cam_Move>().FovTest((float) ((this.tempcamfov * -2) + 30));
                Crypto.Save_int_key("camfov", this.tempcamfov);
            }
            GUI.Label(Crypto.Rect2(260f, 147f, 32f, 32f), "x " + this.tempcamfov, "txt12_w");
        }
        else if (this.pause)
        {
            GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.bg_pause);
            if (GUI.Button(Crypto.Rect2(112f, 80f, 256f, 64f), Language.intxt[this.language, 30], this.pausemenu))
            {
                Time.timeScale = 1f;
                this.pause = false;
                this.script_cha.StartControl();
                base.gameObject.active = false;
                GC.Collect();
            }
            else if (GUI.Button(Crypto.Rect2(112f, 130f, 256f, 64f), Language.intxt[this.language, 0x1f], this.pausemenu))
            {
                this.option = true;
            }
            else if (GUI.Button(Crypto.Rect2(112f, 180f, 256f, 64f), Language.intxt[this.language, 0x3b], this.pausemenu))
            {
                Time.timeScale = 1f;
                this.pause = false;
                this.script_UI.WaveSet(-1);
            }
        }
        if (this.guidestart)
        {
            GUI.DrawTexture(Crypto.Rect2(112f, 96f, 256f, 128f), this.pop_blank);
            GUI.Label(Crypto.Rect2(120f, 102f, 240f, 36f), string.Empty + Language.intxt[this.language, this.guide_txt], "txt12_0");
            GUI.Label(Crypto.Rect2(118f, 200f, 244f, 14f), string.Concat(new object[] { string.Empty, this.guide_curent_subindex + 1, " / ", this.guide_maxindex }), "txt12_0");
            GUI.DrawTexture(this.guide_img_rect, this.guide_img);
            if (this.guide_point)
            {
                GUI.DrawTexture(Crypto.Rect2(this.guide_point_pos.x, this.guide_point_pos.y, 64f, 64f), this.touchthis);
            }
            if ((this.guide_maxindex - 1) <= this.guide_curent_subindex)
            {
                if (GUI.Button(Crypto.Rect2(290f, 184f, 64f, 32f), Language.intxt[this.language, 4], this.bt_yesno))
                {
                    this.guidestart = false;
                    Time.timeScale = 1f;
                    base.gameObject.active = false;
                    this.script_cha.StartControl();
                }
            }
            else if (GUI.Button(Crypto.Rect2(290f, 184f, 64f, 32f), Language.intxt[this.language, 0x2f], this.bt_yesno))
            {
                this.guide_curent_subindex++;
                this.SetTutorial(this.guide_index, this.guide_curent_subindex);
            }
        }
    }

    public void PauseOn()
    {
        if (this.cashshopOn)
        {
            base.gameObject.active = false;
        }
        else
        {
            base.gameObject.active = true;
            Time.timeScale = 0f;
            this.script_cha.StopControl();
            this.pause = true;
            if (ChannelMgr.GetInstance().getChannelId() == "000116")
            {
                AndroidScript.i.loadWDJAds();
                this.showAds = false;
            }
        }
    }

    public void SetTutorial(int _index, int _subindex)
    {
        Time.timeScale = 0f;
        this.script_cha.StopControl();
        this.guidestart = true;
        this.guide_txt = 0;
        this.guide_curent_subindex = _subindex;
        this.guide_index = _index;
        int num = (this.guide_index * 10) + this.guide_curent_subindex;
        this.guide_img = Resources.Load("guide" + num.ToString()) as Texture2D;
        switch (num)
        {
            case 10:
                this.guide_txt = 0x152;
                this.guide_maxindex = 3;
                this.guide_point = false;
                this.guide_img_rect = Crypto.Rect2(170f, 134f, 128f, 64f);
                break;

            case 11:
                this.guide_txt = 0x153;
                this.guide_point = false;
                this.guide_img_rect = Crypto.Rect2(170f, 134f, 128f, 64f);
                break;

            case 12:
                this.guide_txt = 340;
                this.guide_point = false;
                this.guide_img_rect = Crypto.Rect2(170f, 134f, 128f, 64f);
                break;

            case 50:
                this.guide_txt = 0x157;
                this.guide_maxindex = 3;
                this.guide_point = false;
                this.guide_point_pos = new Vector2(10f, 40f);
                this.guide_img_rect = Crypto.Rect2(170f, 134f, 128f, 64f);
                break;

            case 0x33:
                this.guide_txt = 0x158;
                this.guide_point = false;
                this.guide_img_rect = Crypto.Rect2(170f, 134f, 128f, 64f);
                break;

            case 0x34:
                this.guide_txt = 0x159;
                this.guide_point = false;
                this.guide_img_rect = Crypto.Rect2(170f, 134f, 128f, 64f);
                break;

            case 20:
                this.guide_txt = 0x155;
                this.guide_maxindex = 2;
                this.guide_point = false;
                this.guide_img_rect = Crypto.Rect2(170f, 134f, 128f, 64f);
                break;

            case 0x15:
                this.guide_txt = 0x156;
                this.guide_img_rect = Crypto.Rect2(150f, 110f, 40f, 80f);
                break;

            case 30:
                this.guide_txt = 0x24;
                this.guide_maxindex = 2;
                this.guide_point = false;
                this.guide_img_rect = Crypto.Rect2(170f, 134f, 128f, 64f);
                break;

            case 0x1f:
                this.guide_txt = 0x167;
                this.guide_point = false;
                this.guide_img_rect = Crypto.Rect2(170f, 134f, 128f, 64f);
                break;

            case 40:
                this.guide_txt = 0x15a;
                this.guide_maxindex = 2;
                this.guide_point = true;
                this.guide_point_pos = new Vector2(10f, 40f);
                this.guide_img_rect = Crypto.Rect2(170f, 134f, 128f, 64f);
                break;

            case 0x29:
                this.guide_txt = 0x15b;
                this.guide_point = false;
                this.guide_img_rect = Crypto.Rect2(170f, 134f, 128f, 64f);
                break;

            case 60:
                this.guide_txt = 0x15c;
                this.guide_maxindex = 2;
                this.guide_point = false;
                this.guide_img_rect = Crypto.Rect2(170f, 134f, 128f, 64f);
                break;

            case 0x3d:
                this.guide_txt = 0x15d;
                this.guide_point = false;
                this.guide_img_rect = Crypto.Rect2(170f, 134f, 128f, 64f);
                break;

            case 70:
                this.guide_txt = 0x1b1;
                this.guide_maxindex = 1;
                this.guide_point = false;
                this.guide_img_rect = Crypto.Rect2(170f, 134f, 128f, 64f);
                break;
        }
    }

    private void Start()
    {
        Input.multiTouchEnabled = false;
        this.language = PlayerPrefs.GetInt("language");
        this.script_UI = GameObject.FindWithTag("ui").GetComponent<UI_Ingame>();
        this.script_cha = GameObject.FindWithTag("Player").GetComponent<Cha_Control>();
        this.script_spawn = GameObject.FindWithTag("Respawn").GetComponent<Spawn>();
        this.vol_bgm = PlayerPrefs.GetFloat("vol_bgm");
        this.vol_master = PlayerPrefs.GetFloat("vol_master");
        AudioListener.volume = this.vol_master;
        this.infinitymode = this.script_spawn.infinitymode;
        if (this.infinitymode)
        {
            this.require_jade = 3;
        }
        this.tempcamfov = Crypto.Load_int_key("camfov");
        Camera.main.GetComponent<Cam_Move>().FovTest((float) ((this.tempcamfov * -2) + 30));
        base.gameObject.active = false;
    }
}


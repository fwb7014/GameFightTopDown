using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct coustume
{
    public short _name;
    public short _info;
    public short _bossindex;
    public short _plushp;
    public short _jadecost;
}


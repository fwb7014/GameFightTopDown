using System;
using UnityEngine;

public class SpiritSword3 : MonoBehaviour
{
    private Transform[] c_sword = new Transform[4];
    private Transform cha1;
    private bool creatfinish;
    private int creatindex;
    private int hitcount;
    private bool homing = true;
    private Collider mycollider;
    private Transform mytransform;
    private Transform oldtarget;
    private float power;
    private float start_delay;
    public Transform sword;
    private int swordindex;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
        this.cha1 = GameObject.FindWithTag("Player").transform;
    }

    private void OnEnable()
    {
        this.mycollider.enabled = false;
        this.start_delay = 0f;
        this.creatindex = 0;
        this.swordindex = 0;
        this.creatfinish = false;
        this.homing = false;
        this.hitcount = 0;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (((other.gameObject.layer == 8) && !this.homing) && (this.oldtarget != other.transform))
        {
            this.c_sword[this.swordindex].GetComponent<SpiritSword_p3>().FireSword(other.transform);
            this.oldtarget = other.transform;
            this.swordindex = (this.swordindex + 1) % 4;
            this.hitcount++;
            this.mycollider.enabled = false;
            this.start_delay = 0f;
            this.homing = true;
            if (this.hitcount >= 0x18)
            {
                this.homing = false;
                base.gameObject.active = false;
                this.mytransform.position = (Vector3) (Vector3.up * 31f);
                for (int i = 0; i < 4; i++)
                {
                    this.c_sword[i].GetComponent<SpiritSword_p3>().FinishSword();
                }
            }
        }
    }

    private void Start()
    {
        this.power = base.rigidbody.mass;
    }

    private void Update()
    {
        if (!this.creatfinish)
        {
            if (this.start_delay > 0.2f)
            {
                this.start_delay = 0f;
                if (this.c_sword[this.creatindex] == null)
                {
                    this.c_sword[this.creatindex] = (Transform) UnityEngine.Object.Instantiate(this.sword, this.mytransform.position - this.mytransform.forward, this.mytransform.rotation);
                    this.c_sword[this.creatindex].rigidbody.mass = this.power;
                    this.c_sword[this.creatindex].parent = this.mytransform;
                    this.c_sword[this.creatindex].GetComponent<SpiritSword_p3>().SetPos(this.creatindex);
                }
                else
                {
                    this.c_sword[this.creatindex].position = this.mytransform.position - this.mytransform.forward;
                    this.c_sword[this.creatindex].rotation = this.mytransform.rotation;
                    this.c_sword[this.creatindex].gameObject.active = true;
                }
                if (this.creatindex < 3)
                {
                    this.creatindex++;
                }
                else
                {
                    this.creatfinish = true;
                }
            }
            else
            {
                this.start_delay += Time.deltaTime;
            }
        }
        else if (this.start_delay > 0.3f)
        {
            this.homing = false;
            this.mycollider.enabled = true;
            this.start_delay = -1f;
        }
        else if (this.start_delay > -1f)
        {
            this.start_delay += Time.deltaTime;
        }
        else
        {
            this.start_delay -= Time.deltaTime;
            if (this.start_delay < -2f)
            {
                this.mycollider.enabled = false;
                this.mycollider.enabled = true;
                this.oldtarget = null;
            }
        }
        this.mytransform.position = this.cha1.position + ((Vector3) (Vector3.up * 0.1f));
        this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, this.cha1.rotation, Time.deltaTime * 3f);
    }
}


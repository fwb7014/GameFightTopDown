using System;
using UnityEngine;

public class DontDestroyObj : MonoBehaviour
{
    private void Awake()
    {
        UnityEngine.Object.DontDestroyOnLoad(base.gameObject);
    }
}


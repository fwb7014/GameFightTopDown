using System;
using UnityEngine;

public class Cha_Weapon : MonoBehaviour
{
    private GameObject blade;
    public Transform bowgun;
    private Transform c_bowgun;
    private Transform c_spear;
    private short changespd = 1;
    private bool changestart;
    private Transform current_blade;
    private Transform current_blade2;
    private Transform current_weapon;
    public int dock;
    public Transform dummy_spine;
    private float finishtime;
    private Transform general_blade;
    private Transform general_blade2;
    private Transform mytransform;
    private float showdelay;
    public Transform spear;
    public Transform sub_hand;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    public void GeneralWeaponOff()
    {
        if (this.general_blade != null)
        {
            this.general_blade.gameObject.active = false;
        }
        if (this.general_blade2 != null)
        {
            this.general_blade2.gameObject.active = false;
        }
        this.current_blade.gameObject.active = true;
        if (this.current_blade2 != null)
        {
            this.current_blade2.gameObject.active = true;
        }
    }

    public void GeneralWeaponOn(int _generalkind, int _weaponindex)
    {
        this.current_blade.gameObject.active = false;
        if (this.current_blade2 != null)
        {
            this.current_blade2.gameObject.active = false;
        }
        if (this.general_blade == null)
        {
            this.blade = Resources.Load("wp_general" + _weaponindex.ToString()) as GameObject;
            this.general_blade = (Transform) UnityEngine.Object.Instantiate(this.blade.transform, this.mytransform.position, this.mytransform.rotation);
            this.general_blade.parent = this.mytransform;
            if (_generalkind == 1)
            {
                this.general_blade2 = (Transform) UnityEngine.Object.Instantiate(this.blade.transform, this.sub_hand.position, this.sub_hand.rotation);
                this.general_blade2.parent = this.sub_hand;
            }
        }
        else
        {
            this.general_blade.gameObject.active = true;
            if (_generalkind == 1)
            {
                this.general_blade2.gameObject.active = true;
            }
        }
    }

    public void HideBlade()
    {
        this.current_blade.renderer.enabled = false;
        if (this.current_blade2 != null)
        {
            this.current_blade2.renderer.enabled = false;
        }
        if (this.general_blade != null)
        {
            this.general_blade.renderer.enabled = false;
        }
        if (this.general_blade2 != null)
        {
            this.general_blade2.renderer.enabled = false;
        }
    }

    public void ReturnBlade()
    {
        if (this.current_weapon != null)
        {
            this.current_weapon.parent = null;
            this.current_weapon.GetComponent<WeaponDrop>().Drop(false);
        }
        this.current_blade.position = this.mytransform.position;
        this.current_blade.rotation = this.mytransform.rotation;
        this.current_blade.parent = this.mytransform;
        if (this.current_blade2 != null)
        {
            this.current_blade2.position = this.sub_hand.position;
            this.current_blade2.rotation = this.sub_hand.rotation;
            this.current_blade2.parent = this.sub_hand;
        }
    }

    public void SetStageWeapon()
    {
        if (this.current_blade != null)
        {
            UnityEngine.Object.Destroy(this.current_blade.gameObject);
        }
        if (this.current_blade2 != null)
        {
            UnityEngine.Object.Destroy(this.current_blade2.gameObject);
        }
        int num = Crypto.Load_int_key("n34");
        int num2 = (int) (num * 0.01f);
        num = num % 100;
        this.blade = Resources.Load("wp_" + num.ToString()) as GameObject;
        this.current_blade = (Transform) UnityEngine.Object.Instantiate(this.blade.transform, this.dummy_spine.position, this.dummy_spine.rotation);
        this.current_blade.parent = this.dummy_spine;
        if (num2 == 1)
        {
            this.current_blade.position += (Vector3) (this.dummy_spine.forward * 0.01f);
            this.current_blade2 = (Transform) UnityEngine.Object.Instantiate(this.blade.transform, (Vector3) (((this.dummy_spine.position - (this.dummy_spine.up * 0.03f)) + (this.dummy_spine.forward * 0.04f)) + (this.dummy_spine.right * 0.01f)), this.dummy_spine.rotation);
            this.current_blade2.parent = this.dummy_spine;
            this.current_blade2.localRotation = Quaternion.Euler(260f, 180f, 0f);
        }
        if (this.dock == 1)
        {
            this.current_blade.localScale = (Vector3) (this.current_blade.localScale * 0.8f);
            if (num2 == 1)
            {
                this.current_blade2.localScale = (Vector3) (this.current_blade2.localScale * 0.8f);
            }
        }
    }

    public void SetStoryBlade()
    {
        this.blade = Resources.Load("wp_0") as GameObject;
        this.current_blade = (Transform) UnityEngine.Object.Instantiate(this.blade.transform, this.dummy_spine.position, this.dummy_spine.rotation);
    }

    public void SetWeapon(int _meshkind, int _weapon_kind)
    {
        if (this.current_blade != null)
        {
            UnityEngine.Object.Destroy(this.current_blade.gameObject);
        }
        if (this.current_blade2 != null)
        {
            UnityEngine.Object.Destroy(this.current_blade2.gameObject);
        }
        this.blade = Resources.Load("wp_" + _meshkind.ToString()) as GameObject;
        this.current_blade = (Transform) UnityEngine.Object.Instantiate(this.blade.transform, this.dummy_spine.position, this.dummy_spine.rotation);
        this.current_blade.localScale = (Vector3) (this.current_blade.localScale * 4.5f);
        this.current_blade.parent = this.dummy_spine;
        if (_weapon_kind == 1)
        {
            this.current_blade.position += (Vector3) (this.dummy_spine.forward * 0.1f);
            this.current_blade2 = (Transform) UnityEngine.Object.Instantiate(this.blade.transform, (Vector3) (((this.dummy_spine.position - (this.dummy_spine.up * 0.18f)) + (this.dummy_spine.forward * 0.26f)) + (this.dummy_spine.right * 0.04f)), this.dummy_spine.rotation);
            this.current_blade2.localScale = (Vector3) (this.current_blade2.localScale * 4.5f);
            this.current_blade2.parent = this.dummy_spine;
            this.current_blade2.localRotation = Quaternion.Euler(260f, 180f, 0f);
        }
    }

    public void ShowBlade()
    {
        this.current_blade.renderer.enabled = true;
        if (this.current_blade2 != null)
        {
            this.current_blade2.renderer.enabled = true;
        }
        if (this.general_blade != null)
        {
            this.general_blade.renderer.enabled = true;
        }
        if (this.general_blade2 != null)
        {
            this.general_blade2.renderer.enabled = true;
        }
    }

    private void Start()
    {
        if (this.dock < 2)
        {
            this.SetStageWeapon();
        }
    }

    public void SwitchWepon(int kind, short _changespd, float _finishtime, float _showdelay)
    {
        this.changespd = _changespd;
        this.finishtime = _finishtime;
        this.showdelay = _showdelay;
        if (kind == 0)
        {
            if (this.c_spear == null)
            {
                this.c_spear = (Transform) UnityEngine.Object.Instantiate(this.spear, this.mytransform.position, this.mytransform.rotation);
            }
            else
            {
                this.c_spear.position = this.mytransform.position;
                this.c_spear.rotation = this.mytransform.rotation;
                this.c_spear.GetComponent<WeaponDrop>().DropCancel();
                this.c_spear.gameObject.active = true;
            }
            this.current_weapon = this.c_spear;
        }
        else if (kind == 1)
        {
            if (this.c_bowgun == null)
            {
                this.c_bowgun = (Transform) UnityEngine.Object.Instantiate(this.bowgun, this.mytransform.position, this.mytransform.rotation);
            }
            else
            {
                this.c_bowgun.position = this.mytransform.position;
                this.c_bowgun.rotation = this.mytransform.rotation;
                this.c_bowgun.GetComponent<WeaponDrop>().DropCancel();
                this.c_bowgun.gameObject.active = true;
            }
            this.current_weapon = this.c_bowgun;
        }
        else
        {
            this.current_weapon = null;
        }
        if (this.current_weapon != null)
        {
            this.current_weapon.localScale = Vector3.zero;
            this.current_weapon.parent = this.mytransform;
            this.changestart = true;
        }
        this.current_blade.position = this.dummy_spine.position;
        this.current_blade.rotation = this.dummy_spine.rotation;
        this.current_blade.parent = this.dummy_spine;
        if (this.current_blade2 != null)
        {
            this.current_blade.position += (Vector3) (this.dummy_spine.forward * 0.01f);
            this.current_blade2.position = (Vector3) (((this.dummy_spine.position - (this.dummy_spine.up * 0.03f)) + (this.dummy_spine.forward * 0.04f)) + (this.dummy_spine.right * 0.01f));
            this.current_blade2.parent = this.dummy_spine;
            this.current_blade2.localRotation = Quaternion.Euler(260f, 180f, 0f);
        }
    }

    private void Update()
    {
        if (this.changestart)
        {
            if (this.current_weapon.localScale.x >= 1f)
            {
                this.current_weapon.localScale = Vector3.one;
                this.changestart = false;
                this.showdelay = 0f;
            }
            else if (this.showdelay > 1f)
            {
                this.current_weapon.localScale += (Vector3) ((Vector3.one * this.changespd) * Time.deltaTime);
            }
            else
            {
                this.showdelay += Time.deltaTime;
            }
        }
        else if (this.finishtime > 0f)
        {
            this.finishtime -= Time.deltaTime;
            if (this.finishtime < 0f)
            {
                this.ReturnBlade();
            }
        }
    }
}


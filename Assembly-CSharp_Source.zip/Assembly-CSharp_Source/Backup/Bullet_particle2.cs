using System;
using UnityEngine;

public class Bullet_particle2 : MonoBehaviour
{
    public float disable_delay;
    public float emitfinishdelay;
    public float expand_factor;
    private Transform mytransform;
    private Vector3 originscale;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.originscale = this.mytransform.localScale;
    }

    private void finishObj()
    {
        base.gameObject.active = false;
    }

    private void OnEnable()
    {
        base.Invoke("StopEmit", this.emitfinishdelay);
        base.Invoke("finishObj", this.disable_delay);
        base.particleEmitter.emit = true;
        this.mytransform.localScale = this.originscale;
        base.collider.enabled = true;
    }

    private void StopEmit()
    {
        base.particleEmitter.emit = false;
        base.collider.enabled = false;
    }

    private void Update()
    {
        this.mytransform.localScale += (Vector3) ((Vector3.one * Time.deltaTime) * this.expand_factor);
    }
}


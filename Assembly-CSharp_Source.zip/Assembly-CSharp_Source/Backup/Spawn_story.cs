using System;
using UnityEngine;

public class Spawn_story : MonoBehaviour
{
    private Transform[] clone_destroy = new Transform[6];
    private Transform clone_enemy;
    private bool countdown;
    private int cur_difficulty;
    private int destroy_beast_kind = 3;
    private int destroy_human_kind;
    public Transform[] enemy_source = new Transform[3];
    private Transform[] enemyset = new Transform[3];
    private bool guide;
    private GameObject last_mon;
    private int max_stage_index = -1;
    public Transform[] mon_destroy = new Transform[3];
    private int monnum = 3;
    private int regen = -1;
    private int rndoldpoint = -1;
    private int rndpoint;
    private Vector3 rndpos;
    private float spawndelay;
    private Transform spawnenemy;
    private Vector3[] spawpoint = new Vector3[8];
    private Transform stage;
    private int storymonnum = 3;
    private int totalEnemyNum = 10;

    private void Awake()
    {
        this.max_stage_index = Crypto.Load_int_key("n06");
        if (this.max_stage_index != -1)
        {
            this.totalEnemyNum = 0;
        }
    }

    public void EnemyDead(int _destroy, Vector3 _pos, Texture _tex, Vector3 _scale, Vector3 _forcedir)
    {
        if (!this.guide)
        {
            if (this.max_stage_index == -1)
            {
                GameObject.Find("UI_Ingame").GetComponent<UI_Ingame_story>().GuideOn(0);
            }
            this.guide = true;
        }
        this.monnum--;
        if ((this.monnum <= 0) && (this.regen == -2))
        {
            GameObject.Find("scene_trans").GetComponent<Story_trans>().ScreenOn(2f);
        }
        if (_destroy == 2)
        {
            this.clone_destroy[this.destroy_human_kind].position = _pos + ((Vector3) (_forcedir * 0.15f));
            this.clone_destroy[this.destroy_human_kind].rotation = Quaternion.Euler(0f, (float) UnityEngine.Random.Range(0, 360), 0f);
            this.clone_destroy[this.destroy_human_kind].GetComponent<Mon_Destroy>().TextureChange(_tex, _scale, _destroy);
            this.clone_destroy[this.destroy_human_kind].gameObject.active = true;
            this.destroy_human_kind = (this.destroy_human_kind + 1) % 3;
        }
        if (_destroy == 1)
        {
            this.clone_destroy[this.destroy_beast_kind].position = _pos + ((Vector3) (_forcedir * 0.15f));
            this.clone_destroy[this.destroy_beast_kind].rotation = Quaternion.Euler(0f, (float) UnityEngine.Random.Range(0, 360), 0f);
            this.clone_destroy[this.destroy_beast_kind].GetComponent<Mon_Destroy>().TextureChange(_tex, _scale, _destroy);
            this.clone_destroy[this.destroy_beast_kind].gameObject.active = true;
            this.destroy_beast_kind = ((this.destroy_beast_kind + 1) % 3) + 3;
        }
    }

    public void RegenStart()
    {
        this.regen = 0;
        for (int i = 0; i < 3; i++)
        {
            int index = i + this.cur_difficulty;
            this.enemyset[i] = this.enemy_source[index];
        }
    }

    public int SetRndPoint()
    {
        this.rndpoint = UnityEngine.Random.Range(0, 8);
        if (this.rndpoint == this.rndoldpoint)
        {
            this.rndpoint = (this.rndpoint + 1) % 8;
        }
        this.rndoldpoint = this.rndpoint;
        return this.rndpoint;
    }

    private void Start()
    {
        for (int i = 0; i < 3; i++)
        {
            this.clone_destroy[i] = (Transform) UnityEngine.Object.Instantiate(this.mon_destroy[i], (Vector3) (Vector3.one * 6f), Quaternion.identity);
            this.clone_destroy[i + 3] = (Transform) UnityEngine.Object.Instantiate(this.mon_destroy[3], (Vector3) (Vector3.one * 6f), Quaternion.identity);
        }
        this.stage = GameObject.Find("stage").transform;
        for (int j = 0; j < 8; j++)
        {
            this.spawpoint[j] = this.stage.GetChild(0).GetChild(j).position;
        }
        this.cur_difficulty = 0;
    }

    public void StoryEnemyDead()
    {
        this.storymonnum--;
    }

    private void Update()
    {
        if (this.regen >= 0)
        {
            if (this.spawndelay > 0f)
            {
                this.spawndelay -= Time.deltaTime;
            }
            else if ((this.totalEnemyNum > 0) && (this.spawndelay <= 0f))
            {
                this.rndpos = this.spawpoint[this.SetRndPoint()];
                int index = UnityEngine.Random.Range(0, 6);
                if (index <= 2)
                {
                    index = 0;
                }
                else if (index <= 4)
                {
                    index = 1;
                }
                else
                {
                    index = 2;
                }
                this.spawnenemy = this.enemyset[index];
                this.clone_enemy = (Transform) UnityEngine.Object.Instantiate(this.spawnenemy, this.rndpos, Quaternion.identity);
                this.clone_enemy.name = "enemy";
                this.monnum++;
                this.totalEnemyNum--;
                this.spawndelay = 0.2f;
            }
            else if (this.totalEnemyNum <= 0)
            {
                this.regen = -2;
            }
        }
        else if (((this.monnum <= (5 + this.storymonnum)) && !this.countdown) && (this.regen == -2))
        {
            for (int i = 0; i < (this.monnum - this.storymonnum); i++)
            {
                this.last_mon = GameObject.Find("enemy");
                this.last_mon.GetComponent<AI_Enemy01>().CountDown();
                this.last_mon.name = "enemy_confirm";
            }
            this.countdown = true;
        }
    }
}


using System;
using UnityEngine;

public class CaveGetCoinNum : MonoBehaviour
{
    private float finishdelay;
    private float imgnum;
    private bool movefisnish;
    private Transform mytransform;
    private int oldnum;
    private int targetcoin;
    private TextMesh tt;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.tt = base.GetComponent<TextMesh>();
    }

    public void GetOn(int _getcoin)
    {
        this.mytransform.position = new Vector3(0f, 6f, 1.5f);
        base.gameObject.active = true;
        this.targetcoin = _getcoin;
        this.movefisnish = false;
        this.mytransform.GetChild(0).gameObject.active = true;
    }

    private void Start()
    {
        base.gameObject.active = false;
        this.mytransform.GetChild(0).gameObject.active = false;
    }

    private void Update()
    {
        this.mytransform.GetChild(0).Rotate((Vector3) ((Vector3.up * Time.deltaTime) * 600f));
        if (this.movefisnish)
        {
            if (this.imgnum < this.targetcoin)
            {
                this.imgnum += Time.deltaTime * 50f;
            }
            else
            {
                this.imgnum = this.targetcoin;
                this.finishdelay += Time.deltaTime;
                if (this.finishdelay > 2f)
                {
                    this.finishdelay = 0f;
                    base.gameObject.active = false;
                    this.mytransform.GetChild(0).gameObject.active = false;
                }
            }
            if (this.imgnum > this.oldnum)
            {
                this.oldnum = (int) this.imgnum;
                this.tt.text = this.oldnum.ToString();
            }
        }
        else if (this.mytransform.position.y > 2.5f)
        {
            this.mytransform.position -= (Vector3) ((Vector3.up * Time.deltaTime) * 3f);
        }
        else
        {
            this.mytransform.position = new Vector3(0f, 2.5f, 1.5f);
            this.mytransform.GetChild(1).particleEmitter.Emit();
            this.movefisnish = true;
        }
    }
}


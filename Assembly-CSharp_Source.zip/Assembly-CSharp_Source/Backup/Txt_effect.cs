using System;
using UnityEngine;

public class Txt_effect : MonoBehaviour
{
    private float finish_delay;
    private bool isdelay;
    private Material mymaterial;
    private Transform mytransform;
    private Vector3 startscale;
    private Vector3 targetscale = new Vector3(4f, 1f, 0f);

    private void Awake()
    {
        this.mymaterial = base.renderer.sharedMaterial;
        this.mytransform = base.transform;
        this.startscale = this.mytransform.localScale;
    }

    public void TxtEfOn(short _index)
    {
        base.gameObject.active = true;
        this.mytransform.localScale = this.startscale;
        this.finish_delay = 0f;
        if (_index == 2)
        {
            this.mytransform.localScale = Vector3.zero;
            this.isdelay = true;
        }
        this.mymaterial.mainTextureOffset = (Vector2) ((Vector2.up * 0.25f) * _index);
    }

    private void Update()
    {
        this.finish_delay += Time.deltaTime;
        if (this.finish_delay > 0.7f)
        {
            base.gameObject.active = false;
        }
        else if (this.isdelay)
        {
            if (this.finish_delay > 0.2f)
            {
                this.mytransform.localScale = this.startscale;
                this.isdelay = false;
            }
        }
        else
        {
            this.mytransform.localScale = Vector3.Lerp(this.mytransform.localScale, this.targetscale, Time.deltaTime * 15f);
        }
    }
}


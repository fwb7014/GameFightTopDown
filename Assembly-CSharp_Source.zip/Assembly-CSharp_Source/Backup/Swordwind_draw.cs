using System;
using UnityEngine;

public class Swordwind_draw : MonoBehaviour
{
    private float current_delay;
    private Renderer myrenderer;
    private bool show;
    public float startdelay;

    private void Awake()
    {
        this.myrenderer = base.renderer;
    }

    private void OnEnable()
    {
        this.show = false;
        this.current_delay = 0f;
        this.myrenderer.enabled = false;
    }

    private void Start()
    {
        this.myrenderer.enabled = false;
    }

    private void Update()
    {
        this.current_delay += Time.deltaTime;
        if (!this.show && (this.current_delay > this.startdelay))
        {
            this.myrenderer.enabled = true;
            this.show = true;
            this.current_delay = 0f;
        }
    }
}


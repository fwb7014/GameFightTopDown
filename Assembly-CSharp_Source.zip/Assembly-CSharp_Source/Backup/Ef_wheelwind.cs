using System;
using UnityEngine;

public class Ef_wheelwind : MonoBehaviour
{
    private float finishtime = 1.6f;
    private int index;
    private Renderer myrenderer;
    private Transform mytransform;
    private Vector2 offset;
    private int oldindex = -1;
    private Vector2 size;
    private float starttime;
    private float uIndex;
    private int vIndex;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myrenderer = base.renderer;
    }

    private void Start()
    {
        this.mytransform.localScale = (Vector3) (Vector3.one * 0.3f);
        base.collider.isTrigger = true;
        base.renderer.enabled = false;
        this.size = (Vector2) (Vector2.one * 0.5f);
    }

    private void Update()
    {
        if (this.mytransform.localScale.x > 1f)
        {
            base.renderer.enabled = true;
        }
        if (this.mytransform.localScale.x < 1.8f)
        {
            this.mytransform.localScale += (Vector3) ((Vector3.one * 4f) * Time.deltaTime);
        }
        else
        {
            this.mytransform.localScale = (Vector3) (Vector3.one * 1.8f);
        }
        if (this.starttime > this.finishtime)
        {
            base.renderer.enabled = false;
            base.gameObject.active = false;
            this.mytransform.localScale = (Vector3) (Vector3.one * 0.3f);
            this.starttime = 0f;
        }
        this.starttime += Time.deltaTime;
        this.index = (int) (this.starttime * 16f);
        this.index = this.index % 4;
        this.uIndex = this.index % 2;
        this.vIndex = this.index / 2;
        if (this.index != this.oldindex)
        {
            if ((this.index == 0) || (this.index == 3))
            {
                base.collider.enabled = true;
            }
            else
            {
                base.collider.enabled = false;
            }
            this.offset = new Vector2(this.uIndex * this.size.x, (1f - this.size.y) - (this.vIndex * this.size.y));
            this.myrenderer.sharedMaterial.SetTextureOffset("_MainTex", this.offset);
            this.myrenderer.sharedMaterial.SetTextureScale("_MainTex", this.size);
            this.oldindex = this.index;
        }
    }
}


using System;
using UnityEngine;

public class Cam_UI : MonoBehaviour
{
    private void Start()
    {
        base.camera.projectionMatrix = Matrix4x4.Ortho(-1.5f, 1.5f, -1f, 1f, 0.3f, 5f);
    }
}


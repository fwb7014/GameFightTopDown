using System;
using UnityEngine;

public class Cam_Loading : MonoBehaviour
{
    public GUISkin basicSkin;
    public Texture2D black;
    private Transform horse;
    private int language;
    private bool stopCam;
    private int tip_idx;
    public Texture2D txt_loading;

    public void DisappearCam()
    {
        this.stopCam = true;
    }

    private void OnGUI()
    {
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.skin = this.basicSkin;
        GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 64f), this.black);
        GUI.DrawTexture(Crypto.Rect2(0f, 256f, 480f, 74f), this.black);
        GUI.DrawTexture(Crypto.Rect2(370f, 292f, 100f, 25f), this.txt_loading);
        GUI.Label(Crypto.Rect2(0f, 266f, 480f, 16f), Language.intxt[this.language, this.tip_idx], "txt12_w");
    }

    private void Start()
    {
        base.camera.projectionMatrix = Matrix4x4.Perspective(50f, 1.5f, 0.01f, 20f);
        this.horse = GameObject.Find("pet_horse_riding").transform;
        this.language = PlayerPrefs.GetInt("language");
        this.tip_idx = UnityEngine.Random.Range(0x137, 0x14b);
    }

    private void Update()
    {
        if (!this.stopCam)
        {
            base.transform.LookAt(this.horse.position + new Vector3(-0.4f, 0.16f, 0f));
        }
    }
}


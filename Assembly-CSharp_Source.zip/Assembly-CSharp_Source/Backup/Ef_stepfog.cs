using System;
using UnityEngine;

public class Ef_stepfog : MonoBehaviour
{
    private Color currentColor;
    private float dt;
    public int fogalpha;
    public float fogheight;
    public float fogspeed;
    private Vector3 growVector;
    private Renderer myrenderer;
    private Transform mytransform;
    private Vector3 originScale;
    public float smoothfactor;
    private Vector3 smoothgrowVector;
    private Color targetColor;
    private Color transColor;
    public float xyratio;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myrenderer = base.renderer;
    }

    private void Start()
    {
        this.originScale = this.mytransform.localScale;
        this.targetColor = new Color(0.5f, 0.5f, 0.5f, 0f);
        this.myrenderer.enabled = false;
        this.myrenderer.material.SetColor("_TintColor", Color.gray);
        this.growVector = new Vector3(this.fogspeed, this.fogspeed * this.xyratio, this.fogspeed);
        this.smoothgrowVector = new Vector3(this.fogspeed * this.smoothfactor, (this.fogspeed * this.smoothfactor) * 0.5f, this.fogspeed * this.smoothfactor);
        base.gameObject.active = false;
    }

    private void Update()
    {
        if (this.dt < 0.1f)
        {
            this.dt += Time.deltaTime;
        }
        else
        {
            this.myrenderer.enabled = true;
        }
        if (this.myrenderer.enabled)
        {
            this.currentColor = this.myrenderer.material.GetColor("_TintColor");
            this.transColor = Color.Lerp(this.currentColor, this.targetColor, Time.deltaTime * this.fogalpha);
            this.myrenderer.material.SetColor("_TintColor", this.transColor);
            if (this.mytransform.localScale.y > this.fogheight)
            {
                this.mytransform.position = (Vector3) (Vector3.one * 4f);
                this.myrenderer.enabled = false;
                base.gameObject.active = false;
                this.dt = 0f;
                this.myrenderer.material.SetColor("_TintColor", Color.gray);
                this.mytransform.localScale = this.originScale;
            }
            else if (this.mytransform.localScale.y > (this.fogheight * 0.8f))
            {
                this.mytransform.localScale += (Vector3) (this.smoothgrowVector * Time.deltaTime);
            }
            else
            {
                this.mytransform.localScale += (Vector3) (this.growVector * Time.deltaTime);
            }
        }
    }
}


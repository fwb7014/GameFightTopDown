using System;
using UnityEngine;

[Serializable]
public class NonAffectedJoints
{
    public float effect;
    public Transform joint;
}


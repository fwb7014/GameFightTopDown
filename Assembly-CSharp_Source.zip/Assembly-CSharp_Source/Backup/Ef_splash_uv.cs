using System;
using UnityEngine;

public class Ef_splash_uv : MonoBehaviour
{
    private GameObject ascraps;
    private GameObject cha1;
    private float currenttime;
    private int framesPerSecond = 30;
    private float index;
    private int lastframe;
    private float starttime;
    private int uvAnimationTileX = 4;
    private int uvAnimationTileY = 4;
    private int var;

    public void SplashOn()
    {
        base.transform.parent = this.ascraps.transform;
        base.transform.localScale = new Vector3(2f, 2f, 2f);
        this.starttime = Time.time;
        base.renderer.enabled = true;
        base.collider.enabled = true;
        base.transform.rotation = this.cha1.transform.rotation;
        base.transform.position = (this.cha1.transform.position + new Vector3(0f, 0.02f, 0f)) + ((Vector3) (this.cha1.transform.forward * 0.1f));
        base.transform.localRotation = Quaternion.identity;
    }

    private void Start()
    {
        this.cha1 = base.transform.root.gameObject;
        this.ascraps = GameObject.Find("Attack_scraps");
        Physics.IgnoreCollision(this.cha1.collider, base.collider);
        this.currenttime = 0f;
        this.starttime = 0f;
        this.lastframe = this.uvAnimationTileX * this.uvAnimationTileY;
        base.renderer.enabled = false;
        base.transform.localScale = Vector3.zero;
        base.collider.isTrigger = true;
        base.collider.enabled = false;
    }

    private void Update()
    {
        if (base.renderer.enabled)
        {
            this.currenttime = Time.time - this.starttime;
            this.index = this.currenttime * this.framesPerSecond;
            this.index = (int) (this.index % ((float) this.lastframe));
            this.var -= (int) this.index;
            Vector2 scale = new Vector2(1f / ((float) this.uvAnimationTileX), 1f / ((float) this.uvAnimationTileY));
            float num = this.index % ((float) this.uvAnimationTileX);
            int num2 = ((int) this.index) / this.uvAnimationTileX;
            Vector2 offset = new Vector2(num * scale.x, (1f - scale.y) - (num2 * scale.y));
            if ((this.index == 0f) && (this.var != 0))
            {
                base.renderer.enabled = false;
                base.collider.enabled = false;
                base.transform.localScale = Vector3.zero;
                this.var = 0;
                base.transform.parent = this.cha1.transform;
                base.transform.rotation = this.cha1.transform.rotation;
                base.transform.position = (this.cha1.transform.position + new Vector3(0f, 0.02f, 0f)) + ((Vector3) (this.cha1.transform.forward * 0.3f));
            }
            base.renderer.material.SetTextureOffset("_MainTex", offset);
            base.renderer.material.SetTextureScale("_MainTex", scale);
        }
    }
}


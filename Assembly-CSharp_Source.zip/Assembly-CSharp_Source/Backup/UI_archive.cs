using System;
using UnityEngine;

public class UI_archive : MonoBehaviour
{
    public Texture2D archive_complete;
    public Texture2D archive_gift;
    private bool b_delay;
    public GUISkin basicSkin;
    public Texture2D bg_archive;
    public Texture2D bg_archiverate;
    public Texture2D bg_asset;
    public Texture2D bg_black;
    public Texture2D bg_general_detail;
    private float bg_posX_l;
    private float bg_posX_r;
    public Texture2D bg_scroll;
    public Texture2D bg_title;
    private int[] bosskill = new int[12];
    public GUIStyle bt_back;
    public GUIStyle bt_empty;
    public GUIStyle bt_general;
    public GUIStyle bt_kind;
    public Texture2D bt_roullete;
    public Texture2D bt_roullete_active;
    public GUIStyle bt_yesno;
    private int cashing;
    private GameObject cashshop;
    private int caveplay;
    private int coin;
    private int[] complete_archive = new int[0x4c];
    private short confirm;
    private int count_staff;
    private int count_treasure;
    private int[] cur_skill_grade = new int[20];
    private float curMousePosY;
    private int death;
    private int enemykill;
    private int exattack;
    private int expand_height;
    private int expand_height2;
    private float f_delay;
    public Texture2D gauge_rate;
    private int generalsearch;
    private bool[] gift_archive = new bool[0x4c];
    public Texture2D[] gifticon = new Texture2D[6];
    private int grappling;
    public Texture2D icon_coin;
    public Texture2D icon_jade;
    private float icon_posY;
    private int icon_size;
    public Texture2D[] icon_treasure = new Texture2D[0x18];
    public Texture2D icon_warning;
    private bool imagemovefinish;
    public Texture2D[] img_kind = new Texture2D[3];
    private Color inactive = new Color(0f, 0f, 0f, 0.5f);
    private int jade;
    private int language;
    private int max_stage_index = -1;
    private const int MAXARCHIVE = 0x4c;
    private const int MAXGENERALPOOL = 30;
    private const int MAXSKILL = 20;
    private const int MAXTREASURE = 0x18;
    public Texture2D numberbase;
    private int perfectplay;
    private int[] pet_skill_use = new int[2];
    public Texture2D please_touch;
    public Texture2D pop_blank2;
    private Vector2 prev_scrollPosition = Vector2.zero;
    public Texture2D[] prt_general = new Texture2D[30];
    private int[] rate_archive = new int[0x4c];
    private int remain_arch;
    private int resurrection;
    private DB_Archive script_archive;
    private Language_Archive script_archname;
    private Language_Name script_name;
    private SoundEf_UI script_soundUI;
    private Vector2 scrollPosition = Vector2.zero;
    private int selectblank = -1;
    private int selectgeneral = -1;
    private int[] skill_use = new int[20];
    private GameObject sound_UI;
    private float startMousePosY;
    private int step;
    private int[] temp_staff = new int[30];
    private int[] temp_treasure = new int[0x18];
    public Texture2D titlebase;
    private bool[] treasure_gift = new bool[6];
    private int tutorial;
    public Texture2D txt_name;
    private int[] unlock_costume = new int[20];
    private bool warning_newarchive;
    private bool warning_newtreasure;

    public void CashshopOpen()
    {
        if (this.cashshop == null)
        {
            this.cashshop = Resources.Load("CashShop") as GameObject;
        }
        UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
    }

    public void Delay(float t)
    {
        this.b_delay = true;
        this.f_delay = t;
    }

    public void FindNewTreasure()
    {
        bool flag = false;
        for (int i = 0; i < 6; i++)
        {
            int num2 = 0;
            if (this.temp_treasure[4 * i] > 0)
            {
                num2++;
            }
            if (this.temp_treasure[(4 * i) + 1] > 0)
            {
                num2++;
            }
            if (this.temp_treasure[(4 * i) + 2] > 0)
            {
                num2++;
            }
            if (this.temp_treasure[(4 * i) + 3] > 0)
            {
                num2++;
            }
            if (num2 == 4)
            {
                this.treasure_gift[i] = true;
                flag = true;
            }
            else
            {
                this.treasure_gift[i] = false;
            }
        }
        this.warning_newtreasure = flag;
    }

    public bool IsWarning()
    {
        for (int i = 0; i < 0x4c; i++)
        {
            if (this.gift_archive[i])
            {
                return true;
            }
        }
        return false;
    }

    private void OnEnable()
    {
        this.coin = Crypto.Load_int_key("n17");
        this.jade = Crypto.Load_int_key("n24");
    }

    private void OnGUI()
    {
        GUI.skin = this.basicSkin;
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        if (this.confirm > 0)
        {
            GUI.enabled = false;
        }
        GUI.DrawTexture(Crypto.Rect2(this.bg_posX_l, 0f, 320f, 320f), this.bg_archive);
        GUI.DrawTexture(Crypto.Rect2(120f, 30f, 100f, 50f), this.txt_name);
        GUI.Box(Crypto.Rect2(216f, 52f, 80f, 24f), Language.intxt[this.language, 0xc3]);
        GUI.DrawTexture(Crypto.Rect2(112f, 0f, 256f, 32f), this.bg_asset);
        GUI.Label(Crypto.Rect2(146f, 6f, 80f, 14f), string.Empty + this.coin, "txt12_w");
        GUI.Label(Crypto.Rect2(280f, 6f, 64f, 14f), string.Empty + this.jade, "txt12_w");
        if (GUI.Button(Crypto.Rect2(144f, 2f, 100f, 24f), string.Empty, this.bt_empty))
        {
            if (this.sound_UI != null)
            {
                this.script_soundUI.SoundOn(0);
            }
            Crypto.Save_int_key("cashshopkind", 2);
            this.CashshopOpen();
        }
        if (GUI.Button(Crypto.Rect2(272f, 2f, 88f, 24f), string.Empty, this.bt_empty))
        {
            if (this.sound_UI != null)
            {
                this.script_soundUI.SoundOn(0);
            }
            Crypto.Save_int_key("cashshopkind", 1);
            this.CashshopOpen();
        }
        if (this.step == 0)
        {
            GUI.DrawTexture(Crypto.Rect2(200f, 70f, 256f, 128f), this.pop_blank2);
            GUI.Label(Crypto.Rect2(200f, 164f, 256f, 32f), Language.intxt[this.language, 0xae], "txt12_0");
            for (int i = 0; i < 3; i++)
            {
                int num2;
                int num3;
                if (GUI.Button(Crypto.Rect2((float) (0xd8 + (80 * i)), 90f, 64f, 64f), string.Empty, this.bt_kind))
                {
                    this.scrollPosition = Vector2.zero;
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    this.step = i + 1;
                    switch (this.step)
                    {
                        case 1:
                            this.count_treasure = 0;
                            num2 = 0;
                            goto Label_034D;

                        case 2:
                            this.count_staff = 0;
                            num3 = 0;
                            goto Label_0388;
                    }
                }
                goto Label_039A;
            Label_032D:
                if (this.temp_treasure[num2] > 0)
                {
                    this.count_treasure++;
                }
                num2++;
            Label_034D:
                if (num2 < 0x18)
                {
                    goto Label_032D;
                }
                goto Label_039A;
            Label_0368:
                if (this.temp_staff[num3] > 0)
                {
                    this.count_staff++;
                }
                num3++;
            Label_0388:
                if (num3 < 30)
                {
                    goto Label_0368;
                }
            Label_039A:
                GUI.DrawTexture(Crypto.Rect2((float) (0xd8 + (80 * i)), 90f, 64f, 64f), this.img_kind[i]);
                GUI.Label(Crypto.Rect2((float) (0xd8 + (80 * i)), 92f, 64f, 14f), string.Empty + Language.intxt[this.language, 0xab + i], "txt12_w");
            }
            if (this.warning_newarchive)
            {
                GUI.DrawTexture(Crypto.Rect2(416f, 82f, (float) (this.icon_size * 0x20), 32f), this.icon_warning);
            }
            if (this.warning_newtreasure)
            {
                GUI.DrawTexture(Crypto.Rect2(256f, 82f, (float) (this.icon_size * 0x20), 32f), this.icon_warning);
            }
            if (this.tutorial == 1)
            {
                GUI.DrawTexture(Crypto.Rect2(380f, 94f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
            }
            if (GUI.Button(Crypto.Rect2(416f, 0f, 64f, 64f), string.Empty, this.bt_back))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(1);
                }
                if (Crypto.Load_int_key("gamemode") == 0)
                {
                    Application.LoadLevel("Map");
                }
                else
                {
                    Application.LoadLevel("Extreme");
                }
            }
        }
        else if (this.step > 0)
        {
            GUI.DrawTexture(Crypto.Rect2(200f, 34f, 256f, 64f), this.bg_title);
            if (GUI.Button(Crypto.Rect2(384f, 36f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(1);
                }
                if (this.step == 3)
                {
                    this.warning_newarchive = this.IsWarning();
                }
                this.step = 0;
            }
            GUI.DrawTexture(Crypto.Rect2(200f, 70f, 256f, 256f), this.bg_scroll);
            if (Input.GetMouseButtonDown(0))
            {
                this.startMousePosY = Input.mousePosition.y;
                this.prev_scrollPosition = this.scrollPosition;
            }
            if (Input.GetMouseButton(0) && Crypto.Rect2(200f, 80f, 256f, 224f).Contains(Event.current.mousePosition))
            {
                this.curMousePosY = Input.mousePosition.y;
                this.scrollPosition = this.prev_scrollPosition + ((Vector2) ((Vector2.up * (this.curMousePosY - this.startMousePosY)) * (640f / ((float) Screen.height))));
            }
            if (this.step == 1)
            {
                GUI.Label(Crypto.Rect2(220f, 44f, 64f, 16f), this.count_treasure + " / " + 0x18, "txt12_w");
                this.scrollPosition = GUI.BeginScrollView(Crypto.Rect2(200f, 80f, 272f, 224f), this.scrollPosition, Crypto.Rect2(200f, -4f, 256f, 366f));
                for (int j = 0; j < 0x18; j++)
                {
                    GUI.DrawTexture(Crypto.Rect2((float) (220 + ((j % 4) * 0x2c)), (float) (((j / 4) * 60) + 30), 32f, 16f), this.numberbase);
                    GUI.Label(Crypto.Rect2((float) (0xdb + ((j % 4) * 0x2c)), (float) (((j / 4) * 60) + 0x1d), 32f, 16f), string.Empty + this.temp_treasure[j], "txt12_w");
                    if (this.temp_treasure[j] == 0)
                    {
                        GUI.color = this.inactive;
                    }
                    GUI.DrawTexture(Crypto.Rect2((float) (220 + ((j % 4) * 0x2c)), (float) ((j / 4) * 60), 32f, 32f), this.icon_treasure[j]);
                    GUI.color = Color.white;
                }
                for (int k = 0; k < 6; k++)
                {
                    GUI.DrawTexture(Crypto.Rect2(208f, (float) ((k * 60) + 50), 240f, 1f), this.bg_black);
                    if (this.treasure_gift[k])
                    {
                        GUI.Box(Crypto.Rect2(208f, (float) ((k * 60) - 8), (float) (this.icon_size * 240), (float) (this.icon_size * 0x38)), string.Empty, "glow_box");
                        GUI.DrawTexture(Crypto.Rect2(394f, (float) ((k * 60) - 4), 48f, 48f), this.bt_roullete_active);
                        if (GUI.Button(Crypto.Rect2(394f, (float) ((k * 60) - 4), 48f, 48f), string.Empty, this.bt_empty))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            int[] intArray = PlayerPrefsX.GetIntArray("n39");
                            switch (k)
                            {
                                case 0:
                                {
                                    int num7 = Crypto.Load_int_key("n10") + 10;
                                    Crypto.Save_int_key("n10", num7);
                                    break;
                                }
                                case 1:
                                    this.coin += 0x3e8;
                                    Crypto.Property_change(0x3e8, false);
                                    break;

                                case 2:
                                    this.jade += 3;
                                    Crypto.Property_change(3, true);
                                    break;

                                case 3:
                                    intArray[2] += 5;
                                    PlayerPrefsX.SetIntArray("n39", intArray);
                                    break;

                                case 4:
                                    intArray[3] += 4;
                                    PlayerPrefsX.SetIntArray("n39", intArray);
                                    break;

                                case 5:
                                    intArray[4] += 3;
                                    PlayerPrefsX.SetIntArray("n39", intArray);
                                    break;
                            }
                            this.temp_treasure[4 * k]--;
                            this.temp_treasure[(4 * k) + 1]--;
                            this.temp_treasure[(4 * k) + 2]--;
                            this.temp_treasure[(4 * k) + 3]--;
                            PlayerPrefsX.SetIntArray("treasure", this.temp_treasure);
                            this.FindNewTreasure();
                        }
                    }
                    else
                    {
                        GUI.DrawTexture(Crypto.Rect2(394f, (float) ((k * 60) - 4), 48f, 48f), this.bt_roullete);
                    }
                    GUI.DrawTexture(Crypto.Rect2(390f, (float) ((k * 60) - 8), 56f, 56f), this.gifticon[k]);
                }
                GUI.EndScrollView();
            }
            else if (this.step == 2)
            {
                GUI.Label(Crypto.Rect2(220f, 44f, 64f, 16f), this.count_staff + " / " + 30, "txt12_w");
                this.scrollPosition = GUI.BeginScrollView(Crypto.Rect2(200f, 80f, 272f, 224f), this.scrollPosition, Crypto.Rect2(200f, 0f, 256f, 920f));
                for (int m = 0; m < 30; m++)
                {
                    if (this.temp_staff[m] == 0)
                    {
                        GUI.color = this.inactive;
                        GUI.DrawTexture(Crypto.Rect2((float) (0xda + ((m % 3) * 0x4c)), (float) (((m / 3) * 90) + 0x40), 68f, 16f), this.titlebase);
                        GUI.Label(Crypto.Rect2((float) (220 + ((m % 3) * 0x4c)), (float) (((m / 3) * 90) + 0x40), 64f, 16f), "???", "txt12_w");
                    }
                    else
                    {
                        GUI.DrawTexture(Crypto.Rect2((float) (0xda + ((m % 3) * 0x4c)), (float) (((m / 3) * 90) + 0x40), 68f, 16f), this.titlebase);
                        GUI.Label(Crypto.Rect2((float) (220 + ((m % 3) * 0x4c)), (float) (((m / 3) * 90) + 0x40), 64f, 16f), this.script_name.txt_name[this.language, 0x15 + m], "txt12_w");
                    }
                    GUI.DrawTexture(Crypto.Rect2((float) (220 + ((m % 3) * 0x4c)), (float) ((m / 3) * 90), 64f, 64f), this.prt_general[m]);
                    GUI.color = Color.white;
                }
                GUI.EndScrollView();
            }
            else if (this.step == 3)
            {
                GUI.Label(Crypto.Rect2(220f, 44f, 64f, 16f), (0x4c - this.remain_arch) + " / " + 0x4c, "txt12_w");
                this.scrollPosition = GUI.BeginScrollView(Crypto.Rect2(200f, 80f, 272f, 224f), this.scrollPosition, Crypto.Rect2(200f, 0f, 256f, 2474f));
                for (int n = 0; n < 0x4c; n++)
                {
                    if (this.selectblank == n)
                    {
                        this.expand_height = 40;
                    }
                    else
                    {
                        this.expand_height = 0;
                    }
                    if ((this.selectblank != -1) && (n > this.selectblank))
                    {
                        this.expand_height2 = 40;
                    }
                    else
                    {
                        this.expand_height2 = 0;
                    }
                    if (GUI.Button(Crypto.Rect2(212f, (float) ((0x20 * n) + this.expand_height2), 232f, (float) (0x20 + this.expand_height)), string.Empty))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        if (Mathf.Abs((float) (this.curMousePosY - this.startMousePosY)) < (10f * (640f / ((float) Screen.height))))
                        {
                            if (this.gift_archive[n])
                            {
                                string str;
                                Debug.Log("---=-==-==-=-===-=-=-=-=-=-=-=-=--=-=-=-=-=-");
                                if (this.script_archive.aci[n]._reward_kind == 1)
                                {
                                    this.coin += this.script_archive.aci[n]._reward_amount;
                                    Crypto.Property_change(this.script_archive.aci[n]._reward_amount, false);
                                }
                                else if (this.script_archive.aci[n]._reward_kind == 2)
                                {
                                    this.jade += this.script_archive.aci[n]._reward_amount;
                                    Crypto.Property_change(this.script_archive.aci[n]._reward_amount, true);
                                }
                                this.complete_archive[n] = 1;
                                PlayerPrefsX.SetIntArray("archive", this.complete_archive);
                                this.gift_archive[n] = false;
                                this.remain_arch--;
                                if ((this.tutorial == 1) && (n == 0))
                                {
                                    this.tutorial = -4;
                                    Crypto.Save_int_key("tutorial", -4);
                                    this.Delay(1f);
                                    this.confirm = 2;
                                }
                                if ((n + 4) < 10)
                                {
                                    str = "0" + ((n + 4)).ToString();
                                }
                                else
                                {
                                    str = (n + 4).ToString();
                                }
                            }
                            else if (this.selectblank != n)
                            {
                                this.selectblank = n;
                            }
                            else
                            {
                                this.selectblank = -1;
                            }
                        }
                    }
                    if (((((0x40 * n) + this.expand_height2) - this.scrollPosition.y) < 426f) && ((((0x40 * n) + this.expand_height2) - this.scrollPosition.y) > -48f))
                    {
                        if (this.complete_archive[n] != 0)
                        {
                            GUI.DrawTexture(Crypto.Rect2(216f, (float) ((0x20 * n) + this.expand_height2), 32f, 32f), this.archive_complete);
                        }
                        else if (this.gift_archive[n])
                        {
                            GUI.DrawTexture(Crypto.Rect2(216f, (float) ((0x20 * n) + this.expand_height2), 32f, 32f), this.archive_gift);
                            if (this.script_archive.aci[n]._reward_kind == 1)
                            {
                                GUI.DrawTexture(Crypto.Rect2(424f, (float) (((0x20 * n) + this.expand_height2) + 2), 16f, 16f), this.icon_coin);
                            }
                            else
                            {
                                GUI.DrawTexture(Crypto.Rect2(424f, (float) (((0x20 * n) + this.expand_height2) + 2), 16f, 16f), this.icon_jade);
                            }
                            GUI.Label(Crypto.Rect2(406f, (float) (((0x20 * n) + this.expand_height2) + 0x10), 40f, 16f), string.Empty + this.script_archive.aci[n]._reward_amount, "txt12_0");
                        }
                        else
                        {
                            if (this.script_archive.aci[n]._reward_kind == 1)
                            {
                                GUI.DrawTexture(Crypto.Rect2(424f, (float) (((0x20 * n) + this.expand_height2) + 2), 16f, 16f), this.icon_coin);
                            }
                            else
                            {
                                GUI.DrawTexture(Crypto.Rect2(424f, (float) (((0x20 * n) + this.expand_height2) + 2), 16f, 16f), this.icon_jade);
                            }
                            GUI.Label(Crypto.Rect2(406f, (float) (((0x20 * n) + this.expand_height2) + 0x10), 40f, 16f), string.Empty + this.script_archive.aci[n]._reward_amount, "txt12_0");
                            GUI.DrawTexture(Crypto.Rect2(216f, (float) ((0x20 * n) + this.expand_height2), 32f, 32f), this.bg_archiverate);
                            GUI.DrawTexture(Crypto.Rect2(219f, (float) (((0x20 * n) + this.expand_height2) + 20), this.rate_archive[n] * 0.25f, 5f), this.gauge_rate);
                            GUI.Label(Crypto.Rect2(212f, (float) (((0x20 * n) + this.expand_height2) + 5), 32f, 16f), string.Empty + this.rate_archive[n], "txt12_w");
                        }
                        GUI.Label(Crypto.Rect2(208f, (float) (((0x20 * n) + this.expand_height2) + 8), 240f, 16f), this.script_archname.txt_arch[this.language, this.script_archive.aci[n]._name], "txt12_0");
                    }
                }
                if (this.selectblank != -1)
                {
                    GUI.Label(Crypto.Rect2(208f, (float) ((0x20 * this.selectblank) + 0x21), 240f, 32f), this.script_archname.txt_arch[this.language, this.script_archive.aci[this.selectblank]._info], "txt12_0");
                }
                if (this.tutorial == 1)
                {
                    GUI.DrawTexture(Crypto.Rect2(206f, -14f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                }
                GUI.EndScrollView();
            }
        }
        if (this.confirm > 0)
        {
            GUI.enabled = true;
            if (this.confirm == 1)
            {
                GUI.enabled = true;
                GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.bg_general_detail);
                GUI.DrawTexture(Crypto.Rect2(128f, 123f, 64f, 64f), this.prt_general[this.selectgeneral]);
                if (GUI.Button(Crypto.Rect2(284f, 180f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    this.selectgeneral = -1;
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 2)
            {
                GUI.Box(Crypto.Rect2(112f, 140f, 256f, 32f), Language.intxt[this.language, 0x101]);
                if (this.f_delay == 0f)
                {
                    this.confirm = 0;
                }
            }
        }
    }

    private void Start()
    {
        this.language = PlayerPrefs.GetInt("language");
        this.script_archive = base.GetComponent<DB_Archive>();
        this.bg_posX_l = -380f;
        this.bg_posX_r = 480f;
        this.icon_posY = 340f;
        this.temp_treasure = PlayerPrefsX.GetIntArray("treasure");
        this.temp_staff = PlayerPrefsX.GetIntArray("staff");
        this.tutorial = Crypto.Load_int_key("tutorial");
        this.sound_UI = GameObject.FindWithTag("sound");
        if (this.sound_UI != null)
        {
            this.script_soundUI = this.sound_UI.GetComponent<SoundEf_UI>();
        }
        this.script_name = base.GetComponent<Language_Name>();
        this.script_archname = base.GetComponent<Language_Archive>();
        this.complete_archive = PlayerPrefsX.GetIntArray("archive");
        this.bosskill = PlayerPrefsX.GetIntArray("bosskill");
        this.skill_use = PlayerPrefsX.GetIntArray("skill_use");
        this.pet_skill_use = PlayerPrefsX.GetIntArray("pet_skill_use");
        this.enemykill = Crypto.Load_int_key("enemykill");
        this.grappling = Crypto.Load_int_key("grappling");
        this.exattack = Crypto.Load_int_key("exattack");
        this.death = Crypto.Load_int_key("death");
        this.resurrection = Crypto.Load_int_key("resurrection");
        this.max_stage_index = Crypto.Load_int_key("n06");
        this.unlock_costume = PlayerPrefsX.GetIntArray("n18");
        this.cashing = Crypto.Load_int_key("cashing");
        this.generalsearch = Crypto.Load_int_key("generalsearch");
        this.cur_skill_grade = PlayerPrefsX.GetIntArray("n22");
        this.caveplay = Crypto.Load_int_key("caveplay");
        this.perfectplay = Crypto.Load_int_key("perfectplay");
        for (int i = 0; i < 0x4c; i++)
        {
            int num2;
            int num3;
            int num4;
            int num5;
            int num6;
            int num7;
            int num8;
            int num9;
            int num10;
            if (this.complete_archive[i] == 0)
            {
                this.remain_arch++;
                switch (this.script_archive.aci[i]._require_kind)
                {
                    case 1:
                        if (this.enemykill < this.script_archive.aci[i]._require_amount)
                        {
                            goto Label_0285;
                        }
                        this.gift_archive[i] = true;
                        this.warning_newarchive = true;
                        break;

                    case 2:
                        if (this.grappling < this.script_archive.aci[i]._require_amount)
                        {
                            goto Label_02EE;
                        }
                        this.gift_archive[i] = true;
                        this.warning_newarchive = true;
                        break;

                    case 3:
                        if (this.death < this.script_archive.aci[i]._require_amount)
                        {
                            goto Label_0357;
                        }
                        this.gift_archive[i] = true;
                        this.warning_newarchive = true;
                        break;

                    case 4:
                        if (this.resurrection < this.script_archive.aci[i]._require_amount)
                        {
                            goto Label_03C0;
                        }
                        this.gift_archive[i] = true;
                        this.warning_newarchive = true;
                        break;

                    case 5:
                        if (this.exattack < this.script_archive.aci[i]._require_amount)
                        {
                            goto Label_0429;
                        }
                        this.gift_archive[i] = true;
                        this.warning_newarchive = true;
                        break;

                    case 6:
                        num2 = 0;
                        goto Label_048A;

                    case 7:
                        if (this.max_stage_index < this.script_archive.aci[i]._require_amount)
                        {
                            goto Label_04CD;
                        }
                        this.gift_archive[i] = true;
                        this.warning_newarchive = true;
                        break;

                    case 8:
                        if (this.bosskill[this.script_archive.aci[i]._require_kind_sub] < this.script_archive.aci[i]._require_amount)
                        {
                            goto Label_054D;
                        }
                        this.gift_archive[i] = true;
                        this.warning_newarchive = true;
                        break;

                    case 9:
                        if (this.pet_skill_use[this.script_archive.aci[i]._require_kind_sub] < this.script_archive.aci[i]._require_amount)
                        {
                            goto Label_05E4;
                        }
                        this.gift_archive[i] = true;
                        this.warning_newarchive = true;
                        break;

                    case 10:
                        if (this.skill_use[this.script_archive.aci[i]._require_kind_sub] < this.script_archive.aci[i]._require_amount)
                        {
                            goto Label_067B;
                        }
                        this.gift_archive[i] = true;
                        this.warning_newarchive = true;
                        break;

                    case 11:
                        if (this.generalsearch < this.script_archive.aci[i]._require_amount)
                        {
                            goto Label_06FB;
                        }
                        this.gift_archive[i] = true;
                        this.warning_newarchive = true;
                        break;

                    case 12:
                        num3 = 0;
                        num4 = 0;
                        goto Label_074D;

                    case 13:
                        num5 = 0;
                        num6 = 0;
                        goto Label_07C5;

                    case 14:
                        num7 = 0;
                        num8 = 0;
                        goto Label_0855;

                    case 15:
                        if (this.caveplay < this.script_archive.aci[i]._require_amount)
                        {
                            goto Label_08F5;
                        }
                        this.gift_archive[i] = true;
                        this.warning_newarchive = true;
                        break;

                    case 0x10:
                        if (this.perfectplay < this.script_archive.aci[i]._require_amount)
                        {
                            goto Label_095E;
                        }
                        this.gift_archive[i] = true;
                        this.warning_newarchive = true;
                        break;

                    case 0x12:
                        if (this.cashing < this.script_archive.aci[i]._require_amount)
                        {
                            goto Label_09C7;
                        }
                        this.gift_archive[i] = true;
                        this.warning_newarchive = true;
                        break;

                    case 0x13:
                        num9 = 0;
                        num10 = 0;
                        goto Label_0A20;

                    case 20:
                        if (this.remain_arch > 0)
                        {
                            goto Label_0AAB;
                        }
                        this.gift_archive[i] = true;
                        this.warning_newarchive = true;
                        break;
                }
            }
            continue;
        Label_0285:
            this.rate_archive[i] = (int) ((((float) this.enemykill) / ((float) this.script_archive.aci[i]._require_amount)) * 100f);
            continue;
        Label_02EE:
            this.rate_archive[i] = (int) ((((float) this.grappling) / ((float) this.script_archive.aci[i]._require_amount)) * 100f);
            continue;
        Label_0357:
            this.rate_archive[i] = (int) ((((float) this.death) / ((float) this.script_archive.aci[i]._require_amount)) * 100f);
            continue;
        Label_03C0:
            this.rate_archive[i] = (int) ((((float) this.resurrection) / ((float) this.script_archive.aci[i]._require_amount)) * 100f);
            continue;
        Label_0429:
            this.rate_archive[i] = (int) ((((float) this.exattack) / ((float) this.script_archive.aci[i]._require_amount)) * 100f);
            continue;
        Label_0463:
            if (this.temp_staff[num2] == 5)
            {
                this.gift_archive[i] = true;
                this.warning_newarchive = true;
                continue;
            }
            num2++;
        Label_048A:
            if (num2 < 30)
            {
                goto Label_0463;
            }
            continue;
        Label_04CD:
            this.rate_archive[i] = (int) ((((float) this.max_stage_index) / ((float) this.script_archive.aci[i]._require_amount)) * 100f);
            continue;
        Label_054D:
            this.rate_archive[i] = (int) ((((float) this.bosskill[this.script_archive.aci[i]._require_kind_sub]) / ((float) this.script_archive.aci[i]._require_amount)) * 100f);
            continue;
        Label_05E4:
            this.rate_archive[i] = (int) ((((float) this.pet_skill_use[this.script_archive.aci[i]._require_kind_sub]) / ((float) this.script_archive.aci[i]._require_amount)) * 100f);
            continue;
        Label_067B:
            this.rate_archive[i] = (int) ((((float) this.skill_use[this.script_archive.aci[i]._require_kind_sub]) / ((float) this.script_archive.aci[i]._require_amount)) * 100f);
            continue;
        Label_06FB:
            this.rate_archive[i] = (int) ((((float) this.generalsearch) / ((float) this.script_archive.aci[i]._require_amount)) * 100f);
            continue;
        Label_0737:
            if (this.temp_staff[num4] >= 4)
            {
                num3++;
            }
            num4++;
        Label_074D:
            if (num4 < 30)
            {
                goto Label_0737;
            }
            if (num3 >= 5)
            {
                this.gift_archive[i] = true;
                this.warning_newarchive = true;
            }
            else
            {
                this.rate_archive[i] = (int) ((((float) num3) / ((float) this.script_archive.aci[i]._require_amount)) * 100f);
            }
            continue;
        Label_07AA:
            if (this.cur_skill_grade[num6] >= 0)
            {
                num5++;
            }
            num6++;
        Label_07C5:
            if (num6 < 20)
            {
                goto Label_07AA;
            }
            if (num5 >= this.script_archive.aci[i]._require_amount)
            {
                this.gift_archive[i] = true;
                this.warning_newarchive = true;
            }
            else
            {
                this.rate_archive[i] = (int) ((((float) num5) / ((float) this.script_archive.aci[i]._require_amount)) * 100f);
            }
            continue;
        Label_083A:
            if (this.cur_skill_grade[num8] >= 4)
            {
                num7++;
            }
            num8++;
        Label_0855:
            if (num8 < 20)
            {
                goto Label_083A;
            }
            if (num7 >= this.script_archive.aci[i]._require_amount)
            {
                this.gift_archive[i] = true;
                this.warning_newarchive = true;
            }
            else
            {
                this.rate_archive[i] = (int) ((((float) num7) / ((float) this.script_archive.aci[i]._require_amount)) * 100f);
            }
            continue;
        Label_08F5:
            this.rate_archive[i] = (int) ((((float) this.caveplay) / ((float) this.script_archive.aci[i]._require_amount)) * 100f);
            continue;
        Label_095E:
            this.rate_archive[i] = (int) ((((float) this.perfectplay) / ((float) this.script_archive.aci[i]._require_amount)) * 100f);
            continue;
        Label_09C7:
            this.rate_archive[i] = (int) ((((float) this.cashing) / ((float) this.script_archive.aci[i]._require_amount)) * 100f);
            continue;
        Label_0A05:
            if (this.unlock_costume[num10] > 0)
            {
                num9++;
            }
            num10++;
        Label_0A20:
            if (num10 < 20)
            {
                goto Label_0A05;
            }
            if (num9 >= this.script_archive.aci[i]._require_amount)
            {
                this.gift_archive[i] = true;
                this.warning_newarchive = true;
            }
            else
            {
                this.rate_archive[i] = (int) ((((float) num9) / ((float) this.script_archive.aci[i]._require_amount)) * 100f);
            }
            continue;
        Label_0AAB:
            this.rate_archive[i] = (int) ((((float) (0x4c - this.remain_arch)) / 76f) * 100f);
        }
        this.FindNewTreasure();
        base.InvokeRepeating("Warning_iconsize", 0.5f, 0.34f);
    }

    private void Update()
    {
        if (this.b_delay)
        {
            this.f_delay -= Time.deltaTime;
            if (this.f_delay <= 0f)
            {
                this.b_delay = false;
                this.f_delay = 0f;
            }
        }
        if (!this.imagemovefinish)
        {
            if (this.bg_posX_l < -64f)
            {
                this.bg_posX_l += Mathf.Min(-this.bg_posX_l, Time.deltaTime * 600f);
            }
            else
            {
                this.bg_posX_l = -64f;
                this.bg_posX_r -= Mathf.Min(this.bg_posX_r, Time.deltaTime * 1500f);
                if (this.bg_posX_r <= 0f)
                {
                    this.bg_posX_r = 0f;
                    this.icon_posY -= Mathf.Min(this.icon_posY, Time.deltaTime * 500f);
                    if (this.icon_posY <= 230f)
                    {
                        this.icon_posY = 230f;
                        this.imagemovefinish = true;
                    }
                }
            }
        }
    }

    public void Warning_iconsize()
    {
        this.icon_size = (this.icon_size + 1) % 2;
    }
}


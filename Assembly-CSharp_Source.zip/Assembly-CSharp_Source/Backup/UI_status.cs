using System;
using UnityEngine;

public class UI_status : MonoBehaviour
{
    private int[] accessory = new int[6];
    public Texture2D arrow_upgrade;
    private bool b_delay;
    public GUISkin basicSkin;
    public Texture2D bg_asset;
    public Texture2D bg_black;
    private float bg_posX_l;
    private float bg_posX_r;
    public Texture2D bg_shop;
    public GUIStyle bt_acce;
    public GUIStyle bt_back;
    public GUIStyle bt_empty;
    public GUIStyle bt_equip;
    public GUIStyle bt_next;
    public GUIStyle bt_prev;
    public GUIStyle bt_yesno;
    private GameObject cashshop;
    private int coin;
    private short confirm;
    public Texture2D cost_icon;
    private int critical;
    private int[] cur_equip_grade = new int[6];
    private equipitem[,] ei = new equipitem[6, 11];
    private int endurance;
    public Texture2D[] equipicon = new Texture2D[6];
    private int evasion;
    private float exp;
    private float f_delay;
    public Texture2D gauge_exp;
    private int hitrate;
    private int hpplus;
    private float icon_posY;
    private bool imagemovefinish;
    public Texture2D[] img_acce = new Texture2D[6];
    private int jade;
    private int language;
    private int level;
    private int maxhp;
    public Texture2D pop_blank;
    public Texture2D pop_blank2;
    public Texture2D pop_detail;
    private bool popup_equip_select;
    private int rollstat;
    private SoundEf_UI script_soundUI;
    private int select_itemidx;
    private int selectequip;
    public Transform sound_dummy;
    private Transform sound_UI;
    private int statinfo = 0xa1;
    private int statname_idx;
    private string[] thisitemStat = new string[6];
    public Texture2D titlebase;
    public GUIStyle titlebase2;

    private void Awake()
    {
        this.level = Crypto.Load_int_key("n47");
        this.hpplus = Crypto.Load_int_key("n21");
        this.hitrate = Crypto.Load_int_key("n08");
        this.evasion = Crypto.Load_int_key("n30");
        this.endurance = Crypto.Load_int_key("n28");
        this.critical = Crypto.Load_int_key("n32");
    }

    public void CashshopOpen()
    {
        if (this.cashshop == null)
        {
            this.cashshop = Resources.Load("CashShop") as GameObject;
        }
        UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
    }

    public void Delay(float t)
    {
        this.b_delay = true;
        this.f_delay = t;
    }

    private void OnEnable()
    {
        this.coin = Crypto.Load_int_key("n17");
        this.jade = Crypto.Load_int_key("n24");
        this.accessory = PlayerPrefsX.GetIntArray("n36");
    }

    private void OnGUI()
    {
        GUI.skin = this.basicSkin;
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        if (this.confirm > 0)
        {
            GUI.enabled = false;
        }
        GUI.DrawTexture(Crypto.Rect2(this.bg_posX_l, 0f, 320f, 320f), this.bg_shop);
        GUI.DrawTexture(Crypto.Rect2(this.bg_posX_r, 212f, 480f, 100f), this.bg_black);
        GUI.DrawTexture(Crypto.Rect2(112f, 0f, 256f, 32f), this.bg_asset);
        GUI.Label(Crypto.Rect2(146f, 6f, 80f, 14f), string.Empty + this.coin, "txt12_w");
        GUI.Label(Crypto.Rect2(280f, 6f, 64f, 14f), string.Empty + this.jade, "txt12_w");
        if (GUI.Button(Crypto.Rect2(144f, 2f, 100f, 24f), string.Empty, this.bt_empty))
        {
            if (this.sound_UI != null)
            {
                this.script_soundUI.SoundOn(0);
            }
            Crypto.Save_int_key("cashshopkind", 2);
            this.CashshopOpen();
        }
        if (GUI.Button(Crypto.Rect2(272f, 2f, 88f, 24f), string.Empty, this.bt_empty))
        {
            if (this.sound_UI != null)
            {
                this.script_soundUI.SoundOn(0);
            }
            Crypto.Save_int_key("cashshopkind", 1);
            this.CashshopOpen();
        }
        for (int i = 0; i < 6; i++)
        {
            if (this.cur_equip_grade[i] >= 10)
            {
                GUI.Label(Crypto.Rect2((float) ((i * 0x4c) + 0x12), this.icon_posY - 14f, 64f, 14f), Language.intxt[this.language, 60], "txt12_w");
            }
            else
            {
                GUI.Label(Crypto.Rect2((float) ((i * 0x4c) + 0x12), this.icon_posY - 14f, 64f, 14f), "Level " + (this.cur_equip_grade[i] + 1), "txt12_w");
            }
            GUI.DrawTexture(Crypto.Rect2((float) ((i * 0x4c) + 0x12), this.icon_posY, 64f, 64f), this.equipicon[i]);
            if (GUI.Button(Crypto.Rect2((float) ((i * 0x4c) + 0x12), this.icon_posY, 64f, 64f), string.Empty, this.bt_equip))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(0);
                }
                this.selectequip = i;
                this.StatInfo_detail(this.selectequip);
                this.popup_equip_select = true;
            }
            if (this.cur_equip_grade[i] < 10)
            {
                GUI.DrawTexture(Crypto.Rect2((float) ((i * 0x4c) + 0x16), this.icon_posY + 66f, 16f, 16f), this.cost_icon);
                GUI.Label(Crypto.Rect2((float) ((i * 0x4c) + 0x12), this.icon_posY + 66f, 64f, 14f), "    " + this.ei[i, this.cur_equip_grade[i] + 1]._price, "txt12_w");
            }
        }
        if (!this.popup_equip_select)
        {
            GUI.DrawTexture(Crypto.Rect2(200f, 70f, 256f, 128f), this.pop_blank2);
            if (this.rollstat == 0)
            {
                GUI.DrawTexture(Crypto.Rect2(256f, 82f, 146f, 16f), this.titlebase);
                GUI.DrawTexture(Crypto.Rect2(258f, 84f, 142f * this.exp, 12f), this.gauge_exp);
                GUI.Label(Crypto.Rect2(266f, 83f, 128f, 14f), "LEVEL " + this.level, "txt14_w");
                GUI.Label(Crypto.Rect2(202f, 98f, 256f, 14f), string.Concat(new object[] { "( ", Language.intxt[this.language, 0x3d], "   ", ((0.03f * this.level) + 0.5f) * 10f, " % )" }), "txt12_b");
                GUI.Label(Crypto.Rect2(202f, 120f, 256f, 14f), string.Concat(new object[] { Language.intxt[this.language, 0x9a], "   ", this.maxhp, " + ", this.ei[4, this.cur_equip_grade[4]]._capacity }), "txt12_0");
                GUI.Label(Crypto.Rect2(202f, 138f, 256f, 14f), Language.intxt[this.language, 0x91] + "   " + this.ei[5, this.cur_equip_grade[5]]._capacity, "txt12_0");
                for (int j = 0; j < 6; j++)
                {
                    if (GUI.Button(Crypto.Rect2((float) (0xd9 + (j * 0x26)), 158f, 32f, 32f), string.Empty, this.bt_acce))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        if (this.accessory[j] == 0)
                        {
                            this.confirm = 4;
                        }
                        else
                        {
                            this.select_itemidx = j;
                            this.confirm = 5;
                        }
                    }
                    if (this.accessory[j] == 0)
                    {
                        GUI.color = new Color(0f, 0f, 0f, 0.5f);
                    }
                    GUI.DrawTexture(Crypto.Rect2((float) (0xd9 + (j * 0x26)), 158f, 32f, 32f), this.img_acce[j]);
                    GUI.color = Color.white;
                }
            }
            else if (this.rollstat == 1)
            {
                for (int k = 0; k < 4; k++)
                {
                    if (GUI.Button(Crypto.Rect2(254f, (float) (0x5f + (k * 20)), 156f, 16f), string.Empty, this.titlebase2))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.statname_idx = k;
                        this.StatInfo_detail(this.statname_idx);
                        this.confirm = 3;
                    }
                    GUI.Label(Crypto.Rect2(174f, (float) (0x60 + (20 * k)), 256f, 14f), this.thisitemStat[k], "txt12_0");
                }
                GUI.Label(Crypto.Rect2(248f, 96f, 256f, 14f), string.Empty + this.hitrate, "txt12_0");
                GUI.Label(Crypto.Rect2(248f, 116f, 256f, 14f), string.Empty + this.endurance + "%", "txt12_0");
                GUI.Label(Crypto.Rect2(248f, 136f, 256f, 14f), this.critical + "%", "txt12_0");
                GUI.Label(Crypto.Rect2(248f, 156f, 256f, 14f), this.evasion + "%", "txt12_0");
            }
            else if (this.rollstat == 2)
            {
                for (int m = 0; m < 4; m++)
                {
                    if (GUI.Button(Crypto.Rect2(254f, (float) (0x55 + (m * 20)), 156f, 16f), string.Empty, this.titlebase2))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.statinfo = (m + ((this.rollstat - 1) * 5)) + 0xa1;
                        this.statname_idx = m + 5;
                        this.confirm = 3;
                    }
                    GUI.Label(Crypto.Rect2(174f, (float) (0x56 + (20 * m)), 256f, 14f), this.thisitemStat[m + 5], "txt12_0");
                }
            }
            if (GUI.Button(Crypto.Rect2(212f, 116f, 32f, 32f), string.Empty, this.bt_prev))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(0);
                }
                this.rollstat--;
                if (this.rollstat < 0)
                {
                    this.rollstat = 1;
                }
            }
            else if (GUI.Button(Crypto.Rect2(412f, 116f, 32f, 32f), string.Empty, this.bt_next))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(0);
                }
                this.rollstat = (this.rollstat + 1) % 2;
            }
            if (GUI.Button(Crypto.Rect2(416f, 0f, 64f, 64f), string.Empty, this.bt_back))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(1);
                }
                if (Crypto.Load_int_key("gamemode") == 0)
                {
                    Application.LoadLevel("Map");
                }
                else
                {
                    Application.LoadLevel("Extreme");
                }
            }
        }
        else if (this.popup_equip_select)
        {
            GUI.DrawTexture(Crypto.Rect2(200f, 70f, 256f, 128f), this.pop_detail);
            GUI.DrawTexture(Crypto.Rect2(216f, 104f, 64f, 64f), this.equipicon[this.selectequip]);
            GUI.Label(Crypto.Rect2(200f, 81f, 256f, 14f), string.Empty + Language.intxt[this.language, this.ei[this.selectequip, this.cur_equip_grade[this.selectequip]]._name], "txt12_w");
            GUI.Label(Crypto.Rect2(298f, 108f, 124f, 14f), string.Concat(new object[] { string.Empty, this.thisitemStat[this.selectequip], " + ", this.ei[this.selectequip, this.cur_equip_grade[this.selectequip]]._capacity }), "txt12_b");
            GUI.Label(Crypto.Rect2(282f, 134f, 160f, 14f), Language.intxt[this.language, this.statinfo], "txt12_0");
            if (this.cur_equip_grade[this.selectequip] < 10)
            {
                GUI.DrawTexture(Crypto.Rect2(216f, 169f, 16f, 16f), this.cost_icon);
                GUI.Label(Crypto.Rect2(226f, 169f, 58f, 14f), string.Empty + this.ei[this.selectequip, this.cur_equip_grade[this.selectequip] + 1]._price, "txt12_0");
                if (GUI.Button(Crypto.Rect2(300f, 158f, 64f, 32f), Language.intxt[this.language, 0x42], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    if (this.coin < this.ei[this.selectequip, this.cur_equip_grade[this.selectequip] + 1]._price)
                    {
                        this.confirm = 2;
                        this.Delay(1f);
                    }
                    else
                    {
                        this.confirm = 1;
                    }
                }
            }
            else
            {
                GUI.Label(Crypto.Rect2(216f, 169f, 64f, 14f), string.Empty + Language.intxt[this.language, 60], "txt12_b");
            }
            if (GUI.Button(Crypto.Rect2(370f, 158f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(1);
                }
                this.popup_equip_select = false;
            }
        }
        if (this.confirm > 0)
        {
            GUI.enabled = true;
            if (this.confirm == 1)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                GUI.Label(Crypto.Rect2(112f, 106f, 256f, 14f), Language.intxt[this.language, 14], "txt12_0");
                GUI.Label(Crypto.Rect2(156f, 132f, 128f, 14f), string.Concat(new object[] { string.Empty, this.thisitemStat[this.selectequip], " + ", this.ei[this.selectequip, this.cur_equip_grade[this.selectequip]]._capacity }), "txt12_0");
                GUI.Label(Crypto.Rect2(200f, 150f, 128f, 14f), string.Concat(new object[] { string.Empty, this.thisitemStat[this.selectequip], " + ", this.ei[this.selectequip, this.cur_equip_grade[this.selectequip] + 1]._capacity }), "txt12_b");
                GUI.DrawTexture(Crypto.Rect2(182f, 149f, 16f, 16f), this.arrow_upgrade);
                if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    if (Crypto.Property_change(-this.ei[this.selectequip, this.cur_equip_grade[this.selectequip] + 1]._price, false))
                    {
                        this.coin -= this.ei[this.selectequip, this.cur_equip_grade[this.selectequip] + 1]._price;
                        this.cur_equip_grade[this.selectequip]++;
                        this.hitrate = this.ei[0, this.cur_equip_grade[0]]._capacity;
                        this.endurance = this.ei[1, this.cur_equip_grade[1]]._capacity;
                        this.critical = this.ei[2, this.cur_equip_grade[2]]._capacity;
                        this.evasion = this.ei[3, this.cur_equip_grade[3]]._capacity;
                        this.hpplus = this.ei[4, this.cur_equip_grade[4]]._capacity;
                        PlayerPrefsX.SetIntArray("n20", this.cur_equip_grade);
                        Crypto.Save_int_key("n08", this.hitrate);
                        Crypto.Save_int_key("n28", this.endurance);
                        Crypto.Save_int_key("n32", this.critical);
                        Crypto.Save_int_key("n30", this.evasion);
                        Crypto.Save_int_key("n21", this.hpplus);
                        Crypto.Save_int_key("n26", this.ei[5, this.cur_equip_grade[5]]._capacity);
                        this.confirm = 0;
                    }
                }
                else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 2)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                GUI.Label(Crypto.Rect2(120f, 130f, 240f, 16f), Language.intxt[this.language, 0x16], "txt12_0");
                if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    Crypto.Save_int_key("cashshopkind", 2);
                    this.confirm = 0;
                    if (this.cashshop == null)
                    {
                        this.cashshop = Resources.Load("CashShop") as GameObject;
                    }
                    UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
                }
                else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 3)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                GUI.DrawTexture(Crypto.Rect2(160f, 106f, 160f, 16f), this.titlebase);
                GUI.Label(Crypto.Rect2(120f, 110f, 240f, 64f), Language.intxt[this.language, this.statinfo], "txt12_0");
                GUI.Label(Crypto.Rect2(120f, 106f, 240f, 16f), this.thisitemStat[this.statname_idx], "txt12_w");
                if (GUI.Button(Crypto.Rect2(208f, 180f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 4)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                GUI.Label(Crypto.Rect2(120f, 130f, 230f, 16f), Language.intxt[this.language, 0x151], "txt12_0");
                if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    Crypto.Save_int_key("cashshopkind", 6);
                    this.confirm = 0;
                    if (this.cashshop == null)
                    {
                        this.cashshop = Resources.Load("CashShop") as GameObject;
                    }
                    UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
                }
                else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 5)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                GUI.Box(Crypto.Rect2(176f, 100f, 128f, 22f), Language.intxt[this.language, 0x14b + this.select_itemidx]);
                GUI.Label(Crypto.Rect2(120f, 136f, 230f, 16f), Language.intxt[this.language, 0x15f + this.select_itemidx], "txt12_0");
                if (GUI.Button(Crypto.Rect2(208f, 180f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.confirm = 0;
                }
            }
        }
    }

    private void Start()
    {
        this.language = PlayerPrefs.GetInt("language");
        this.bg_posX_l = -380f;
        this.bg_posX_r = 480f;
        this.icon_posY = 340f;
        this.ei = base.GetComponent<DB_EquipItem>().ei;
        this.maxhp = 0x5f + (this.level * 5);
        this.exp = Crypto.Load_int_key("n11");
        this.exp /= (float) (this.level * 100);
        this.cur_equip_grade = PlayerPrefsX.GetIntArray("n20");
        if (GameObject.FindWithTag("sound") == null)
        {
            this.sound_UI = (Transform) UnityEngine.Object.Instantiate(this.sound_dummy, Vector3.zero, Quaternion.identity);
        }
        else
        {
            this.sound_UI = GameObject.FindWithTag("sound").transform;
        }
        if (this.sound_UI != null)
        {
            this.script_soundUI = this.sound_UI.GetComponent<SoundEf_UI>();
        }
        this.thisitemStat[0] = Language.intxt[this.language, 0x8f];
        this.thisitemStat[1] = Language.intxt[this.language, 0x93];
        this.thisitemStat[2] = Language.intxt[this.language, 0x94];
        this.thisitemStat[3] = Language.intxt[this.language, 0x92];
        this.thisitemStat[4] = Language.intxt[this.language, 0x9a];
        this.thisitemStat[5] = Language.intxt[this.language, 0x91];
    }

    public void StatInfo_detail(int _index)
    {
        switch (_index)
        {
            case 0:
                this.statinfo = 0xa3;
                break;

            case 1:
                this.statinfo = 0xa2;
                break;

            case 2:
                this.statinfo = 0xa7;
                break;

            case 3:
                this.statinfo = 0xa5;
                break;

            case 4:
                this.statinfo = 0xa1;
                break;

            case 5:
                this.statinfo = 170;
                break;
        }
    }

    private void Update()
    {
        if (this.b_delay)
        {
            this.f_delay -= Time.deltaTime;
            if (this.f_delay <= 0f)
            {
                this.b_delay = false;
                this.f_delay = 0f;
            }
        }
        if (!this.imagemovefinish)
        {
            if (this.bg_posX_l < -64f)
            {
                this.bg_posX_l += Mathf.Min(-this.bg_posX_l, Time.deltaTime * 600f);
            }
            else
            {
                this.bg_posX_l = -64f;
                this.bg_posX_r -= Mathf.Min(this.bg_posX_r, Time.deltaTime * 1500f);
                if (this.bg_posX_r <= 0f)
                {
                    this.bg_posX_r = 0f;
                    this.icon_posY -= Mathf.Min(this.icon_posY, Time.deltaTime * 500f);
                    if (this.icon_posY <= 230f)
                    {
                        this.icon_posY = 230f;
                        this.imagemovefinish = true;
                    }
                }
            }
        }
    }
}


using System;
using UnityEngine;

public class CombineMesh : MonoBehaviour
{
    private MeshFilter meshFilter;
    private Transform mytransform;
    public Mesh splitmesh;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.meshFilter = base.GetComponent<MeshFilter>();
    }

    public void CreatSplitMesh(Vector3 _pos, Vector3 _scale)
    {
        GameObject obj2 = new GameObject("split");
        Transform childtransform = obj2.transform;
        MeshFilter filter = obj2.AddComponent<MeshFilter>();
        int num = UnityEngine.Random.Range(0, 2);
        int num2 = UnityEngine.Random.Range(0, 2);
        this.splitmesh.uv = new Vector2[] { new Vector2(0f + (num * 0.5f), 0.5f + (num2 * 0.5f)), new Vector2(0.5f + (num * 0.5f), 0.5f + (num2 * 0.5f)), new Vector2(0f + (num * 0.5f), 0f + (num2 * 0.5f)), new Vector2(0.5f + (num * 0.5f), 0f + (num2 * 0.5f)) };
        filter.mesh = this.splitmesh;
        childtransform.position = _pos;
        childtransform.rotation = Quaternion.Euler(0f, (float) UnityEngine.Random.Range(0, 360), 0f);
        childtransform.localScale = (Vector3) (UnityEngine.Random.Range((float) 0.7f, (float) 1f) * _scale);
        childtransform.parent = this.mytransform;
        this.Merge(this.splitmesh, childtransform);
    }

    public void Merge(Mesh childmesh, Transform childtransform)
    {
        Transform transform = (Transform) UnityEngine.Object.Instantiate(base.transform, base.transform.position, Quaternion.identity);
        CombineInstance[] combine = new CombineInstance[2];
        combine[0].mesh = transform.GetComponent<MeshFilter>().mesh;
        combine[1].mesh = childmesh;
        combine[1].transform = childtransform.localToWorldMatrix;
        this.meshFilter.mesh = new Mesh();
        this.meshFilter.mesh.CombineMeshes(combine);
        base.transform.gameObject.active = true;
    }
}


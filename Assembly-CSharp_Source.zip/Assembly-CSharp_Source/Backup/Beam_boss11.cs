using System;
using UnityEngine;

public class Beam_boss11 : MonoBehaviour
{
    private float delay;
    public float finishdelay = 3f;
    private Material mymaterial;
    private Transform mytransform;
    private Vector2 offset;
    private float rotatefactor = 1f;
    public float uvspeed = 1f;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mymaterial = base.renderer.sharedMaterial;
    }

    private void DanceHit()
    {
    }

    private void OnEnable()
    {
        this.offset = Vector2.zero;
        this.mymaterial.mainTextureOffset = Vector2.zero;
        this.mytransform.localScale = Vector3.zero;
        this.delay = 0f;
        this.rotatefactor = 1f;
    }

    private void Update()
    {
        this.offset += (Vector2) ((Vector2.up * Time.deltaTime) * this.uvspeed);
        if (this.delay > this.finishdelay)
        {
            this.mytransform.position = (Vector3) (Vector3.one * 38f);
            base.gameObject.active = false;
            this.delay = 0f;
        }
        else
        {
            this.rotatefactor += Time.deltaTime * 100f;
            this.delay += Time.deltaTime;
            this.mymaterial.mainTextureOffset = this.offset;
            this.mytransform.localScale = Vector3.Lerp(this.mytransform.localScale, new Vector3(1.4f, 1.4f, 2f), Time.deltaTime * 3f);
            this.mytransform.root.Rotate((Vector3) ((Vector3.up * Time.deltaTime) * this.rotatefactor));
        }
    }
}


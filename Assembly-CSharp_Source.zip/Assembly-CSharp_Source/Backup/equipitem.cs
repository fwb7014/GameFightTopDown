using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct equipitem
{
    public short _name;
    public short _grade;
    public short _capacity;
    public short _price;
}


using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class UI_skill : MonoBehaviour
{
    public Texture2D active_slot;
    public Texture2D arrow;
    private bool b_delay;
    public GUISkin basicSkin;
    public Texture2D bg_asset;
    public Texture2D bg_black;
    public Texture2D bg_black100;
    private float bg_posX_l;
    private float bg_posX_r;
    public Texture2D bg_skill;
    public GUIStyle bt_back;
    public GUIStyle bt_empty;
    public GUIStyle bt_skill;
    public GUIStyle bt_skill_slot;
    public GUIStyle bt_yesno;
    private GameObject cashshop;
    private int chalevel;
    private int coin;
    private short confirm;
    private Texture2D cost_icon;
    public int[] cur_skill_grade = new int[20];
    private float currentX;
    private bool dragOn;
    private float dragposX;
    private float dragrange;
    private int emptyslot = -1;
    private float f_delay;
    public Texture2D icon_coin;
    public Texture2D[] icon_diamond = new Texture2D[3];
    public Texture2D icon_jade;
    private float icon_posY;
    private int icon_size;
    public Texture2D icon_soul;
    private bool imageloading;
    private bool imagemovefinish;
    private int jade;
    private int language;
    private const int MAXSKILL = 20;
    public Texture2D please_touch;
    public Texture2D pop_blank;
    public Texture2D pop_blank2;
    public Texture2D pop_detail;
    private bool popupOn;
    private float prevposX;
    private SoundEf_UI script_soundUI;
    private bool scrollOn;
    private int selectskill;
    private bool showimg;
    private int[] skill_slot = new int[5];
    public Texture2D[] skillicon = new Texture2D[20];
    public Transform sound_dummy;
    private Transform sound_UI;
    private skillset[,] ss = new skillset[20, 5];
    private Texture2D ss_skill;
    private string[] ss_url = new string[20];
    public Texture2D titlebase;
    public Texture2D titlebase_w;
    private int tutorial;
    public Texture2D txt_name;
    private string updatestring;
    private WWW www;

    private void Awake()
    {
        this.ss_url[0] = "http://ozd.dn.hangame.com/smart/ozd/udi/01_Skill_1.jpg";
        this.ss_url[1] = "http://ozd.dn.hangame.com/smart/ozd/udi/02_Skill_2.jpg";
        this.ss_url[2] = "http://ozd.dn.hangame.com/smart/ozd/udi/03_Skill_1.jpg";
        this.ss_url[3] = "http://ozd.dn.hangame.com/smart/ozd/udi/04_Skill_1.jpg";
        this.ss_url[4] = "http://ozd.dn.hangame.com/smart/ozd/udi/05_Skill_1.jpg";
        this.ss_url[5] = "http://ozd.dn.hangame.com/smart/ozd/udi/06_Skill_1.jpg";
        this.ss_url[6] = "http://ozd.dn.hangame.com/smart/ozd/udi/07_Skill_1.jpg";
        this.ss_url[7] = "http://ozd.dn.hangame.com/smart/ozd/udi/08_Skill_1.jpg";
        this.ss_url[8] = "http://ozd.dn.hangame.com/smart/ozd/udi/09_Skill_1.jpg";
        this.ss_url[9] = "http://ozd.dn.hangame.com/smart/ozd/udi/10_Skill_1.jpg";
        this.ss_url[10] = "http://ozd.dn.hangame.com/smart/ozd/udi/11_Skill_2.jpg";
        this.ss_url[11] = "http://ozd.dn.hangame.com/smart/ozd/udi/12_Skill_1.jpg";
        this.ss_url[12] = "http://ozd.dn.hangame.com/smart/ozd/udi/13_Skill_1.jpg";
        this.ss_url[13] = "http://ozd.dn.hangame.com/smart/ozd/udi/14_Skill_1.jpg";
        this.ss_url[14] = "http://ozd.dn.hangame.com/smart/ozd/udi/15_Skill_2.jpg";
        this.ss_url[15] = "http://ozd.dn.hangame.com/smart/ozd/udi/16_Skill_1.jpg";
        this.ss_url[0x10] = "http://ozd.dn.hangame.com/smart/ozd/udi/17_Skill_2.jpg";
        this.ss_url[0x11] = "http://ozd.dn.hangame.com/smart/ozd/udi/18_Skill_2.jpg";
        this.ss_url[0x12] = "http://ozd.dn.hangame.com/smart/ozd/udi/19_Skill_2.jpg";
        this.ss_url[0x13] = "http://ozd.dn.hangame.com/smart/ozd/udi/20_Skill_2.jpg";
    }

    public void CashshopOpen()
    {
        if (this.cashshop == null)
        {
            this.cashshop = Resources.Load("CashShop") as GameObject;
        }
        UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
    }

    public void Delay(float t)
    {
        this.b_delay = true;
        this.f_delay = t;
    }

    public int FindEmptySlot()
    {
        this.emptyslot = -1;
        for (int i = 0; i < 5; i++)
        {
            if (this.skill_slot[i] == -1)
            {
                this.emptyslot = i;
                break;
            }
        }
        return this.emptyslot;
    }

    private void OnEnable()
    {
        this.coin = Crypto.Load_int_key("n17");
        this.jade = Crypto.Load_int_key("n24");
    }

    private void OnGUI()
    {
        GUI.skin = this.basicSkin;
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        if ((this.confirm > 0) || this.showimg)
        {
            GUI.enabled = false;
        }
        GUI.DrawTexture(Crypto.Rect2(this.bg_posX_l, 0f, 320f, 320f), this.bg_skill);
        GUI.DrawTexture(Crypto.Rect2(this.bg_posX_r, 224f, 480f, 100f), this.bg_black);
        GUI.DrawTexture(Crypto.Rect2(120f, 30f, 100f, 50f), this.txt_name);
        GUI.Box(Crypto.Rect2(190f, 70f, 80f, 24f), Language.intxt[this.language, 0x44]);
        GUI.DrawTexture(Crypto.Rect2(112f, 0f, 256f, 32f), this.bg_asset);
        GUI.Label(Crypto.Rect2(146f, 6f, 80f, 14f), string.Empty + this.coin, "txt12_w");
        GUI.Label(Crypto.Rect2(280f, 6f, 64f, 14f), string.Empty + this.jade, "txt12_w");
        if (GUI.Button(Crypto.Rect2(144f, 2f, 100f, 24f), string.Empty, this.bt_empty))
        {
            if (this.sound_UI != null)
            {
                this.script_soundUI.SoundOn(0);
            }
            Crypto.Save_int_key("cashshopkind", 2);
            this.CashshopOpen();
        }
        if (GUI.Button(Crypto.Rect2(272f, 2f, 88f, 24f), string.Empty, this.bt_empty))
        {
            if (this.sound_UI != null)
            {
                this.script_soundUI.SoundOn(0);
            }
            Crypto.Save_int_key("cashshopkind", 1);
            this.CashshopOpen();
        }
        for (int i = 0; i < 20; i++)
        {
            if ((((i * 0x98) + (this.dragposX * 2f)) > -152f) && (((i * 0x98) + (this.dragposX * 2f)) < 1100f))
            {
                if (this.cur_skill_grade[i] == -2)
                {
                    GUI.Label(Crypto.Rect2(((i * 0x4c) + 0x12) + this.dragposX, this.icon_posY + 74f, 64f, 14f), Language.intxt[this.language, 0x10a] + this.ss[i, 0]._requireLV, "txt12_r");
                    GUI.color = Color.gray;
                    GUI.DrawTexture(Crypto.Rect2(((i * 0x4c) + 0x12) + this.dragposX, this.icon_posY + 8f, 64f, 64f), this.skillicon[i]);
                    GUI.color = Color.white;
                }
                else if (this.cur_skill_grade[i] >= 4)
                {
                    GUI.DrawTexture(Crypto.Rect2(((i * 0x4c) + 0x12) + this.dragposX, this.icon_posY + 8f, 64f, 64f), this.skillicon[i]);
                    GUI.Label(Crypto.Rect2(((i * 0x4c) + 0x12) + this.dragposX, this.icon_posY - 6f, 64f, 14f), Language.intxt[this.language, 60], "txt12_w");
                }
                else
                {
                    if (this.ss[i, this.cur_skill_grade[i] + 1]._pricekind == 1)
                    {
                        this.cost_icon = this.icon_jade;
                        GUI.DrawTexture(Crypto.Rect2(((i * 0x4c) + 0x16) + this.dragposX, this.icon_posY + 74f, 16f, 16f), this.cost_icon);
                        GUI.Label(Crypto.Rect2(((i * 0x4c) + 0x12) + this.dragposX, this.icon_posY + 74f, 64f, 14f), "\t  " + this.ss[i, this.cur_skill_grade[i] + 1]._price, "txt12_w");
                    }
                    else if (this.cur_skill_grade[i] != -1)
                    {
                        this.cost_icon = this.icon_coin;
                        GUI.DrawTexture(Crypto.Rect2(((i * 0x4c) + 0x16) + this.dragposX, this.icon_posY + 74f, 16f, 16f), this.cost_icon);
                        GUI.Label(Crypto.Rect2(((i * 0x4c) + 0x12) + this.dragposX, this.icon_posY + 74f, 64f, 14f), "\t  " + this.ss[i, this.cur_skill_grade[i] + 1]._price, "txt12_w");
                    }
                    GUI.DrawTexture(Crypto.Rect2(((i * 0x4c) + 0x12) + this.dragposX, this.icon_posY + 8f, 64f, 64f), this.skillicon[i]);
                    if (this.cur_skill_grade[i] >= 0)
                    {
                        GUI.Label(Crypto.Rect2(((i * 0x4c) + 0x12) + this.dragposX, this.icon_posY - 6f, 64f, 14f), "Level " + (this.cur_skill_grade[i] + 1), "txt12_w");
                    }
                    else
                    {
                        GUI.Label(Crypto.Rect2(((i * 0x4c) + 0x12) + this.dragposX, this.icon_posY - 6f, 64f, 14f), Language.intxt[this.language, 0x128], "txt12_w");
                    }
                }
                if (GUI.Button(Crypto.Rect2(((i * 0x4c) + 0x12) + this.dragposX, this.icon_posY + 8f, 64f, 64f), string.Empty, this.bt_skill))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    if (!this.scrollOn)
                    {
                        this.selectskill = i;
                        this.UpdateSkillStat(this.selectskill);
                        this.popupOn = true;
                    }
                }
            }
        }
        if (this.popupOn)
        {
            GUI.Box(Crypto.Rect2(180f, 44f, 256f, 24f), Language.intxt[this.language, 0x5e]);
            GUI.DrawTexture(Crypto.Rect2(180f, 70f, 256f, 128f), this.pop_detail);
            GUI.DrawTexture(Crypto.Rect2(196f, 104f, 64f, 64f), this.skillicon[this.selectskill]);
            GUI.Label(Crypto.Rect2(180f, 81f, 256f, 14f), Language.intxt[this.language, this.ss[this.selectskill, 0]._name], "txt12_w");
            GUI.Label(Crypto.Rect2(264f, 90f, 160f, 64f), Language.intxt[this.language, this.ss[this.selectskill, 0]._info], "txt12_0");
            GUI.Box(Crypto.Rect2(194f, 79f, 32f, 20f), "    " + this.ss[this.selectskill, 0]._soulprice);
            GUI.DrawTexture(Crypto.Rect2(196f, 81f, 16f, 16f), this.icon_soul);
            if (this.cur_skill_grade[this.selectskill] == -2)
            {
                GUI.Label(Crypto.Rect2(196f, 169f, 64f, 14f), Language.intxt[this.language, 0x10a] + this.ss[this.selectskill, 0]._requireLV, "txt12_0");
            }
            else
            {
                string str;
                if (this.cur_skill_grade[this.selectskill] < 4)
                {
                    if (this.ss[this.selectskill, this.cur_skill_grade[this.selectskill] + 1]._pricekind == 1)
                    {
                        this.cost_icon = this.icon_jade;
                    }
                    else
                    {
                        this.cost_icon = this.icon_coin;
                    }
                    GUI.DrawTexture(Crypto.Rect2(196f, 169f, 16f, 16f), this.cost_icon);
                    GUI.Label(Crypto.Rect2(206f, 169f, 58f, 14f), string.Empty + this.ss[this.selectskill, this.cur_skill_grade[this.selectskill] + 1]._price, "txt12_0");
                }
                if (this.cur_skill_grade[this.selectskill] >= 0)
                {
                    str = Language.intxt[this.language, 7];
                }
                else
                {
                    str = Language.intxt[this.language, 0xd1];
                }
                if (this.cur_skill_grade[this.selectskill] < 4)
                {
                    GUI.Label(Crypto.Rect2(280f, 140f, 128f, 16f), Language.intxt[this.language, 0x5f] + "   " + (this.cur_skill_grade[this.selectskill] + 1), "txt12_b");
                    if (GUI.Button(Crypto.Rect2(280f, 158f, 64f, 32f), str, this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        this.confirm = 1;
                    }
                }
                else
                {
                    GUI.Label(Crypto.Rect2(196f, 169f, 64f, 14f), Language.intxt[this.language, 60], "txt12_b");
                }
            }
            if (GUI.Button(Crypto.Rect2(350f, 158f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(1);
                }
                this.popupOn = false;
            }
            for (int j = 0; j < 5; j++)
            {
                if (this.skill_slot[j] >= 0)
                {
                    GUI.DrawTexture(Crypto.Rect2(446f, (float) (0x2a + (j * 0x24)), 28f, 28f), this.skillicon[this.skill_slot[j]]);
                }
                else
                {
                    GUI.DrawTexture(Crypto.Rect2(446f, (float) (0x2a + (j * 0x24)), 28f, 28f), this.bg_black);
                }
                if (GUI.Button(Crypto.Rect2(444f, (float) (40 + (j * 0x24)), 32f, 32f), string.Empty + (j + 1), this.bt_skill_slot))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    if (this.cur_skill_grade[this.selectskill] < 0)
                    {
                        this.confirm = 4;
                        this.Delay(1f);
                    }
                    else
                    {
                        this.ShortCut(j);
                    }
                }
                if (this.selectskill == this.skill_slot[j])
                {
                    GUI.DrawTexture(Crypto.Rect2(446f, (float) (0x2a + (j * 0x24)), (float) (this.icon_size * 0x1c), (float) (this.icon_size * 0x1c)), this.active_slot);
                }
            }
            if (this.showimg)
            {
                GUI.enabled = true;
                GUI.DrawTexture(Crypto.Rect2(97f, 24f, 286f, 286f), this.bg_black100);
                if (this.imageloading)
                {
                    if ((this.www.error == null) && (this.ss_skill != null))
                    {
                        GUI.DrawTexture(Crypto.Rect2(112f, 40f, 256f, 256f), this.ss_skill);
                    }
                    else
                    {
                        GUI.Label(Crypto.Rect2(60f, 40f, 360f, 240f), Language.intxt[this.language, 0x130], "txt12_w");
                    }
                }
                else
                {
                    GUI.Label(Crypto.Rect2(60f, 40f, 360f, 240f), Language.intxt[this.language, 0x187], "txt12_w");
                }
                if (GUI.Button(Crypto.Rect2(208f, 280f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.showimg = false;
                    this.imageloading = false;
                }
            }
        }
        else
        {
            GUI.DrawTexture(Crypto.Rect2(180f, 90f, 256f, 64f), this.pop_blank);
            GUI.Label(Crypto.Rect2(188f, 104f, 240f, 32f), Language.intxt[this.language, 0x12], "txt12_0");
            if (GUI.Button(Crypto.Rect2(416f, 0f, 64f, 64f), string.Empty, this.bt_back))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(1);
                }
                this.popupOn = false;
                if (Crypto.Load_int_key("gamemode") == 0)
                {
                    Application.LoadLevel("Map");
                }
                else
                {
                    Application.LoadLevel("Extreme");
                }
            }
        }
        if (this.confirm > 0)
        {
            GUI.enabled = true;
            if (this.confirm == 1)
            {
                if (this.cur_skill_grade[this.selectskill] >= 0)
                {
                    GUI.DrawTexture(Crypto.Rect2(112f, 80f, 256f, 148f), this.pop_blank2);
                    GUI.DrawTexture(Crypto.Rect2(160f, 89f, 160f, 20f), this.titlebase);
                    GUI.Label(Crypto.Rect2(112f, 92f, 256f, 14f), Language.intxt[this.language, this.ss[this.selectskill, 0]._name], "txt12_w");
                    GUI.DrawTexture(Crypto.Rect2(140f, 113f, 200f, 16f), this.titlebase_w);
                    GUI.Label(Crypto.Rect2(130f, 112f, 128f, 16f), Language.intxt[this.language, 0x5f], "txt12_0");
                    GUI.Label(Crypto.Rect2(212f, 112f, 128f, 16f), (this.cur_skill_grade[this.selectskill] + 1) + "           " + (this.cur_skill_grade[this.selectskill] + 2), "txt12_0");
                    GUI.DrawTexture(Crypto.Rect2(268f, 112f, 16f, 16f), this.arrow);
                    GUI.DrawTexture(Crypto.Rect2(140f, 133f, 200f, 16f), this.titlebase_w);
                    GUI.Label(Crypto.Rect2(130f, 132f, 128f, 16f), this.updatestring, "txt12_0");
                    GUI.Label(Crypto.Rect2(212f, 132f, 128f, 16f), this.ss[this.selectskill, this.cur_skill_grade[this.selectskill]]._attackpoint + "           " + this.ss[this.selectskill, this.cur_skill_grade[this.selectskill] + 1]._attackpoint, "txt12_0");
                    GUI.DrawTexture(Crypto.Rect2(268f, 132f, 16f, 16f), this.arrow);
                    GUI.DrawTexture(Crypto.Rect2(140f, 153f, 200f, 16f), this.titlebase_w);
                    GUI.Label(Crypto.Rect2(130f, 152f, 128f, 16f), Language.intxt[this.language, 200], "txt12_0");
                    GUI.Label(Crypto.Rect2(212f, 152f, 128f, 16f), this.ss[this.selectskill, this.cur_skill_grade[this.selectskill]]._cooltime + "           " + this.ss[this.selectskill, this.cur_skill_grade[this.selectskill] + 1]._cooltime, "txt12_0");
                    GUI.DrawTexture(Crypto.Rect2(268f, 152f, 16f, 16f), this.arrow);
                    GUI.DrawTexture(Crypto.Rect2(200f, 172f, 16f, 16f), this.cost_icon);
                    GUI.Label(Crypto.Rect2(224f, 172f, 48f, 16f), string.Empty + this.ss[this.selectskill, this.cur_skill_grade[this.selectskill] + 1]._price, "txt12_b");
                    if (this.ss[this.selectskill, this.cur_skill_grade[this.selectskill] + 1]._pricekind == 1)
                    {
                        GUI.Label(Crypto.Rect2(180f, 172f, 256f, 16f), Language.intxt[this.language, 350], "txt12_b");
                    }
                }
                else
                {
                    GUI.DrawTexture(Crypto.Rect2(112f, 100f, 256f, 128f), this.pop_blank2);
                    GUI.DrawTexture(Crypto.Rect2(160f, 109f, 160f, 20f), this.titlebase);
                    GUI.Label(Crypto.Rect2(112f, 112f, 256f, 14f), Language.intxt[this.language, this.ss[this.selectskill, 0]._name], "txt12_w");
                    if (this.ss[this.selectskill, this.cur_skill_grade[this.selectskill] + 1]._pricekind == 1)
                    {
                        GUI.Label(Crypto.Rect2(112f, 132f, 256f, 14f), Language.intxt[this.language, 0x5b], "txt12_0");
                        GUI.DrawTexture(Crypto.Rect2(200f, 152f, 16f, 16f), this.cost_icon);
                        GUI.Label(Crypto.Rect2(224f, 152f, 48f, 16f), string.Empty + this.ss[this.selectskill, this.cur_skill_grade[this.selectskill] + 1]._price, "txt12_b");
                        GUI.Label(Crypto.Rect2(112f, 172f, 256f, 16f), Language.intxt[this.language, 350], "txt12_b");
                    }
                    else
                    {
                        GUI.Label(Crypto.Rect2(112f, 152f, 256f, 14f), Language.intxt[this.language, 0x5b], "txt12_0");
                    }
                }
                if (GUI.Button(Crypto.Rect2(170f, 188f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    if (this.ss[this.selectskill, this.cur_skill_grade[this.selectskill] + 1]._pricekind == 1)
                    {
                        if (!Crypto.Property_change(-this.ss[this.selectskill, this.cur_skill_grade[this.selectskill] + 1]._price, true))
                        {
                            this.confirm = 3;
                            return;
                        }
                        this.jade -= this.ss[this.selectskill, this.cur_skill_grade[this.selectskill] + 1]._price;
                        this.cur_skill_grade[this.selectskill]++;
                        PlayerPrefsX.SetIntArray("n22", this.cur_skill_grade);
                        PurchaseLog.LogOn(string.Concat(new object[] { Language.intxt[this.language, 0xea], " (", this.ss[this.selectskill, this.cur_skill_grade[this.selectskill]]._price, ")\t", Language.intxt[this.language, this.ss[this.selectskill, 0]._name] }));
                    }
                    else if (Crypto.Property_change(-this.ss[this.selectskill, this.cur_skill_grade[this.selectskill] + 1]._price, false))
                    {
                        this.coin -= this.ss[this.selectskill, this.cur_skill_grade[this.selectskill] + 1]._price;
                        this.cur_skill_grade[this.selectskill]++;
                        PlayerPrefsX.SetIntArray("n22", this.cur_skill_grade);
                    }
                    else
                    {
                        this.confirm = 2;
                        return;
                    }
                    if (this.tutorial == 0)
                    {
                        this.confirm = 0;
                    }
                    else if (this.cur_skill_grade[this.selectskill] < 0)
                    {
                        if (this.FindEmptySlot() >= 0)
                        {
                            this.confirm = 5;
                        }
                        else
                        {
                            this.confirm = 0;
                        }
                    }
                    else
                    {
                        this.confirm = 0;
                    }
                }
                else if (GUI.Button(Crypto.Rect2(240f, 188f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 2)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                GUI.Label(Crypto.Rect2(120f, 130f, 240f, 16f), Language.intxt[this.language, 0x16], "txt12_0");
                if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    Crypto.Save_int_key("cashshopkind", 2);
                    this.confirm = 0;
                    if (this.cashshop == null)
                    {
                        this.cashshop = Resources.Load("CashShop") as GameObject;
                    }
                    UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
                }
                else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 3)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                GUI.Label(Crypto.Rect2(120f, 130f, 230f, 16f), Language.intxt[this.language, 0x15], "txt12_0");
                if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    Crypto.Save_int_key("cashshopkind", 1);
                    this.confirm = 0;
                    if (this.cashshop == null)
                    {
                        this.cashshop = Resources.Load("CashShop") as GameObject;
                    }
                    UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
                }
                else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 4)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                GUI.Label(Crypto.Rect2(112f, 110f, 256f, 64f), Language.intxt[this.language, 210], "txt12_0");
                if (this.f_delay == 0f)
                {
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 5)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                GUI.Label(Crypto.Rect2(112f, 120f, 256f, 14f), Language.intxt[this.language, 0x5c], "txt12_0");
                if (GUI.Button(Crypto.Rect2(170f, 138f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    this.confirm = 0;
                    this.ShortCut(this.emptyslot);
                }
                else if (GUI.Button(Crypto.Rect2(240f, 138f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 6)
            {
                GUI.Box(Crypto.Rect2(112f, 140f, 256f, 32f), Language.intxt[this.language, 0x62]);
                if (this.f_delay == 0f)
                {
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 7)
            {
                GUI.Box(Crypto.Rect2(112f, 140f, 256f, 32f), Language.intxt[this.language, 0x100]);
                if (this.f_delay == 0f)
                {
                    this.confirm = 0;
                }
            }
        }
        if (this.tutorial == 0)
        {
            if (!this.popupOn)
            {
                GUI.DrawTexture(Crypto.Rect2(24f + this.dragposX, this.icon_posY + 16f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
            }
            else if (!this.showimg)
            {
                if (this.selectskill == 0)
                {
                    if (this.cur_skill_grade[0] >= 0)
                    {
                        GUI.DrawTexture(Crypto.Rect2(432f, 24f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                    }
                    else if (this.confirm == 1)
                    {
                        GUI.DrawTexture(Crypto.Rect2(174f, 174f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                    }
                    else
                    {
                        GUI.DrawTexture(Crypto.Rect2(284f, 142f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                    }
                }
                else if (this.selectskill > 0)
                {
                    this.Delay(1f);
                    this.popupOn = false;
                    this.confirm = 6;
                }
                else
                {
                    GUI.DrawTexture(Crypto.Rect2(24f + this.dragposX, this.icon_posY + 16f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                }
            }
        }
    }

    public void ShortCut(int _index)
    {
        if (this.selectskill == this.skill_slot[_index])
        {
            this.skill_slot[_index] = -1;
            if (this.tutorial == -2)
            {
                this.tutorial = 0;
                Crypto.Save_int_key("tutorial", 0);
            }
        }
        else
        {
            for (int i = 0; i < 5; i++)
            {
                if (this.skill_slot[i] == this.selectskill)
                {
                    this.skill_slot[i] = -1;
                }
            }
            this.skill_slot[_index] = this.selectskill;
            if (this.tutorial == 0)
            {
                this.tutorial = -2;
                Crypto.Save_int_key("tutorial", -2);
                this.Delay(1f);
                this.confirm = 7;
            }
        }
        PlayerPrefsX.SetIntArray("skill_slot", this.skill_slot);
    }

    [DebuggerHidden]
    private IEnumerator ShotLoading(int _index)
    {
        return new <ShotLoading>c__Iterator21 { _index = _index, <$>_index = _index, <>f__this = this };
    }

    private void Start()
    {
        this.skill_slot = PlayerPrefsX.GetIntArray("skill_slot");
        this.chalevel = Crypto.Load_int_key("n47");
        this.dragrange = Screen.height * 0.375f;
        this.language = PlayerPrefs.GetInt("language");
        this.bg_posX_l = -380f;
        this.bg_posX_r = 480f;
        this.icon_posY = 340f;
        this.ss = base.GetComponent<DB_Skill>().ss;
        this.tutorial = Crypto.Load_int_key("tutorial");
        this.cur_skill_grade = PlayerPrefsX.GetIntArray("n22");
        if (GameObject.FindWithTag("sound") == null)
        {
            this.sound_UI = (Transform) UnityEngine.Object.Instantiate(this.sound_dummy, Vector3.zero, Quaternion.identity);
        }
        else
        {
            this.sound_UI = GameObject.FindWithTag("sound").transform;
        }
        if (this.sound_UI != null)
        {
            this.script_soundUI = this.sound_UI.GetComponent<SoundEf_UI>();
        }
        for (int i = 0; i < 20; i++)
        {
            if ((this.cur_skill_grade[i] == -2) && (this.chalevel >= this.ss[i, 0]._requireLV))
            {
                this.cur_skill_grade[i] = -1;
            }
        }
        PlayerPrefsX.SetIntArray("n22", this.cur_skill_grade);
        base.InvokeRepeating("Warning_iconsize", 0.1f, 0.34f);
    }

    private void Update()
    {
        if (this.b_delay)
        {
            this.f_delay -= Time.deltaTime;
            if (this.f_delay <= 0f)
            {
                this.b_delay = false;
                this.f_delay = 0f;
            }
        }
        if (!this.imagemovefinish)
        {
            if (this.bg_posX_l < -64f)
            {
                this.bg_posX_l += Mathf.Min(-this.bg_posX_l, Time.deltaTime * 600f);
            }
            else
            {
                this.bg_posX_l = -64f;
                this.bg_posX_r -= Mathf.Min(this.bg_posX_r, Time.deltaTime * 1500f);
                if (this.bg_posX_r <= 0f)
                {
                    this.bg_posX_r = 0f;
                    this.icon_posY -= Mathf.Min(this.icon_posY, Time.deltaTime * 500f);
                    if (this.icon_posY <= 230f)
                    {
                        this.icon_posY = 230f;
                        this.imagemovefinish = true;
                    }
                }
            }
        }
        if (Input.GetMouseButtonDown(0))
        {
            if (Input.mousePosition.y < this.dragrange)
            {
                this.dragOn = true;
                this.prevposX = Input.mousePosition.x;
                this.currentX = this.dragposX;
            }
        }
        else if (Input.GetMouseButtonUp(0))
        {
            this.dragOn = false;
            this.scrollOn = false;
        }
        if (this.dragOn)
        {
            if (Mathf.Abs((float) (Input.mousePosition.x - this.prevposX)) > 8f)
            {
                this.scrollOn = true;
            }
            this.dragposX = ((Input.mousePosition.x - this.prevposX) * (480f / ((float) Screen.width))) + this.currentX;
            this.dragposX = Mathf.Min(this.dragposX, 0f);
            this.dragposX = Mathf.Max(this.dragposX, -1060f);
        }
    }

    public void UpdateSkillStat(int _skillindex)
    {
        short num = this.ss[_skillindex, 0]._txtkind;
        if (this.cur_skill_grade[_skillindex] < 4)
        {
            switch (num)
            {
                case 1:
                    this.updatestring = Language.intxt[this.language, 0x111];
                    break;

                case 2:
                    this.updatestring = Language.intxt[this.language, 0x61];
                    break;

                default:
                    this.updatestring = Language.intxt[this.language, 0x112];
                    break;
            }
        }
    }

    public void Warning_iconsize()
    {
        this.icon_size = (this.icon_size + 1) % 2;
    }

    [CompilerGenerated]
    private sealed class <ShotLoading>c__Iterator21 : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal int _index;
        internal int <$>_index;
        internal UI_skill <>f__this;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<>f__this.www = new WWW(this.<>f__this.ss_url[this._index]);
                    this.$current = this.<>f__this.www;
                    this.$PC = 1;
                    return true;

                case 1:
                    if (this.<>f__this.www.error == null)
                    {
                        this.<>f__this.ss_skill = this.<>f__this.www.texture;
                    }
                    this.<>f__this.imageloading = true;
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }
}


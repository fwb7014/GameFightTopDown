using System;
using UnityEngine;

public class Language_Costume : MonoBehaviour
{
    public string[,] txt_cos;

    public Language_Costume()
    {
        string[] textArray1 = new string[,] { { 
            "No bonus.", "Dancing Gown", "Long Cloak", "Black Vest", "Iron Plate", "Silver Armor", "Monk's Robe", "Battle Dress", "Aegis", "Samurai", "Karate", "Officer", "Yaksa", "Ritual", "Fisherman", "Pirate", 
            "Summoner", "Gentleman", string.Empty, string.Empty, string.Empty, "No bonus.", "Increases Item effect", "Increases EXP earned", "Increases Atk. Speed", "No Soulstone used", string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, 
            string.Empty, string.Empty, string.Empty, "HP natural recovery", "Captain(Branch: Magic) 0 soulstone consumed when skill is used", "Random skill activates during evasion.", string.Empty, string.Empty, string.Empty, "Swordstaff", "Whiteteeth Spear", "Slashing Sword", "Falchion", "Long Silver Spear", "Royal Blade", "Gongfu Blade", 
            "Fedora", "Naginata", "Iron Halberd", "Scimitar", "Gladius", "Crescent Blade", "Halberd", "Gichun Sword", string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, 
            string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, "Devilish", "Dragon", "Catapult", "Barbs", "Destiny", "Runed Sword", "Deliverer", "Royal Sword", "Rune Sword", 
            "Guardian Sword", "Long Sword", string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, "Adds Fire damage(S)", "Adds Ice damage(S)", "Adds Bolt damage(S)", "Adds Dark damage(S)", "Guard Break(S)", 
            "SP Drain(S)", "Skill Power+7%", string.Empty, string.Empty, string.Empty, "Adds Fire damage(M)", "Adds Ice damage(M)", "Adds Bolt damage(M)", "Adds Dark damage(M)", "Guard Break(M)", "SP Drain(M)", "Skill Power+10%", string.Empty, string.Empty, string.Empty, "Adds Fire damage(L)", 
            "Adds Ice damage(L)", "Adds Bolt damage(L)", "Adds Dark damage(L)", "Guard Break(L)", "SP Drain(L)", "Skill Power+50%", string.Empty, string.Empty, "HP Drain"
         }, { 
            "没有附加能力。", "巫服", "长袍", "黑夜衣", "铁胸甲", "银甲", "骑乘袍", "战斗服", "兵甲", "道袍", "长衫", "官服", "夜叉衣", "礼服", "鱼服", "海盗服", 
            "龙袍", "疑问之服", string.Empty, string.Empty, string.Empty, "没有附加能力.", "增加道具的效果", "增加经验值的获得量", "增加攻速", "灵魂石消耗量 0", string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, 
            string.Empty, string.Empty, string.Empty, "自动恢复生命", "副将(兵戈: 魔法)使用技能时消耗灵魂石0", "回避动作时会随机性的发动技能.", string.Empty, string.Empty, string.Empty, "二狼刀", "白牙矛", "锐刀", "柳叶刀", "十字阴矛", "破天剑", "洪儒烨刀", 
            "蛇矛", "斩马刀", "铁戟", "偃月刀", "蕨手刀", "半月刀", "画戟", "气天剑", string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, 
            string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, "魔神大剑", "琵琶龙珍剑", "黑作大刀", "七指刀", "极云剑", "越王九天剑", "死印剑", "太祖天剑", "前轮魔刀", 
            "明王剑", "长剑", string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, "焰属性 增加(小)", "冰属性 增加(小)", "雷属性 增加(小)", "暗属性 增加(小)", "破坏防御(小)", 
            "SP 吸收(小)", "技能攻击力+7%", string.Empty, string.Empty, string.Empty, "焰属性 增加(中)", "冰属性 增加(中)", "雷属性 增加(中)", "暗属性 增加(中)", "破坏防御(中)", "SP 吸收(中)", "技能攻击力+10%", string.Empty, string.Empty, string.Empty, "焰属性 增加(大)", 
            "冰属性 增加(大)", "雷属性 增加(大)", "暗属性 增加(大)", "破坏防御(大)", "SP 吸收(大)", "技能攻击力+50%", string.Empty, string.Empty, "附加吸血"
         } };
        this.txt_cos = textArray1;
    }
}


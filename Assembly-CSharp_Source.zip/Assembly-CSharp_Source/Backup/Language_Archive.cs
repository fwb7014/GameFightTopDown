using System;
using UnityEngine;

public class Language_Archive : MonoBehaviour
{
    public string[,] txt_arch;

    public Language_Archive()
    {
        string[] textArray1 = new string[,] { { 
            string.Empty, "Freshman", "Sophomore", "Junior", "Senior", "Slayer", "Slayer 2", "Undead Slayer", "Legendary Slayer", "Jujitsu Master 1", "Jujitsu Master 2", "Jujitsu Master 3", "Legendary Jujitsu Master", "Mental Damage", "Enough", "Challenger", 
            "Cool Guy", "Will To Win", "Controller 1", "Controller 2", "Controller 3", "Turncoat's Blood", "Respect Elders", "Macho Man", "Ugly Face", "Broken Spear", "The Bottleneck", "Cruel Barber", "The Falling Star", "The Fall Of The Emperor", "No Country For Zombies", "Horse Lover", 
            "Y U So Tall?", "The Ragged", "Like A Model", "Oppa Gangnam Style", "Lonely", "Where Is My Partner?", "Where Is He?", "Third Time's A Charm", "Scouting God", "Skill Beginner", "You Have Much To Learn", "Combat Ready", "Kill'em With Style", "Skill Master 1", "Skill Master 2", "The Orange Cross", 
            "Home Wrecker", "Barbarian", "I Feel No Pain", "That Is Not From My Mouth", "Unsheathing Master", "New Type", "Give Me Strength, Earthlings", "Walking Poison", "The Hands Of Midas", "Sword Striker", "Volcano", "Rurouni Kenshin", "Come, Monster", "Taming A Dragon", "Heart Breaker", "Yellow Turban Rebellion", 
            "Red Bamboo Forest", "Arrow Rain", "Pyromaniac", "Your First Purchase", "Dear Customer", "I Am The Big Fish Here", "Where Am I?!", "To Infinity!", "They Come In Numbers", "Perfectionist 1", "Perfectionist 2", "Perfectionist 3", "Perfectionist 4", string.Empty, string.Empty, string.Empty, 
            string.Empty, "Clear battlefield one time", "Clear battlefield ten times", "Clear battlefield 30 times", "Clear battlefield 90 times", "Defeat at least 500 foes", "Defeat at least 2,000 foes", "Defeat at least 5,000 foes", "Defeat at least 10,000 foes", "Defeat at least 50 foes with special attacks", "Defeat at least 200 foes with special attacks", "Defeat at least 500 foes with special attacks", "Defeat at least 1,000 foes with special attacks", "Die at least 10 times", "Die at least 100 times", "Resurrect at least 10 times", 
            "Resurrect at least 50 times", "500X times step2 extra attack", "1000X times step2 extra attack", "Perform at least 500 tier 3 EX attacks", "Perform at least 1,000 tier 3 EX attacks", "Defeat Wei Yan at least 5 times", "Defeat Huang Zhong at least 5 times", "Defeat Ma Chao at least 5 times", "Defeat Pang Tong at least 5 times", "Defeat Zhao Yun at least 5 times", "Defeat Zhang Fei at least 5 times", "Defeat Guan Yu at least 5 times", "Defeat Zhuge Liang at least 5 times", "Defeat Liu Bei at least 5 times", "Defeat Lu Bu at least 5 times", "Summon Jeolyeong at least 50 times in combat", 
            "Summon Bronze Sparrow at least 50 times in combat", "Unlock at least 3 costumes", "Unlock at least 5 costumes", "Unlock at least 10 costumes", "Perform Search for Heroes 5 times", "Perform Search for Heroes 20 times", "Perform Search for Heroes 100 times", "Find the highest graded captain with Search for Heroes (once for the first time)", "Find at least 5 captains with rarity of 4 or higher with Search for Heroes", "Learn at least 3 skills", "Learn at least 5 skills", "Learn at least 10 skills", "Learn at least 20 skills", "Fully upgrade at least 5 skills", "Fully upgrade at least 10 skills", "Use Sword Wave at least 100 times", 
            "Use Shockwave at least 100 times", "Use Spinning Slash at least 100 times", "Use Defensive Stance at least 100 times", "Use Shadow Blade at least 100 times", "Use Charging Slash at least 100 times", "Use Icicle Shards at least 100 times", "Use Aggression at least 100 times", "Use Poison Cloud at least 100 times", "Use Quivering Palm at least 100 times", "Use Vacuum Sword at least 100 times", "Use Hellfire at least 100 times", "Use Teleport Attack at least 100 times", "Use Summon Dian Wei at least 100 times", "Use Summon Zhou Yu at least 100 times", "Use Summon Diaochan at least 100 times", "Use Tranquility at least 100 times", 
            "Use Bamboo Spears at least 100 times", "Use Rain of Swords at least 100 times", "Use Red Hare's Wings at least 100 times", "Spend at least $1 to buy jade", "Spend at least $30 to buy jade", "Complete all achievements", "Enter an unlimited dungeon one time", "Entered sealed cave 10 times", "Entered sealed cave 50 times", "Create a 3-star battlefield", "Create 10 3-star battlefields", "Create 30 3-star battlefields", "Create 90 3-star battlefields"
         }, { 
            string.Empty, "新手", "初级", "中级", "高级", "百人斩", "千人斩", "超级千人斩", "万人斩", "特殊攻击", "特殊攻击百人斩", "超级特殊攻击", "特殊攻击千人斩", "死亡者", "超级死亡者", "复活者", 
            "复活达人", "超级复活者", "2阶段攻击", "2阶段攻击达人", "超级2阶段攻击", "叛徒的血", "尊敬老人", "猛男", "对不起，长得太丑了", "断掉的枪", "长板桥之魂", "走麦城", "五丈原的落星", "白帝城托孤", "白门楼", "风驰电掣", 
            "神乎万唤", "服装解禁", "服装解禁2", "超级服装解禁", "人物搜索", "搜索达人", "疯狂搜索", "三顾草庐", "选拔之神", "技能新手", "技能人", "技能师", "技能达人", "强化技能", "强化技能1", "红十字", 
            "破裂斩", "回旋斩烈", "金刚不死", "无影神技", "转魂崩裂", "冰雅神技", "贵人狂花", "毒.毒雾环绕", "点金手", "超级伏魔刀", "火山", "风的剑神", "暴力怪", "水龙狂涛", "连环计 ", "黄巾贼之乱", 
            "红竹林", "火箭雨", "爆马", "突破千元.", "突破万元。", "挑战达人", "这是哪里？！", "无限挑战", "极限挑战", "完美过关战场1", "完美过关战场2", "完美过关战场3", "完美过关战场4", string.Empty, string.Empty, string.Empty, 
            string.Empty, "通过1个战场", "通过10个战场", "通过30个战场", "通过90个战场", "击杀敌人500名以上。", "击杀敌人2000名以上", "击杀敌人5000名以上", "击杀敌人10000名以上", "用特殊攻击击杀敌人50名以上", "用特殊攻击击杀敌人200名以上", "用特殊攻击击杀敌人500名以上", "用特殊攻击击杀敌人1000名以上", "死亡次数10次以上", "死亡次数100次以上", "复活次数10次以上", 
            "复活次数50次以上", "复活次数100次以上", "进行2阶段ex攻击 100次以上", "进行2阶段ex攻击 500次以上", "进行2阶段ex攻击 1000次以上", "击杀魏延5次以上", "击杀黄忠5次以上", "击杀马超5次以上", "击杀庞统5次以上", "击杀赵云5次以上", "击杀张飞5次以上", "击杀关羽5次以上", "击杀诸葛亮5次以上", "击杀刘备5次以上", "击杀吕布5次以上", "战斗中召唤绝影50次以上", 
            "战斗中召唤动作50次以上", "解禁服装3个以上", "解禁服装5个以上", "解禁服装10个以上", "人物搜索5次", "人物搜索20次", "人物搜索100次", "通过人物搜索获得最高级副将(最初1次)", "通过人物搜索获得稀有度4级以上的副将5次以上", "持有技能3个以上", "持有技能5个以上", "持有技能10个以上", "持有技能20个以上", "强化技能最多5个以上", "强化技能最多10个以上", "使用闪钢剑技能100次以上", 
            "使用破裂剑技能100次以上", "使用回转斩技能100次以上", "使用金刚护体技能100次以上", "使用无影岛技能100次以上", "使用转魂斩技能100次以上", "使用冰雅七巧技能100次以上", "使用贵人花技能100次以上", "使用毒雾剑技能100次以上", "使用冰白镜匠技能100次以上", "使用魔刀斩技能100次以上", "使用超裂地狱技能100次以上", "使用神奇之剑技能100次以上", "使用贵将典韦技能100次以上", "使用水龙周瑜技能100次以上", "使用极影貂蝉技能100次以上", "使用太平妖术技能100次以上", 
            "使用竹天枪技能100次以上", "使用天空雨剑技能100次以上", "使用赤土之翼技能100次以上", "充值1$以上曲玉。", "充值30$以上曲玉。", "完成所有挑战", "进入无限副本1次", "进入10次封印之洞", "进入50次封印之洞", "建立3星级战场1个", "建立3星级战场10个", "建立3星级战场30个", "建立3星级战场90个"
         } };
        this.txt_arch = textArray1;
    }
}


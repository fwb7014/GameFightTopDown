using System;
using UnityEngine;

public class ImageNumber : MonoBehaviour
{
    private int finalnum;
    private Vector2 imagenumber;
    private Vector2[] imagesetUV = new Vector2[] { new Vector2(0f, 0.875f), new Vector2(0.125f, 0.875f), new Vector2(0.25f, 0.875f), new Vector2(0.375f, 0.875f), new Vector2(0.5f, 0.875f), new Vector2(0f, 0.75f), new Vector2(0.125f, 0.75f), new Vector2(0.25f, 0.75f), new Vector2(0.375f, 0.75f), new Vector2(0.5f, 0.75f), new Vector2(0.625f, 0.875f) };
    public int[] number = new int[3];
    private const int NUMBERSCALE = 3;
    private short size_a;
    private Mesh thismesh;

    public void ImageNum(int _num, int _digit, int _imagekind)
    {
        this.thismesh = base.GetComponent<MeshFilter>().mesh;
        this.size_a = 0;
        for (int i = 0; i < 3; i++)
        {
            this.number[i] = _num % 10;
            _num /= 10;
            if (_num != 0)
            {
                this.size_a = (short) (this.size_a + 1);
            }
        }
        this.finalnum = this.number[_digit];
        this.imagenumber = this.imagesetUV[this.finalnum];
        if (((_num != 0) || (_digit != 0)) && ((_digit >= this.size_a) && (this.finalnum == 0)))
        {
            this.imagenumber = this.imagesetUV[10];
        }
        switch (_imagekind)
        {
            case 0:
                this.thismesh.uv = new Vector2[] { this.imagenumber + (Vector2.up * 0.125f), this.imagenumber + (Vector2.one * 0.125f), this.imagenumber, this.imagenumber + (Vector2.right * 0.125f) };
                break;

            case 1:
                this.thismesh.uv = new Vector2[] { ((this.imagenumber * 0.5f) + (Vector2.up * 0.0625f)) + (Vector2.up * 0.25f), ((this.imagenumber * 0.5f) + (Vector2.one * 0.0625f)) + (Vector2.up * 0.25f), (this.imagenumber * 0.5f) + (Vector2.up * 0.25f), ((this.imagenumber * 0.5f) + (Vector2.right * 0.0625f)) + (Vector2.up * 0.25f) };
                break;
        }
    }

    private void Start()
    {
    }
}


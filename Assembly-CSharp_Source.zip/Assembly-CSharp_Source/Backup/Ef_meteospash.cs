using System;
using UnityEngine;

public class Ef_meteospash : MonoBehaviour
{
    private float currenttime;
    private int framesPerSecond = 0x16;
    private float index;
    private int lastframe;
    private float starttime;
    private int uvAnimationTileX = 4;
    private int uvAnimationTileY = 4;
    private int var;

    private void Start()
    {
        this.starttime = Time.time;
        this.currenttime = Time.time;
        this.lastframe = this.uvAnimationTileX * this.uvAnimationTileY;
        base.transform.localScale = new Vector3(1.3f, 1.3f, 1.3f);
        base.transform.parent = GameObject.Find("SkillEf").transform;
        base.collider.isTrigger = true;
        base.renderer.enabled = true;
    }

    private void Update()
    {
        if (base.renderer.enabled)
        {
            if (base.transform.localScale.x < 3.5f)
            {
                Transform transform = base.transform;
                transform.localScale += (Vector3) (new Vector3(1f, 1f, 1f) * Time.deltaTime);
            }
            this.currenttime = Time.time - this.starttime;
            this.index = this.currenttime * this.framesPerSecond;
            this.index = (int) (this.index % ((float) this.lastframe));
            this.var -= (int) this.index;
            Vector2 scale = new Vector2(1f / ((float) this.uvAnimationTileX), 1f / ((float) this.uvAnimationTileY));
            float num = this.index % ((float) this.uvAnimationTileX);
            int num2 = ((int) this.index) / this.uvAnimationTileX;
            Vector2 offset = new Vector2(num * scale.x, (1f - scale.y) - (num2 * scale.y));
            if ((this.index == 0f) && (this.var != 0))
            {
                base.renderer.enabled = false;
                base.transform.localScale = new Vector3(0f, 0f, 0f);
                this.var = 0;
                base.collider.isTrigger = false;
            }
            base.renderer.material.SetTextureOffset("_MainTex", offset);
            base.renderer.material.SetTextureScale("_MainTex", scale);
        }
    }
}


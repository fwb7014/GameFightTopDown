using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct petset
{
    public short _grade;
    public short _info;
    public short _attackpoint;
    public short _price;
    public short _passive;
    public float _duration;
}


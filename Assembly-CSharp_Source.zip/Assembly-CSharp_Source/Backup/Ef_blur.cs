using System;
using UnityEngine;

public class Ef_blur : MonoBehaviour
{
    private Material mymat;

    private void Awake()
    {
        this.mymat = base.renderer.sharedMaterial;
        this.mymat.mainTextureOffset = Vector2.zero;
        base.gameObject.active = false;
    }

    private void Update()
    {
        if (this.mymat.mainTextureOffset.y > -1f)
        {
            this.mymat.mainTextureOffset -= (Vector2) ((Vector2.up * Time.deltaTime) * 2f);
        }
        else
        {
            this.mymat.mainTextureOffset = Vector2.zero;
            base.gameObject.active = false;
        }
    }
}


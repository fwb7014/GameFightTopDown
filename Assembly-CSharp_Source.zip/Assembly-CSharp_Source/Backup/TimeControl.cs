using System;
using UnityEngine;

public static class TimeControl
{
    public static TimeSpan difference;
    private const int MAXWORK = 2;
    public static DateTime servertime;
    public static string[] string_starttime = new string[2];
    public static DateTime[] work_starttime = new DateTime[2];

    public static void EraseAll()
    {
        string_starttime = new string[2];
        work_starttime = new DateTime[2];
        for (int i = 0; i < 2; i++)
        {
            DateTime time = new DateTime();
            if (servertime == time)
            {
                work_starttime[i] = DateTime.UtcNow;
            }
            else
            {
                work_starttime[i] = servertime;
            }
            string_starttime[i] = work_starttime[i].ToBinary().ToString();
        }
        PlayerPrefsX.SetStringArray("n60", string_starttime);
    }

    private static void GameQuit()
    {
        for (int i = 0; i < 2; i++)
        {
            string_starttime[i] = work_starttime[i].ToBinary().ToString();
        }
        PlayerPrefsX.SetStringArray("n60", string_starttime);
    }

    public static void InitStart()
    {
        string_starttime = PlayerPrefsX.GetStringArray("n60");
        long[] numArray = new long[2];
        for (int i = 0; i < 2; i++)
        {
            try
            {
                numArray[i] = Convert.ToInt64(string_starttime[i]);
                work_starttime[i] = DateTime.FromBinary(numArray[i]);
            }
            catch (IndexOutOfRangeException)
            {
                work_starttime[i] = DateTime.Now;
            }
        }
    }

    public static void RequestServerTime()
    {
        servertime = DateTime.Now;
    }

    public static void SetDelay(int _index)
    {
        if (servertime != new DateTime())
        {
            work_starttime[_index] = servertime;
            string_starttime[_index] = work_starttime[_index].ToBinary().ToString();
            PlayerPrefsX.SetStringArray("n60", string_starttime);
        }
    }

    public static void SetRemain(int _index)
    {
        int[] intArray = new int[] { _index };
        PlayerPrefsX.SetIntArray("n51", intArray);
    }

    public static int SubtractDelay(int _index)
    {
        if (servertime == new DateTime())
        {
            return 0;
        }
        difference = servertime.Subtract(work_starttime[_index]);
        int totalMinutes = 0;
        totalMinutes = (int) difference.TotalMinutes;
        return Mathf.Clamp(totalMinutes, 0, 0x2710);
    }
}


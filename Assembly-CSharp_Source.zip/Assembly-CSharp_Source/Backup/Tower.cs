using System;
using UnityEngine;

public class Tower : MonoBehaviour
{
    public Transform arrow;
    private Vector3 arrowdir;
    private Transform c_arrow;
    private short cur_stage_index;
    private Collider mycollider;
    private Transform mytransform;
    private float reload_delay;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == 15)
        {
            this.mycollider.enabled = false;
            this.arrowdir = other.transform.position - this.mytransform.position;
            this.c_arrow.position = this.mytransform.position;
            this.c_arrow.rotation = Quaternion.LookRotation(this.arrowdir);
            this.c_arrow.gameObject.active = true;
            this.arrowdir[1] = 0f;
            this.mytransform.rotation = Quaternion.LookRotation(this.arrowdir);
            this.reload_delay = 2f;
        }
    }

    private void Start()
    {
        this.cur_stage_index = (short) Crypto.Load_int_key("cur_stage_index");
        this.c_arrow = (Transform) UnityEngine.Object.Instantiate(this.arrow, this.mytransform.position, Quaternion.identity);
        this.c_arrow.GetComponent<WeaponDamage>().PressDamage(this.cur_stage_index + 1);
    }

    private void Update()
    {
        if (this.reload_delay > 0f)
        {
            this.reload_delay -= Time.deltaTime;
            if (this.reload_delay < 0f)
            {
                this.reload_delay = 0f;
                this.mycollider.enabled = true;
            }
        }
    }
}


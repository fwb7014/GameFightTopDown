using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class Cha_Skill : MonoBehaviour
{
    public Transform bamboo;
    public Transform bamboobase;
    private float basedamage = 1f;
    public Transform bombsphere;
    private Transform[] c_bamboo = new Transform[3];
    private Transform c_bamboobase;
    private Transform c_bombsphere;
    private Transform c_chosun;
    private Transform c_crow;
    private Transform c_defenceup;
    private Transform c_dragonhead;
    private Transform c_energypillar;
    private Transform c_fincanon;
    private Transform[] c_generalskill = new Transform[7];
    private Transform c_groundbreak;
    private Transform c_hand;
    private Transform c_icespear;
    private Transform c_junwui;
    private Transform c_lightningblade;
    private Transform c_poison;
    private Transform c_rapidstab;
    private Transform c_supersword;
    private Transform c_sworddance;
    private Transform c_swordrain;
    private Transform c_swordrain_b;
    private Transform c_swordrain_s;
    private Transform c_swordwind;
    private Transform c_wheelwind;
    private Transform c_wing;
    private float castingdelay;
    public Transform chosun;
    public Transform crow;
    private int[] cur_skill_grade = new int[20];
    private float currentdelay = 10f;
    public Transform deathhand;
    private Transform directionArrow;
    public Transform dragonhead;
    public Transform ef_gather;
    public Transform ef_groundbreak;
    public Transform ef_rotfog;
    public Transform energypillar;
    public Transform fincanon;
    private short g_motionkind;
    private short g_skillatk;
    public Transform jin;
    public Transform junwui;
    public Transform lightningblade;
    private GameObject load_skobj;
    private const int MAXSKILL = 20;
    public Transform meteo;
    private short motionkind;
    private Animation myanimation;
    private Transform mytransform;
    public Transform pt_attackup;
    public Transform pt_boom;
    public Transform pt_defenceup;
    private Transform pt_ki;
    private float pt_off_delay = 10f;
    public Transform pt_poison;
    private Transform r_hand;
    public Transform rapidstab;
    private bool repeat;
    private float repeatatk;
    private float repeatdelay;
    private int repeatkind;
    private int repeattime;
    private Vector3 rndpos;
    private Cam_Move script_cam;
    private Cha_Control script_cha1;
    private Cha_Costume script_costume;
    private DB_Skill script_DBskill;
    private Ef_rotfog script_rotfog;
    private int skill_index = -1;
    private float skillatk;
    public AudioClip snd_jin;
    public Transform supersword;
    public Transform sworddance;
    public Transform swordrain;
    public Transform swordrain_b;
    public Transform swordrain_s;
    public Transform swordwind;
    private AnimationState temp;
    private float tempradian;
    public Transform wheelwind;
    public Transform wing;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myanimation = base.animation;
    }

    [DebuggerHidden]
    public IEnumerator BambooFin()
    {
        return new <BambooFin>c__IteratorC { <>f__this = this };
    }

    public void BoomOn(int _index, bool _collider)
    {
        this.pt_boom.GetComponent<Ef_boom>().SetTex(_index, this.mytransform.position, _collider);
    }

    public void DelaySkill(int _index)
    {
        if (this.c_groundbreak == null)
        {
            this.c_groundbreak = (Transform) UnityEngine.Object.Instantiate(this.ef_groundbreak, this.mytransform.position, Quaternion.identity);
        }
        else
        {
            this.c_groundbreak.position = this.mytransform.position;
            this.c_groundbreak.gameObject.active = true;
        }
        this.c_groundbreak.rigidbody.mass = (this.skillatk * this.basedamage) * 0.01f;
        switch (_index)
        {
            case 2:
                this.c_groundbreak.localScale = (Vector3) (Vector3.one * 0.5f);
                this.script_cam.Hitcam2(2f);
                break;

            case 0x13:
                this.c_groundbreak.localScale = (Vector3) (Vector3.one * 1f);
                this.script_cam.Hitcam2(4f);
                Time.timeScale = 0.6f;
                base.StartCoroutine(this.ResetTimeScale());
                this.c_bombsphere = (Transform) UnityEngine.Object.Instantiate(this.bombsphere, this.mytransform.position, Quaternion.identity);
                UnityEngine.Object.Destroy(this.c_bombsphere.gameObject, 1.2f);
                break;
        }
    }

    public void LaunchSkill(int index)
    {
        base.audio.PlayOneShot(this.snd_jin);
        this.pt_ki.particleEmitter.emit = false;
        switch (index)
        {
            case 0:
                this.myanimation.Play("skill01");
                if (this.c_swordwind != null)
                {
                    this.c_swordwind.gameObject.active = true;
                    this.c_swordwind.position = this.mytransform.position;
                    this.c_swordwind.rotation = this.mytransform.rotation;
                }
                else
                {
                    this.c_swordwind = (Transform) UnityEngine.Object.Instantiate(this.swordwind, this.mytransform.position, this.mytransform.rotation);
                    this.c_swordwind.rigidbody.mass = (this.skillatk * this.basedamage) * 0.01f;
                }
                goto Label_2606;

            case 1:
                this.myanimation.Play("jumpattack_air");
                this.myanimation.PlayQueued("jumpattack_impact").speed = 0.25f;
                goto Label_2606;

            case 2:
                this.myanimation.Play("wheelwind");
                if (this.c_wheelwind != null)
                {
                    this.c_wheelwind.gameObject.active = true;
                }
                else
                {
                    this.c_wheelwind = (Transform) UnityEngine.Object.Instantiate(this.wheelwind, this.mytransform.position + ((Vector3) (Vector3.up * 0.1f)), Quaternion.Euler(180f, 0f, 0f));
                    this.c_wheelwind.rigidbody.mass = (this.skillatk * this.basedamage) * 0.01f;
                    this.c_wheelwind.parent = this.mytransform;
                }
                goto Label_2606;

            case 3:
                this.myanimation.Play("skill03");
                if (this.c_defenceup != null)
                {
                    base.CancelInvoke("Sk_DefenceUp");
                    break;
                }
                this.c_defenceup = (Transform) UnityEngine.Object.Instantiate(this.pt_defenceup, this.mytransform.position, Quaternion.identity);
                break;

            case 4:
                this.myanimation.Play("rapidstab");
                if (this.c_rapidstab != null)
                {
                    this.c_rapidstab.gameObject.active = true;
                    this.c_rapidstab.position = (Vector3) ((this.mytransform.position + (this.mytransform.forward * 0.25f)) + (Vector3.up * 0.04f));
                    this.c_rapidstab.rotation = this.mytransform.rotation;
                }
                else
                {
                    this.c_rapidstab = (Transform) UnityEngine.Object.Instantiate(this.rapidstab, (Vector3) ((this.mytransform.position + (this.mytransform.forward * 0.25f)) + (Vector3.up * 0.04f)), this.mytransform.rotation);
                    this.c_rapidstab.rigidbody.mass = (this.skillatk * this.basedamage) * 0.01f;
                }
                goto Label_2606;

            case 5:
                this.myanimation["attackex3"].speed = 0.35f;
                this.myanimation.Play("attackex3");
                this.temp = this.myanimation.PlayQueued("attackex3_impact");
                this.temp.speed = 0.25f;
                if (this.c_lightningblade != null)
                {
                    this.c_lightningblade.gameObject.active = true;
                }
                else
                {
                    this.c_lightningblade = (Transform) UnityEngine.Object.Instantiate(this.lightningblade, this.mytransform.position + ((Vector3) (Vector3.up * 0.05f)), this.mytransform.rotation);
                    this.c_lightningblade.parent = this.mytransform;
                    this.c_lightningblade.rigidbody.mass = (this.skillatk * this.basedamage) * 0.01f;
                }
                goto Label_2606;

            case 6:
                this.myanimation.Play("skill03");
                if (this.c_icespear != null)
                {
                    this.c_icespear.GetComponent<SpiritSword>().Init();
                    this.c_icespear.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.2f));
                    this.c_icespear.rotation = this.mytransform.rotation;
                    this.c_icespear.gameObject.active = true;
                }
                else
                {
                    this.c_icespear = (Transform) UnityEngine.Object.Instantiate(this.meteo, this.mytransform.position + ((Vector3) (Vector3.up * 0.2f)), this.mytransform.rotation);
                    this.c_icespear.rigidbody.mass = (this.skillatk * this.basedamage) * 0.01f;
                }
                goto Label_2606;

            case 7:
            {
                this.myanimation.Play("skill03");
                ParticleEmitter particleEmitter = this.pt_attackup.particleEmitter;
                if (particleEmitter.emit)
                {
                    base.CancelInvoke("Sk_AttackUp");
                }
                else
                {
                    particleEmitter.emit = true;
                }
                this.pt_boom.GetComponent<Ef_boom>().SetTex(0, this.mytransform.position, true);
                this.script_cha1.AttakUp(1.5f);
                base.Invoke("Sk_AttackUp", this.skillatk);
                goto Label_2606;
            }
            case 8:
                this.myanimation.Play("skill02");
                this.c_poison = (Transform) UnityEngine.Object.Instantiate(this.pt_poison, this.mytransform.position + ((Vector3) (Vector3.up * 0.22f)), Quaternion.identity);
                this.c_poison.rigidbody.mass = (this.skillatk * this.basedamage) * 0.01f;
                if (this.c_poison.rigidbody.mass < 1f)
                {
                    this.c_poison.rigidbody.mass = 1f;
                }
                this.c_poison.parent = this.mytransform;
                goto Label_2606;

            case 9:
                this.myanimation.Play("skill04");
                if (this.c_hand != null)
                {
                    this.c_hand.gameObject.active = true;
                }
                else
                {
                    this.c_hand = (Transform) UnityEngine.Object.Instantiate(this.deathhand, this.mytransform.position + ((Vector3) (Vector3.up * 0.05f)), this.mytransform.rotation);
                    this.c_hand.rigidbody.mass = this.skillatk;
                    this.c_hand.parent = this.mytransform;
                }
                goto Label_2606;

            case 10:
                this.myanimation.Play("skill_chargesmash");
                if (this.c_supersword != null)
                {
                    this.c_supersword.gameObject.active = true;
                }
                else
                {
                    this.c_supersword = (Transform) UnityEngine.Object.Instantiate(this.supersword, this.r_hand.position, this.r_hand.rotation);
                    this.c_supersword.up = this.r_hand.forward;
                    this.c_supersword.parent = this.r_hand;
                    this.c_supersword.rigidbody.mass = (this.skillatk * this.basedamage) * 0.01f;
                }
                goto Label_2606;

            case 11:
                this.script_cha1.Invincibility(5f);
                this.myanimation.Play("skill03");
                this.repeatatk = (this.skillatk * this.basedamage) * 0.01f;
                this.Repeatskill(this.skill_index, 5, 0.8f);
                goto Label_2606;

            case 12:
                this.myanimation.Play("skill01");
                if (this.c_sworddance != null)
                {
                    this.c_sworddance.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.05f));
                    this.c_sworddance.rotation = Quaternion.LookRotation(-this.mytransform.forward + this.mytransform.right);
                    this.c_sworddance.gameObject.active = true;
                }
                else
                {
                    this.c_sworddance = (Transform) UnityEngine.Object.Instantiate(this.sworddance, this.mytransform.position + ((Vector3) (Vector3.up * 0.05f)), Quaternion.LookRotation(-this.mytransform.forward + this.mytransform.right));
                    this.c_sworddance.rigidbody.mass = (this.skillatk * this.basedamage) * 0.01f;
                }
                base.StartCoroutine(this.Sk_SwordDance());
                this.script_costume.Disappear();
                this.script_cha1.StopControl();
                goto Label_2606;

            case 13:
                this.myanimation.Play("skill03");
                this.script_cha1.Invincibility(4f);
                if (this.c_junwui != null)
                {
                    this.c_junwui.gameObject.active = false;
                    this.c_junwui.gameObject.active = true;
                    this.c_junwui.position = this.mytransform.position + ((Vector3) (this.mytransform.forward * 0.2f));
                    this.c_junwui.rotation = this.mytransform.rotation;
                }
                else
                {
                    this.c_junwui = (Transform) UnityEngine.Object.Instantiate(this.junwui, this.mytransform.position + ((Vector3) (this.mytransform.forward * 0.2f)), this.mytransform.rotation);
                    this.c_junwui.GetComponent<Junwui>().SetDamage((this.skillatk * this.basedamage) * 0.01f);
                }
                this.script_cam.LookTarget(this.c_junwui, 0x19, 0.7f);
                goto Label_2606;

            case 14:
                this.myanimation.Play("skill04");
                this.script_cha1.Invincibility(4f);
                if (this.c_dragonhead != null)
                {
                    this.c_dragonhead.rigidbody.mass = (this.skillatk * this.basedamage) * 0.01f;
                    this.c_dragonhead.gameObject.active = true;
                    this.c_dragonhead.position = this.mytransform.position - ((Vector3) (this.mytransform.forward * 0.2f));
                    this.c_dragonhead.rotation = this.mytransform.rotation;
                }
                else
                {
                    this.c_dragonhead = (Transform) UnityEngine.Object.Instantiate(this.dragonhead, this.mytransform.position - ((Vector3) (this.mytransform.forward * 0.2f)), this.mytransform.rotation);
                    this.c_dragonhead.rigidbody.mass = (this.skillatk * this.basedamage) * 0.01f;
                }
                goto Label_2606;

            case 15:
                this.myanimation.Play("skill03");
                this.script_cha1.Invincibility(4f);
                if (this.c_chosun != null)
                {
                    this.c_chosun.gameObject.active = false;
                    this.c_chosun.gameObject.active = true;
                    this.c_chosun.position = this.mytransform.position + ((Vector3) (this.mytransform.forward * 0.2f));
                    this.c_chosun.rotation = this.chosun.localRotation;
                }
                else
                {
                    this.c_chosun = (Transform) UnityEngine.Object.Instantiate(this.chosun, this.mytransform.position + ((Vector3) (this.mytransform.forward * 0.2f)), this.chosun.localRotation);
                    this.c_chosun.rigidbody.mass = (this.skillatk * this.basedamage) * 0.01f;
                }
                this.script_cam.LookTarget(this.c_chosun, 0x1c, 0.5f);
                goto Label_2606;

            case 0x10:
                this.myanimation.Play("skill03");
                this.temp = this.myanimation.PlayQueued("skill03");
                this.temp.speed = 0.2f;
                goto Label_2606;

            case 0x11:
                if (this.c_crow != null)
                {
                    this.c_crow.position = (Vector3) ((this.mytransform.forward * 0.35f) + (Vector3.up * 0.3f));
                    this.c_bamboobase.position = (Vector3) ((this.mytransform.forward * 0.35f) + (Vector3.up * 0.01f));
                    this.c_crow.rotation = this.mytransform.rotation;
                    this.c_bamboobase.rotation = this.mytransform.rotation;
                }
                else
                {
                    this.c_crow = (Transform) UnityEngine.Object.Instantiate(this.crow, (Vector3) ((this.mytransform.position + (this.mytransform.forward * 0.35f)) + (Vector3.up * 0.3f)), this.mytransform.rotation);
                    this.c_bamboobase = (Transform) UnityEngine.Object.Instantiate(this.bamboobase, (Vector3) ((this.mytransform.position + (this.mytransform.forward * 0.35f)) + (Vector3.up * 0.01f)), this.mytransform.rotation);
                }
                this.myanimation.Play("skill03");
                this.repeatatk = (this.skillatk * this.basedamage) * 0.01f;
                this.Repeatskill(this.skill_index, 3, 0.2f);
                base.StartCoroutine(this.BambooFin());
                goto Label_2606;

            case 0x12:
                this.myanimation.Play("skill03");
                if (this.c_swordrain_s != null)
                {
                    this.c_swordrain_s.gameObject.active = true;
                    this.c_swordrain_s.position = this.mytransform.position;
                    this.c_swordrain.gameObject.active = true;
                    this.c_swordrain.position = this.mytransform.position + ((Vector3) (Vector3.up * 1f));
                    this.c_swordrain.rotation = this.mytransform.rotation;
                    this.c_swordrain_b.gameObject.active = true;
                    this.c_swordrain_b.position = this.mytransform.position + ((Vector3) (Vector3.up * -0.1f));
                    this.c_swordrain_b.rotation = this.mytransform.rotation;
                }
                else
                {
                    this.c_swordrain_s = (Transform) UnityEngine.Object.Instantiate(this.swordrain_s, this.mytransform.position, Quaternion.identity);
                    this.c_swordrain = (Transform) UnityEngine.Object.Instantiate(this.swordrain, this.mytransform.position + ((Vector3) (Vector3.up * 1f)), this.mytransform.rotation);
                    this.c_swordrain_b = (Transform) UnityEngine.Object.Instantiate(this.swordrain_b, this.mytransform.position + ((Vector3) (Vector3.up * -0.1f)), this.mytransform.rotation);
                    this.c_swordrain_b.rigidbody.mass = (this.skillatk * this.basedamage) * 0.01f;
                }
                goto Label_2606;

            case 0x13:
                this.myanimation.Play("wing");
                this.temp = this.myanimation.PlayQueued("wing_i");
                this.temp.speed = 0.2f;
                goto Label_2606;

            case 0x15:
                this.myanimation.Play("skill03");
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].position = this.mytransform.position + ((Vector3) (Vector3.up * 0.2f));
                    this.c_generalskill[0].rotation = this.mytransform.rotation;
                    this.c_generalskill[0].gameObject.active = true;
                }
                else
                {
                    this.load_skobj = Resources.Load("general_spiritsword") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, this.mytransform.position + ((Vector3) (Vector3.up * 0.2f)), this.mytransform.rotation);
                    this.c_generalskill[0].rigidbody.mass = this.skillatk;
                }
                goto Label_2606;

            case 0x16:
                this.myanimation.Play("skill_chargesmash");
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].gameObject.active = true;
                    this.c_generalskill[0].GetChild(0).particleEmitter.emit = true;
                }
                else
                {
                    this.load_skobj = Resources.Load("general_spinaxe") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, this.r_hand.position + ((Vector3) (this.r_hand.forward * 0.2f)), this.r_hand.rotation);
                    this.c_generalskill[0].parent = this.r_hand;
                    this.c_generalskill[0].rigidbody.mass = this.skillatk;
                }
                this.pt_off_delay = 2.5f;
                base.StartCoroutine(this.Pt_Off(this.c_generalskill[0].GetChild(0)));
                goto Label_2606;

            case 0x17:
                this.myanimation.Play("skill03");
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].position = this.mytransform.position + ((Vector3) (Vector3.up * 0.1f));
                    this.c_generalskill[0].gameObject.active = true;
                }
                else
                {
                    this.load_skobj = Resources.Load("general_fly") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, this.mytransform.position + ((Vector3) (Vector3.up * 0.1f)), Quaternion.identity);
                }
                goto Label_2606;

            case 0x18:
                this.myanimation.Play("skill03");
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].position = this.mytransform.position;
                    this.c_generalskill[0].rotation = this.mytransform.rotation;
                    this.c_generalskill[0].gameObject.active = true;
                }
                else
                {
                    this.load_skobj = Resources.Load("general_sister") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, this.mytransform.position, this.mytransform.rotation);
                    this.c_generalskill[0].rigidbody.mass = this.skillatk;
                }
                goto Label_2606;

            case 0x19:
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].particleEmitter.emit = true;
                    this.c_generalskill[0].position = (Vector3) ((this.mytransform.position + (this.mytransform.forward * 0.15f)) + (Vector3.up * 0.01f));
                    this.c_generalskill[0].rotation = this.mytransform.rotation;
                }
                else
                {
                    this.load_skobj = Resources.Load("general_ice_spear") as GameObject;
                    GameObject obj2 = Resources.Load("general_icebg") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(obj2.transform, (Vector3) ((this.mytransform.position + (this.mytransform.forward * 0.15f)) + (Vector3.up * 0.01f)), this.mytransform.rotation);
                }
                this.myanimation.Play("skill03");
                this.repeatatk = this.skillatk;
                this.pt_off_delay = 6f;
                base.StartCoroutine(this.Pt_Off(this.c_generalskill[0]));
                this.Repeatskill(this.skill_index, 5, 0.12f);
                goto Label_2606;

            case 0x1a:
                this.myanimation.Play("skill03");
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].gameObject.active = true;
                    this.c_generalskill[0].position = this.mytransform.position;
                }
                else
                {
                    this.load_skobj = Resources.Load("general_sworddance") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, this.mytransform.position, Quaternion.identity);
                    this.c_generalskill[0].rigidbody.mass = this.skillatk;
                }
                goto Label_2606;

            case 0x1b:
                this.myanimation.Play("wheelwind");
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].position = this.mytransform.position;
                    this.c_generalskill[0].gameObject.active = true;
                }
                else
                {
                    this.load_skobj = Resources.Load("general_axedance") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, this.mytransform.position, this.mytransform.rotation);
                    this.c_generalskill[0].rigidbody.mass = this.skillatk;
                }
                goto Label_2606;

            case 0x1c:
                this.myanimation.Play("skill04");
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].gameObject.active = true;
                    this.c_generalskill[0].position = (Vector3) ((this.mytransform.position + (Vector3.up * 1f)) - (this.mytransform.forward * 0.7f));
                    this.c_generalskill[0].rotation = this.mytransform.rotation;
                    this.c_generalskill[1].gameObject.active = true;
                    this.c_generalskill[1].position = (Vector3) ((this.mytransform.position + (Vector3.up * -0.03f)) + (this.mytransform.forward * 0.35f));
                    this.c_generalskill[1].rotation = this.mytransform.rotation;
                }
                else
                {
                    this.load_skobj = Resources.Load("general_arrowrain") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, (Vector3) ((this.mytransform.position + (Vector3.up * 1f)) - (this.mytransform.forward * 0.7f)), this.mytransform.rotation);
                    this.c_generalskill[0].parent = this.mytransform;
                    this.load_skobj = Resources.Load("general_arrowrain_base") as GameObject;
                    this.c_generalskill[1] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, (Vector3) ((this.mytransform.position + (Vector3.up * -0.03f)) + (this.mytransform.forward * 0.35f)), this.mytransform.rotation);
                    this.c_generalskill[1].rigidbody.mass = this.skillatk;
                    this.c_generalskill[1].parent = this.mytransform;
                }
                goto Label_2606;

            case 0x1d:
                this.myanimation.Play("skill03");
                if (this.load_skobj == null)
                {
                    this.load_skobj = Resources.Load("general_risespear") as GameObject;
                }
                this.repeatatk = this.skillatk;
                this.Repeatskill(this.skill_index, 6, 0.1f);
                goto Label_2606;

            case 30:
                this.myanimation.Play("skill02");
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].position = (Vector3) ((this.mytransform.position + (Vector3.up * 4.2f)) - (this.mytransform.forward * 5.5f));
                    this.c_generalskill[0].rotation = this.mytransform.rotation;
                    this.c_generalskill[0].gameObject.active = true;
                }
                else
                {
                    this.load_skobj = Resources.Load("general_meteo") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, (Vector3) ((this.mytransform.position + (Vector3.up * 4.2f)) - (this.mytransform.forward * 5.5f)), this.mytransform.rotation);
                    this.c_generalskill[0].rigidbody.mass = this.skillatk;
                }
                goto Label_2606;

            case 0x1f:
                if (this.load_skobj == null)
                {
                    this.load_skobj = Resources.Load("general_mirage") as GameObject;
                }
                this.myanimation.Play("skill03");
                this.repeatatk = this.skillatk;
                this.Repeatskill(this.skill_index, 6, 0.05f);
                base.StartCoroutine(this.Sk_Mirage());
                this.script_costume.Disappear();
                this.script_cha1.StopControl();
                goto Label_2606;

            case 0x20:
                this.myanimation.Play("dodge");
                this.temp = this.myanimation.PlayQueued("attackex2");
                this.temp.speed = 0.28f;
                this.temp.layer = 2;
                this.temp = this.myanimation.PlayQueued("attackex2_impact");
                this.temp.speed = 0.25f;
                this.temp.layer = 2;
                base.rigidbody.AddForce((Vector3) (this.mytransform.forward * 180f));
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].position = (Vector3) ((this.mytransform.position + (Vector3.up * 0.1f)) + (this.mytransform.forward * 0.2f));
                    this.c_generalskill[0].rotation = this.mytransform.rotation;
                    this.c_generalskill[0].gameObject.active = true;
                }
                else
                {
                    this.load_skobj = Resources.Load("general_edge_wheel") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, (Vector3) ((this.mytransform.position + (Vector3.up * 0.1f)) + (this.mytransform.forward * 0.2f)), this.mytransform.rotation);
                    this.c_generalskill[0].rigidbody.mass = this.skillatk;
                }
                goto Label_2606;

            case 0x21:
                this.myanimation.Play("skill04");
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].position = (Vector3) ((this.mytransform.position + (Vector3.up * 0.01f)) + (this.mytransform.forward * 0.5f));
                    this.c_generalskill[0].gameObject.active = true;
                }
                else
                {
                    this.load_skobj = Resources.Load("general_swamp") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, (Vector3) ((this.mytransform.position + (Vector3.up * 0.01f)) + (this.mytransform.forward * 0.5f)), Quaternion.identity);
                    this.c_generalskill[0].rigidbody.mass = this.skillatk;
                }
                goto Label_2606;

            case 0x22:
                this.myanimation.Play("skill04");
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].position = this.mytransform.position + ((Vector3) (Vector3.up * 0.1f));
                    this.c_generalskill[0].rotation = this.mytransform.rotation;
                    this.c_generalskill[0].gameObject.active = true;
                }
                else
                {
                    this.load_skobj = Resources.Load("general_multispear") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, this.mytransform.position + ((Vector3) (Vector3.up * 0.1f)), this.mytransform.rotation);
                    this.c_generalskill[0].rigidbody.mass = this.skillatk;
                }
                goto Label_2606;

            case 0x23:
                this.myanimation.Play("skill03");
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].gameObject.active = true;
                    this.c_generalskill[0].position = this.mytransform.position;
                    this.c_generalskill[0].rotation = this.mytransform.rotation;
                    this.c_generalskill[0].parent = this.mytransform;
                }
                else
                {
                    this.load_skobj = Resources.Load("general_fincanon") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, this.mytransform.position, this.mytransform.rotation);
                    this.c_generalskill[0].rigidbody.mass = this.skillatk;
                    this.c_generalskill[0].parent = this.mytransform;
                }
                base.collider.enabled = false;
                this.script_cha1.Invincibility(3f);
                goto Label_2606;

            case 0x24:
                this.myanimation.Play("wheelwind");
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].position = this.mytransform.position + ((Vector3) (Vector3.up * 0.1f));
                    this.c_generalskill[0].rotation = this.mytransform.rotation;
                    this.c_generalskill[0].gameObject.active = true;
                }
                else
                {
                    this.load_skobj = Resources.Load("general_flowerfan") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, this.mytransform.position + ((Vector3) (Vector3.up * 0.1f)), this.mytransform.rotation);
                    this.c_generalskill[0].rigidbody.mass = this.skillatk;
                }
                goto Label_2606;

            case 0x25:
                this.myanimation.Play("skill03");
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].gameObject.active = true;
                    this.c_generalskill[0].position = this.mytransform.position - ((Vector3) (Vector3.up * 0.1f));
                }
                else
                {
                    this.load_skobj = Resources.Load("general_chain") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, this.mytransform.position - ((Vector3) (Vector3.up * 0.1f)), Quaternion.identity);
                    this.c_generalskill[0].rigidbody.mass = this.skillatk;
                }
                goto Label_2606;

            case 0x26:
                this.myanimation.Play("skill03");
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].gameObject.active = true;
                    this.c_generalskill[0].position = (Vector3) ((this.mytransform.position + (this.mytransform.forward * 0.1f)) + (Vector3.up * 0.07f));
                    this.c_generalskill[0].rotation = this.mytransform.rotation;
                }
                else
                {
                    this.load_skobj = Resources.Load("general_arrow_poison") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, (Vector3) ((this.mytransform.position + (this.mytransform.forward * 0.05f)) + (Vector3.up * 0.07f)), this.mytransform.rotation);
                    this.c_generalskill[0].rigidbody.mass = this.skillatk;
                }
                goto Label_2606;

            case 0x27:
                this.myanimation.Play("rapidstab");
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].gameObject.active = true;
                    this.c_generalskill[0].position = (Vector3) ((this.mytransform.position + (this.mytransform.forward * 0.15f)) + (Vector3.up * 0.05f));
                    this.c_generalskill[0].rotation = this.mytransform.rotation;
                }
                else
                {
                    this.load_skobj = Resources.Load("general_rapidthrust") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, (Vector3) ((this.mytransform.position + (this.mytransform.forward * 0.15f)) + (Vector3.up * 0.05f)), this.mytransform.rotation);
                    this.c_generalskill[0].rigidbody.mass = this.skillatk;
                }
                goto Label_2606;

            case 40:
                this.myanimation.Play("skill04");
                if (this.load_skobj != null)
                {
                    this.c_generalskill[0].gameObject.active = true;
                    this.c_generalskill[0].position = (Vector3) ((this.mytransform.position + (this.mytransform.forward * 0.22f)) + (Vector3.up * 0.06f));
                    this.c_generalskill[0].rotation = this.mytransform.rotation;
                }
                else
                {
                    this.load_skobj = Resources.Load("general_elec_shock") as GameObject;
                    this.c_generalskill[0] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, (Vector3) ((this.mytransform.position + (this.mytransform.forward * 0.22f)) + (Vector3.up * 0.06f)), this.mytransform.rotation);
                    this.c_generalskill[0].rigidbody.mass = this.skillatk;
                }
                goto Label_2606;

            default:
                goto Label_2606;
        }
        this.pt_boom.GetComponent<Ef_boom>().SetTex(1, this.mytransform.position, true);
        this.script_cha1.DefenceUp();
        base.Invoke("Sk_DefenceUp", this.skillatk);
    Label_2606:
        this.skill_index = -1;
    }

    public void PetSkillOn(int index)
    {
        this.ef_rotfog.position = this.mytransform.position;
        this.script_rotfog.RotfogOn(3f, 4f, 80, 5, 3f);
        this.script_cam.ZoomIn(5, 15, 1f);
        switch (index)
        {
            case 0:
                this.script_cha1.CallHorse();
                break;

            case 1:
                this.script_cha1.Fly();
                break;
        }
    }

    [DebuggerHidden]
    public IEnumerator Pt_Off(Transform _pt)
    {
        return new <Pt_Off>c__IteratorA { _pt = _pt, <$>_pt = _pt, <>f__this = this };
    }

    public void Repeatskill(int _kind, int _count, float _delay)
    {
        this.repeat = true;
        this.repeatkind = _kind;
        this.repeattime = _count;
        this.repeatdelay = _delay;
        this.currentdelay = this.repeatdelay;
        switch (this.repeatkind)
        {
            case 0x1d:
                this.rndpos = (Vector3) ((this.mytransform.position + (this.mytransform.forward * (0.1f + (0.14f * (6 - this.repeattime))))) + (this.mytransform.right * UnityEngine.Random.Range((float) -0.1f, (float) 0.1f)));
                this.rndpos[1] = -1f;
                if (this.c_generalskill[this.repeattime] != null)
                {
                    this.c_generalskill[this.repeattime].position = this.rndpos;
                    this.c_generalskill[this.repeattime].gameObject.active = true;
                    return;
                }
                this.c_generalskill[this.repeattime] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, this.rndpos, Quaternion.Euler(0f, (float) UnityEngine.Random.Range(0, 360), 0f));
                this.c_generalskill[this.repeattime].rigidbody.mass = this.repeatatk;
                return;

            case 0x1f:
                if (this.c_generalskill[this.repeattime] != null)
                {
                    this.c_generalskill[this.repeattime].position = this.mytransform.position;
                    this.c_generalskill[this.repeattime].rotation = Quaternion.Euler(0f, (float) (this.repeattime * 60), 0f);
                    this.c_generalskill[this.repeattime].gameObject.active = true;
                    return;
                }
                this.c_generalskill[this.repeattime] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, this.mytransform.position, Quaternion.Euler(0f, (float) (this.repeattime * 60), 0f));
                this.c_generalskill[this.repeattime].rigidbody.mass = this.repeatatk;
                return;

            case 11:
                this.rndpos = (Vector3) ((this.mytransform.position + (this.mytransform.forward * 0.3f)) + (this.mytransform.right * UnityEngine.Random.Range((float) -0.2f, (float) 0.2f)));
                this.rndpos[1] = 0.01f;
                this.c_energypillar = (Transform) UnityEngine.Object.Instantiate(this.energypillar, this.rndpos, Quaternion.identity);
                this.c_energypillar.rigidbody.mass = this.repeatatk;
                UnityEngine.Object.Destroy(this.c_energypillar.gameObject, 1.5f);
                this.script_cam.Hitcam2(1.5f);
                break;

            case 0x11:
                this.rndpos = (Vector3) ((this.mytransform.position + (this.mytransform.forward * UnityEngine.Random.Range((float) 0.3f, (float) 0.45f))) + ((this.mytransform.right * (2 - this.repeattime)) * 0.5f));
                this.rndpos[1] = -1f;
                if (this.c_bamboo[3 - this.repeattime] == null)
                {
                    this.c_bamboo[3 - this.repeattime] = (Transform) UnityEngine.Object.Instantiate(this.bamboo, this.rndpos, Quaternion.Euler(0f, (float) UnityEngine.Random.Range(0, 360), 0f));
                    this.c_bamboo[3 - this.repeattime].rigidbody.mass = this.repeatatk;
                }
                else
                {
                    this.c_bamboo[3 - this.repeattime].position = this.rndpos;
                    this.c_bamboo[3 - this.repeattime].gameObject.active = true;
                }
                this.script_cam.Hitcam2(1.5f);
                break;

            case 0x19:
                this.tempradian = ((((3 - this.repeattime) * 0x2d) - this.mytransform.eulerAngles.y) + 90f) * 0.01745f;
                this.rndpos = (Vector3) ((this.mytransform.position + ((0.3f * Vector3.right) * Mathf.Cos(this.tempradian))) + ((0.3f * Vector3.forward) * Mathf.Sin(this.tempradian)));
                this.rndpos[1] = -1f;
                if (this.c_generalskill[this.repeattime] == null)
                {
                    this.c_generalskill[this.repeattime] = (Transform) UnityEngine.Object.Instantiate(this.load_skobj.transform, this.rndpos, Quaternion.Euler(0f, (float) UnityEngine.Random.Range(0, 360), 0f));
                    this.c_generalskill[this.repeattime].localScale = Vector3.one + ((Vector3) (Vector3.up * UnityEngine.Random.Range((float) -0.1f, (float) 0.5f)));
                    Transform transform1 = this.c_generalskill[this.repeattime];
                    transform1.localScale = (Vector3) (transform1.localScale * UnityEngine.Random.Range((float) 0.7f, (float) 1.2f));
                    this.c_generalskill[this.repeattime].rigidbody.mass = this.repeatatk;
                }
                else
                {
                    this.c_generalskill[this.repeattime].localScale = Vector3.one + ((Vector3) (Vector3.up * UnityEngine.Random.Range((float) -0.1f, (float) 0.5f)));
                    Transform transform2 = this.c_generalskill[this.repeattime];
                    transform2.localScale = (Vector3) (transform2.localScale * UnityEngine.Random.Range((float) 0.7f, (float) 1.2f));
                    this.c_generalskill[this.repeattime].position = this.rndpos;
                    this.c_generalskill[this.repeattime].gameObject.active = true;
                }
                break;
        }
    }

    [DebuggerHidden]
    public IEnumerator ResetTimeScale()
    {
        return new <ResetTimeScale>c__IteratorB { <>f__this = this };
    }

    public void Set_General_Skill(short _maxatk, short _skillatk, short _motionkind)
    {
        this.g_skillatk = (short) ((_maxatk * _skillatk) * 0.01f);
        this.g_skillatk = (short) Mathf.Max(this.g_skillatk, 1);
        this.g_motionkind = _motionkind;
    }

    public void Set_R_hand(Transform _hand)
    {
        this.r_hand = _hand;
    }

    public void SetBaseDamage(float _dmg)
    {
        this.basedamage = _dmg;
    }

    private void Sk_AttackUp()
    {
        this.pt_attackup.particleEmitter.emit = false;
        this.script_cha1.ResetAtk();
    }

    private void Sk_DefenceUp()
    {
        UnityEngine.Object.Destroy(this.c_defenceup.gameObject);
        this.script_cha1.ResetDef();
    }

    [DebuggerHidden]
    public IEnumerator Sk_Mirage()
    {
        return new <Sk_Mirage>c__IteratorE { <>f__this = this };
    }

    [DebuggerHidden]
    public IEnumerator Sk_SwordDance()
    {
        return new <Sk_SwordDance>c__IteratorD { <>f__this = this };
    }

    public void SkillOn(int _index, bool _general)
    {
        this.script_cha1.SkillStart();
        this.pt_ki.particleEmitter.emit = true;
        base.rigidbody.drag = 20f;
        this.skill_index = _index;
        this.ef_rotfog.position = this.mytransform.position;
        this.script_rotfog.RotfogOn(1.5f, 40f, 800, 150, 0.5f);
        Time.timeScale = 0.1f;
        if (!_general)
        {
            this.motionkind = this.script_DBskill.ss[this.skill_index, 0]._kind;
            this.cur_skill_grade[this.skill_index] = Mathf.Max(0, this.cur_skill_grade[this.skill_index]);
            this.skillatk = this.script_DBskill.ss[this.skill_index, this.cur_skill_grade[this.skill_index]]._attackpoint;
        }
        else
        {
            this.motionkind = this.g_motionkind;
            this.skillatk = this.g_skillatk;
            this.skill_index += 0x15;
        }
        if (this.motionkind == 1)
        {
            this.directionArrow.renderer.enabled = true;
            this.myanimation.Play("cast1");
        }
        else if (this.motionkind == 2)
        {
            this.script_cam.ZoomIn(20, 0x10, 0.3f);
            this.myanimation.Play("cast2");
            if ((this.skill_index == 13) || (this.skill_index == 15))
            {
                base.audio.PlayOneShot(this.snd_jin);
                this.jin.gameObject.active = true;
                this.jin.position = (Vector3) ((this.mytransform.position + (this.mytransform.forward * 0.2f)) + (Vector3.up * 0.01f));
            }
            else if (this.skill_index == 0x13)
            {
                this.wing.gameObject.active = true;
            }
        }
        else if (this.motionkind == 3)
        {
            this.directionArrow.renderer.enabled = true;
            this.myanimation.Play("cast3");
            if (this.skill_index == 8)
            {
                this.ef_gather.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.22f));
                this.ef_gather.gameObject.active = true;
                this.ef_gather.GetComponent<Ef_energy_gather>().SetTex(0, 1.2f);
            }
            else if (this.skill_index == 9)
            {
                this.ef_gather.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.22f));
                this.ef_gather.gameObject.active = true;
                this.ef_gather.GetComponent<Ef_energy_gather>().SetTex(1, 0.8f);
            }
        }
        else if (this.motionkind == 4)
        {
            this.directionArrow.renderer.enabled = true;
            this.myanimation.Play("cast4");
            if (this.skill_index == 0x10)
            {
                this.jin.gameObject.active = true;
                this.jin.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.01f));
                if (this.c_fincanon == null)
                {
                    this.c_fincanon = (Transform) UnityEngine.Object.Instantiate(this.fincanon, this.mytransform.position, this.mytransform.rotation);
                    this.c_fincanon.rigidbody.mass = (this.skillatk * this.basedamage) * 0.01f;
                    this.c_fincanon.parent = this.mytransform;
                }
                else
                {
                    this.c_fincanon.gameObject.active = true;
                    this.c_fincanon.position = this.mytransform.position;
                    this.c_fincanon.rotation = this.mytransform.rotation;
                    this.c_fincanon.parent = this.mytransform;
                }
            }
        }
    }

    private void Start()
    {
        this.script_DBskill = GameObject.FindWithTag("ui").GetComponent<DB_Skill>();
        this.cur_skill_grade = PlayerPrefsX.GetIntArray("n22");
        this.script_cha1 = base.GetComponent<Cha_Control>();
        this.script_costume = base.GetComponent<Cha_Costume>();
        this.script_rotfog = this.ef_rotfog.GetComponent<Ef_rotfog>();
        this.script_cam = Camera.main.GetComponent<Cam_Move>();
        this.pt_ki = this.mytransform.Find("pt_ki");
        this.directionArrow = this.mytransform.Find("directionArrow");
    }

    private void Update()
    {
        if (this.skill_index != -1)
        {
            this.castingdelay += Time.deltaTime;
            if (this.castingdelay > 0.18f)
            {
                base.rigidbody.drag = 5f;
                Time.timeScale = 1f;
                this.myanimation.Stop();
                this.LaunchSkill(this.skill_index);
                this.castingdelay = 0f;
                this.directionArrow.renderer.enabled = false;
            }
        }
        if (this.repeat && (this.currentdelay > 0f))
        {
            this.currentdelay -= Time.deltaTime;
            if (this.currentdelay <= 0f)
            {
                this.repeattime--;
                if (this.repeattime > 0)
                {
                    this.Repeatskill(this.repeatkind, this.repeattime, this.repeatdelay);
                }
                else
                {
                    this.repeat = false;
                }
            }
        }
    }

    [CompilerGenerated]
    private sealed class <BambooFin>c__IteratorC : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal Cha_Skill <>f__this;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.$current = new WaitForSeconds(3.5f);
                    this.$PC = 1;
                    return true;

                case 1:
                    this.<>f__this.c_crow.particleEmitter.emit = false;
                    this.<>f__this.c_bamboobase.particleEmitter.emit = false;
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [CompilerGenerated]
    private sealed class <Pt_Off>c__IteratorA : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal Transform _pt;
        internal Transform <$>_pt;
        internal Cha_Skill <>f__this;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.$current = new WaitForSeconds(this.<>f__this.pt_off_delay);
                    this.$PC = 1;
                    return true;

                case 1:
                    this._pt.particleEmitter.emit = false;
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [CompilerGenerated]
    private sealed class <ResetTimeScale>c__IteratorB : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal Cha_Skill <>f__this;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.$current = new WaitForSeconds(0.5f);
                    this.$PC = 1;
                    return true;

                case 1:
                    Time.timeScale = 1f;
                    this.<>f__this.pt_boom.GetComponent<Ef_boom>().SetTex(0, this.<>f__this.mytransform.position, false);
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [CompilerGenerated]
    private sealed class <Sk_Mirage>c__IteratorE : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal Cha_Skill <>f__this;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.$current = new WaitForSeconds(1f);
                    this.$PC = 1;
                    return true;

                case 1:
                    this.<>f__this.script_costume.Appear();
                    this.<>f__this.script_cha1.StartControl();
                    this.<>f__this.animation.Play("attackex2_impact");
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [CompilerGenerated]
    private sealed class <Sk_SwordDance>c__IteratorD : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal Cha_Skill <>f__this;
        internal AnimationState <comein>__0;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.$current = new WaitForSeconds(0.5f);
                    this.$PC = 1;
                    return true;

                case 1:
                    this.<>f__this.myanimation.Stop();
                    this.<comein>__0 = this.<>f__this.myanimation.PlayQueued("change_in_atk");
                    this.<comein>__0.speed = 0.5f;
                    this.<>f__this.script_costume.Appear();
                    this.<>f__this.script_cha1.StartControl();
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }
}


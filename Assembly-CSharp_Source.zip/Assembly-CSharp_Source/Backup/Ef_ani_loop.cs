using System;
using UnityEngine;

public class Ef_ani_loop : MonoBehaviour
{
    public int framesPerSecond = 20;
    public int impact = 1;
    private int index;
    private int lastframe;
    public bool loop;
    private Collider mycollider;
    private Material mymaterial;
    private Renderer myrenderer;
    private Vector2 offset;
    private int oldindex = -1;
    public bool sharedmtl;
    private Vector2 size;
    private float starttime;
    private float uIndex;
    public int uvAnimationTileX = 4;
    public int uvAnimationTileY = 4;
    private int vIndex;

    private void Awake()
    {
        this.myrenderer = base.renderer;
        if (base.collider != null)
        {
            this.mycollider = base.collider;
            this.mycollider.enabled = false;
            this.mycollider.isTrigger = true;
        }
    }

    private void Start()
    {
        this.starttime = 0f;
        this.lastframe = this.uvAnimationTileX * this.uvAnimationTileY;
        this.size = new Vector2(1f / ((float) this.uvAnimationTileX), 1f / ((float) this.uvAnimationTileY));
        if (this.sharedmtl)
        {
            this.mymaterial = this.myrenderer.sharedMaterial;
        }
        else
        {
            this.mymaterial = this.myrenderer.material;
        }
    }

    private void Update()
    {
        if (this.myrenderer.enabled)
        {
            this.starttime += Time.deltaTime;
            this.index = (int) (this.starttime * this.framesPerSecond);
            if (this.loop)
            {
                this.index = this.index % this.lastframe;
            }
            this.uIndex = this.index % this.uvAnimationTileX;
            this.vIndex = this.index / this.uvAnimationTileX;
            if (this.index != this.oldindex)
            {
                if (this.index >= this.lastframe)
                {
                    this.starttime = 0f;
                    this.oldindex = -1;
                    base.gameObject.active = false;
                    this.mycollider.enabled = false;
                }
                else if (this.index >= this.impact)
                {
                    this.mycollider.enabled = true;
                }
                this.offset = (Vector2) (((Vector2.right * this.uIndex) * this.size.x) + (Vector2.up * ((1f - this.size.y) - (this.vIndex * this.size.y))));
                this.mymaterial.mainTextureOffset = this.offset;
                this.mymaterial.mainTextureScale = this.size;
                this.oldindex = this.index;
            }
        }
    }
}


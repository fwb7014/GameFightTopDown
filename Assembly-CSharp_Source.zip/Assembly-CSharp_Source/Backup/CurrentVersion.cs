using System;
using UnityEngine;

public class CurrentVersion : MonoBehaviour
{
    public string gameID;
    public int gameNo;
    public string hsp_version;
}


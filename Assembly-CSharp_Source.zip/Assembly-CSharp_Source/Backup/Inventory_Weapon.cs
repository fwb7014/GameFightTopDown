using System;
using UnityEngine;

public class Inventory_Weapon : MonoBehaviour
{
    private int _getslot = -1;
    public Texture2D[] armoricon = new Texture2D[7];
    private bool b_delay;
    public GUISkin basicSkin;
    public Texture2D bg_black;
    private int bg_posX_r = 480;
    public Texture2D bg_weapon;
    public Texture2D bg_weapon_l;
    private int[] bottom_icon = new int[6];
    public GUIStyle bt_equip;
    public GUIStyle bt_yesno;
    public Texture2D c_equip;
    private short confirm;
    private int cur_difficulty;
    private int cur_item;
    private int cur_stage_index;
    public GUIStyle erase;
    private float f_delay;
    private int getequip_hp;
    private int getequip_index;
    private int getequip_special;
    private bool getitem;
    private int getitem_grade;
    private int getitem_seed;
    private int getweapon_index;
    private int getweapon_kind;
    private int getweapon_maxatk;
    private int getweapon_meshkind;
    private int getweapon_minatk;
    private int getweapon_name;
    private float getweapon_spd;
    private int getweapon_special;
    private int getweapon_special_txt;
    public Texture2D icon_coin;
    private float icon_delay;
    public Texture2D icon_jade;
    public Texture2D icon_lock;
    public Texture2D icon_new;
    private float icon_posY = 320f;
    private int icon_size = 0x20;
    public Texture2D icon_unlock;
    private bool imagemovefinish;
    private int[] item_seed = new int[0x1a];
    private int language;
    private float nextdelay = 0.5f;
    private bool nextstart;
    public Texture2D pop_blank;
    public Texture2D pop_blank2;
    private bool popupOn;
    private float posX = 112f;
    private int posX2;
    private int posY = 90;
    private int posY2;
    private short rewardkind;
    private Language_Costume script_name;
    private UI_result script_ui;
    private WeaponStat script_weaponstat;
    private int selectslot = -1;
    private int selequip_hp;
    private int selequip_index;
    private int selequip_special;
    private int sellcost_get;
    private int sellcost_sel;
    private int selweapon_grade;
    private int selweapon_index;
    private int selweapon_kind;
    private int selweapon_maxatk;
    private int selweapon_minatk;
    private int selweapon_name;
    private float selweapon_spd;
    private int selweapon_special_txt;
    private int slot_item = 3;
    public Texture2D star_grade;
    private bool stopgui;
    public Texture2D titlebase;
    public Texture2D titlebase2;
    public Texture2D[] weapon_kindicon = new Texture2D[3];
    private int[] weapon_plusup = new int[0x1a];
    public Texture2D[] weaponicon = new Texture2D[20];

    private void Awake()
    {
        this.cur_stage_index = Crypto.Load_int_key("cur_stage_index");
        this.script_ui = GameObject.FindWithTag("ui").GetComponent<UI_result>();
        this.language = PlayerPrefs.GetInt("language");
        this.script_name = base.GetComponent<Language_Costume>();
        this.cur_difficulty = Crypto.Load_int_key("n14");
    }

    public void Delay(float t)
    {
        this.b_delay = true;
        this.f_delay = t;
    }

    public void EnableGUI()
    {
        this.stopgui = false;
    }

    public void GetArmor(int _index)
    {
        this.rewardkind = 2;
        this.Start_Armor();
        this.getequip_hp = (((int) ((this.cur_stage_index + 1) * 0.4f)) + UnityEngine.Random.Range(0, 2)) + this.getitem_grade;
        this.getequip_index = UnityEngine.Random.Range(1, 7);
        this.getitem_seed = ((this.getequip_index + 100) + (this.getequip_special * 0x3e8)) + (this.getequip_hp * 0x2710);
        this.getitem = true;
        this.script_ui.OpenShop();
        this.sellcost_get = this.getequip_hp * 5;
    }

    public void GetWeapon(int _index)
    {
        this.rewardkind = 1;
        this.Start_Weapon();
        this.getweapon_index = _index;
        this.getitem_grade = UnityEngine.Random.Range(0, 0x3e8);
        switch (this.cur_difficulty)
        {
            case 0:
                if (this.getitem_grade <= 900)
                {
                    if (this.getitem_grade > 700)
                    {
                        this.getitem_grade = 3;
                    }
                    else if (this.getitem_grade > 300)
                    {
                        this.getitem_grade = 2;
                    }
                    else
                    {
                        this.getitem_grade = 1;
                    }
                    break;
                }
                this.getitem_grade = 4;
                break;

            case 1:
                if (this.getitem_grade <= 900)
                {
                    if (this.getitem_grade > 500)
                    {
                        this.getitem_grade = 3;
                    }
                    else if (this.getitem_grade > 200)
                    {
                        this.getitem_grade = 2;
                    }
                    else
                    {
                        this.getitem_grade = 1;
                    }
                    break;
                }
                this.getitem_grade = 4;
                break;

            case 2:
                if (this.getitem_grade <= 800)
                {
                    if (this.getitem_grade > 300)
                    {
                        this.getitem_grade = 3;
                    }
                    else if (this.getitem_grade > 100)
                    {
                        this.getitem_grade = 2;
                    }
                    else
                    {
                        this.getitem_grade = 1;
                    }
                    break;
                }
                this.getitem_grade = 4;
                break;
        }
        int num = (UnityEngine.Random.Range(10, 0x2703) + ((this.getitem_grade - 1) * 3)) + UnityEngine.Random.Range(0, 4);
        this.getitem_seed = ((this.getweapon_index * 0xf4240) + (this.getitem_grade * 0x2710)) + num;
        this.script_weaponstat.SetStat(this.getitem_seed);
        this.getweapon_meshkind = this.script_weaponstat.weapon_meshkind;
        this.getitem_grade = this.script_weaponstat.weapon_grade;
        this.getweapon_name = this.script_weaponstat.weapon_name;
        this.getweapon_maxatk = this.script_weaponstat.weapon_maxatk;
        this.getweapon_minatk = this.script_weaponstat.weapon_minatk;
        this.getweapon_kind = this.script_weaponstat.weapon_kind;
        this.getweapon_spd = this.script_weaponstat.weapon_spd;
        this.getweapon_special = this.script_weaponstat.weapon_special;
        this.getweapon_special_txt = this.script_weaponstat.weapon_special_txt;
        this.getitem = true;
        this.sellcost_get = (int) ((this.getweapon_index + (this.getitem_grade * 0.1f)) * 10f);
        this.script_ui.OpenShop();
    }

    private void OnGUI()
    {
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.skin = this.basicSkin;
        GUI.depth = -5;
        if (!this.stopgui)
        {
            if ((this.confirm > 0) || this.nextstart)
            {
                GUI.enabled = false;
            }
            GUI.DrawTexture(Crypto.Rect2((float) this.bg_posX_r, 230f, 480f, 84f), this.bg_black);
            if (this.getitem)
            {
                GUI.DrawTexture(Crypto.Rect2(this.posX, (float) this.posY, 256f, 128f), this.bg_weapon_l);
                GUI.Box(Crypto.Rect2(this.posX, (float) this.posY, (float) (this.icon_size * 8), (float) (this.icon_size * 4)), string.Empty, "glow_box");
                if (this.rewardkind == 1)
                {
                    GUI.DrawTexture(Crypto.Rect2(this.posX + 16f, (float) (this.posY + 0x21), 64f, 64f), this.weaponicon[this.getweapon_meshkind]);
                    GUI.Label(Crypto.Rect2(this.posX + 68f, (float) (this.posY + 10), 128f, 16f), this.script_name.txt_cos[this.language, this.getweapon_name], "txt12_w");
                    GUI.DrawTexture(Crypto.Rect2(this.posX + 212f, (float) (this.posY + 6), 26f, 26f), this.weapon_kindicon[this.getweapon_kind]);
                    for (int k = 0; k < 3; k++)
                    {
                        GUI.DrawTexture(Crypto.Rect2(this.posX + 98f, (float) ((this.posY + 0x21) + (k * 20)), 140f, 16f), this.titlebase);
                    }
                    GUI.Label(Crypto.Rect2(this.posX + 102f, (float) (this.posY + 0x21), 128f, 16f), string.Concat(new object[] { Language.intxt[this.language, 0x8d], "   ", this.getweapon_minatk, " - ", this.getweapon_maxatk }), "txt12_0");
                    GUI.Label(Crypto.Rect2(this.posX + 102f, (float) (this.posY + 0x35), 128f, 16f), Language.intxt[this.language, 0x99] + "   " + ((this.getweapon_spd * 100f)).ToString("F1"), "txt12_0");
                    GUI.Label(Crypto.Rect2(this.posX + 102f, (float) (this.posY + 0x49), 128f, 16f), this.script_name.txt_cos[this.language, this.getweapon_special_txt], "txt12_0");
                }
                else
                {
                    GUI.DrawTexture(Crypto.Rect2(this.posX + 16f, (float) (this.posY + 0x21), 64f, 64f), this.armoricon[this.getequip_index]);
                    GUI.Label(Crypto.Rect2(this.posX + 68f, (float) (this.posY + 10), 128f, 16f), this.script_name.txt_cos[this.language, this.getequip_index + 1], "txt12_w");
                    for (int m = 0; m < 2; m++)
                    {
                        GUI.DrawTexture(Crypto.Rect2(this.posX + 98f, (float) ((this.posY + 0x21) + (m * 20)), 140f, 16f), this.titlebase);
                    }
                    GUI.Label(Crypto.Rect2(this.posX + 102f, (float) (this.posY + 0x21), 128f, 16f), Language.intxt[this.language, 0x8e] + " + " + this.getequip_hp, "txt12_0");
                    GUI.Label(Crypto.Rect2(this.posX + 102f, (float) (this.posY + 0x35), 128f, 16f), this.script_name.txt_cos[this.language, this.getequip_special + 0x15], "txt12_0");
                }
                GUI.DrawTexture(Crypto.Rect2(this.posX + 32f, (float) (this.posY + 0x20), (float) this.icon_size, 16f), this.icon_new);
                for (int j = 0; j < this.getitem_grade; j++)
                {
                    GUI.DrawTexture(Crypto.Rect2(((this.posX - (this.getitem_grade * 7)) + 47f) + (j * 14), (float) (this.posY + 0x63), 16f, 16f), this.star_grade);
                }
                if (GUI.Button(Crypto.Rect2(this.posX + 84f, (float) (this.posY + 90), 32f, 32f), string.Empty, this.erase))
                {
                    this.selectslot = -1;
                    this.popupOn = false;
                    this.confirm = 1;
                }
                else if (GUI.Button(Crypto.Rect2(this.posX + 174f, (float) (this.posY + 90), 64f, 32f), Language.intxt[this.language, 0x2d], this.bt_yesno))
                {
                    this._getslot = -1;
                    for (int n = 0; n < this.slot_item; n++)
                    {
                        if (this.item_seed[n] == 0)
                        {
                            this._getslot = n;
                            break;
                        }
                    }
                    if (this._getslot != -1)
                    {
                        this.item_seed[this._getslot] = this.getitem_seed;
                        if (this.rewardkind == 1)
                        {
                            PlayerPrefsX.SetIntArray("n41", this.item_seed);
                            this.bottom_icon[this._getslot] = this.script_weaponstat.IconImage_Only(this.item_seed[this._getslot]);
                        }
                        else
                        {
                            PlayerPrefsX.SetIntArray("n45", this.item_seed);
                            this.bottom_icon[this._getslot] = this.item_seed[this._getslot] % 100;
                        }
                        this.confirm = 7;
                        this.getitem = false;
                        this.popupOn = false;
                        this.nextstart = true;
                        this.bg_posX_r = 480;
                    }
                    else if (this.slot_item < 6)
                    {
                        this.confirm = 2;
                    }
                    else
                    {
                        this.Delay(1f);
                        this.confirm = 6;
                    }
                }
            }
            if (this.popupOn)
            {
                this.posX2 = 280;
                this.posY2 = 90;
                GUI.DrawTexture(Crypto.Rect2((float) this.posX2, (float) this.posY2, 256f, 128f), this.bg_weapon);
                if (this.rewardkind == 1)
                {
                    if (this.weapon_plusup[this.selectslot] > 0)
                    {
                        GUI.Label(Crypto.Rect2((float) (this.posX2 + 0x1a), (float) (this.posY2 + 10), 128f, 16f), this.script_name.txt_cos[this.language, this.selweapon_name] + " + " + this.weapon_plusup[this.selectslot], "txt12_w");
                    }
                    else
                    {
                        GUI.Label(Crypto.Rect2((float) (this.posX2 + 0x1a), (float) (this.posY2 + 10), 128f, 16f), this.script_name.txt_cos[this.language, this.selweapon_name], "txt12_w");
                    }
                    GUI.DrawTexture(Crypto.Rect2((float) (this.posX2 + 0x89), (float) (this.posY2 + 6), 26f, 26f), this.weapon_kindicon[this.selweapon_kind]);
                    for (int num5 = 0; num5 < 3; num5++)
                    {
                        GUI.DrawTexture(Crypto.Rect2((float) (this.posX2 + 0x18), (float) ((this.posY2 + 0x21) + (num5 * 20)), 140f, 16f), this.titlebase);
                    }
                    for (int num6 = 0; num6 < this.selweapon_grade; num6++)
                    {
                        GUI.DrawTexture(Crypto.Rect2((float) (((this.posX2 - (this.selweapon_grade * 7)) + 0x24) + (num6 * 14)), (float) (this.posY2 + 0x63), 16f, 16f), this.star_grade);
                    }
                    GUI.Label(Crypto.Rect2((float) (this.posX2 + 30), (float) (this.posY2 + 0x21), 128f, 16f), string.Concat(new object[] { Language.intxt[this.language, 0x8d], "   ", this.selweapon_minatk, " - ", this.selweapon_maxatk }), "txt12_0");
                    GUI.Label(Crypto.Rect2((float) (this.posX2 + 30), (float) (this.posY2 + 0x35), 128f, 16f), Language.intxt[this.language, 0x99] + "   " + ((this.selweapon_spd * 100f)).ToString("F1"), "txt12_0");
                    GUI.Label(Crypto.Rect2((float) (this.posX2 + 30), (float) (this.posY2 + 0x49), 128f, 16f), this.script_name.txt_cos[this.language, this.selweapon_special_txt], "txt12_0");
                }
                else
                {
                    GUI.Label(Crypto.Rect2((float) (this.posX2 + 0x1a), (float) (this.posY2 + 10), 128f, 16f), this.script_name.txt_cos[this.language, this.selequip_index + 1], "txt12_w");
                    for (int num7 = 0; num7 < 2; num7++)
                    {
                        GUI.DrawTexture(Crypto.Rect2((float) (this.posX2 + 0x18), (float) ((this.posY2 + 0x21) + (num7 * 20)), 140f, 16f), this.titlebase);
                    }
                    GUI.Label(Crypto.Rect2((float) (this.posX2 + 30), (float) (this.posY2 + 0x21), 128f, 16f), Language.intxt[this.language, 0x8e] + " + " + this.selequip_hp, "txt12_0");
                    GUI.Label(Crypto.Rect2((float) (this.posX2 + 30), (float) (this.posY2 + 0x35), 128f, 16f), this.script_name.txt_cos[this.language, this.selequip_special + 0x15], "txt12_0");
                }
                if (GUI.Button(Crypto.Rect2((float) (this.posX2 + 0x3e), (float) (this.posY2 + 90), 32f, 32f), string.Empty, this.erase))
                {
                    if (this.selectslot == this.cur_item)
                    {
                        this.Delay(1.5f);
                        this.confirm = 5;
                    }
                    else
                    {
                        this.confirm = 1;
                    }
                }
                else if (GUI.Button(Crypto.Rect2((float) (this.posX2 + 100), (float) (this.posY2 + 90), 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                {
                    this.popupOn = false;
                    this.selectslot = -1;
                }
            }
            for (int i = 0; i < 6; i++)
            {
                if (GUI.Button(Crypto.Rect2((float) ((i * 0x4c) + 0x12), this.icon_posY, 64f, 64f), string.Empty, this.bt_equip))
                {
                    if (i >= this.slot_item)
                    {
                        this.confirm = 3;
                    }
                    else if ((this.item_seed[i] > 0) && (this.selectslot != i))
                    {
                        this.selectslot = i;
                        if (this.rewardkind == 1)
                        {
                            this.SetUpWeapon(this.item_seed[this.selectslot]);
                        }
                        else
                        {
                            this.SetUpArmor(this.item_seed[this.selectslot]);
                        }
                        this.popupOn = true;
                    }
                }
                if (this.item_seed[i] > 0)
                {
                    if (this.rewardkind == 1)
                    {
                        GUI.DrawTexture(Crypto.Rect2((float) ((i * 0x4c) + 0x12), this.icon_posY, 64f, 64f), this.weaponicon[this.bottom_icon[i]]);
                    }
                    else
                    {
                        GUI.DrawTexture(Crypto.Rect2((float) ((i * 0x4c) + 0x12), this.icon_posY, 64f, 64f), this.armoricon[this.bottom_icon[i]]);
                    }
                }
                else if (i >= this.slot_item)
                {
                    GUI.DrawTexture(Crypto.Rect2((float) ((i * 0x4c) + 0x12), this.icon_posY, 64f, 64f), this.icon_lock);
                }
                if ((i == this.cur_item) && (this.nextdelay > 0f))
                {
                    GUI.Label(Crypto.Rect2((float) ((i * 0x4c) + 0x12), this.icon_posY - 16f, 64f, 16f), Language.intxt[this.language, 0x59], "txt12_w");
                }
            }
            if (this.selectslot != -1)
            {
                GUI.DrawTexture(Crypto.Rect2((float) ((this.selectslot * 0x4c) + 0x12), this.icon_posY, 64f, 64f), this.c_equip);
            }
            if (this.confirm > 0)
            {
                GUI.enabled = true;
                if (this.confirm == 1)
                {
                    GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                    GUI.Label(Crypto.Rect2(112f, 120f, 256f, 14f), Language.intxt[this.language, 12], "txt12_0");
                    GUI.DrawTexture(Crypto.Rect2(200f, 148f, 16f, 16f), this.icon_coin);
                    if (this.selectslot == -1)
                    {
                        GUI.Label(Crypto.Rect2(224f, 148f, 48f, 16f), string.Empty + this.sellcost_get, "txt12_b");
                    }
                    else
                    {
                        GUI.Label(Crypto.Rect2(224f, 148f, 48f, 16f), string.Empty + this.sellcost_sel, "txt12_b");
                    }
                    if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                    {
                        int num9 = Crypto.Load_int_key("n17");
                        if (this.selectslot == -1)
                        {
                            this.nextstart = true;
                            this.getitem = false;
                            this.bg_posX_r = 480;
                            if (this.rewardkind == 1)
                            {
                                Crypto.Property_change((int) ((this.getweapon_index + (this.getitem_grade * 0.1f)) * 10f), false);
                                num9 += (int) ((this.getweapon_index + (this.getitem_grade * 0.1f)) * 10f);
                            }
                            else
                            {
                                Crypto.Property_change(this.getequip_hp * 5, false);
                                num9 += this.getequip_hp * 5;
                            }
                        }
                        else
                        {
                            this.item_seed[this.selectslot] = 0;
                            if (this.rewardkind == 1)
                            {
                                Crypto.Property_change((int) ((this.selweapon_index + (this.selweapon_grade * 0.1f)) * 10f), false);
                                num9 += (int) ((this.selweapon_index + (this.selweapon_grade * 0.1f)) * 10f);
                                this.weapon_plusup[this.selectslot] = 0;
                                PlayerPrefsX.SetIntArray("n41", this.item_seed);
                                PlayerPrefsX.SetIntArray("n19", this.weapon_plusup);
                            }
                            else
                            {
                                Crypto.Property_change(this.selequip_hp * 5, false);
                                num9 += this.selequip_hp * 5;
                                PlayerPrefsX.SetIntArray("n45", this.item_seed);
                            }
                            this.popupOn = false;
                        }
                        this.confirm = 0;
                        this.script_ui.AmountCoin(num9);
                    }
                    else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                    {
                        this.confirm = 0;
                    }
                }
                else if (this.confirm == 2)
                {
                    GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                    GUI.Label(Crypto.Rect2(112f, 110f, 256f, 64f), Language.intxt[this.language, 0x17], "txt12_0");
                    if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                    {
                        this.confirm = 3;
                    }
                    else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                    {
                        this.confirm = 0;
                    }
                }
                else if (this.confirm == 3)
                {
                    GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                    GUI.DrawTexture(Crypto.Rect2(160f, 98f, 160f, 18f), this.titlebase2);
                    GUI.Label(Crypto.Rect2(120f, 120f, 230f, 16f), Language.intxt[this.language, 300], "txt12_0");
                    GUI.DrawTexture(Crypto.Rect2(186f, 134f, 32f, 32f), this.icon_unlock);
                    GUI.DrawTexture(Crypto.Rect2(244f, 142f, 16f, 16f), this.icon_jade);
                    GUI.Label(Crypto.Rect2(264f, 142f, 16f, 16f), "3", "txt12_b");
                    GUI.Label(Crypto.Rect2(112f, 162f, 256f, 16f), Language.intxt[this.language, 350], "txt12_b");
                    if (this.rewardkind == 1)
                    {
                        GUI.Label(Crypto.Rect2(120f, 98f, 230f, 16f), Language.intxt[this.language, 0xeb] + " +1", "txt12_w");
                    }
                    else
                    {
                        GUI.Label(Crypto.Rect2(120f, 98f, 230f, 16f), Language.intxt[this.language, 0xc6] + " +1", "txt12_w");
                    }
                    if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                    {
                        int num10 = Crypto.Load_int_key("n24");
                        this.confirm = 0;
                        if (num10 >= 3)
                        {
                            if (Crypto.Property_change(-3, true))
                            {
                                num10 -= 3;
                                this.slot_item = Mathf.Min(6, this.slot_item + 1);
                                if (this.rewardkind == 1)
                                {
                                    Crypto.Save_int_key("n03", this.slot_item);
                                    PurchaseLog.LogOn(Language.intxt[this.language, 0xea] + " (3)\t" + Language.intxt[this.language, 0xeb]);
                                }
                                else
                                {
                                    Crypto.Save_int_key("n42", this.slot_item);
                                    PurchaseLog.LogOn(Language.intxt[this.language, 0xea] + " (3)\t" + Language.intxt[this.language, 0xc6]);
                                }
                                this.script_ui.AmountJade(num10);
                            }
                        }
                        else
                        {
                            this.confirm = 4;
                        }
                    }
                    else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                    {
                        this.confirm = 0;
                    }
                }
                else if (this.confirm == 4)
                {
                    GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                    GUI.Label(Crypto.Rect2(112f, 110f, 256f, 64f), Language.intxt[this.language, 0x15], "txt12_0");
                    if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                    {
                        this.script_ui.CashshopOpen(1);
                        this.stopgui = true;
                        this.confirm = 0;
                    }
                    else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                    {
                        this.confirm = 0;
                    }
                }
                else if (this.confirm == 5)
                {
                    GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                    GUI.Label(Crypto.Rect2(112f, 110f, 256f, 64f), Language.intxt[this.language, 0xce], "txt12_0");
                    if (this.f_delay == 0f)
                    {
                        this.confirm = 0;
                    }
                }
                else if (this.confirm == 6)
                {
                    GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                    GUI.Label(Crypto.Rect2(112f, 110f, 256f, 64f), Language.intxt[this.language, 0x10b], "txt12_0");
                    if (this.f_delay == 0f)
                    {
                        this.confirm = 0;
                    }
                }
                else if (this.confirm == 7)
                {
                    GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                    GUI.Label(Crypto.Rect2(112f, 110f, 256f, 64f), Language.intxt[this.language, 0x1b], "txt12_0");
                    if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                    {
                        this.cur_item = this._getslot;
                        if (this.rewardkind == 1)
                        {
                            Crypto.Save_int_key("n44", this.cur_item);
                            Crypto.Save_int_key("n34", this.getweapon_meshkind + (this.getweapon_kind * 100));
                            Crypto.Save_int_key("n31", this.getweapon_maxatk);
                            Crypto.Save_int_key("n04", this.getweapon_minatk);
                            Crypto.Save_int_key("n35", (int) (this.getweapon_spd * 100f));
                            int num11 = Mathf.Min(this.getitem_grade, 3);
                            Crypto.Save_int_key("n38", (num11 * 10) + this.getweapon_special);
                            GameObject.Find("dummy_weapon").GetComponent<Cha_Weapon>().SetStageWeapon();
                        }
                        else
                        {
                            Crypto.Save_int_key("n05", this.cur_item);
                            Crypto.Save_int_key("n43", this.getequip_index);
                            GameObject.FindWithTag("Player").GetComponent<Cha_Costume>().Costume(this.getequip_index);
                        }
                        this.confirm = 0;
                    }
                    else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                    {
                        this.confirm = 0;
                    }
                }
            }
        }
    }

    public void SetUpArmor(int _index)
    {
        this.selequip_index = _index % 100;
        _index /= 100;
        int[] numArray = new int[2];
        for (int i = 0; i < 2; i++)
        {
            numArray[i] = _index % 10;
            _index /= 10;
        }
        this.selequip_special = numArray[1];
        this.selequip_hp = _index;
        this.sellcost_sel = this.selequip_hp * 5;
    }

    public void SetUpWeapon(int _index)
    {
        this.script_weaponstat.SetStat(_index);
        this.selweapon_index = this.script_weaponstat.weapon_index;
        this.selweapon_grade = this.script_weaponstat.weapon_grade;
        this.selweapon_name = this.script_weaponstat.weapon_name;
        this.selweapon_maxatk = this.script_weaponstat.weapon_maxatk + this.weapon_plusup[this.selectslot];
        this.selweapon_minatk = this.script_weaponstat.weapon_minatk + this.weapon_plusup[this.selectslot];
        this.selweapon_kind = this.script_weaponstat.weapon_kind;
        this.selweapon_spd = this.script_weaponstat.weapon_spd;
        this.selweapon_special_txt = this.script_weaponstat.weapon_special_txt;
        this.sellcost_sel = (int) ((this.selweapon_index + (this.selweapon_grade * 0.1f)) * 10f);
    }

    private void Start_Armor()
    {
        this.cur_item = Crypto.Load_int_key("n05");
        this.slot_item = Crypto.Load_int_key("n42");
        this.item_seed = PlayerPrefsX.GetIntArray("n45");
        for (int i = 0; i < this.slot_item; i++)
        {
            this.bottom_icon[i] = this.item_seed[i] % 100;
        }
    }

    private void Start_Weapon()
    {
        this.script_weaponstat = base.GetComponent<WeaponStat>();
        this.cur_item = Crypto.Load_int_key("n44");
        this.slot_item = Crypto.Load_int_key("n03");
        this.item_seed = PlayerPrefsX.GetIntArray("n41");
        this.weapon_plusup = PlayerPrefsX.GetIntArray("n19");
        for (int i = 0; i < this.slot_item; i++)
        {
            this.bottom_icon[i] = this.script_weaponstat.IconImage_Only(this.item_seed[i]);
        }
    }

    private void Update()
    {
        if (this.b_delay)
        {
            this.f_delay -= Time.deltaTime;
            if (this.f_delay <= 0f)
            {
                this.b_delay = false;
                this.f_delay = 0f;
            }
        }
        if (!this.imagemovefinish)
        {
            this.bg_posX_r -= (int) Mathf.Min((float) this.bg_posX_r, Time.deltaTime * 1500f);
            if (this.bg_posX_r <= 0)
            {
                this.bg_posX_r = 0;
                this.icon_posY -= Mathf.Min(this.icon_posY, Time.deltaTime * 500f);
                if (this.icon_posY <= 240f)
                {
                    this.icon_posY = 240f;
                    this.imagemovefinish = true;
                }
            }
        }
        else if (this.getitem)
        {
            this.icon_delay += Time.deltaTime;
            if (this.icon_delay > 0.8)
            {
                this.icon_size = 0x20;
                this.icon_delay = 0f;
            }
            else if (this.icon_delay > 0.4f)
            {
                this.icon_size = 0;
            }
        }
        else if (this.nextstart)
        {
            this.nextdelay -= Time.deltaTime;
            if (this.nextdelay <= 0f)
            {
                this.nextdelay = 0f;
                this.icon_posY += 500f * Time.deltaTime;
                if (this.icon_posY > 320f)
                {
                    this.nextstart = false;
                    this.script_ui.GoNext();
                }
            }
        }
        if (this.popupOn)
        {
            this.posX = Mathf.MoveTowards(this.posX, 20f, Time.deltaTime * 800f);
        }
        else
        {
            this.posX = Mathf.MoveTowards(this.posX, 112f, Time.deltaTime * 800f);
        }
    }
}


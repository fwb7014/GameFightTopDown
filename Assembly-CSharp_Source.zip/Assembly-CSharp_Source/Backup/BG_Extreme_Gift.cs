using System;
using UnityEngine;

public class BG_Extreme_Gift : MonoBehaviour
{
    private float delay;
    private bool movefinish;
    private Transform mytransform;
    private bool ptemit;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void OnEnable()
    {
        this.mytransform.localScale = Vector3.zero;
        this.movefinish = false;
        this.delay = 3f;
        this.ptemit = false;
    }

    private void Update()
    {
        if (this.movefinish)
        {
            if (this.mytransform.localScale.x < 0f)
            {
                this.movefinish = false;
                this.mytransform.localScale = Vector3.zero;
                base.gameObject.active = false;
                this.mytransform.rotation = Quaternion.identity;
            }
            else
            {
                this.mytransform.localScale -= (Vector3) ((Vector3.one * Time.deltaTime) * 8f);
                this.mytransform.Rotate((float) 0f, 0f, (float) (500f * Time.deltaTime));
            }
        }
        else if (this.delay > 0f)
        {
            if (this.mytransform.position.y > 2.2f)
            {
                this.mytransform.position -= (Vector3) ((Vector3.up * Time.deltaTime) * 3f);
            }
            else if (!this.ptemit)
            {
                this.mytransform.position = new Vector3(0f, 2.2f, 1.5f);
                this.mytransform.GetChild(0).particleEmitter.Emit();
                this.ptemit = true;
            }
            this.delay -= Time.deltaTime;
            this.mytransform.localScale = Vector3.MoveTowards(this.mytransform.localScale, (Vector3) (Vector3.one * 1.5f), Time.deltaTime * 5f);
        }
        else
        {
            this.movefinish = true;
        }
    }
}


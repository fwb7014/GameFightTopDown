using System;
using UnityEngine;

public class SoundEf_slash : MonoBehaviour
{
    public AudioClip block;
    public AudioClip block_break;
    private float delay;
    private AudioSource myaudio;
    private int rndsound;
    public AudioClip[] slash = new AudioClip[2];
    public AudioClip smash;
    public AudioClip split;
    public AudioClip thrust;

    private void Awake()
    {
        this.myaudio = base.audio;
    }

    public void SoundOn(int soundkind)
    {
        int num = soundkind;
        switch ((num + 1))
        {
            case 0:
                this.myaudio.PlayOneShot(this.block_break);
                break;

            case 1:
                this.myaudio.clip = this.block;
                this.myaudio.Play();
                break;

            case 2:
                if (this.delay <= 0f)
                {
                    this.rndsound = UnityEngine.Random.Range(0, 2);
                    this.myaudio.clip = this.slash[this.rndsound];
                    this.myaudio.Play();
                }
                break;

            case 3:
                this.myaudio.PlayOneShot(this.smash);
                break;

            case 4:
                this.myaudio.clip = this.thrust;
                this.myaudio.Play();
                break;

            case 5:
                this.myaudio.PlayOneShot(this.split);
                break;
        }
        this.delay = 0.05f;
    }

    private void Update()
    {
        if (this.delay > 0f)
        {
            this.delay -= Time.deltaTime;
        }
    }
}


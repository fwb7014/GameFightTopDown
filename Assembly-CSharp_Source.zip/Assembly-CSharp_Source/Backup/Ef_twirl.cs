using System;
using UnityEngine;

public class Ef_twirl : MonoBehaviour
{
    private int framesPerSecond = 180;
    private int index;
    private bool isloop;
    private int lastframe;
    private Renderer myrenderer;
    private Vector2 offset;
    private int oldindex;
    private Vector2 size;
    private float starttime;
    private float uIndex;
    private int uvAnimationTileX = 4;
    private int uvAnimationTileY = 4;
    private int vIndex;

    private void Awake()
    {
        this.myrenderer = base.renderer;
    }

    private void Start()
    {
        this.starttime = 0f;
        this.lastframe = this.uvAnimationTileX * this.uvAnimationTileY;
        this.myrenderer.enabled = false;
    }

    public void TwirlOff()
    {
        this.myrenderer.enabled = false;
    }

    public void TwirlOn(int x, int y, int fps, bool loop)
    {
        this.uvAnimationTileX = x;
        this.uvAnimationTileY = y;
        this.framesPerSecond = fps;
        this.myrenderer.enabled = true;
        this.starttime = 0f;
        this.lastframe = this.uvAnimationTileX * this.uvAnimationTileY;
        this.isloop = loop;
        this.size = new Vector2(1f / ((float) this.uvAnimationTileX), 1f / ((float) this.uvAnimationTileY));
    }

    private void Update()
    {
        if (this.myrenderer.enabled)
        {
            this.starttime += Time.deltaTime;
            this.index = (int) (this.starttime * this.framesPerSecond);
            if (this.isloop)
            {
                this.index = this.index % this.lastframe;
            }
            this.uIndex = this.index % this.uvAnimationTileX;
            this.vIndex = this.index / this.uvAnimationTileX;
            if (this.index != this.oldindex)
            {
                if (this.index >= this.lastframe)
                {
                    this.myrenderer.enabled = false;
                    this.oldindex = -1;
                }
                this.offset = new Vector2(this.uIndex * this.size.x, (1f - this.size.y) - (this.vIndex * this.size.y));
                this.myrenderer.sharedMaterial.SetTextureOffset("_MainTex", this.offset);
                this.myrenderer.sharedMaterial.SetTextureScale("_MainTex", this.size);
                this.oldindex = this.index;
            }
        }
    }
}


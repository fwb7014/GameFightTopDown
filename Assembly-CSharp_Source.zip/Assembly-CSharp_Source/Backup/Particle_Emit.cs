using System;
using UnityEngine;

public class Particle_Emit : MonoBehaviour
{
    private bool colliderexist;
    public float destroy_time;
    public float emitfinish_time;
    public bool ismoveup;
    private bool move;
    public float movespeed;
    private Collider mycollider;
    private Transform mytransform;
    public float show_time;

    private void Awake()
    {
        this.mytransform = base.transform;
        if (base.collider != null)
        {
            this.mycollider = base.collider;
            this.colliderexist = true;
        }
    }

    public void DestroyEmitter()
    {
        base.gameObject.active = false;
    }

    public void EmitFinish()
    {
        base.particleEmitter.emit = false;
        if (this.colliderexist)
        {
            base.CancelInvoke("RepeatDamage");
            this.mycollider.enabled = false;
        }
    }

    public void EmitStart()
    {
        base.particleEmitter.emit = true;
        this.move = true;
        if (this.colliderexist)
        {
            base.InvokeRepeating("RepeatDamage", 0.1f, 0.3f);
        }
    }

    private void OnEnable()
    {
        base.Invoke("EmitStart", this.show_time);
        base.Invoke("EmitFinish", this.emitfinish_time);
        base.Invoke("DestroyEmitter", this.destroy_time);
        this.move = false;
    }

    private void RepeatDamage()
    {
        this.mycollider.enabled = false;
        this.mycollider.enabled = true;
    }

    private void Update()
    {
        if (this.move)
        {
            if (!this.ismoveup)
            {
                this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * this.movespeed);
            }
            else
            {
                this.mytransform.position += (Vector3) ((Vector3.up * Time.deltaTime) * this.movespeed);
            }
        }
    }
}


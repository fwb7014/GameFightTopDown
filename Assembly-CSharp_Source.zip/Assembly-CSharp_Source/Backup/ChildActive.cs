using System;
using UnityEngine;

public class ChildActive : MonoBehaviour
{
    private Transform firstchild;

    private void Awake()
    {
        this.firstchild = base.transform.GetChild(0);
    }

    private void OnEnable()
    {
        this.firstchild.gameObject.active = true;
    }
}


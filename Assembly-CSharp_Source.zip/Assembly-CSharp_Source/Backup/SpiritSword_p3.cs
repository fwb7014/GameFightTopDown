using System;
using UnityEngine;

public class SpiritSword_p3 : MonoBehaviour
{
    private Vector3 directionVector;
    private float f_speed;
    private bool finish;
    private bool fireon;
    private Collider mycollider;
    private Transform myparent;
    private TrailRenderer mytrail;
    private Transform mytransform;
    private Vector3 n_pos;
    private Transform target;
    private Vector3 targetpos;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
        this.mytrail = base.GetComponent<TrailRenderer>();
    }

    public void FinishSword()
    {
        this.mycollider.enabled = false;
        this.fireon = false;
        this.f_speed = 0f;
        this.finish = true;
    }

    public void FireSword(Transform _enemy)
    {
        this.mycollider.enabled = true;
        this.target = _enemy;
        this.targetpos = this.target.position;
        this.directionVector = this.targetpos - this.mytransform.position;
        this.directionVector[1] = 0f;
        if (this.directionVector != Vector3.zero)
        {
            this.mytransform.forward = this.directionVector;
        }
        this.f_speed = 0.4f;
        this.fireon = true;
    }

    private void OnEnable()
    {
        this.finish = false;
        this.mycollider.enabled = false;
        this.f_speed = 0.4f;
        this.mytrail.enabled = true;
    }

    public void SetPos(int _index)
    {
        switch (_index)
        {
            case 0:
                this.n_pos = (Vector3) (new Vector3(1f, 0f, 1f) * 0.13f);
                break;

            case 1:
                this.n_pos = (Vector3) (new Vector3(1f, 0f, -1f) * 0.13f);
                break;

            case 2:
                this.n_pos = (Vector3) (new Vector3(-1f, 0f, 1f) * 0.13f);
                break;

            case 3:
                this.n_pos = (Vector3) (new Vector3(-1f, 0f, -1f) * 0.13f);
                break;
        }
    }

    private void Start()
    {
        this.myparent = this.mytransform.parent;
        this.mytransform.parent = null;
    }

    private void Update()
    {
        if (this.finish)
        {
            this.mytransform.position += (Vector3) ((Vector3.up * 3f) * Time.deltaTime);
            if (this.mytransform.position.y > 1f)
            {
                this.finish = false;
                this.mytrail.enabled = false;
                base.gameObject.active = false;
                base.CancelInvoke();
            }
        }
        else if (this.fireon)
        {
            this.f_speed -= Time.deltaTime;
            if (this.f_speed < 0f)
            {
                this.fireon = false;
            }
            else
            {
                this.mytransform.up = this.directionVector;
                this.mytransform.position += (Vector3) (((this.directionVector * Time.deltaTime) * this.f_speed) * 20f);
            }
        }
        else
        {
            this.mycollider.enabled = false;
            this.directionVector = (Vector3) (((this.myparent.position - this.mytransform.position) + (this.myparent.forward * this.n_pos.z)) + (this.myparent.right * this.n_pos.x));
            if (this.directionVector != Vector3.zero)
            {
                this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, Quaternion.LookRotation(this.directionVector), Time.deltaTime * 12f);
            }
            this.mytransform.position += (Vector3) ((this.directionVector * 3f) * Time.deltaTime);
            this.f_speed = 0f;
        }
    }
}


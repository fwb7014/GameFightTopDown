using System;
using UnityEngine;

public class Cam_Move_story : MonoBehaviour
{
    public GUISkin basic;
    public Texture2D cha_cutin;
    private string chaname;
    private float color_alpha;
    private int language;
    private Transform mytransform;
    private bool showcut;
    private string speech;
    private bool story_final;
    private bool trans;
    public Texture2D txt_box;
    private float updelay;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void OnGUI()
    {
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.skin = this.basic;
        if (this.story_final)
        {
            GUI.depth = -5;
            GUI.color = new Color(1f, 1f, 1f, this.color_alpha);
            GUI.DrawTexture(Crypto.Rect2(-64f, 0f, 320f, 320f), this.cha_cutin);
            if (this.mytransform.position.y > 0.3f)
            {
                this.showcut = false;
            }
            else if (this.mytransform.position.y > -0.9f)
            {
                this.showcut = true;
                GUI.Label(Crypto.Rect2(0f, 280f, 480f, 20f), this.chaname, "txt12_w");
                GUI.DrawTexture(Crypto.Rect2(150f, 40f, 256f, 64f), this.txt_box);
                GUI.Label(Crypto.Rect2(158f, 60f, 240f, 20f), this.speech, "txt12_0");
            }
        }
    }

    public void ShowOff()
    {
        this.color_alpha = 0f;
    }

    private void Start()
    {
        if (Application.loadedLevelName == "Story_5")
        {
            base.camera.projectionMatrix = Matrix4x4.Ortho(-1.5f, 1.5f, -1f, 1f, 0.01f, 10f);
            this.story_final = true;
            this.language = PlayerPrefs.GetInt("language");
            if (Crypto.Load_int_key("n06") != -1)
            {
                this.cha_cutin = Resources.Load("cc_yun0") as Texture2D;
                this.chaname = Language.intxt[this.language, 0x174] + " , 36 " + Language.intxt[this.language, 0x169];
                this.speech = Language.intxt[this.language, 0x176];
            }
            else
            {
                this.chaname = Language.intxt[this.language, 0x48] + " , 34 " + Language.intxt[this.language, 0x169];
                this.speech = Language.intxt[this.language, 50];
            }
        }
        else
        {
            this.mytransform.GetChild(0).camera.projectionMatrix = Matrix4x4.Perspective(60f, 1.5f, 0.01f, 5f);
        }
    }

    private void Update()
    {
        this.updelay += Time.deltaTime * 0.04f;
        this.mytransform.position += (Vector3) ((Vector3.up * Time.deltaTime) * this.updelay);
        if ((this.mytransform.position.y > 0.5f) && !this.trans)
        {
            GameObject.Find("scene_trans").GetComponent<Story_trans>().ScreenOn(2f);
            this.trans = true;
        }
        if (this.story_final)
        {
            if (this.showcut)
            {
                if (this.color_alpha < 1f)
                {
                    this.color_alpha += Time.deltaTime * 2f;
                }
                else
                {
                    this.color_alpha = 1f;
                }
            }
            else if (this.color_alpha > 0f)
            {
                this.color_alpha -= Time.deltaTime * 2f;
            }
            else
            {
                this.color_alpha = 0f;
            }
        }
    }
}


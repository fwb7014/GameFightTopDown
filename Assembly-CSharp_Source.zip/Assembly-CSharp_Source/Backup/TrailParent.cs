using System;
using UnityEngine;

public class TrailParent : MonoBehaviour
{
    private Transform mytransform;
    private Transform parent_cha;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.parent_cha = GameObject.FindWithTag("Player").transform;
    }

    private void Update()
    {
        this.mytransform.position = this.parent_cha.position;
    }
}


using System;
using UnityEngine;

public class Bullet_chaarrow : MonoBehaviour
{
    private Transform mytransform;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void Start()
    {
    }

    private void Update()
    {
        this.mytransform.position += (Vector3) ((4f * base.transform.forward) * Time.deltaTime);
        if (this.mytransform.position.y < 0f)
        {
            base.gameObject.active = false;
        }
    }
}


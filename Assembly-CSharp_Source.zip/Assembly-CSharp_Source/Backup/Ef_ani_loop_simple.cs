using System;
using UnityEngine;

public class Ef_ani_loop_simple : MonoBehaviour
{
    public int framesPerSecond = 20;
    private int index;
    public bool instance_material;
    private int lastframe;
    public bool loop;
    private Material mymaterial;
    private Renderer myrenderer;
    private Vector2 offset;
    private int oldindex = -1;
    private Vector2 size;
    private float starttime;
    public bool timetune;
    private float uIndex;
    public int uvAnimationTileX = 4;
    public int uvAnimationTileY = 4;
    private int vIndex;

    private void Awake()
    {
        this.myrenderer = base.renderer;
    }

    private void Start()
    {
        this.starttime = 0f;
        this.lastframe = this.uvAnimationTileX * this.uvAnimationTileY;
        this.size = new Vector2(1f / ((float) this.uvAnimationTileX), 1f / ((float) this.uvAnimationTileY));
        if (!this.instance_material)
        {
            this.mymaterial = this.myrenderer.sharedMaterial;
        }
        else
        {
            this.mymaterial = this.myrenderer.material;
        }
    }

    private void Update()
    {
        if (this.myrenderer.enabled)
        {
            if (!this.timetune)
            {
                this.starttime += Time.deltaTime;
            }
            else if (Time.timeScale != 0f)
            {
                this.starttime += Time.deltaTime / Time.timeScale;
            }
            this.index = (int) (this.starttime * this.framesPerSecond);
            if (this.loop)
            {
                this.index = this.index % this.lastframe;
            }
            this.uIndex = this.index % this.uvAnimationTileX;
            this.vIndex = this.index / this.uvAnimationTileX;
            if (this.index != this.oldindex)
            {
                if (this.index >= this.lastframe)
                {
                    this.starttime = 0f;
                    this.oldindex = -1;
                    base.gameObject.active = false;
                }
                this.offset = (Vector2) (((Vector2.right * this.uIndex) * this.size.x) + (Vector2.up * ((1f - this.size.y) - (this.vIndex * this.size.y))));
                this.mymaterial.mainTextureOffset = this.offset;
                this.mymaterial.mainTextureScale = this.size;
                this.oldindex = this.index;
            }
        }
    }
}


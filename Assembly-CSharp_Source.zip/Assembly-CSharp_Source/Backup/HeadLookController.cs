using System;
using System.Collections;
using UnityEngine;

public class HeadLookController : MonoBehaviour
{
    public float effect = 1f;
    public Vector3 headLookVector = Vector3.forward;
    public Vector3 headUpVector = Vector3.up;
    public NonAffectedJoints[] nonAffectedJoints;
    public bool overrideAnimation;
    public Transform rootNode;
    public BendingSegment[] segments;
    public Transform target;

    public static float AngleAroundAxis(Vector3 dirA, Vector3 dirB, Vector3 axis)
    {
        dirA -= Vector3.Project(dirA, axis);
        dirB -= Vector3.Project(dirB, axis);
        return (Vector3.Angle(dirA, dirB) * ((Vector3.Dot(axis, Vector3.Cross(dirA, dirB)) >= 0f) ? ((float) 1) : ((float) (-1))));
    }

    private void LateUpdate()
    {
        if (Time.deltaTime != 0f)
        {
            Vector3[] vectorArray = new Vector3[this.nonAffectedJoints.Length];
            for (int i = 0; i < this.nonAffectedJoints.Length; i++)
            {
                IEnumerator enumerator = this.nonAffectedJoints[i].joint.GetEnumerator();
                try
                {
                    while (enumerator.MoveNext())
                    {
                        Transform current = (Transform) enumerator.Current;
                        vectorArray[i] = current.position - this.nonAffectedJoints[i].joint.position;
                    }
                }
                finally
                {
                    IDisposable disposable = enumerator as IDisposable;
                    if (disposable == null)
                    {
                    }
                    disposable.Dispose();
                }
            }
            foreach (BendingSegment segment in this.segments)
            {
                Transform lastTransform = segment.lastTransform;
                if (this.overrideAnimation)
                {
                    for (int m = segment.chainLength - 1; m >= 0; m--)
                    {
                        lastTransform.localRotation = segment.origRotations[m];
                        lastTransform = lastTransform.parent;
                    }
                }
                Quaternion rotation = segment.firstTransform.parent.rotation;
                Quaternion quaternion2 = Quaternion.Inverse(rotation);
                Vector3 vector10 = this.target.position - segment.lastTransform.position;
                Vector3 normalized = vector10.normalized;
                Vector3 dirB = (Vector3) (quaternion2 * normalized);
                float f = AngleAroundAxis(segment.referenceLookDir, dirB, segment.referenceUpDir);
                Vector3 axis = Vector3.Cross(segment.referenceUpDir, dirB);
                Vector3 dirA = dirB - Vector3.Project(dirB, segment.referenceUpDir);
                float num5 = AngleAroundAxis(dirA, dirB, axis);
                float num6 = Mathf.Max((float) 0f, (float) (Mathf.Abs(f) - segment.thresholdAngleDifference)) * Mathf.Sign(f);
                float num7 = Mathf.Max((float) 0f, (float) (Mathf.Abs(num5) - segment.thresholdAngleDifference)) * Mathf.Sign(num5);
                f = (Mathf.Max((float) (Mathf.Abs(num6) * Mathf.Abs(segment.bendingMultiplier)), (float) (Mathf.Abs(f) - segment.maxAngleDifference)) * Mathf.Sign(f)) * Mathf.Sign(segment.bendingMultiplier);
                num5 = (Mathf.Max((float) (Mathf.Abs(num7) * Mathf.Abs(segment.bendingMultiplier)), (float) (Mathf.Abs(num5) - segment.maxAngleDifference)) * Mathf.Sign(num5)) * Mathf.Sign(segment.bendingMultiplier);
                f = Mathf.Clamp(f, -segment.maxBendingAngle, segment.maxBendingAngle);
                num5 = Mathf.Clamp(num5, -segment.maxBendingAngle, segment.maxBendingAngle);
                Vector3 vector5 = Vector3.Cross(segment.referenceUpDir, segment.referenceLookDir);
                segment.angleH = Mathf.Lerp(segment.angleH, f, Time.deltaTime * segment.responsiveness);
                segment.angleV = Mathf.Lerp(segment.angleV, num5, Time.deltaTime * segment.responsiveness);
                dirB = (Vector3) ((Quaternion.AngleAxis(segment.angleH, segment.referenceUpDir) * Quaternion.AngleAxis(segment.angleV, vector5)) * segment.referenceLookDir);
                Vector3 referenceUpDir = segment.referenceUpDir;
                Vector3.OrthoNormalize(ref dirB, ref referenceUpDir);
                Vector3 normal = dirB;
                segment.dirUp = Vector3.Slerp(segment.dirUp, referenceUpDir, Time.deltaTime * 5f);
                Vector3.OrthoNormalize(ref normal, ref segment.dirUp);
                Quaternion to = (rotation * Quaternion.LookRotation(normal, segment.dirUp)) * Quaternion.Inverse(rotation * Quaternion.LookRotation(segment.referenceLookDir, segment.referenceUpDir));
                Quaternion quaternion4 = Quaternion.Slerp(Quaternion.identity, to, this.effect / ((float) segment.chainLength));
                lastTransform = segment.lastTransform;
                for (int k = 0; k < segment.chainLength; k++)
                {
                    lastTransform.rotation = quaternion4 * lastTransform.rotation;
                    lastTransform = lastTransform.parent;
                }
            }
            for (int j = 0; j < this.nonAffectedJoints.Length; j++)
            {
                Vector3 vector9;
                Vector3 zero = Vector3.zero;
                IEnumerator enumerator2 = this.nonAffectedJoints[j].joint.GetEnumerator();
                try
                {
                    while (enumerator2.MoveNext())
                    {
                        Transform transform3 = (Transform) enumerator2.Current;
                        zero = transform3.position - this.nonAffectedJoints[j].joint.position;
                        goto Label_04A8;
                    }
                }
                finally
                {
                    IDisposable disposable2 = enumerator2 as IDisposable;
                    if (disposable2 == null)
                    {
                    }
                    disposable2.Dispose();
                }
            Label_04A8:
                vector9 = Vector3.Slerp(vectorArray[j], zero, this.nonAffectedJoints[j].effect);
                this.nonAffectedJoints[j].joint.rotation = Quaternion.FromToRotation(zero, vector9) * this.nonAffectedJoints[j].joint.rotation;
            }
        }
    }

    private void Start()
    {
        if (this.rootNode == null)
        {
            this.rootNode = base.transform;
        }
        foreach (BendingSegment segment in this.segments)
        {
            Quaternion quaternion2 = Quaternion.Inverse(segment.firstTransform.parent.rotation);
            segment.referenceLookDir = (Vector3) ((quaternion2 * this.rootNode.rotation) * this.headLookVector.normalized);
            segment.referenceUpDir = (Vector3) ((quaternion2 * this.rootNode.rotation) * this.headUpVector.normalized);
            segment.angleH = 0f;
            segment.angleV = 0f;
            segment.dirUp = segment.referenceUpDir;
            segment.chainLength = 1;
            Transform lastTransform = segment.lastTransform;
            while ((lastTransform != segment.firstTransform) && (lastTransform != lastTransform.root))
            {
                segment.chainLength++;
                lastTransform = lastTransform.parent;
            }
            segment.origRotations = new Quaternion[segment.chainLength];
            lastTransform = segment.lastTransform;
            for (int i = segment.chainLength - 1; i >= 0; i--)
            {
                segment.origRotations[i] = lastTransform.localRotation;
                lastTransform = lastTransform.parent;
            }
        }
    }
}


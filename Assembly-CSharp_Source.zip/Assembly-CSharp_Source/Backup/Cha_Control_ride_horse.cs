using System;
using UnityEngine;

public class Cha_Control_ride_horse : MonoBehaviour
{
    private float action_delay;
    public AudioClip behit;
    private RaycastHit casthit;
    public Transform cha1;
    private short changeScene;
    private float dragdistanceY;
    private Vector2 dragStartpos = Vector2.zero;
    private float dragSumposY;
    private float dubbleclick;
    private bool finish;
    private bool isintro = true;
    public AudioClip jump;
    private bool keydown;
    private Vector3 leftlean = new Vector3(-1f, 0f, 2f);
    public GameObject map;
    private short monmovestat;
    private float movespeed;
    private Transform mytransform;
    private Vector3 pickPoint;
    private Vector3 prevPoint;
    public Transform pt_stepfog;
    private Vector3 rightlean = new Vector3(1f, 0f, 2f);
    public AudioClip run;
    private Cha_Control_ride_cha script_cha;
    private float startdelay;
    public Texture[] tex_stepfog = new Texture[5];

    private void Awake()
    {
        UnityEngine.Object.DontDestroyOnLoad(base.gameObject);
        this.mytransform = base.transform;
    }

    public void FallDown()
    {
        if (!this.finish)
        {
            base.rigidbody.AddForce((Vector3) (Vector3.forward * -130f));
            base.animation.Play("horse_cry");
        }
    }

    public void HorseJump()
    {
        base.audio.clip = this.jump;
        base.audio.Play();
        base.animation.Play("horse_jump");
    }

    public void RidingFinish()
    {
        base.audio.clip = this.run;
        base.audio.Play();
        this.isintro = true;
        this.startdelay = 0f;
        this.finish = true;
        this.script_cha.Finish();
    }

    private void Start()
    {
        this.script_cha = this.cha1.GetComponent<Cha_Control_ride_cha>();
        this.mytransform.position = new Vector3(0f, 0f, -0.5f);
        base.animation["horse_run"].speed = 0.7f;
        base.animation["horse_jump"].speed = 0.34f;
        base.animation["horse_cry"].speed = 0.5f;
        base.animation["horse_jump"].layer = 1;
        base.animation["horse_cry"].layer = 2;
        base.animation.Play("horse_run");
        int num = Crypto.Load_int_key("cur_stage_kind");
        this.pt_stepfog.renderer.sharedMaterial.mainTexture = this.tex_stepfog[num - 1];
    }

    private void Update()
    {
        if (this.isintro)
        {
            if (this.finish)
            {
                if (this.changeScene != 2)
                {
                    if (this.changeScene == 1)
                    {
                        base.transform.position = Vector3.zero;
                        base.animation.Play("horse_stand");
                        base.audio.Stop();
                        base.animation.Stop();
                        base.animation["horse_cry"].speed = 0.25f;
                        base.animation.Play("horse_cry");
                        base.audio.PlayOneShot(this.behit);
                        AnimationState state = base.animation.PlayQueued("horse_stand");
                        state.layer = 2;
                        state.speed = 0.1f;
                        this.changeScene = 2;
                    }
                    else if (this.changeScene == 0)
                    {
                        if (this.mytransform.position.z > 2f)
                        {
                            this.script_cha.CrynStop();
                            UnityEngine.Object.Destroy(this.pt_stepfog.gameObject);
                            Application.LoadLevel("Result_ride");
                            this.changeScene = 1;
                        }
                        else
                        {
                            this.mytransform.position += (Vector3) (Vector3.forward * Time.deltaTime);
                            this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, Quaternion.LookRotation(Vector3.forward), Time.deltaTime * 5f);
                        }
                    }
                }
            }
            else if (this.startdelay > 1f)
            {
                this.isintro = false;
            }
            else if (this.mytransform.position.z < 0f)
            {
                this.mytransform.position += (Vector3) ((Vector3.forward * 0.4f) * Time.deltaTime);
            }
            this.startdelay += Time.deltaTime;
        }
        else
        {
            if (((Mathf.Abs(this.mytransform.position.x) > 0.7f) || (this.mytransform.position.z > 1f)) || (this.mytransform.position.z < -0.4f))
            {
                this.mytransform.position = Vector3.Lerp(this.mytransform.position, Vector3.zero, Time.deltaTime * 1f);
                this.pickPoint = Vector3.zero;
            }
            else if (Input.anyKeyDown)
            {
                this.dragStartpos = Input.mousePosition;
            }
            else if (Input.anyKey)
            {
                this.keydown = true;
                this.dragdistanceY = (Input.mousePosition.y - this.dragStartpos.y) * Time.deltaTime;
                if (this.dragdistanceY > (0.001 * Screen.height))
                {
                    this.dragSumposY += this.dragdistanceY;
                }
                else
                {
                    this.dragSumposY = 0f;
                }
                this.dragStartpos = Input.mousePosition;
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                if ((this.dragSumposY > (0.003f * Screen.height)) && (this.monmovestat == 1))
                {
                    this.HorseJump();
                    this.dragSumposY = 0f;
                }
                else if (((this.dubbleclick < 0.25f) && (this.monmovestat == 1)) && (Vector3.Distance(Input.mousePosition, this.prevPoint) < 50f))
                {
                    this.HorseJump();
                }
                if (this.map.collider.Raycast(ray, out this.casthit, 4f))
                {
                    this.pickPoint = this.casthit.point;
                    base.animation.CrossFade("horse_run");
                }
                this.movespeed = 0.5f;
                if ((this.pickPoint.x - this.mytransform.position.x) > 0.01f)
                {
                    this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, Quaternion.LookRotation(this.rightlean), Time.deltaTime * 3f);
                }
                else if ((this.pickPoint.x - this.mytransform.position.x) < -0.01f)
                {
                    this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, Quaternion.LookRotation(this.leftlean), Time.deltaTime * 3f);
                }
                else
                {
                    this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, Quaternion.LookRotation(Vector3.forward), Time.deltaTime * 3f);
                }
            }
            else if (this.keydown)
            {
                this.dubbleclick = 0f;
                this.prevPoint = Input.mousePosition;
                this.keydown = false;
            }
            else
            {
                this.dubbleclick += 2f * Time.deltaTime;
                this.dragSumposY = 0f;
                if (this.movespeed > 0f)
                {
                    this.movespeed -= Time.deltaTime;
                }
                else
                {
                    this.movespeed = 0f;
                }
                this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, Quaternion.LookRotation(Vector3.forward), Time.deltaTime * 3f);
            }
            this.mytransform.position = Vector3.MoveTowards(this.mytransform.position, this.pickPoint, Time.deltaTime * this.movespeed);
            if (base.animation.IsPlaying("horse_cry"))
            {
                if (this.monmovestat != 3)
                {
                    base.audio.PlayOneShot(this.behit);
                    this.monmovestat = 3;
                }
            }
            else if (this.action_delay > 0f)
            {
                this.action_delay -= Time.deltaTime;
                this.monmovestat = 4;
            }
            else if (base.animation.IsPlaying("horse_jump"))
            {
                this.monmovestat = 2;
            }
            else if (base.animation.IsPlaying("horse_run") && (this.monmovestat != 1))
            {
                base.audio.clip = this.run;
                base.audio.Play();
                this.monmovestat = 1;
            }
        }
    }
}


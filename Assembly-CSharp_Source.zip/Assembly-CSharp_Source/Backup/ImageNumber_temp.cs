using System;
using UnityEngine;

public class ImageNumber_temp : MonoBehaviour
{
    public Vector2[] imagenumber = new Vector2[6];
    private int index;
    public Texture num;
    public int[] number = new int[6];
    private const int SIZE = 6;
    private short size_a;
    private int uvAnimationTileX = 5;
    private int uvAnimationTileY = 2;

    public Vector2[] ImageNum(int a)
    {
        this.size_a = 0;
        for (int i = 0; i < 4; i++)
        {
            this.number[i] = a % 10;
            a /= 10;
            if (a != 0)
            {
                this.size_a = (short) (this.size_a + 1);
            }
        }
        for (int j = 0; j < this.size_a; j++)
        {
            this.index = this.number[j];
            Vector2 vector = new Vector2(1f / ((float) this.uvAnimationTileX), 1f / ((float) this.uvAnimationTileY));
            float num3 = this.index % this.uvAnimationTileX;
            int num4 = this.index / this.uvAnimationTileX;
            this.imagenumber[j] = new Vector2(num3 * vector.x, (1f - vector.y) - (num4 * vector.y));
        }
        return this.imagenumber;
    }

    private void Start()
    {
    }

    private void Update()
    {
    }
}


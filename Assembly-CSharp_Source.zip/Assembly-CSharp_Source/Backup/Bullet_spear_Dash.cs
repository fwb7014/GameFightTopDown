using System;
using UnityEngine;

public class Bullet_spear_Dash : MonoBehaviour
{
    private float delay;
    private Transform mytransform;
    private Vector3 originscale;
    private bool shoot;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.originscale = this.mytransform.localScale;
    }

    private void OnEnable()
    {
        this.mytransform.localScale = this.originscale;
        this.delay = 0f;
        this.shoot = false;
    }

    private void Update()
    {
        if (this.delay < 0.4f)
        {
            this.delay += Time.deltaTime;
        }
        else if (!this.shoot)
        {
            this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * 1.5f);
            this.mytransform.localScale += (Vector3) ((Vector3.forward * 30f) * Time.deltaTime);
            if (this.mytransform.localScale.z > 3f)
            {
                this.mytransform.localScale = (Vector3) ((Vector3.one * 2f) + (Vector3.forward * 2f));
                this.shoot = true;
            }
        }
        else if (this.shoot)
        {
            this.mytransform.localScale -= (Vector3) ((Vector3.forward * 3f) * Time.deltaTime);
            this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * 0.5f);
            if (this.mytransform.localScale.z < 0.1f)
            {
                base.gameObject.active = false;
            }
        }
    }
}


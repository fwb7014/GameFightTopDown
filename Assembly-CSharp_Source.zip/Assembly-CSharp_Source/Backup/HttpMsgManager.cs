using LitJson;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class HttpMsgManager : MonoBehaviour
{
    private string errorString = string.Empty;
    private string httpHost = "http://192.168.21.76:30001";
    private const int MSG_GETRANK = 0x2711;
    private string password = string.Empty;
    private bool showErrorWindow;
    private string userName = string.Empty;

    private void DoMyWindow(int windowID)
    {
        GUI.skin.label.fontSize = 20;
        GUI.Label(new Rect(10f, 20f, 220f, 200f), this.errorString);
        if (GUI.Button(new Rect(75f, 140f, 100f, 30f), "确定"))
        {
            this.showErrorWindow = false;
        }
    }

    private void errorParse(int code)
    {
    }

    public void getRankList()
    {
        Dictionary<string, string> post = new Dictionary<string, string>();
        post.Add("msgId", 0x2711.ToString());
        base.StartCoroutine(this.POST(this.httpHost + "/rank", post));
    }

    private void OnGUI()
    {
        if (this.showErrorWindow)
        {
            GUI.Window(0, new Rect(400f, 250f, 250f, 170f), new GUI.WindowFunction(this.DoMyWindow), "错误");
        }
    }

    [DebuggerHidden]
    private IEnumerator POST(string url, Dictionary<string, string> post)
    {
        return new <POST>c__IteratorF { post = post, url = url, <$>post = post, <$>url = url, <>f__this = this };
    }

    private void Start()
    {
    }

    private void Update()
    {
    }

    [CompilerGenerated]
    private sealed class <POST>c__IteratorF : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal Dictionary<string, string> <$>post;
        internal string <$>url;
        internal Dictionary<string, string>.Enumerator <$s_7>__1;
        internal HttpMsgManager <>f__this;
        internal int <code>__6;
        internal JSONNode <data>__4;
        internal WWWForm <form>__0;
        internal int <id>__7;
        internal KeyValuePair<string, string> <post_arg>__2;
        internal int <querySuccess>__5;
        internal WWW <www>__3;
        internal Dictionary<string, string> post;
        internal string url;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<form>__0 = new WWWForm();
                    this.<$s_7>__1 = this.post.GetEnumerator();
                    try
                    {
                        while (this.<$s_7>__1.MoveNext())
                        {
                            this.<post_arg>__2 = this.<$s_7>__1.Current;
                            this.<form>__0.AddField(this.<post_arg>__2.Key, this.<post_arg>__2.Value);
                        }
                    }
                    finally
                    {
                        this.<$s_7>__1.Dispose();
                    }
                    this.<www>__3 = new WWW(this.url, this.<form>__0);
                    this.$current = this.<www>__3;
                    this.$PC = 1;
                    return true;

                case 1:
                    if (this.<www>__3.error == null)
                    {
                        this.<data>__4 = JSON.Parse(this.<www>__3.text);
                        this.<querySuccess>__5 = int.Parse(this.<data>__4["querySuccess"].ToString());
                        this.<code>__6 = int.Parse(this.<data>__4["code"].ToString());
                        if (this.<querySuccess>__5 > 0)
                        {
                            this.<id>__7 = int.Parse(this.<data>__4["msgId"].ToString());
                            if (this.<id>__7 == 0x2711)
                            {
                            }
                        }
                        else
                        {
                            this.<>f__this.errorParse(this.<code>__6);
                        }
                        break;
                    }
                    UnityEngine.Debug.Log("error is :" + this.<www>__3.error);
                    this.<>f__this.errorString = this.<www>__3.error;
                    this.<>f__this.showErrorWindow = true;
                    break;

                default:
                    goto Label_01D5;
            }
            this.$PC = -1;
        Label_01D5:
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }
}


using System;
using UnityEngine;

public class Bullet_runswing_b06 : MonoBehaviour
{
    private float collideron_delay;
    private float current_time;
    private float disable_delay;
    public Transform ef_trail;
    private Collider mycollider;

    private void Awake()
    {
        this.mycollider = base.collider;
        this.collideron_delay = 0.2f;
        this.disable_delay = 0.4f;
        base.gameObject.active = false;
    }

    private void OnEnable()
    {
        this.ef_trail.gameObject.active = true;
        this.mycollider.enabled = false;
        this.current_time = 0f;
    }

    private void Update()
    {
        this.current_time += Time.deltaTime;
        if (this.current_time > this.disable_delay)
        {
            base.gameObject.active = false;
            this.mycollider.enabled = false;
            this.current_time = 0f;
        }
        else if (this.current_time > this.collideron_delay)
        {
            this.mycollider.enabled = true;
        }
    }
}


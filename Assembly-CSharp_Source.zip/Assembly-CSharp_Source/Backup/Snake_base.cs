using System;
using UnityEngine;

public class Snake_base : MonoBehaviour
{
    private float finish_delay;
    private Collider mycollider;
    private Transform mytransform;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
    }

    private void ColliderOn()
    {
        this.mycollider.enabled = false;
        this.mycollider.enabled = true;
    }

    private void OnEnable()
    {
        this.finish_delay = 0f;
        this.mytransform.localScale = Vector3.zero;
        this.mytransform.GetChild(0).gameObject.active = true;
        this.mytransform.GetChild(1).gameObject.active = true;
        base.particleEmitter.emit = true;
        base.InvokeRepeating("ColliderOn", 0.3f, 0.5f);
    }

    private void Update()
    {
        this.finish_delay += Time.deltaTime;
        if (this.finish_delay > 8f)
        {
            base.gameObject.active = false;
            this.mytransform.GetChild(0).gameObject.active = false;
            this.mytransform.GetChild(1).gameObject.active = false;
            base.CancelInvoke();
        }
        else if (this.finish_delay > 6f)
        {
            base.particleEmitter.emit = false;
            this.mytransform.localScale = Vector3.MoveTowards(this.mytransform.localScale, Vector3.zero, Time.deltaTime * 3f);
        }
        else
        {
            this.mytransform.localScale = Vector3.MoveTowards(this.mytransform.localScale, Vector3.one, Time.deltaTime * 3f);
        }
    }
}


using System;
using UnityEngine;

public class CmBillingAndroid
{
    private static CmBillingAndroid _instance;
    private AndroidJavaClass klass = new AndroidJavaClass("com.nhncorp.skundeadck.MainActivity");

    public void DoBilling(string _index, string _name, string _price, int _telecomPayCode, bool _alipay)
    {
        Debug.Log("DoBilling start!!");
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
        {
            using (AndroidJavaObject obj2 = class2.GetStatic<AndroidJavaObject>("currentActivity"))
            {
                object[] args = new object[] { _index, _name, _price, _telecomPayCode, _alipay };
                obj2.Call("DobillingStart", args);
            }
        }
        Debug.Log("DoBilling finish!!");
    }

    public void Exit()
    {
        this.klass.CallStatic("exitApp", new object[0]);
    }

    public void ExitWithUI()
    {
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
        {
            using (AndroidJavaObject obj2 = class2.GetStatic<AndroidJavaObject>("currentActivity"))
            {
                object[] args = new object[] { obj2 };
                this.klass.CallStatic("exit", args);
            }
        }
    }

    public bool GetActivateFlag(string index)
    {
        object[] args = new object[] { index };
        return this.klass.CallStatic<bool>("getActivateFlag", args);
    }

    public string GetBillingResult(string index)
    {
        object[] args = new object[] { index };
        return this.klass.CallStatic<string>("getBillingResult", args);
    }

    public void GetCash(string _id, string _name, int _price)
    {
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
        {
            using (class2.GetStatic<AndroidJavaObject>("currentActivity"))
            {
                object[] args = new object[] { SystemInfo.deviceUniqueIdentifier, _id, _name, _price };
                this.klass.CallStatic("BuyJade", args);
            }
        }
    }

    public void InitializeApp(string chanelID, string aliPayKey, string aliPaySecret)
    {
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
        {
            using (class2.GetStatic<AndroidJavaObject>("currentActivity"))
            {
                object[] args = new object[] { chanelID, aliPayKey, aliPaySecret };
                this.klass.CallStatic("InitHS", args);
            }
        }
    }

    public bool IsMusicEnabled()
    {
        return this.klass.CallStatic<bool>("isMusicEnabled", new object[0]);
    }

    public void Log_LogIn(string _deviceID, int _chaLV)
    {
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
        {
            using (class2.GetStatic<AndroidJavaObject>("currentActivity"))
            {
                object[] args = new object[] { _deviceID, _chaLV };
                this.klass.CallStatic("Log_LogIn", args);
            }
        }
    }

    public void Log_LogOut(string _deviceID, int _chaLV, long _playTime)
    {
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
        {
            using (class2.GetStatic<AndroidJavaObject>("currentActivity"))
            {
                object[] args = new object[] { _deviceID, _chaLV, _playTime };
                this.klass.CallStatic("Log_LogOut", args);
            }
        }
    }

    public void Redeem(string _code)
    {
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
        {
            using (class2.GetStatic<AndroidJavaObject>("currentActivity"))
            {
                object[] args = new object[] { _code };
                this.klass.CallStatic("redeemClicked", args);
            }
        }
    }

    public void SetActivateFlag(string index, bool flag)
    {
        object[] args = new object[] { index, flag };
        this.klass.CallStatic("setActivateFlag", args);
    }

    public void UseCash(string _id, string _name, int _price)
    {
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
        {
            using (class2.GetStatic<AndroidJavaObject>("currentActivity"))
            {
                object[] args = new object[] { SystemInfo.deviceUniqueIdentifier, _id, _name, _price };
                this.klass.CallStatic("UseJade", args);
            }
        }
    }

    public static CmBillingAndroid Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = new CmBillingAndroid();
            }
            return _instance;
        }
    }

    public class BillingResult
    {
        public const string CANCELLED = "3";
        public const string FAILED = "2";
        public const string NONE = "0";
        public const string SUCCESS = "1";
    }
}


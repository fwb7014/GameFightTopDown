using System;
using UnityEngine;

public class Splash_angel_poison : MonoBehaviour
{
    private float delay = 2.5f;
    private Transform mytransform;

    private void Awake()
    {
        this.mytransform = base.transform;
        base.gameObject.active = false;
    }

    private void OnEnable()
    {
        this.delay = 2.5f;
    }

    private void Update()
    {
        if (this.delay < 0f)
        {
            this.mytransform.position -= (Vector3) ((Vector3.up * Time.deltaTime) * 0.05f);
            if (this.mytransform.position.y < -0.05f)
            {
                base.gameObject.active = false;
            }
        }
        else
        {
            this.delay -= Time.deltaTime;
        }
    }
}


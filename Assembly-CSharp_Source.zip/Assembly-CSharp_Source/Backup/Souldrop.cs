using System;
using UnityEngine;

public class Souldrop : MonoBehaviour
{
    private Transform cha1;
    private Vector3 directionVector;
    private float finish_delay = 4f;
    private Collider mycollider;
    private Transform mytransform;
    private Quaternion rotate;
    private Vector3 targetVector;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
    }

    public void Finish()
    {
        base.gameObject.active = false;
        this.mytransform.position = (Vector3) (Vector3.one * 34f);
    }

    private void OnEnable()
    {
        this.directionVector = (Vector3) (Vector3.up * 2f);
        base.particleEmitter.emit = true;
        this.finish_delay = 4f;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == 15)
        {
            this.mytransform.position = this.cha1.position;
            this.mycollider.enabled = false;
            base.particleEmitter.emit = false;
            base.Invoke("Finish", 0.5f);
        }
    }

    private void Start()
    {
        this.cha1 = GameObject.FindWithTag("Player").transform;
        base.gameObject.active = false;
    }

    private void Update()
    {
        if (this.finish_delay < 0f)
        {
            this.Finish();
            this.finish_delay = 4f;
        }
        else if (this.finish_delay < 3f)
        {
            this.mycollider.enabled = true;
        }
        else
        {
            this.finish_delay -= Time.deltaTime;
        }
        this.targetVector = Vector3.Normalize((this.cha1.position - this.mytransform.position) + ((Vector3) (Vector3.up * 0.05f)));
        this.directionVector = Vector3.MoveTowards(this.directionVector, this.targetVector, Time.deltaTime * 5f);
        this.mytransform.position += (Vector3) (this.directionVector * Time.deltaTime);
    }
}


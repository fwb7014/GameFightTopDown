using System;
using UnityEngine;

public class Bullet_Angel2 : MonoBehaviour
{
    private float delay;
    public float delay_collision = 0.2f;
    public float delay_destroy = 0.6f;
    private bool impactOn;
    private Collider mycollider;
    private Transform mytransform;
    private AI_Asist script_angel;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
        this.script_angel = GameObject.Find("asist").GetComponent<AI_Asist>();
        base.gameObject.active = false;
    }

    private void OnEnable()
    {
        base.collider.enabled = false;
        this.delay = 0f;
        this.impactOn = false;
        this.mytransform.rotation = Quaternion.LookRotation(new Vector3(this.mytransform.forward.x, 0f, this.mytransform.forward.z));
        base.particleEmitter.Emit();
    }

    private void Update()
    {
        if (this.delay > this.delay_destroy)
        {
            this.mycollider.enabled = false;
            base.particleEmitter.ClearParticles();
            base.gameObject.active = false;
        }
        else if (!this.impactOn && (this.delay > this.delay_collision))
        {
            this.script_angel.AttackFinish();
            this.mycollider.enabled = true;
            this.impactOn = true;
        }
        this.delay += Time.deltaTime;
    }
}


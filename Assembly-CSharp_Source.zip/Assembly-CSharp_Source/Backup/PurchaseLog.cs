using System;
using System.IO;
using UnityEngine;

public static class PurchaseLog
{
    public static void FileCreat()
    {
        using (StreamWriter writer = new StreamWriter(Application.persistentDataPath + "/purchaselog.txt", true))
        {
            writer.WriteLine("\r\n");
        }
    }

    public static void LogOn(string _log)
    {
        using (StreamWriter writer = new StreamWriter(Application.persistentDataPath + "/purchaselog.txt", true))
        {
            writer.WriteLine(DateTime.Now.ToString() + "\r\n\t\t" + _log + "\r\n");
            writer.Close();
        }
    }
}


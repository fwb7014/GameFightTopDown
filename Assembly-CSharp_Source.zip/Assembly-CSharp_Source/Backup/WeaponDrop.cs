using System;
using UnityEngine;

public class WeaponDrop : MonoBehaviour
{
    private bool drop;
    private float maxy = 1.7f;
    private Transform mytransform;
    private Vector3 rotateaxis;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.rotateaxis = this.mytransform.right;
    }

    private void Disappear()
    {
        this.mytransform.position = (Vector3) (Vector3.one * 4f);
        base.gameObject.active = false;
    }

    public void Drop(bool _destroy)
    {
        base.CancelInvoke("Disappear");
        if (_destroy)
        {
            UnityEngine.Object.Destroy(base.gameObject, 2.5f);
        }
        else
        {
            base.Invoke("Disappear", 3.5f);
        }
        this.drop = true;
        this.maxy = 1.7f;
    }

    public void DropCancel()
    {
        base.CancelInvoke("Disappear");
        this.drop = false;
    }

    private void Update()
    {
        if (this.drop)
        {
            if (this.mytransform.position.y > 0f)
            {
                this.mytransform.Rotate((Vector3) ((this.rotateaxis * Time.deltaTime) * 720f));
                this.maxy -= 3.5f * Time.deltaTime;
                this.mytransform.position += (Vector3) ((Vector3.up * this.maxy) * Time.deltaTime);
            }
            else
            {
                this.mytransform.position = (Vector3) ((Vector3.right * this.mytransform.position.x) + (Vector3.forward * this.mytransform.position.z));
                this.drop = false;
            }
        }
    }
}


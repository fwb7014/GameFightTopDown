using System;
using UnityEngine;

public class Pet_horse : MonoBehaviour
{
    private Transform cha1;
    private bool disappear;
    private float disappeardelay;
    public AudioClip horse_cry;
    private float horsedistance;
    private Transform mytransform;
    private bool rideon;
    private Cha_Control script_cha1;
    private bool skillon;
    private AnimationState temp;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    public void GetOffHorse()
    {
        this.rideon = false;
        this.mytransform.parent = null;
        base.animation.Stop();
        base.animation.Play("horse_cry");
        this.temp = base.animation.PlayQueued("horse_run", QueueMode.CompleteOthers);
        this.temp.speed = base.animation["horse_run"].speed;
        this.disappear = true;
        base.audio.Stop();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.transform.IsChildOf(this.cha1) && !this.rideon)
        {
            this.script_cha1.RideHorse();
            this.rideon = true;
        }
    }

    public void RideandCry()
    {
        this.mytransform.parent = this.cha1;
        this.mytransform.position = this.mytransform.root.position;
        this.mytransform.rotation = this.mytransform.root.rotation;
        base.animation.Stop();
        base.audio.PlayOneShot(this.horse_cry);
        base.animation.Play("horse_cry");
        this.temp = base.animation.PlayQueued("horse_stand");
        this.temp.speed = base.animation["horse_stand"].speed;
    }

    public void Rideing(bool _stop)
    {
        if (_stop)
        {
            this.rideon = false;
            this.mytransform.parent = null;
            this.mytransform.position = (Vector3) (Vector3.one * 71f);
        }
        else
        {
            this.rideon = true;
            this.mytransform.parent = this.cha1;
            this.mytransform.position = this.mytransform.root.position;
            this.mytransform.rotation = this.mytransform.root.rotation;
        }
    }

    public void RunStart(bool a)
    {
        if (a)
        {
            base.animation.Play("horse_run");
            base.audio.Play();
        }
        else
        {
            base.animation.CrossFade("horse_stand");
            base.audio.Stop();
        }
    }

    public void SkillOn()
    {
        base.gameObject.active = true;
        float f = UnityEngine.Random.Range(0, 360);
        Vector3 vector = this.cha1.position + ((Vector3) (new Vector3(Mathf.Cos(f), 0f, Mathf.Sin(f)) * 2f));
        this.mytransform.position = vector;
        this.skillon = true;
        this.disappear = false;
        Vector3 forward = this.cha1.position - this.mytransform.position;
        forward = new Vector3(forward.x, 0f, forward.z);
        if (forward != Vector3.zero)
        {
            this.mytransform.rotation = Quaternion.LookRotation(forward);
        }
        base.animation.Play("horse_run");
    }

    private void Start()
    {
        base.animation["horse_run"].layer = 1;
        base.animation["horse_stand"].layer = 1;
        base.animation["horse_cry"].layer = 1;
        base.animation["horse_jump"].layer = 1;
        base.animation["horse_run"].speed = 0.6f;
        base.animation["horse_stand"].speed = 0.1f;
        base.animation["horse_cry"].speed = 0.32f;
        base.animation["horse_jump"].speed = 0.3f;
        this.cha1 = GameObject.FindWithTag("Player").transform;
        this.script_cha1 = this.cha1.GetComponent<Cha_Control>();
        base.animation.Play("horse_stand");
    }

    private void Update()
    {
        if (this.disappear && !base.animation.IsPlaying("horse_cry"))
        {
            if (this.disappeardelay < 3f)
            {
                this.disappeardelay += Time.deltaTime;
                this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * 0.8f);
            }
            else
            {
                this.disappear = false;
                this.disappeardelay = 0f;
                this.mytransform.position = (Vector3) (Vector3.one * 4f);
                base.gameObject.active = false;
            }
        }
        else if (this.skillon)
        {
            this.horsedistance = Vector3.Distance(this.cha1.position, this.mytransform.position);
            if ((this.horsedistance <= 1.5f) && !this.rideon)
            {
                base.animation.Stop();
                base.animation.Play("horse_jump");
                this.temp = base.animation.PlayQueued("horse_stand");
                this.temp.speed = base.animation["horse_stand"].speed;
                this.rideon = true;
            }
            if (!base.animation.IsPlaying("horse_stand"))
            {
                this.mytransform.position = Vector3.Lerp(this.mytransform.position, this.cha1.position, Time.deltaTime * 3.5f);
            }
            else
            {
                this.skillon = false;
            }
        }
    }
}


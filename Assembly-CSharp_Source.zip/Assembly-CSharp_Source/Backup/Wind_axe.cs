using System;
using UnityEngine;

public class Wind_axe : MonoBehaviour
{
    private Transform cha1;
    private float finish_delay;
    private Transform mytransform;
    private Vector3 originscale;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.cha1 = GameObject.FindWithTag("Player").transform;
        this.originscale = this.mytransform.localScale;
        this.mytransform.GetChild(0).animation["tornado"].speed = 0.2f;
    }

    private void OnEnable()
    {
        this.mytransform.localScale = Vector3.zero;
        this.mytransform.GetChild(0).gameObject.active = true;
        this.finish_delay = 0f;
    }

    private void Update()
    {
        this.mytransform.position = this.cha1.position;
        this.finish_delay += Time.deltaTime;
        if (this.finish_delay > 1.5f)
        {
            this.mytransform.localScale = Vector3.MoveTowards(this.mytransform.localScale, Vector3.zero, Time.deltaTime * 5f);
        }
        else
        {
            this.mytransform.localScale = Vector3.MoveTowards(this.mytransform.localScale, this.originscale, Time.deltaTime * 3f);
        }
    }
}


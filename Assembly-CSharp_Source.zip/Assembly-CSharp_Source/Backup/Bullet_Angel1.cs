using System;
using UnityEngine;

public class Bullet_Angel1 : MonoBehaviour
{
    public float bullet_speed = 2f;
    private ParticleSystem mychild;
    private Transform mytransform;
    private AI_Asist script_angel;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.script_angel = GameObject.Find("asist").GetComponent<AI_Asist>();
        base.gameObject.active = false;
        if (this.mytransform.childCount > 0)
        {
            this.mychild = this.mytransform.GetChild(0).particleSystem;
        }
    }

    private void OnEnable()
    {
        if (this.mychild != null)
        {
            this.mychild.Play();
        }
    }

    private void Update()
    {
        this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * this.bullet_speed);
        if (this.mytransform.position.y < 0f)
        {
            this.script_angel.AttackFinish();
            base.gameObject.active = false;
        }
    }
}


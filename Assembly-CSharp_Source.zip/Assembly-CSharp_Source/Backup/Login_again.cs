using System;
using UnityEngine;

public class Login_again : MonoBehaviour
{
    private void OnApplicationPause(bool pocus)
    {
        if (pocus && (Application.loadedLevelName != "Ready"))
        {
        }
    }

    private void Start()
    {
        UnityEngine.Object.DontDestroyOnLoad(base.gameObject);
    }

    private void Update()
    {
    }
}


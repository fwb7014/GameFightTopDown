using System;
using UnityEngine;

public class Spawn : MonoBehaviour
{
    private short allycount;
    public Transform barrack;
    private short barrack_count = 6;
    public Transform basecamp;
    public Transform[] boss = new Transform[11];
    private const int BOSS_POOL = 11;
    private int bosscount;
    private short[] bossindex = new short[3];
    private int[] bosskill = new int[12];
    private short bossremain;
    private Transform[] c_barrack = new Transform[6];
    private Transform c_basecamp;
    private Transform c_dun_door;
    private Transform c_extraunit;
    private Transform c_stage;
    private Transform c_tank;
    private Transform[] c_tower = new Transform[6];
    public Transform cart;
    private Transform clone_Boss;
    private Transform[] clone_destroy = new Transform[6];
    private Transform clone_enemy;
    private Transform[] clone_soul = new Transform[3];
    public Transform collider_ground;
    private bool countdown;
    private int cur_difficulty;
    public int cur_general = -1;
    private short cur_stage_index;
    public Transform cut_boss;
    private int destroy_beast_kind = 3;
    private int destroy_human_kind;
    private int destroy_last_kind;
    private const int ENEMY_POOL = 0x10;
    public Transform[] enemy_source = new Transform[0x10];
    public int enemykill;
    private int enemykind;
    private Transform[] enemyset = new Transform[4];
    public int finalstage = 3;
    private short g_grade;
    private float g_hp_length;
    private Transform g_hpgauge;
    private int[] general_hp = new int[12];
    private short general_index;
    public Transform general_portrait;
    public int grappling;
    public Transform icon_dead;
    private short infinity_stage_index;
    public bool infinitymode;
    private GameObject last_mon;
    public Texture lightmap_tank;
    private int maxEnemyNum = 15;
    public Transform[] mon_destroy = new Transform[4];
    public int monnum;
    private short negativefactor = 1;
    private int oldstageindex = -1;
    public Transform plane_staff;
    private int play_kind;
    private Texture prt_cha;
    private Texture prt_general;
    public Transform pt_soul;
    public Transform pt_summonfog;
    private int regen = -1;
    private float restrict_Factor = 100f;
    private float[] restrictArea = new float[] { 0.9f, 0.9f, 0.9f, 0.8f, 0.9f, 0.9f, 0.9f, 0.9f };
    public short rewardkind;
    private int rndoldpoint = -1;
    private int rndpoint;
    private Vector3 rndpos;
    private Cha_Control script_cha;
    private DB_General script_DBgeneral;
    private Gauge_UV script_g_hpgauge;
    private General_Stat script_generalstat;
    private Icon_Skill script_iconskill;
    private UI_Ingame script_IngameUI;
    private DB_Stage script_stageDB;
    private float set_spawndelay = 1f;
    private int soulcount;
    private float spawndelay = 1f;
    private Transform spawnenemy;
    private Vector3[] spawpoint = new Vector3[8];
    public Transform[] stage = new Transform[10];
    private bool stagefinish;
    private int summon_amount;
    private Vector3 summonpos = Vector3.zero;
    public Transform tank;
    private Vector3 temprndpos;
    private int totalEnemyNum;
    public Transform tower;
    private short tower_count = 6;
    public int wave = 1;
    private int WAVEEMEMYNUM = 40;

    private void Awake()
    {
        this.bosskill = PlayerPrefsX.GetIntArray("bosskill");
        this.cur_difficulty = Crypto.Load_int_key("n14");
        this.script_stageDB = base.GetComponent<DB_Stage>();
        int num = Crypto.Load_int_key("cur_stage_kind");
        this.cur_stage_index = (short) Crypto.Load_int_key("cur_stage_index");
        this.infinity_stage_index = (short) (this.cur_stage_index % 90);
        this.play_kind = Crypto.Load_int_key("play_kind");
        this.cur_general = Crypto.Load_int_key("cur_general");
        GameObject obj2 = GameObject.FindWithTag("Player");
        this.script_cha = obj2.GetComponent<Cha_Control>();
        this.script_generalstat = base.GetComponent<General_Stat>();
        this.script_iconskill = GameObject.FindWithTag("icon_skill").GetComponent<Icon_Skill>();
        if (num == 11)
        {
            this.cur_difficulty = 0;
            this.infinitymode = true;
            this.wave = Crypto.Load_int_key("n49");
            this.cur_stage_index = (short) (2 + (3 * (this.wave - 1)));
            this.infinity_stage_index = (short) (this.cur_stage_index % 90);
            GameObject obj3 = Resources.Load("dun_gate") as GameObject;
            this.c_dun_door = (Transform) UnityEngine.Object.Instantiate(obj3.transform, (Vector3) (Vector3.up * 55f), Quaternion.identity);
            this.set_spawndelay = 0.4f;
            this.finalstage = 0x3e8;
            this.WAVEEMEMYNUM = 80;
        }
        else
        {
            if (this.play_kind == 5)
            {
                this.SetMapStory(num, false);
                this.bossremain = this.script_stageDB.st[this.cur_stage_index]._bosscount;
                this.finalstage = 1;
                this.WAVEEMEMYNUM = 120;
            }
            if (this.play_kind == 6)
            {
                this.SetMapStory(num, true);
                this.collider_ground.position = new Vector3(0f, -0.01f, 3f);
                this.collider_ground.localScale = new Vector3(1f, 0f, 6f);
                this.cur_general = -1;
                this.c_extraunit = (Transform) UnityEngine.Object.Instantiate(this.cart, (Vector3) (Vector3.forward * 0.5f), Quaternion.identity);
                this.general_portrait.gameObject.active = true;
                this.general_portrait.renderer.material.mainTexture = Resources.Load("prt_cart") as Texture;
                this.set_spawndelay = 6.5f - (this.cur_stage_index * 0.03f);
                this.finalstage = 1;
                this.WAVEEMEMYNUM = 250;
            }
            else if (this.play_kind == 7)
            {
                this.SetMapStory(num, true);
                this.collider_ground.position = new Vector3(0f, -0.01f, 3f);
                this.collider_ground.localScale = new Vector3(1f, 0f, 6f);
                for (int i = 0; i < 3; i++)
                {
                    this.c_tower[2 * i] = (Transform) UnityEngine.Object.Instantiate(this.tower, (Vector3) (((Vector3.forward * (i * 3)) + (Vector3.forward * 3f)) - (Vector3.right * 0.5f)), Quaternion.Euler(0f, 45f, 0f));
                    this.c_tower[(2 * i) + 1] = (Transform) UnityEngine.Object.Instantiate(this.tower, (Vector3) (((Vector3.forward * (i * 3)) + (Vector3.forward * 3f)) + (Vector3.right * 0.5f)), Quaternion.Euler(0f, 45f, 0f));
                    this.c_barrack[2 * i] = (Transform) UnityEngine.Object.Instantiate(this.barrack, (Vector3) (((Vector3.forward * (i * 3)) + (Vector3.forward * 2f)) + (Vector3.right * 0.4f)), Quaternion.Euler(0f, 225f, 0f));
                    this.c_barrack[(2 * i) + 1] = (Transform) UnityEngine.Object.Instantiate(this.barrack, (Vector3) (((Vector3.forward * (i * 3)) + (Vector3.forward * 1f)) - (Vector3.right * 0.4f)), Quaternion.Euler(0f, -225f, 0f));
                }
                this.c_basecamp = (Transform) UnityEngine.Object.Instantiate(this.basecamp, (Vector3) (Vector3.forward * 10f), Quaternion.identity);
                this.c_tank = (Transform) UnityEngine.Object.Instantiate(this.tank, (Vector3) (Vector3.forward * -0.5f), Quaternion.Euler(0f, 180f, 0f));
                this.set_spawndelay = 3f;
                this.c_stage.Find("amap").renderer.material.SetTexture("_LightMap", this.lightmap_tank);
                base.InvokeRepeating("RegenAlly", 2f, 2f);
                this.finalstage = 1;
                this.WAVEEMEMYNUM = 250;
            }
            else
            {
                this.SetMapStory(num, false);
                this.finalstage = this.script_stageDB.st[this.cur_stage_index]._stagenum;
                this.WAVEEMEMYNUM = 120;
                if (this.cur_stage_index == 0)
                {
                    this.WAVEEMEMYNUM = 40;
                }
            }
            this.rewardkind = this.script_stageDB.st[this.infinity_stage_index]._reward;
        }
        if (this.cur_general != -1)
        {
            this.script_DBgeneral = base.GetComponent<DB_General>();
            int[] intArray = new int[6];
            intArray = PlayerPrefsX.GetIntArray("n13");
            this.general_hp = PlayerPrefsX.GetIntArray("n33");
            this.GeneralHP(true);
            int num3 = intArray[this.cur_general];
            this.script_generalstat.SetGeneral(num3);
            short num4 = this.script_generalstat.general_kind;
            short num5 = this.script_generalstat.g_maxhp;
            this.g_grade = this.script_generalstat.g_grade;
            int num6 = this.general_hp[this.cur_general];
            if (num6 > num5)
            {
                num6 = num5;
            }
            this.general_index = this.script_generalstat.general_index;
            short num7 = this.script_generalstat.g_maxatk;
            float num8 = this.script_generalstat.g_atkspd;
            float num9 = this.script_DBgeneral.gs[this.general_index]._cooltime - (num8 * 40f);
            short num10 = this.script_DBgeneral.gs[this.general_index]._soulcost;
            if (this.infinitymode)
            {
                num10 = 0;
            }
            short num11 = this.script_DBgeneral.gs[this.general_index]._voice;
            this.script_cha.Set_General(this.script_DBgeneral.gs[this.general_index]._weapon, num4, num5, num7, this.script_generalstat.g_def, num8, this.script_generalstat.g_unique, num6, num11);
            if (this.g_grade < 2)
            {
                UnityEngine.Object.Destroy(this.general_portrait.GetChild(0).gameObject);
            }
            else
            {
                obj2.GetComponent<Cha_Skill>().Set_General_Skill(num7, this.script_DBgeneral.gs[this.general_index]._skillatk, this.script_DBgeneral.gs[this.general_index]._skillkind);
                this.script_iconskill.Set_General(num10, num9, num4, this.infinitymode);
            }
            this.general_portrait.gameObject.active = true;
            int num12 = this.general_index + 1;
            this.prt_general = Resources.Load("prt_general" + num12.ToString()) as Texture;
            this.prt_cha = Resources.Load("prt_cha") as Texture;
            this.general_portrait.renderer.material.mainTexture = this.prt_general;
            this.general_portrait.GetChild(0).GetComponent<Icon_Skill_p>().SkillKind(0, this.general_index, 0, num10);
            if (this.cur_difficulty != 2)
            {
                this.g_hpgauge = GameObject.FindWithTag("p_plan").GetComponent<MakeUI>().CreatCustomPlane(new Vector2(0.24f, 0.08f), 0f, new Vector3(-1.39f, 2.36f, 1.8f), new Vector2(0.75f, 0.625f), new Vector2(0.875f, 0.6875f), "general_hp", "Gauge_UV", 0.1f, 0);
                this.script_g_hpgauge = this.g_hpgauge.GetComponent<Gauge_UV>();
                this.g_hp_length = (1f - (((float) num6) / ((float) num5))) * 0.125f;
                this.script_g_hpgauge.UvMove((Vector2) (Vector2.right * this.g_hp_length));
            }
        }
    }

    public void BossAppear(short _kind)
    {
        this.rndpos = this.SetRndPoint();
        this.clone_Boss = (Transform) UnityEngine.Object.Instantiate(this.boss[_kind], this.rndpos, Quaternion.identity);
        this.clone_Boss.GetComponent<AI_Boss01>().SetLevel(this.cur_stage_index, this.restrict_Factor);
        this.monnum++;
        this.countdown = true;
    }

    public void BossCutin(int _enemykind)
    {
        this.cut_boss.gameObject.active = true;
        this.cut_boss.GetComponent<Cutin_BossTexture>().SetCutinTexture(_enemykind);
        this.cut_boss.gameObject.active = true;
        this.cut_boss.GetComponent<Cutin01>().CutinOn(new Vector3(3f, 2f, 1f), new Vector3(0.5f, 2f, 1f), new Vector3(7f, 7f, 0f), 0.1f, 2.4f, 2.5f, true);
        this.ChangeBGM(true);
    }

    public void BossKill(int _enemykind)
    {
        if (_enemykind == 0)
        {
            this.bosskill[9]++;
        }
        else
        {
            this.bosskill[_enemykind]++;
        }
        PlayerPrefsX.SetIntArray("bosskill", this.bosskill);
        if (!this.infinitymode && (this.bosscount <= 0))
        {
            this.bossremain = (short) (this.bossremain - 1);
            if (this.bossremain <= 0)
            {
                this.script_IngameUI.WaveSet(100);
            }
        }
        this.ChangeBGM(false);
    }

    public void BossKill_Cheat()
    {
        if (this.clone_Boss != null)
        {
            UnityEngine.Object.Destroy(this.clone_Boss.gameObject);
            this.monnum--;
        }
    }

    public void CallGeneral(bool _general, int _hp, int _maxhp)
    {
        if (!_general)
        {
            this.general_portrait.renderer.material.mainTexture = this.prt_general;
            if (this.g_grade >= 2)
            {
                this.general_portrait.GetChild(0).gameObject.active = false;
            }
        }
        else
        {
            this.general_portrait.renderer.material.mainTexture = this.prt_cha;
            if (this.g_grade >= 2)
            {
                this.general_portrait.GetChild(0).gameObject.active = true;
            }
        }
        if (this.cur_difficulty != 2)
        {
            this.g_hp_length = (1f - (((float) _hp) / ((float) _maxhp))) * 0.125f;
            this.script_g_hpgauge.UvMove((Vector2) (Vector2.right * this.g_hp_length));
        }
    }

    public void ChangeBGM(bool _boss)
    {
        if (_boss)
        {
            base.audio.clip = Resources.Load("bgm_boss") as AudioClip;
        }
        else
        {
            int num = UnityEngine.Random.Range(1, 4);
            base.audio.clip = Resources.Load("bgm_stage" + num.ToString()) as AudioClip;
        }
        base.audio.Play();
    }

    public void ChangeBoss(Vector3 _pos, Quaternion _rot)
    {
        this.clone_Boss = (Transform) UnityEngine.Object.Instantiate(this.boss[0], _pos, _rot);
        this.clone_Boss.GetComponent<AI_Boss01>().SetLevel(this.cur_stage_index, this.restrict_Factor);
    }

    public void EnemyChange()
    {
        if (this.set_spawndelay > 0.5f)
        {
            this.set_spawndelay -= 0.3f;
        }
        if (this.wave < 5)
        {
            this.wave++;
        }
        for (int i = 0; i < 3; i++)
        {
            int index = ((this.wave + i) + (this.cur_stage_index % 10)) - 1;
            this.enemyset[i] = this.enemy_source[index];
        }
    }

    public void EnemyDead(int _destroy, Vector3 _pos, Texture _tex, Vector3 _scale, Vector3 _forcedir)
    {
        this.monnum--;
        if ((!this.stagefinish && (this.monnum <= 0)) && (this.regen == -2))
        {
            this.stagefinish = true;
            if (this.infinitymode)
            {
                this.c_stage.GetComponent<Map_extreme>().TrapStop();
            }
            this.script_IngameUI.WaveSet(this.wave);
            this.wave++;
        }
        if (_destroy == 2)
        {
            this.clone_destroy[this.destroy_human_kind].position = _pos + ((Vector3) (_forcedir * 0.15f));
            this.clone_destroy[this.destroy_human_kind].rotation = Quaternion.Euler(0f, (float) UnityEngine.Random.Range(0, 360), 0f);
            this.clone_destroy[this.destroy_human_kind].GetComponent<Mon_Destroy>().TextureChange(_tex, _scale, _destroy);
            this.clone_destroy[this.destroy_human_kind].gameObject.active = true;
            this.destroy_human_kind = (this.destroy_human_kind + 1) % 3;
            this.destroy_last_kind = this.destroy_human_kind;
        }
        else if (_destroy == 1)
        {
            this.clone_destroy[this.destroy_beast_kind].position = _pos + ((Vector3) (_forcedir * 0.15f));
            this.clone_destroy[this.destroy_beast_kind].rotation = Quaternion.Euler(0f, (float) UnityEngine.Random.Range(0, 360), 0f);
            this.clone_destroy[this.destroy_beast_kind].GetComponent<Mon_Destroy>().TextureChange(_tex, _scale, _destroy);
            this.clone_destroy[this.destroy_beast_kind].gameObject.active = true;
            this.destroy_beast_kind = ((this.destroy_beast_kind + 1) % 3) + 3;
            this.destroy_last_kind = this.destroy_beast_kind;
        }
        else if (_destroy == 3)
        {
            this.clone_destroy[this.destroy_last_kind].position = _pos;
            this.clone_destroy[this.destroy_last_kind].rotation = Quaternion.Euler(0f, (float) UnityEngine.Random.Range(0, 360), 0f);
            if (this.destroy_last_kind < 3)
            {
                _destroy = 2;
            }
            else
            {
                _destroy = 1;
            }
            this.clone_destroy[this.destroy_last_kind].GetComponent<Mon_Destroy>().TextureChange(_tex, _scale, _destroy);
            this.clone_destroy[this.destroy_last_kind].gameObject.active = true;
            this.destroy_last_kind = (this.destroy_last_kind + 1) % 6;
        }
        else
        {
            this.grappling++;
        }
        this.enemykill++;
        if (this.script_IngameUI.GetExp(_destroy))
        {
            this.clone_soul[this.soulcount].gameObject.active = true;
            this.clone_soul[this.soulcount].position = _pos;
            this.soulcount = (this.soulcount + 1) % 3;
        }
    }

    public void FinalWave()
    {
        this.script_IngameUI.WaveSet(this.finalstage - 1);
        this.wave = this.finalstage;
    }

    public void GeneralDead()
    {
        if (this.g_grade >= 2)
        {
            this.general_portrait.GetChild(0).gameObject.active = false;
        }
        this.GeneralHP(false);
        if (this.cur_difficulty != 2)
        {
            this.g_hpgauge.gameObject.active = false;
        }
        this.icon_dead.gameObject.active = true;
    }

    public void GeneralHP(bool _isstart)
    {
        if (this.cur_general != -1)
        {
            int num = TimeControl.SubtractDelay(1);
            for (int i = 0; i < 12; i++)
            {
                this.general_hp[i] += (int) (num * 0.2f);
            }
            if (!_isstart)
            {
                this.general_hp[this.cur_general] = this.script_cha.g_hp;
            }
            PlayerPrefsX.SetIntArray("n33", this.general_hp);
            TimeControl.SetDelay(1);
        }
    }

    public void OpenDundoor()
    {
        this.c_dun_door.gameObject.active = true;
    }

    public void RegenAlly()
    {
        if (this.allycount == 0)
        {
            if (this.c_tank.position.y >= 10f)
            {
                this.c_tank.position = (Vector3) (Vector3.forward * -0.5f);
                this.c_tank.gameObject.active = true;
            }
        }
        else if (this.allycount < 8)
        {
            this.negativefactor = (short) (this.negativefactor * -1);
            UnityEngine.Object.Instantiate(this.plane_staff, (Vector3) (((Vector3.right * UnityEngine.Random.Range((float) 0.1f, (float) 0.3f)) * this.negativefactor) - (Vector3.forward * 0.5f)), Quaternion.identity);
        }
        else if (this.allycount > 12)
        {
            this.allycount = -1;
        }
        this.allycount = (short) (this.allycount + 1);
    }

    public void RegenStart()
    {
        this.monnum = 0;
        this.stagefinish = false;
        this.bosscount = this.script_stageDB.st[this.infinity_stage_index]._bosscount;
        if (this.bosscount > 0)
        {
            this.bossindex[0] = this.script_stageDB.st[this.infinity_stage_index]._boss1;
            this.bossindex[1] = this.script_stageDB.st[this.infinity_stage_index]._boss2;
            this.bossindex[2] = this.script_stageDB.st[this.infinity_stage_index]._boss3;
        }
        this.totalEnemyNum = this.WAVEEMEMYNUM;
        this.regen = 0;
        this.enemyset[0] = this.enemy_source[this.script_stageDB.st[this.infinity_stage_index]._basemon1];
        this.enemyset[1] = this.enemy_source[this.script_stageDB.st[this.infinity_stage_index]._basemon2];
        this.enemyset[2] = this.enemy_source[this.script_stageDB.st[this.infinity_stage_index]._mainmon];
    }

    public void SetBGM(float _vol)
    {
        base.audio.volume = _vol;
        PlayerPrefs.SetFloat("vol_bgm", _vol);
    }

    public void SetMapExtreme(bool _clear)
    {
        if (_clear)
        {
            for (int i = 0; i < 6; i++)
            {
                this.clone_destroy[i].GetComponent<Mon_Destroy>().FinishNow();
            }
            GameObject.FindWithTag("efs_mon").GetComponent<Monster_efs>().FinishEfs();
        }
        int index = 0;
        index = (this.wave - 1) / 8;
        if (index == this.oldstageindex)
        {
            this.c_stage.GetComponent<Map_extreme>().SetWave(this.wave);
        }
        else if (index < 8)
        {
            if (this.c_stage != null)
            {
                UnityEngine.Object.Destroy(this.c_stage.gameObject);
            }
            int num5 = index + 1;
            GameObject obj2 = Resources.Load("Stage_dun" + num5.ToString()) as GameObject;
            this.c_stage = (Transform) UnityEngine.Object.Instantiate(obj2.transform, Vector3.zero, Quaternion.Euler(0f, (float) UnityEngine.Random.Range(0, 360), 0f));
            this.c_stage.name = "stage";
            this.c_stage.GetComponent<Map_extreme>().SetWave(this.wave);
            float x = this.c_stage.localScale.x;
            this.restrict_Factor = this.restrictArea[index] * x;
            this.c_dun_door.position = (Vector3) (-this.c_stage.forward * this.restrict_Factor);
            this.c_dun_door.rotation = Quaternion.LookRotation(-this.c_dun_door.position);
            this.c_dun_door.gameObject.active = false;
            this.c_stage.Find("light_dun1").rotation = Quaternion.Euler(0f, 120f, 0f);
            this.oldstageindex = index;
            this.script_cha.SetRestrictArea(this.restrict_Factor);
            for (int j = 0; j < 8; j++)
            {
                this.spawpoint[j] = this.c_stage.GetChild(0).GetChild(j).position;
            }
        }
    }

    public void SetMapStory(int _cur_stage_kind, bool _islinemap)
    {
        int num = 0;
        if (_islinemap)
        {
            num = 5;
        }
        this.c_stage = (Transform) UnityEngine.Object.Instantiate(this.stage[(_cur_stage_kind - 1) + num], Vector3.zero, Quaternion.identity);
        this.c_stage.name = "stage";
        if (!_islinemap)
        {
            for (int i = 0; i < 8; i++)
            {
                this.spawpoint[i] = this.c_stage.GetChild(0).GetChild(i).position;
            }
        }
    }

    public Vector3 SetRndPoint()
    {
        if (this.play_kind == 6)
        {
            this.temprndpos = (Vector3) ((this.c_extraunit.position + (Vector3.forward * UnityEngine.Random.Range((float) -1.5f, (float) 1.5f))) + ((Vector3.right * (UnityEngine.Random.Range(-1, 1) + 0.5f)) * 3f));
        }
        else if (this.play_kind != 7)
        {
            if (this.infinitymode)
            {
                this.rndpoint = (this.rndpoint + 1) % 8;
                this.temprndpos = this.spawpoint[this.rndpoint];
            }
            else
            {
                this.rndpoint = UnityEngine.Random.Range(0, 8);
                if (this.rndpoint == this.rndoldpoint)
                {
                    this.rndpoint = (this.rndpoint + 1) % 8;
                }
                this.rndoldpoint = this.rndpoint;
                this.temprndpos = this.spawpoint[this.rndpoint];
            }
        }
        else
        {
            int num = 0;
            for (int i = 0; i < 6; i++)
            {
                this.rndpoint = (this.rndpoint + 1) % 6;
                if (this.c_barrack[this.rndpoint] != null)
                {
                    this.temprndpos = this.c_barrack[this.rndpoint].position;
                    num++;
                    break;
                }
            }
            if (num == 0)
            {
                this.regen = -1;
            }
        }
        return this.temprndpos;
    }

    private void Start()
    {
        int num = UnityEngine.Random.Range(1, 4);
        base.audio.clip = Resources.Load("bgm_stage" + num.ToString()) as AudioClip;
        base.audio.Play();
        base.audio.volume = PlayerPrefs.GetFloat("vol_bgm");
        for (int i = 0; i < 3; i++)
        {
            this.clone_destroy[i] = (Transform) UnityEngine.Object.Instantiate(this.mon_destroy[i], (Vector3) (Vector3.one * 6f), Quaternion.identity);
            this.clone_destroy[i + 3] = (Transform) UnityEngine.Object.Instantiate(this.mon_destroy[3], (Vector3) (Vector3.one * 6f), Quaternion.identity);
            this.clone_soul[i] = (Transform) UnityEngine.Object.Instantiate(this.pt_soul, (Vector3) (Vector3.one * 31f), Quaternion.identity);
        }
        if (this.infinitymode)
        {
            this.SetMapExtreme(false);
        }
        this.monnum = 0;
        this.totalEnemyNum = this.WAVEEMEMYNUM;
        this.script_IngameUI = GameObject.FindWithTag("ui").GetComponent<UI_Ingame>();
        this.enemykill = Crypto.Load_int_key("enemykill");
        this.grappling = Crypto.Load_int_key("grappling");
    }

    public void Summon(int _amount, Vector3 _summonpos)
    {
        if (this.summon_amount <= 0)
        {
            this.summon_amount = _amount;
            this.summonpos = _summonpos;
            base.InvokeRepeating("Summon_p", 0.1f, 0.5f);
        }
    }

    private void Summon_p()
    {
        if (this.monnum > 0)
        {
            Vector3 position = this.summonpos + ((Vector3) (UnityEngine.Random.onUnitSphere * 0.3f));
            position[1] = 0f;
            this.pt_summonfog.position = position;
            this.pt_summonfog.particleSystem.Play();
            this.spawnenemy = this.enemyset[UnityEngine.Random.Range(0, 2)];
            this.clone_enemy = (Transform) UnityEngine.Object.Instantiate(this.spawnenemy, position, Quaternion.Euler(0f, (float) UnityEngine.Random.Range(0, 360), 0f));
            this.clone_enemy.name = "enemy";
            this.clone_enemy.GetComponent<AI_Enemy01>().SetLevel(this.cur_stage_index, this.play_kind, true, this.restrict_Factor);
            this.monnum++;
            this.summon_amount--;
        }
        else
        {
            this.summon_amount = 0;
            base.CancelInvoke("Summon_p");
        }
        if (this.summon_amount <= 0)
        {
            this.summon_amount = 0;
            base.CancelInvoke("Summon_p");
        }
    }

    public void TowerBreak(bool istower)
    {
        if (istower)
        {
            this.tower_count = (short) (this.tower_count - 1);
        }
        else
        {
            this.barrack_count = (short) (this.barrack_count - 1);
        }
        if ((this.tower_count <= 0) && (this.barrack_count <= 0))
        {
            this.c_tank.GetComponent<Tank>().HurryUp();
        }
    }

    private void Update()
    {
        if (this.regen == 0)
        {
            for (int i = 0; i < 3; i++)
            {
                this.rndpos = this.SetRndPoint();
                this.spawnenemy = this.enemyset[i];
                this.clone_enemy = (Transform) UnityEngine.Object.Instantiate(this.spawnenemy, this.rndpos, Quaternion.identity);
                this.clone_enemy.name = "enemy";
                this.clone_enemy.GetComponent<AI_Enemy01>().SetLevel(this.cur_stage_index, this.play_kind, this.infinitymode, this.restrict_Factor);
                if (this.infinitymode)
                {
                    this.pt_summonfog.position = this.rndpos;
                    this.pt_summonfog.particleSystem.Play();
                }
                this.monnum++;
                this.totalEnemyNum--;
            }
            this.regen = 1;
            this.countdown = false;
        }
        else if (this.regen > 0)
        {
            if (this.spawndelay > 0f)
            {
                this.spawndelay -= Time.deltaTime;
            }
            else if (this.totalEnemyNum > 0)
            {
                if (this.monnum < this.maxEnemyNum)
                {
                    this.rndpos = this.SetRndPoint();
                    this.enemykind = UnityEngine.Random.Range(0, 100);
                    if (this.enemykind < 0x2d)
                    {
                        this.enemykind = 0;
                    }
                    else if (this.enemykind < 80)
                    {
                        this.enemykind = 1;
                    }
                    else
                    {
                        this.enemykind = 2;
                    }
                    this.spawnenemy = this.enemyset[this.enemykind];
                    this.clone_enemy = (Transform) UnityEngine.Object.Instantiate(this.spawnenemy, this.rndpos, Quaternion.identity);
                    this.clone_enemy.name = "enemy";
                    this.clone_enemy.GetComponent<AI_Enemy01>().SetLevel(this.cur_stage_index, this.play_kind, this.infinitymode, this.restrict_Factor);
                    if (this.infinitymode)
                    {
                        this.pt_summonfog.position = this.rndpos;
                        this.pt_summonfog.particleSystem.Play();
                    }
                    this.monnum++;
                    this.totalEnemyNum--;
                    this.spawndelay = this.set_spawndelay;
                }
            }
            else if (this.totalEnemyNum <= 0)
            {
                if (this.wave >= this.finalstage)
                {
                    if (this.bosscount > 0)
                    {
                        this.spawndelay = 1f;
                        this.BossAppear(this.bossindex[this.script_stageDB.st[this.infinity_stage_index]._bosscount - this.bosscount]);
                        this.bosscount--;
                        if (this.bosscount <= 0)
                        {
                            this.regen = -2;
                        }
                    }
                    else
                    {
                        this.regen = -2;
                    }
                }
                else if (this.infinitymode)
                {
                    if (this.bosscount > 0)
                    {
                        this.BossAppear(this.bossindex[this.script_stageDB.st[this.infinity_stage_index]._bosscount - this.bosscount]);
                        this.bosscount--;
                        if (this.bosscount <= 0)
                        {
                            this.cur_stage_index = (short) (this.cur_stage_index + 3);
                            this.infinity_stage_index = (short) (this.cur_stage_index % 90);
                            this.regen = -2;
                        }
                    }
                    else
                    {
                        this.cur_stage_index = (short) (this.cur_stage_index + 3);
                        this.infinity_stage_index = (short) (this.cur_stage_index % 90);
                        this.regen = -2;
                    }
                }
                else
                {
                    this.regen = -2;
                }
            }
        }
        else if ((this.monnum <= 5) && !this.countdown)
        {
            for (int j = 0; j < this.monnum; j++)
            {
                this.last_mon = GameObject.Find("enemy");
                this.last_mon.GetComponent<AI_Enemy01>().CountDown();
                this.last_mon.name = "enemy_confirm";
            }
            this.countdown = true;
        }
    }
}


using System;
using UnityEngine;

public class Touch_zoom : MonoBehaviour
{
    private bool iszoom;
    private UI_map script_ui;

    private void Start()
    {
        this.script_ui = base.GetComponent<UI_map>();
    }

    private void Update()
    {
        float num = 0f;
        if (!this.iszoom && (Input.touchCount == 2))
        {
            if (Input.GetTouch(1).phase == TouchPhase.Began)
            {
                num = Vector2.Distance(Input.GetTouch(0).position, Input.GetTouch(1).position);
            }
            else if ((Input.GetTouch(0).phase == TouchPhase.Ended) || (Input.GetTouch(1).phase == TouchPhase.Ended))
            {
                this.iszoom = false;
            }
            else if (((Input.GetTouch(0).phase == TouchPhase.Moved) || (Input.GetTouch(1).phase == TouchPhase.Moved)) && (Mathf.Abs((float) (Vector2.Distance(Input.GetTouch(0).position, Input.GetTouch(1).position) - num)) > 1f))
            {
                this.iszoom = true;
                this.script_ui.Zoom_finger(true, Vector3.one);
            }
        }
    }
}


using System;
using UnityEngine;

public class GiftBox : MonoBehaviour
{
    private Vector3 directionVector;
    private bool drop_impact;
    public Transform ef_risingitem;
    private float homingdelay;
    public Transform inven_gem;
    public Transform inven_weapon;
    private int isclear;
    private bool itemrising;
    public AudioClip snd_drop;
    public AudioClip snd_open;
    public Texture spbox;
    private Vector3 targetpos;

    public void OpenBox()
    {
        base.audio.PlayOneShot(this.snd_open);
        base.animation.Play("open_box");
        this.itemrising = true;
        this.ef_risingitem.particleEmitter.emit = true;
    }

    private void Start()
    {
        this.targetpos = (Vector3) ((-Vector3.up * 0.6f) + (Vector3.forward * 0.2f));
        this.directionVector = (Vector3) (Vector3.up * 0.5f);
        base.animation["invisible"].speed = 0.06f;
        base.animation["open_box"].speed = 0.25f;
        this.isclear = GameObject.FindWithTag("ui").GetComponent<UI_result>().isclear;
        if (this.isclear <= 0)
        {
            base.animation["invisible"].wrapMode = WrapMode.ClampForever;
            base.animation.Play("invisible");
        }
        else
        {
            if (this.isclear > 100)
            {
                base.transform.GetChild(2).renderer.material.mainTexture = this.spbox;
                base.transform.localScale = Vector3.one;
            }
            base.animation.Play("invisible");
            base.animation.PlayQueued("drop").speed = 0.3f;
            base.animation.PlayQueued("drop_i").speed = 0.3f;
        }
    }

    private void Update()
    {
        if (!this.drop_impact)
        {
            if (base.animation.IsPlaying("drop_i"))
            {
                this.drop_impact = true;
                base.audio.PlayOneShot(this.snd_drop);
            }
        }
        else if (this.itemrising)
        {
            if (this.homingdelay < 1.5f)
            {
                this.homingdelay += Time.deltaTime;
                this.ef_risingitem.position += (Vector3) (this.directionVector * Time.deltaTime);
                this.directionVector += (Vector3) (this.targetpos * Time.deltaTime);
            }
            else
            {
                if (this.isclear > 100)
                {
                    this.inven_weapon.gameObject.active = true;
                    int num = this.isclear / 100;
                    if (num == 1)
                    {
                        this.inven_weapon.GetComponent<Inventory_Weapon>().GetWeapon(this.isclear % 100);
                    }
                    else
                    {
                        this.inven_weapon.GetComponent<Inventory_Weapon>().GetArmor(this.isclear % 100);
                    }
                }
                else
                {
                    this.inven_gem.gameObject.active = true;
                    this.inven_gem.GetComponent<Inventory_Gem>().GetItem();
                }
                this.ef_risingitem.position = new Vector3(this.ef_risingitem.position.x, 0.2f, this.ef_risingitem.position.z);
                this.ef_risingitem.particleEmitter.emit = false;
                this.itemrising = false;
            }
        }
    }
}


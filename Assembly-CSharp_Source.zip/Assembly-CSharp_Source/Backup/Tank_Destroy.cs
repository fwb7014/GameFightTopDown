using System;
using UnityEngine;

public class Tank_Destroy : MonoBehaviour
{
    private float delay;
    private bool fogon;
    private Animation myanimation;
    public Transform pt_fog;

    private void Awake()
    {
        this.myanimation = base.animation;
        this.myanimation["tank_destroy"].speed = 0.25f;
    }

    private void OnEnable()
    {
        this.pt_fog.particleEmitter.emit = true;
        this.delay = 0f;
        this.fogon = true;
        this.myanimation.Stop();
        this.myanimation.Play("tank_destroy");
    }

    private void Update()
    {
        if (this.delay > 2.5f)
        {
            base.transform.position = (Vector3) (Vector3.up * 25f);
            base.gameObject.active = false;
        }
        if ((this.delay > 0.5f) && this.fogon)
        {
            this.pt_fog.particleEmitter.emit = false;
            this.fogon = false;
        }
        this.delay += Time.deltaTime;
    }
}


using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct generalset
{
    public short _voice;
    public short _kind;
    public short _weapon;
    public short _skillname;
    public short _skillindex;
    public short _skillkind;
    public short _skillatk;
    public float _cooltime;
    public short _soulcost;
}


using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class Loading_horse : MonoBehaviour
{
    private AsyncOperation async;
    private bool camstop;
    private Transform mytransform;
    private int playkind;
    public Transform pt_stepfog;
    public Texture[] tex_stepfog = new Texture[5];

    private void Awake()
    {
        this.mytransform = base.transform;
        base.animation["horse_run"].speed = 0.7f;
        base.animation.Play("horse_run");
        int num = Crypto.Load_int_key("cur_stage_kind");
        this.playkind = Crypto.Load_int_key("play_kind");
        this.pt_stepfog.renderer.sharedMaterial.mainTexture = this.tex_stepfog[num - 1];
    }

    [DebuggerHidden]
    private IEnumerator Start()
    {
        return new <Start>c__Iterator10 { <>f__this = this };
    }

    private void Update()
    {
        this.mytransform.position += (Vector3) (Vector3.forward * Time.deltaTime);
        if (this.mytransform.position.z > 5.1f)
        {
            if (this.async.isDone)
            {
                UnityEngine.Object.Destroy(this.mytransform.root.gameObject);
                Camera.main.transform.GetChild(0).gameObject.active = true;
                GameObject.FindWithTag("ui").SendMessage("LoadingFinish");
            }
        }
        else if ((this.mytransform.position.z > 4.55f) && !this.camstop)
        {
            this.camstop = true;
            GameObject.Find("Cam_loading").GetComponent<Cam_Loading>().DisappearCam();
        }
    }

    [CompilerGenerated]
    private sealed class <Start>c__Iterator10 : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal Loading_horse <>f__this;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    if (this.<>f__this.playkind != 4)
                    {
                        this.<>f__this.async = Application.LoadLevelAdditiveAsync("Stage");
                        break;
                    }
                    this.<>f__this.async = Application.LoadLevelAdditiveAsync("Stage_ride");
                    break;

                case 1:
                    this.$PC = -1;
                    goto Label_0085;

                default:
                    goto Label_0085;
            }
            this.$current = this.<>f__this.async;
            this.$PC = 1;
            return true;
        Label_0085:
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }
}


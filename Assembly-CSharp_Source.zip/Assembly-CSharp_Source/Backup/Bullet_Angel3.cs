using System;
using UnityEngine;

public class Bullet_Angel3 : MonoBehaviour
{
    private Transform cha1;
    private float delay;
    private Vector3 dir;
    private Transform mychild;
    private LineRenderer myline;
    private Transform mytransform;
    private AI_Asist script_angel;
    private Vector3 targetPos;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myline = base.GetComponent<LineRenderer>();
        this.cha1 = GameObject.Find("asist").transform;
        this.script_angel = this.cha1.GetComponent<AI_Asist>();
        this.mychild = this.mytransform.GetChild(0);
        base.gameObject.active = false;
    }

    private void OnEnable()
    {
        this.targetPos = this.mytransform.position + ((Vector3) (this.mytransform.forward * 0.3f));
        this.targetPos.y = 0.005f;
        this.dir = this.mytransform.forward;
        this.dir.y = 0f;
        this.delay = 2.8f;
        this.mytransform.rotation = Quaternion.identity;
        this.mychild.forward = this.dir;
    }

    private void Update()
    {
        this.dir += (Vector3) ((this.mychild.right * Time.deltaTime) * 6f);
        this.dir.y = 0f;
        this.targetPos += (Vector3) ((this.dir * Time.deltaTime) * 1f);
        Vector3 position = this.cha1.position;
        this.myline.SetPosition(0, position);
        this.myline.SetPosition(1, this.targetPos);
        this.mychild.position = this.targetPos;
        this.mychild.forward = this.dir;
        if (this.delay < 0f)
        {
            this.script_angel.AttackFinish();
            base.gameObject.active = false;
        }
        this.delay -= Time.deltaTime;
    }
}


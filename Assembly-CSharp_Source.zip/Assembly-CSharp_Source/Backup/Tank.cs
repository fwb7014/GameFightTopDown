using System;
using UnityEngine;

public class Tank : MonoBehaviour
{
    public Transform behit_collider;
    private Transform c_destroy;
    private short cur_stage_index;
    private int damage;
    private float delay;
    private short hp;
    private Transform hpbar;
    private bool life = true;
    private short maxhp;
    private float movespeed = 0.1f;
    private Animation myanimation;
    private Transform mytransform;
    public Transform pt_hit;
    private Cam_Move script_cam;
    private Tower_base script_castle;
    private Hp_bar script_hpbar;
    public AudioClip snd_break;
    public AudioClip snd_hit;
    private bool stophit;
    private bool super;
    public Transform tank_destroy;

    public void AttakCastle()
    {
        if (!this.script_castle.TankDamage())
        {
            this.stophit = true;
        }
        this.script_cam.Hitcam();
        base.audio.PlayOneShot(this.snd_hit);
    }

    private void Awake()
    {
        this.cur_stage_index = (short) Crypto.Load_int_key("cur_stage_index");
        this.maxhp = (short) (200 + (3 * this.cur_stage_index));
        this.hp = this.maxhp;
        this.mytransform = base.transform;
        this.myanimation = base.animation;
        this.mytransform.position = (Vector3) (-Vector3.forward * 0.7f);
        this.hpbar = GameObject.FindWithTag("efs_mon").GetComponent<Monster_efs>().CreatHpbar(new Vector2(0.1f, 0.02f), false, true);
        this.hpbar.position = this.mytransform.position + ((Vector3) (Vector3.up * 0.3f));
        this.hpbar.parent = this.mytransform;
        this.script_hpbar = this.hpbar.GetComponent<Hp_bar>();
    }

    public void Damaged(Vector3 _damageVector)
    {
        if (this.life && !this.super)
        {
            this.damage = (int) _damageVector.y;
            _damageVector[1] = 0f;
            this.myanimation.Stop();
            this.myanimation.Play("tank_damage");
            this.delay = 2f;
            base.audio.Stop();
            base.audio.PlayOneShot(this.snd_break);
            this.pt_hit.particleEmitter.emit = true;
            this.hp = (short) (this.hp - ((short) this.damage));
            this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, 0.2f, -1);
            if (this.hp <= 0)
            {
                if (this.c_destroy == null)
                {
                    this.c_destroy = (Transform) UnityEngine.Object.Instantiate(this.tank_destroy, this.mytransform.position, this.mytransform.rotation);
                }
                else
                {
                    this.c_destroy.position = this.mytransform.position;
                    this.c_destroy.gameObject.active = true;
                }
                this.behit_collider.collider.enabled = false;
                this.mytransform.position = (Vector3) (Vector3.up * 20f);
                this.hp = this.maxhp;
                this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, 0.2f, -1);
                base.gameObject.active = false;
                this.life = false;
            }
        }
    }

    public void HurryUp()
    {
        this.movespeed = 0.5f;
        this.myanimation["tank_run"].speed = 2f;
    }

    private void OnEnable()
    {
        this.life = true;
        this.behit_collider.collider.enabled = true;
    }

    private void Start()
    {
        this.myanimation["tank_run"].speed = 0.4f;
        this.myanimation["tank_damage"].speed = 0.3f;
        this.myanimation["tank_attack"].speed = 0.3f;
        base.audio.Play();
        this.script_castle = GameObject.FindWithTag("Finish").GetComponent<Tower_base>();
        this.script_cam = Camera.main.GetComponent<Cam_Move>();
    }

    private void Update()
    {
        if (this.life)
        {
            if (this.delay > 0f)
            {
                this.delay -= Time.deltaTime;
                if (this.delay <= 0f)
                {
                    this.myanimation.CrossFade("tank_run");
                    base.audio.Play();
                }
                else if (this.delay < 1.5f)
                {
                    this.pt_hit.particleEmitter.emit = false;
                }
            }
            else if (!this.stophit)
            {
                if (this.mytransform.position.z > 9.25f)
                {
                    this.myanimation.Play("tank_attack");
                }
                else if (this.life)
                {
                    this.mytransform.position += (Vector3) ((Vector3.forward * Time.deltaTime) * this.movespeed);
                }
            }
        }
    }
}


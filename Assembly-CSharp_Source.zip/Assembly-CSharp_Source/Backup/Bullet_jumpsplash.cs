using System;
using UnityEngine;

public class Bullet_jumpsplash : MonoBehaviour
{
    private Color currentColor;
    private Vector3 growVector = new Vector3(0.8f, -2f, 0.8f);
    private Collider mycollider;
    private Renderer myrenderer;
    private Transform mytransform;
    private Vector3 originScale = new Vector3(1f, 8f, 1f);
    public float postune;
    private Color targetColor = new Color(0.5f, 0.5f, 0.5f, 0f);
    private Color transColor;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myrenderer = base.renderer;
        this.mycollider = base.collider;
    }

    private void OnEnable()
    {
        this.mytransform.localScale = this.originScale;
        this.mytransform.position += (Vector3) (this.mytransform.forward * this.postune);
        this.myrenderer.material.SetColor("_TintColor", Color.gray);
        this.mycollider.enabled = true;
    }

    private void Update()
    {
        this.mytransform.localScale += (Vector3) ((this.growVector * Time.deltaTime) * 7f);
        if (this.mytransform.localScale.y < 1f)
        {
            base.gameObject.active = false;
        }
        else if (this.mytransform.localScale.y < 4f)
        {
            this.mycollider.enabled = false;
        }
        this.currentColor = this.myrenderer.material.GetColor("_TintColor");
        this.transColor = Color.Lerp(this.currentColor, this.targetColor, Time.deltaTime * 5f);
        this.myrenderer.material.SetColor("_TintColor", this.transColor);
    }
}


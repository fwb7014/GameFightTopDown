using System;
using UnityEngine;

public class Splash_angel_bomb : MonoBehaviour
{
    private float delay = 2.5f;
    private ParticleEmitter mychild;
    private Transform mytransform;
    private Vector3 targetScale;

    private void Awake()
    {
        this.mytransform = base.transform;
        base.gameObject.active = false;
        this.targetScale = this.mytransform.localScale;
        this.mychild = this.mytransform.GetChild(0).particleEmitter;
    }

    private void OnEnable()
    {
        this.delay = 1f;
        this.mytransform.localScale = Vector3.zero;
        this.mychild.Emit();
    }

    private void Update()
    {
        if (this.delay < 0f)
        {
            this.mytransform.localScale -= (Vector3) ((Vector3.one * Time.deltaTime) * 3f);
            if (this.mytransform.localScale.y < -0.2f)
            {
                this.mytransform.localScale = Vector3.zero;
                base.gameObject.active = false;
            }
        }
        else
        {
            this.mytransform.localScale = Vector3.Lerp(this.mytransform.localScale, this.targetScale, Time.deltaTime * 5f);
            this.delay -= Time.deltaTime;
        }
    }
}


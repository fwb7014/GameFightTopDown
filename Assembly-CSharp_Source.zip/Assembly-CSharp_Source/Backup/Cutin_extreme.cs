using System;
using UnityEngine;

public class Cutin_extreme : MonoBehaviour
{
    public float delay = 2f;
    private float duration;
    private Transform mytransform;
    private Vector3 originPos;
    private Vector3 originScale;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.originPos = this.mytransform.position;
        this.originScale = this.mytransform.localScale;
    }

    private void OnEnable()
    {
        int num = 3;
        if (this.originPos.x < 0f)
        {
            num *= -1;
        }
        this.mytransform.position += Vector3.right * num;
        this.mytransform.localScale = Vector3.zero;
        this.duration = this.delay;
    }

    private void Update()
    {
        float num = 0f;
        if (Time.timeScale != 0f)
        {
            num = Time.deltaTime / Time.timeScale;
        }
        if (this.duration < 0f)
        {
            base.gameObject.active = false;
        }
        else if (this.duration < 1f)
        {
            this.mytransform.localScale = Vector3.MoveTowards(this.mytransform.localScale, Vector3.zero, num * 25f);
        }
        else if (this.duration < 2f)
        {
            this.mytransform.position = Vector3.MoveTowards(this.mytransform.position, this.originPos, num * 15f);
            this.mytransform.localScale = Vector3.MoveTowards(this.mytransform.localScale, this.originScale, num * 15f);
        }
        this.duration -= num;
    }
}


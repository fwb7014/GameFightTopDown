using System;
using UnityEngine;

public class Icon_Stage_Extreme : MonoBehaviour
{
    public int _index;
    private bool _isclear;
    private string _name;

    public void IconDown()
    {
        GameObject.FindWithTag("ui").GetComponent<UI_Extreme>().SetStage(this._index);
    }
}


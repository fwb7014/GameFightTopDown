using MiniJSON;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JSONObject
{
    private Dictionary<string, object> dictionary;

    public JSONObject()
    {
        this.Init();
    }

    public JSONObject(string jsonString)
    {
        this.ParseString(jsonString);
    }

    public void Add(string key, object val)
    {
        if (key == null)
        {
            Debug.LogError("[JSONOjbect.Add] : the key cannot be null !");
        }
        else
        {
            this.dictionary[key] = val;
        }
    }

    public bool ContainKey(string key)
    {
        if (key == null)
        {
            return false;
        }
        return this.dictionary.ContainsKey(key);
    }

    public T Get<T>(string key)
    {
        return CommonUtils.GetVal<T>(this.dictionary, key);
    }

    private void Init()
    {
        this.dictionary = new Dictionary<string, object>();
    }

    public static JSONObject Parse(string jsonValue)
    {
        return new JSONObject(jsonValue);
    }

    private void ParseString(string jsonString)
    {
        object obj2 = Json.Deserialize(jsonString);
        if (obj2 == null)
        {
            this.Init();
        }
        if (!(obj2 is Dictionary<string, object>) && (obj2 is ArrayList))
        {
        }
        this.dictionary = obj2 as Dictionary<string, object>;
    }

    public override string ToString()
    {
        return this.hashtableStr;
    }

    public string hashtableStr
    {
        get
        {
            return Json.Serialize(this.dictionary);
        }
    }
}


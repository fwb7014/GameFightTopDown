using System;
using UnityEngine;

public class Bullet_delay2 : MonoBehaviour
{
    public float disable_delay;
    public bool moveleft;
    private Transform mytransform;
    public float show_delay;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void finishObj()
    {
        base.gameObject.active = false;
        base.collider.enabled = false;
    }

    private void OnEnable()
    {
        base.Invoke("StartObj", this.show_delay);
        base.Invoke("finishObj", this.disable_delay);
        base.collider.enabled = false;
    }

    private void StartObj()
    {
        base.gameObject.active = true;
        base.collider.enabled = true;
    }

    private void Update()
    {
        if (this.moveleft)
        {
            this.mytransform.position -= (Vector3) ((this.mytransform.right * Time.deltaTime) * 0.2f);
        }
    }
}


using System;
using UnityEngine;

public class Loading_cha : MonoBehaviour
{
    public Transform horse;
    public Transform horseSpine;
    private Transform mytransform;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void Start()
    {
        base.animation["ride2"].speed = 0.7f;
        base.animation.Play("ride2");
    }

    private void Update()
    {
        this.mytransform.position = this.horseSpine.position + ((Vector3) (Vector3.up * -0.085f));
        this.mytransform.rotation = this.horse.rotation;
    }
}


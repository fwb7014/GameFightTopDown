using System;
using UnityEngine;

public class Monster_efs : MonoBehaviour
{
    public Transform arrowmark;
    public Texture[] attribute_tex = new Texture[4];
    public AnimationClip[] begrab = new AnimationClip[6];
    public AnimationClip[] bekicked = new AnimationClip[6];
    public AnimationClip[] bethrust = new AnimationClip[6];
    public Material[] blood_mat = new Material[5];
    private Transform[] c_damagenum = new Transform[10];
    private Transform[] c_ef_blood = new Transform[10];
    private Transform[] c_ef_hit = new Transform[10];
    private Transform[] c_ef_split = new Transform[10];
    private Transform[] c_hpbar = new Transform[15];
    private Transform[] c_item = new Transform[15];
    private Transform[] c_shadow = new Transform[15];
    private int count_damagenum;
    private int count_item;
    private int ef_attribute;
    public Transform ef_block;
    public Transform ef_blood;
    public Transform ef_hit;
    public int[] force_grab = new int[7];
    public int[] force_kick = new int[7];
    public AnimationClip[] getup = new AnimationClip[6];
    private Transform grab_blood;
    public Material hp_bar;
    private Vector2 hpsize = new Vector2(0.05f, 0.01f);
    private int index_destroy;
    private int index_ef;
    private bool infinitymode;
    public Material item_material;
    private float limit_x = 2.65f;
    private float limit_y_b = -2.6f;
    private float limit_y_f = 2.5f;
    private Mesh[] m_item = new Mesh[15];
    public Material main_material;
    private const int MONNUM = 15;
    private Transform mytransform;
    public Transform num_damage;
    private Vector3 originpos = ((Vector3) (Vector3.one * 3f));
    public AnimationClip pierce;
    public Transform pt_itemdrop;
    private Spawn script_spawn;
    private Spawn_story script_spawn_story;
    private Transform selecthpbar;
    private int selectshadow;
    public Transform shadow;
    private const int SHORTMONNUM = 10;
    public AudioClip[] snd_move = new AudioClip[3];
    public AudioClip[] snd_scream = new AudioClip[4];
    public float[] speed_begrab = new float[7];
    public float[] speed_bekicked = new float[7];
    public float[] speed_bethrust = new float[7];
    public float[] speed_getup = new float[7];
    public Material split_material;
    public bool story;
    public AnimationClip[] summon = new AnimationClip[2];

    private void Awake()
    {
        this.mytransform = base.transform;
        for (int i = 0; i < 15; i++)
        {
            this.c_hpbar[i] = this.CreatHpbar(this.hpsize, false, false);
            this.c_hpbar[i].position = (Vector3) (Vector3.one * 4f);
            this.c_shadow[i] = (Transform) UnityEngine.Object.Instantiate(this.shadow, this.originpos, Quaternion.identity);
            this.c_shadow[i].gameObject.active = false;
        }
        for (int j = 0; j < 10; j++)
        {
            this.c_damagenum[j] = (Transform) UnityEngine.Object.Instantiate(this.num_damage, this.originpos, this.num_damage.rotation);
            this.c_ef_hit[j] = (Transform) UnityEngine.Object.Instantiate(this.ef_hit, this.originpos, Quaternion.identity);
            this.c_ef_blood[j] = (Transform) UnityEngine.Object.Instantiate(this.ef_blood, this.originpos, Quaternion.identity);
            this.c_ef_split[j] = this.SplitOn((j + 1) % 4);
            this.c_ef_split[j].position = this.originpos;
            this.c_ef_hit[j].parent = this.mytransform;
            this.c_ef_blood[j].parent = this.mytransform;
            this.c_ef_split[j].parent = this.mytransform;
            this.c_item[j] = this.CreatItemBox();
            this.c_item[j].position = (Vector3) (Vector3.one * 5f);
        }
    }

    public void BloodAttribute(int _index)
    {
        if (this.ef_attribute != _index)
        {
            for (int i = 0; i < 10; i++)
            {
                this.c_ef_blood[i].renderer.material = this.blood_mat[_index];
            }
        }
        this.ef_attribute = _index;
    }

    public void CreatBlood(Vector3 _pos, Vector3 _dir)
    {
        this.c_ef_blood[this.index_ef].gameObject.active = true;
        this.c_ef_blood[this.index_ef].position = _pos + ((Vector3) (Vector3.up * 0.05f));
        if (_dir != Vector3.zero)
        {
            this.c_ef_blood[this.index_ef].rotation = Quaternion.LookRotation(-_dir);
        }
        this.c_ef_hit[this.index_ef].gameObject.active = true;
        this.c_ef_hit[this.index_ef].position = (Vector3) ((_pos + (_dir * 0.1f)) + (Vector3.up * 0.05f));
        this.c_ef_hit[this.index_ef].rotation = Quaternion.Euler(Vector3.up * UnityEngine.Random.Range(0, 360));
        this.index_ef = (this.index_ef + 1) % 10;
    }

    public void CreatBlood_Only(Vector3 _pos, Vector3 _dir)
    {
        this.c_ef_hit[this.index_ef].gameObject.active = true;
        this.c_ef_hit[this.index_ef].position = (Vector3) ((_pos + (_dir * -0.1f)) + (Vector3.up * 0.05f));
        this.c_ef_hit[this.index_ef].rotation = Quaternion.Euler(Vector3.up * UnityEngine.Random.Range(0, 360));
        this.index_ef = (this.index_ef + 1) % 10;
    }

    public void CreatGrabBlood(Vector3 _pos, Quaternion _dir)
    {
        this.grab_blood.gameObject.active = true;
        this.grab_blood.position = _pos;
        this.grab_blood.rotation = _dir;
    }

    public Transform CreatHpbar(Vector2 _size, bool _turretmode, bool _ally)
    {
        GameObject obj2 = new GameObject("hp_bar");
        MeshFilter filter = obj2.AddComponent<MeshFilter>();
        Mesh mesh = new Mesh();
        obj2.AddComponent<MeshRenderer>();
        mesh.vertices = new Vector3[] { new Vector3(-_size.x, _size.y, 0f) * 0.5f, new Vector3(_size.x, _size.y, 0f) * 0.5f, new Vector3(-_size.x, -_size.y, -0.02f) * 0.5f, new Vector3(_size.x, -_size.y, -0.02f) * 0.5f };
        float y = 0f;
        if (_ally)
        {
            y = 0.75f;
        }
        mesh.uv = new Vector2[] { new Vector2(0f, 0.25f + y), new Vector2(0.5f, 0.25f + y), new Vector2(0f, y), new Vector2(0.5f, y) };
        Renderer renderer = obj2.renderer;
        renderer.receiveShadows = false;
        renderer.castShadows = false;
        renderer.sharedMaterial = this.hp_bar;
        mesh.triangles = new int[] { 0, 1, 2, 2, 1, 3 };
        mesh.RecalculateNormals();
        filter.mesh = mesh;
        obj2.transform.parent = this.mytransform;
        if (!_turretmode)
        {
            obj2.AddComponent("Hp_bar");
        }
        else
        {
            obj2.AddComponent("Hp_bar_fixed");
        }
        return obj2.transform;
    }

    public Transform CreatItemBox()
    {
        GameObject obj2 = new GameObject("itemBox");
        MeshFilter filter = obj2.AddComponent<MeshFilter>();
        Mesh mesh = new Mesh();
        obj2.AddComponent<MeshRenderer>();
        mesh.vertices = new Vector3[] { new Vector3(-0.035f, 0.05f, 0.05f), new Vector3(0.035f, 0.05f, 0.05f), Vector3.right * -0.035f, Vector3.right * 0.035f };
        mesh.uv = new Vector2[] { Vector2.up, Vector2.one, Vector2.zero, Vector2.right };
        Renderer renderer = obj2.renderer;
        renderer.receiveShadows = false;
        renderer.castShadows = false;
        renderer.sharedMaterial = this.item_material;
        SphereCollider collider = obj2.AddComponent<SphereCollider>();
        collider.radius = 0.08f;
        collider.enabled = false;
        collider.isTrigger = true;
        mesh.triangles = new int[] { 0, 1, 2, 2, 1, 3 };
        mesh.RecalculateNormals();
        filter.mesh = mesh;
        this.m_item[this.count_item] = mesh;
        this.count_item++;
        obj2.transform.parent = this.mytransform;
        obj2.layer = 13;
        obj2.AddComponent("Itemdrop");
        return obj2.transform;
    }

    public int CreatShadow(Transform _mon, float _size)
    {
        for (int i = 0; i < 15; i++)
        {
            if (this.c_shadow[i].position.y > 2f)
            {
                this.selectshadow = i;
                break;
            }
        }
        this.c_shadow[this.selectshadow].position = (Vector3) (Vector3.one * -1f);
        this.c_shadow[this.selectshadow].GetComponent<Shadow>().Pickparent(_mon, _size);
        this.c_shadow[this.selectshadow].gameObject.active = true;
        return this.selectshadow;
    }

    public void DestroyShadow(int _index)
    {
        this.c_shadow[_index].GetComponent<Shadow>().Finish();
    }

    public void DirectionArrow()
    {
    }

    public void EnemyDead(int _destroy, Vector3 _pos, Texture _tex, Vector3 _scale, Vector3 _forcedir)
    {
        if (!this.story)
        {
            this.script_spawn.EnemyDead(_destroy, _pos, _tex, _scale, _forcedir);
        }
        else
        {
            this.script_spawn_story.EnemyDead(_destroy, _pos, _tex, _scale, _forcedir);
        }
        _pos[1] = 0f;
        this.c_ef_split[this.index_destroy].gameObject.active = true;
        this.c_ef_split[this.index_destroy].position = _pos + ((Vector3) (_forcedir * 0.2f));
        this.c_ef_split[this.index_destroy].rotation = Quaternion.Euler(Vector3.up * UnityEngine.Random.Range(0, 360));
        this.index_destroy = (this.index_destroy + 1) % 10;
    }

    public void FinishEfs()
    {
        for (int i = 0; i < 10; i++)
        {
            this.c_ef_split[i].GetComponent<Ef_split1>().FinishNow();
            this.c_item[i].GetComponent<Itemdrop>().Disappear();
        }
    }

    public void RestrictArea(float _limit_x, float _limit_y_b, float _limit_y_f)
    {
        this.limit_x = _limit_x;
        this.limit_y_b = _limit_y_b;
        this.limit_y_f = _limit_y_f;
    }

    public AudioClip ScreamSFX()
    {
        return this.snd_scream[UnityEngine.Random.Range(0, 4)];
    }

    public void SetDamageNum(Vector3 _pos, short _damage, Vector3 _dir)
    {
        this.c_damagenum[this.count_damagenum].GetComponent<DamageNum>().TextOn(_pos, _damage, _dir);
        this.count_damagenum = (this.count_damagenum + 1) % 10;
    }

    public Transform SetHpbar()
    {
        for (int i = 0; i < 15; i++)
        {
            if (this.c_hpbar[i].position.y > 2f)
            {
                this.selecthpbar = this.c_hpbar[i];
                break;
            }
        }
        return this.selecthpbar;
    }

    public void SetItemBox(int _level, Vector3 _pos)
    {
        int num = UnityEngine.Random.Range(0, 0x3e8);
        int num2 = -1;
        if (this.infinitymode)
        {
            if (num < 20)
            {
                num2 = UnityEngine.Random.Range(100, 120);
                this.c_item[this.count_item].renderer.material = this.main_material;
                this.pt_itemdrop.position = _pos;
                this.pt_itemdrop.particleEmitter.Emit();
            }
            else if (num < 70)
            {
                this.c_item[this.count_item].renderer.material = this.item_material;
                if (num < 0x23)
                {
                    num2 = 2;
                }
                else
                {
                    num2 = 1;
                }
            }
            else
            {
                num2 = -1;
            }
        }
        else if (!this.story)
        {
            if (num < 2)
            {
                num2 = 4;
            }
            else if (num < 30)
            {
                num2 = 3;
            }
            else if (num < 70)
            {
                num2 = 2;
            }
            else if (num < 120)
            {
                num2 = 1;
            }
            else if (num < 200)
            {
                num2 = 0;
            }
            else
            {
                num2 = -1;
            }
        }
        if (num2 >= 0)
        {
            Vector2 zero = Vector2.zero;
            float num3 = 0f;
            if (num2 >= 100)
            {
                int num4 = num2 - 100;
                zero = new Vector2(0.125f * (num4 % 8), 0.125f * (num4 / 8));
                num3 = 0.125f;
            }
            else
            {
                int num5 = num2 % 4;
                int num6 = num2 / 4;
                zero = new Vector2(num5 * 0.25f, 0.75f - (num6 * 0.25f));
                num3 = 0.25f;
            }
            this.m_item[this.count_item].uv = new Vector2[] { zero + (Vector2.up * num3), zero + (Vector2.one * num3), zero, zero + (Vector2.right * num3) };
            _pos[0] = Mathf.Clamp(_pos[0], -this.limit_x, this.limit_x);
            _pos[2] = Mathf.Clamp(_pos[2], this.limit_y_b, this.limit_y_f);
            this.c_item[this.count_item].position = _pos + ((Vector3) (Vector3.up * 0.1f));
            this.c_item[this.count_item].GetComponent<Itemdrop>().Whatsindex(num2, _level);
            this.c_item[this.count_item].gameObject.active = true;
            this.count_item = (this.count_item + 1) % 10;
        }
    }

    public Transform SplitOn(int _rnduv)
    {
        Vector2 zero = Vector2.zero;
        switch (_rnduv)
        {
            case 0:
                zero = (Vector2) (Vector2.up * 0.5f);
                break;

            case 1:
                zero = (Vector2) (Vector2.one * 0.5f);
                break;

            case 2:
                zero = (Vector2) (Vector2.zero * 0.5f);
                break;

            case 3:
                zero = (Vector2) (Vector2.right * 0.5f);
                break;
        }
        GameObject obj2 = new GameObject("split");
        MeshFilter filter = obj2.AddComponent<MeshFilter>();
        Mesh mesh = new Mesh();
        obj2.AddComponent<MeshRenderer>();
        float z = UnityEngine.Random.Range((float) 0.15f, (float) 0.2f);
        mesh.vertices = new Vector3[] { new Vector3(-z, 0.005f, z), new Vector3(z, 0.005f, z), new Vector3(-z, 0.005f, -z), new Vector3(z, 0.005f, -z) };
        mesh.name = "splitmesh";
        mesh.uv = new Vector2[] { ((Vector2) (Vector2.up * 0.5f)) + zero, ((Vector2) (Vector2.one * 0.5f)) + zero, Vector2.zero + zero, ((Vector2) (Vector2.right * 0.5f)) + zero };
        mesh.triangles = new int[] { 0, 1, 2, 2, 1, 3 };
        mesh.RecalculateNormals();
        Renderer renderer = obj2.renderer;
        renderer.receiveShadows = false;
        renderer.castShadows = false;
        renderer.sharedMaterial = this.split_material;
        renderer.sharedMaterial.renderQueue = 0x7d2;
        filter.mesh = mesh;
        obj2.AddComponent("Ef_split1");
        return obj2.transform;
    }

    private void Start()
    {
        if (!this.story)
        {
            this.script_spawn = GameObject.FindWithTag("Respawn").GetComponent<Spawn>();
            this.infinitymode = this.script_spawn.infinitymode;
        }
        else
        {
            this.script_spawn_story = GameObject.FindWithTag("Respawn").GetComponent<Spawn_story>();
        }
        this.grab_blood = (Transform) UnityEngine.Object.Instantiate(this.ef_blood, this.originpos, Quaternion.identity);
        this.grab_blood.parent = this.mytransform;
        this.grab_blood.localScale = new Vector3(0.5f, 1.2f, 1.2f);
        this.count_item = 0;
        this.speed_begrab[0] = 0.25f;
        this.speed_bethrust[0] = 0.5f;
        this.speed_bekicked[0] = 0.2f;
        this.speed_getup[0] = 0.25f;
        this.speed_begrab[1] = 0.28f;
        this.speed_bethrust[1] = 0.28f;
        this.speed_bekicked[1] = 0.25f;
        this.speed_getup[1] = 0.25f;
        this.speed_begrab[2] = 0.24f;
        this.speed_bethrust[2] = 0.28f;
        this.speed_bekicked[2] = 0.25f;
        this.speed_getup[2] = 0.25f;
        this.speed_begrab[3] = 0.35f;
        this.speed_bethrust[3] = 0.25f;
        this.speed_bekicked[3] = 0.3f;
        this.speed_getup[3] = 0.25f;
        this.speed_begrab[4] = 0.4f;
        this.speed_bethrust[4] = 0.25f;
        this.speed_bekicked[4] = 0.25f;
        this.speed_getup[4] = 0.25f;
        this.speed_begrab[5] = 0.22f;
        this.speed_bethrust[5] = 0.25f;
        this.speed_bekicked[5] = 0.28f;
        this.speed_getup[5] = 0.25f;
        this.speed_begrab[6] = 0.35f;
        this.speed_bethrust[6] = 0.35f;
        this.speed_bekicked[6] = 0.25f;
        this.speed_getup[6] = 0.25f;
        this.force_grab[0] = 40;
        this.force_grab[1] = 40;
        this.force_grab[2] = 30;
        this.force_grab[3] = 80;
        this.force_grab[4] = 60;
        this.force_grab[5] = 80;
        this.force_grab[6] = 60;
        this.force_kick[0] = -200;
        this.force_kick[1] = -10;
        this.force_kick[2] = -10;
        this.force_kick[3] = 240;
        this.force_kick[4] = 20;
        this.force_kick[5] = -160;
        this.force_kick[6] = -100;
    }
}


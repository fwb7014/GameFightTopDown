using System;
using UnityEngine;

public class Ef_Coin : MonoBehaviour
{
    private float d_finish;
    private Transform mytransform;
    private Vector3 targetpos;

    private void Awake()
    {
        this.mytransform = base.transform;
        base.gameObject.active = false;
    }

    public void GetCoin(Vector3 _pos)
    {
        this.mytransform.position = _pos;
        this.targetpos = _pos;
        this.targetpos[1] = 0.15f;
        this.d_finish = 0f;
        base.gameObject.active = true;
    }

    private void Update()
    {
        this.d_finish += Time.deltaTime;
        if (this.d_finish > 0.5f)
        {
            base.gameObject.active = false;
        }
        else
        {
            this.mytransform.position = Vector3.Lerp(this.mytransform.position, this.targetpos, Time.deltaTime * 15f);
            this.mytransform.Rotate((Vector3) ((Vector3.up * 1200f) * Time.deltaTime));
        }
    }
}


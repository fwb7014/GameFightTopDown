using System;
using UnityEngine;

public class WeaponDamage : MonoBehaviour
{
    public float colliderofftime;
    private float currenttime;
    public int damage;
    public float destroytime;
    public bool impactDestroy;
    private Collider mycollider;
    private Transform mytransform;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
        this.currenttime = 0f;
    }

    private void OnEnable()
    {
        this.currenttime = 0f;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == 15)
        {
            this.mytransform.forward[1] = 0f;
            other.transform.root.SendMessage("Damaged", this.mytransform.forward + (Vector3.up * this.damage));
            if (this.impactDestroy)
            {
                base.gameObject.active = false;
                this.mytransform.position = (Vector3) (Vector3.one * 5f);
            }
        }
    }

    public void PressDamage(int a)
    {
        this.damage = a;
    }

    private void Update()
    {
        if (this.destroytime > 0f)
        {
            this.currenttime += Time.deltaTime;
            if ((this.colliderofftime > 0f) && (this.currenttime >= this.colliderofftime))
            {
                this.mycollider.enabled = false;
            }
            if (this.currenttime >= this.destroytime)
            {
                this.currenttime = 0f;
                base.gameObject.active = false;
                this.mytransform.position = (Vector3) (Vector3.one * 5f);
                this.mycollider.enabled = true;
            }
        }
    }
}


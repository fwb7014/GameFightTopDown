using System;
using UnityEngine;

public class Ef_forge_hammer : MonoBehaviour
{
    private bool anistart;
    private int framesPerSecond = 20;
    private bool impact;
    private int index;
    private int lastframe;
    private Material mymaterial;
    private Transform mytransform;
    private Vector2 offset;
    private int oldindex = -1;
    private UI_forge script_ui;
    private Vector2 size;
    private float starttime;
    private float uIndex;
    private int uvAnimationTileX = 4;
    private int uvAnimationTileY = 4;
    private int vIndex;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mymaterial = base.renderer.material;
        this.script_ui = GameObject.FindWithTag("ui").GetComponent<UI_forge>();
    }

    public void HammerHit()
    {
        this.index = 0;
        this.starttime = 0f;
        this.oldindex = -1;
        this.impact = false;
        this.anistart = true;
    }

    private void OnEnable()
    {
        this.mytransform.localScale = Vector3.zero;
    }

    private void Start()
    {
        this.starttime = 0f;
        this.lastframe = this.uvAnimationTileX * this.uvAnimationTileY;
        this.size = new Vector2(1f / ((float) this.uvAnimationTileX), 1f / ((float) this.uvAnimationTileY));
    }

    private void Update()
    {
        this.mytransform.localScale = Vector3.MoveTowards(this.mytransform.localScale, (Vector3) (Vector3.one * 2f), Time.deltaTime * 15f);
        if (this.anistart)
        {
            this.starttime += Time.deltaTime;
            this.index = (int) (this.starttime * this.framesPerSecond);
            this.uIndex = this.index % this.uvAnimationTileX;
            this.vIndex = this.index / this.uvAnimationTileY;
            if (this.index != this.oldindex)
            {
                if ((this.index >= 2) && !this.impact)
                {
                    this.script_ui.Impact();
                    this.impact = true;
                }
                if (this.index >= this.lastframe)
                {
                    this.anistart = false;
                }
                else
                {
                    this.offset = (Vector2) (((Vector2.right * this.uIndex) * this.size.x) + (Vector2.up * ((1f - this.size.y) - (this.vIndex * this.size.y))));
                    this.mymaterial.SetTextureOffset("_MainTex", this.offset);
                    this.mymaterial.SetTextureScale("_MainTex", this.size);
                    this.oldindex = this.index;
                }
            }
        }
    }
}


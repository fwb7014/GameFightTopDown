using System;
using UnityEngine;

public class Scenario : MonoBehaviour
{
    private bool b_delay;
    public GUISkin basicSkin;
    public Texture2D black;
    private int cur_difficulty;
    private float[] currentposX = new float[] { -320f, 480f };
    private bool disappear;
    private int dx = 3;
    private Texture2D extraimg;
    private short extraimg_num;
    private float f_delay;
    private short finish;
    private float input_delay = 0.2f;
    private int language;
    private float[] movetowardX = new float[2];
    private Texture2D[] portrait = new Texture2D[2];
    private short pos_idx;
    private float[] remainposX = new float[] { -80f, 240f };
    private short scenecount;
    private DB_Scenario script_db;
    private Language_Scenario script_scenetxt;
    private UI_map script_uimap;
    private bool shake;
    private int showef = 1;
    private float[] startposX = new float[] { -320f, 480f };
    private float[] targetposX = new float[] { 20f, 180f };
    private Texture2D temp;
    private float temptowardX;
    public Texture2D txtbox1;
    private float txtboxscale;

    private void Awake()
    {
        this.script_uimap = GameObject.FindWithTag("ui").GetComponent<UI_map>();
        this.script_db = base.GetComponent<DB_Scenario>();
        this.script_scenetxt = base.GetComponent<Language_Scenario>();
        this.language = PlayerPrefs.GetInt("language");
    }

    public void Delay(float _time)
    {
        this.b_delay = true;
        this.f_delay = _time;
    }

    public void NextScene(short _scenenum)
    {
        this.targetposX[0] = 20f;
        this.targetposX[1] = 180f;
        this.pos_idx = this.script_db.sn[this.cur_difficulty, _scenenum]._pos;
        this.showef = this.script_db.sn[this.cur_difficulty, _scenenum]._showef;
        this.extraimg_num = this.script_db.sn[this.cur_difficulty, _scenenum]._extraimg;
        if (this.extraimg_num > 0x3e8)
        {
            this.extraimg = Resources.Load("extraimg" + this.extraimg_num.ToString()) as Texture2D;
        }
        if (this.portrait[(this.pos_idx + 1) % 2] == null)
        {
            this.targetposX[this.pos_idx] = 80f;
        }
        if (this.showef >= 4)
        {
            this.finish = 1;
            this.movetowardX[this.pos_idx] = this.targetposX[this.pos_idx];
            this.movetowardX[(this.pos_idx + 1) % 2] = this.remainposX[(this.pos_idx + 1) % 2];
            if (this.showef == 5)
            {
                this.Delay(0.3f);
                this.movetowardX[this.pos_idx] = this.startposX[this.pos_idx];
                this.temp = Resources.Load(this.script_db.sn[this.cur_difficulty, _scenenum]._chaimg) as Texture2D;
                this.movetowardX[(this.pos_idx + 1) % 2] = this.remainposX[(this.pos_idx + 1) % 2];
                return;
            }
        }
        else if (this.showef == 3)
        {
            this.targetposX[this.pos_idx] = 80f;
            this.disappear = true;
            this.movetowardX[(this.pos_idx + 1) % 2] = this.startposX[(this.pos_idx + 1) % 2];
            this.Delay(0.5f);
        }
        else if (this.showef == 2)
        {
            if (this.movetowardX[(this.pos_idx + 1) % 2] == 80f)
            {
                this.movetowardX[(this.pos_idx + 1) % 2] = this.targetposX[(this.pos_idx + 1) % 2];
            }
            this.movetowardX[this.pos_idx] = this.targetposX[this.pos_idx];
            this.temptowardX = this.movetowardX[this.pos_idx];
            this.shake = true;
            this.Delay(0.5f);
            base.InvokeRepeating("ShakePos", 0.05f, 0.05f);
            this.movetowardX[(this.pos_idx + 1) % 2] = this.remainposX[(this.pos_idx + 1) % 2];
        }
        else if (this.showef == 1)
        {
            if (this.movetowardX[(this.pos_idx + 1) % 2] == 80f)
            {
                this.movetowardX[(this.pos_idx + 1) % 2] = this.targetposX[(this.pos_idx + 1) % 2];
            }
            if (this.portrait[this.pos_idx] != null)
            {
                this.Delay(0.3f);
                this.movetowardX[this.pos_idx] = this.startposX[this.pos_idx];
                this.temp = Resources.Load(this.script_db.sn[this.cur_difficulty, _scenenum]._chaimg) as Texture2D;
                this.movetowardX[(this.pos_idx + 1) % 2] = this.remainposX[(this.pos_idx + 1) % 2];
                return;
            }
            this.currentposX[this.pos_idx] = this.startposX[this.pos_idx];
            this.movetowardX[this.pos_idx] = this.targetposX[this.pos_idx];
            this.movetowardX[(this.pos_idx + 1) % 2] = this.remainposX[(this.pos_idx + 1) % 2];
        }
        else if (this.showef == 0)
        {
            this.movetowardX[this.pos_idx] = this.targetposX[this.pos_idx];
            this.movetowardX[(this.pos_idx + 1) % 2] = this.remainposX[(this.pos_idx + 1) % 2];
        }
        this.portrait[this.pos_idx] = Resources.Load(this.script_db.sn[this.cur_difficulty, _scenenum]._chaimg) as Texture2D;
    }

    private void OnGUI()
    {
        GUI.depth = -1;
        GUI.skin = this.basicSkin;
        GUI.matrix = Matrix4x4.Scale(new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 64f), this.black);
        GUI.DrawTexture(Crypto.Rect2(0f, 256f, 480f, 74f), this.black);
        for (short i = 0; i < 2; i = (short) (i + 1))
        {
            if (this.portrait[i] != null)
            {
                if (i != this.pos_idx)
                {
                    GUI.color = Color.gray;
                }
                GUI.DrawTexture(Crypto.Rect2(this.currentposX[i], 0f, 300f, 300f), this.portrait[i]);
            }
            GUI.color = Color.white;
        }
        if (this.extraimg_num > 0x3e8)
        {
            if (this.targetposX[this.pos_idx] == 80f)
            {
                GUI.DrawTexture(Crypto.Rect2(280f, 30f, 80f, 80f), this.extraimg);
            }
            else
            {
                GUI.DrawTexture(Crypto.Rect2(200f, 30f, 80f, 80f), this.extraimg);
            }
        }
        if (this.finish != 2)
        {
            GUI.DrawTexture(Crypto.Rect2(40f, 282f - (this.txtboxscale * 0.5f), 400f, this.txtboxscale), this.txtbox1);
            GUI.Label(Crypto.Rect2(60f, 250f, 360f, 64f), this.script_scenetxt.txt_scene[this.language, this.script_db.sn[this.cur_difficulty, this.scenecount - 1]._txtidx], "txt12_0");
        }
    }

    public void SceneStart(int _difficulty)
    {
        base.gameObject.active = true;
        this.cur_difficulty = _difficulty;
        this.NextScene(0);
        this.scenecount = (short) (this.scenecount + 1);
        this.showef = 1;
        this.finish = 0;
        this.disappear = false;
    }

    private void ShakePos()
    {
        this.dx = -this.dx;
        this.movetowardX[this.pos_idx] = this.temptowardX + this.dx;
    }

    private void Update()
    {
        if (this.input_delay < 0f)
        {
            if (Input.GetMouseButtonDown(0) && (this.finish != 2))
            {
                if (this.finish == 1)
                {
                    this.Delay(0.5f);
                    this.finish = 2;
                }
                else
                {
                    this.NextScene(this.scenecount);
                    this.scenecount = (short) (this.scenecount + 1);
                    this.input_delay = 0.2f;
                    this.txtboxscale = 0f;
                }
            }
        }
        else
        {
            this.input_delay -= Time.deltaTime;
        }
        if (this.b_delay)
        {
            this.f_delay -= Time.deltaTime;
            if (this.f_delay <= 0f)
            {
                this.b_delay = false;
                this.f_delay = 0f;
                this.movetowardX[this.pos_idx] = this.targetposX[this.pos_idx];
                if (this.finish == 2)
                {
                    this.scenecount = 0;
                    base.gameObject.active = false;
                    for (int i = 0; i < 2; i++)
                    {
                        this.portrait[i] = null;
                    }
                    this.script_uimap.ScenarioFinish(this.extraimg_num);
                }
                else if (this.disappear)
                {
                    this.disappear = false;
                    this.portrait[(this.pos_idx + 1) % 2] = null;
                }
                else if (this.shake)
                {
                    this.shake = false;
                    base.CancelInvoke("ShakePos");
                }
                else
                {
                    this.portrait[this.pos_idx] = this.temp;
                }
            }
        }
        if (this.finish == 2)
        {
            for (short j = 0; j < 2; j = (short) (j + 1))
            {
                if (this.portrait[j] != null)
                {
                    this.currentposX[j] = Mathf.MoveTowards(this.currentposX[j], this.startposX[j], Time.deltaTime * 1500f);
                }
            }
        }
        else
        {
            for (int k = 0; k < 2; k++)
            {
                this.currentposX[k] = Mathf.MoveTowards(this.currentposX[k], this.movetowardX[k], Time.deltaTime * 1500f);
            }
        }
        this.txtboxscale = Mathf.MoveTowards(this.txtboxscale, 64f, Time.deltaTime * 500f);
    }
}


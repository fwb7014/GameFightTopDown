using System;
using UnityEngine;

public class Bullet_explode : MonoBehaviour
{
    private float c_delay;
    private bool c_emit;
    public float distance;
    private Transform mytransform;
    private Transform pt1;
    private Transform pt2;
    private Transform ptm;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.pt1 = this.mytransform.GetChild(1);
        this.pt2 = this.mytransform.GetChild(2);
        this.ptm = this.mytransform.GetChild(0);
        this.ptm.animation["dt1"].speed = 0.35f;
    }

    private void OnEnable()
    {
        this.pt1.particleEmitter.emit = true;
        this.pt2.particleEmitter.emit = true;
        this.ptm.animation.Play("dt1");
        base.collider.enabled = true;
        this.mytransform.position += (Vector3) (this.mytransform.forward * this.distance);
    }

    private void Update()
    {
        this.c_delay += Time.deltaTime;
        if (this.c_delay > 1.5f)
        {
            this.ptm.animation.Stop("dt1");
            base.gameObject.active = false;
            this.mytransform.position = (Vector3) (Vector3.one * 25f);
            this.c_delay = 0f;
            this.c_emit = false;
        }
        else if (!this.c_emit && (this.c_delay > 0.5f))
        {
            this.pt1.particleEmitter.emit = false;
            this.pt2.particleEmitter.emit = false;
            base.collider.enabled = false;
            this.c_emit = true;
        }
    }
}


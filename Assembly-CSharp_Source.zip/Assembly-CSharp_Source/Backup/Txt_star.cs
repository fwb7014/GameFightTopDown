using System;
using UnityEngine;

public class Txt_star : MonoBehaviour
{
    private bool anistart;
    private float destroydelay;
    private Transform mytransform;
    private Vector3 originpos;
    private Vector3 originscale;
    private Mesh thismesh;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.thismesh = base.GetComponent<MeshFilter>().mesh;
        this.originpos = this.mytransform.position;
        this.originscale = this.mytransform.localScale;
    }

    public void SetStar(int _count)
    {
        this.thismesh.uv = new Vector2[] { Vector2.up * 0.25f, new Vector2(0.3333f * _count, 0.25f), Vector2.zero, (Vector2.right * 0.3333f) * _count };
        this.originscale = new Vector3(0.3333f * _count, 1f, 1f);
        this.mytransform.localScale = new Vector3((float) (2 * _count), 6f, 6f);
        this.destroydelay = 0f;
        this.mytransform.position = this.originpos;
        this.anistart = true;
    }

    private void Start()
    {
    }

    private void Update()
    {
        if (this.anistart)
        {
            this.mytransform.localScale = Vector3.Lerp(this.mytransform.localScale, this.originscale, Time.deltaTime * 8f);
            if (this.destroydelay < 2f)
            {
                this.destroydelay += Time.deltaTime;
            }
            else
            {
                base.gameObject.active = false;
                this.mytransform.position = (Vector3) (Vector3.one * 5f);
                this.destroydelay = 0f;
                this.anistart = false;
            }
        }
    }
}


using System;
using UnityEngine;

public class Cha_Control_ride_cha : MonoBehaviour
{
    public int amount_soulstone;
    private float attackdelay;
    public Transform coin;
    public int count_behit;
    public int count_coin;
    public int count_monster;
    public Transform dummy_weapon;
    public Transform ef_damage;
    public Transform ef_souleat;
    private Transform ef_swing;
    public Transform ef_twirl;
    private float falldowndelay;
    private Transform gauge_navi;
    public Transform horse;
    public Transform horseSpine;
    private bool isfinish;
    private Animation myanimation;
    private Transform mytransform;
    private Transform pack;
    private float particledelay;
    public Transform screen_effect;
    private Cam_Move_ride script_cam;
    private Ef_Coin script_coin;
    private Cha_Control_ride_horse script_horse;
    private MakeUI script_pack;
    private Ef_swing1_ride script_swing;
    private Ef_twirl script_twirl;
    public Transform spear;
    private TextMesh stage_num;

    public void Attack(bool _isright)
    {
        if ((this.attackdelay <= 0f) && (this.mytransform.position.y < 0.01f))
        {
            if (_isright)
            {
                this.myanimation.Play("attack_ride1");
                this.ef_swing.localRotation = Quaternion.Euler(20f, 60f, 170f);
                this.script_swing.SwingOn(0.16f, 2, 2, 0x12, 1, 0);
            }
            else
            {
                this.myanimation.Play("attack_ride2");
                this.ef_swing.localRotation = Quaternion.Euler(20f, -60f, 10f);
                this.script_swing.SwingOn(0.16f, 2, 2, 0x12, 1, 0);
            }
            this.attackdelay = 1f;
        }
    }

    private void Awake()
    {
        UnityEngine.Object.DontDestroyOnLoad(base.gameObject);
        this.mytransform = base.transform;
        this.myanimation = base.animation;
    }

    public void CrynStop()
    {
        this.script_twirl.TwirlOff();
        UnityEngine.Object.Destroy(this.spear.gameObject);
        this.myanimation.Stop();
        this.myanimation["ride2"].speed = 0.16f;
        this.myanimation["ride2"].wrapMode = WrapMode.Once;
        this.myanimation.Play("ride2");
        this.myanimation.PlayQueued("getoff_horse").speed = 0.15f;
        this.myanimation.PlayQueued("risecoin").speed = 0.2f;
        this.myanimation.PlayQueued("idle_ridestage").speed = 0.1f;
    }

    public void Damaged()
    {
        if (!this.isfinish)
        {
            this.GetSoulStone(-3);
        }
    }

    public void FallDown()
    {
        if (!this.isfinish && (this.falldowndelay <= 0f))
        {
            this.script_horse.FallDown();
            this.GetSoulStone(-3);
            this.falldowndelay = 1f;
        }
    }

    public void Finish()
    {
        this.isfinish = true;
    }

    public void GetSoulStone(int a)
    {
        this.amount_soulstone = Mathf.Max(0, this.amount_soulstone + a);
        if (a == 1)
        {
            this.ef_souleat.particleEmitter.emit = true;
            this.script_twirl.TwirlOn(4, 4, 20, false);
            base.audio.Play();
            this.script_coin.GetCoin(this.mytransform.position);
            this.count_coin++;
        }
        else if (a < 0)
        {
            this.screen_effect.gameObject.active = true;
            this.script_cam.Hitcam();
            this.ef_damage.particleEmitter.emit = true;
            this.count_behit++;
        }
        else
        {
            this.count_monster++;
        }
        this.stage_num.text = this.amount_soulstone.ToString();
        this.particledelay = 0.5f;
    }

    public void RisePocket()
    {
        GameObject.FindWithTag("dummy").GetComponent<Obj_Pocket>().PickPocket();
    }

    private void Start()
    {
        this.script_cam = Camera.main.GetComponent<Cam_Move_ride>();
        this.ef_swing = this.mytransform.Find("ef_swing1");
        this.pack = GameObject.FindWithTag("p_plan").transform;
        this.script_coin = this.coin.GetComponent<Ef_Coin>();
        this.script_swing = this.ef_swing.GetComponent<Ef_swing1_ride>();
        this.script_horse = this.horse.GetComponent<Cha_Control_ride_horse>();
        this.script_twirl = this.ef_twirl.GetComponent<Ef_twirl>();
        this.script_pack = this.pack.GetComponent<MakeUI>();
        this.myanimation["ride1"].speed = 0.7f;
        this.myanimation.Play("ride1");
        this.myanimation["attack_ride1"].speed = 0.3f;
        this.myanimation["attack_ride2"].speed = 0.3f;
        this.myanimation["attack_ride1"].layer = 1;
        this.myanimation["attack_ride2"].layer = 1;
        this.gauge_navi = this.script_pack.CreatCustomPlane((Vector2) (Vector2.one * 0.12f), 0f, new Vector3(-1.36f, 2.9f, 1.5f), new Vector2(0.8125f, 0.9375f), new Vector2(0.875f, 1f), "navi_gauge", null, 0f, 0);
        this.script_pack.CreatCustomPlane(new Vector2(1.6f, 0.1f), 0f, new Vector3(-0.64f, 2.9f, 1.8f), new Vector2(0f, 0.375f), new Vector2(1f, 0.4375f), "navi", null, 0f, 0);
        this.script_pack.CreatCustomPlane((Vector2) (Vector2.one * 0.15f), 0f, new Vector3(0.53f, 2.9f, 2.1f), new Vector2(0.75f, 0.9375f), new Vector2(0.8125f, 1f), "icon_soul", null, 0f, 0);
        GameObject obj2 = Resources.Load("stagenum_cave") as GameObject;
        Transform transform = (Transform) UnityEngine.Object.Instantiate(obj2.transform, obj2.transform.localPosition, Quaternion.identity);
        transform.position += (Vector3) (Vector3.right * 0.34f);
        this.stage_num = transform.GetComponent<TextMesh>();
        this.stage_num.text = "0";
    }

    private void Update()
    {
        if (!this.isfinish)
        {
            this.gauge_navi.position += (Vector3) ((Vector3.right * Time.deltaTime) * 0.033f);
        }
        this.mytransform.position = this.horseSpine.position + ((Vector3) (Vector3.up * -0.085f));
        this.mytransform.rotation = this.horse.rotation;
        if (this.falldowndelay > 0f)
        {
            this.falldowndelay -= Time.deltaTime;
        }
        else if (this.attackdelay > 0f)
        {
            this.attackdelay -= Time.deltaTime;
        }
        if (this.particledelay > 0f)
        {
            this.particledelay -= Time.deltaTime;
            if (this.particledelay < 0f)
            {
                this.ef_souleat.particleEmitter.emit = false;
                this.ef_damage.particleEmitter.emit = false;
                this.particledelay = 0f;
            }
        }
    }
}


using System;
using UnityEngine;

public class CamScroll_Extreme : MonoBehaviour
{
    private Transform below;
    private float camsize = 1f;
    private bool camsizechange;
    private Transform cover;
    private float current_camsize = 1f;
    private Vector3 currentCampos;
    public bool drag;
    private bool isevent;
    private float movecamspeed = 7f;
    private float movedelay;
    private Transform mytransform;
    private float prevMposX;
    private bool scrollOn;
    private bool stopmove;
    private float tempx;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    public void DisableMove()
    {
        this.stopmove = true;
    }

    public void EnableMove()
    {
        this.stopmove = false;
    }

    public void MoveTargetCancel()
    {
        this.movedelay = 0f;
        this.isevent = false;
    }

    public void SetCover(Transform _cover, Transform _below, float _camposX, bool _isscroll, float _speed)
    {
        this.cover = _cover;
        this.below = _below;
        this.tempx = _camposX;
        this.tempx = Mathf.Clamp(this.tempx, -10.4f, 10.4f);
        if (_isscroll)
        {
            this.mytransform.position = new Vector3(10.4f, 0f, 1f);
            this.cover.transform.position = new Vector3(-10.4f, -0.15f, -0.5f);
            this.below.transform.position = new Vector3(6.344f, -0.15f, -1.5f);
            this.movedelay = 1f;
            this.movecamspeed = _speed;
        }
        else
        {
            this.mytransform.position = new Vector3(this.tempx, 0f, 1f);
            this.cover.transform.position = new Vector3(-this.tempx, -0.15f, -0.5f);
            this.below.transform.position = new Vector3(this.tempx * 0.61f, -0.15f, -1.5f);
        }
    }

    private void Start()
    {
        base.camera.projectionMatrix = Matrix4x4.Ortho(-1.5f, 1.5f, -1f, 1f, 0.3f, 5f);
    }

    private void Update()
    {
        if (this.movedelay > 0f)
        {
            this.movedelay -= Time.deltaTime;
            float x = Mathf.Lerp(this.mytransform.position.x, this.tempx, Time.deltaTime * this.movecamspeed);
            this.mytransform.position = new Vector3(x, 0f, 1f);
            this.cover.transform.position = new Vector3(-x, -0.15f, -0.5f);
            this.below.transform.position = new Vector3(x * 0.61f, -0.15f, -1.5f);
            this.currentCampos = this.mytransform.position;
            this.scrollOn = false;
            if (!this.isevent || (this.movedelay > 0f))
            {
            }
        }
        else
        {
            if (this.stopmove)
            {
                return;
            }
            if (Input.GetMouseButtonDown(0))
            {
                this.drag = false;
                this.scrollOn = true;
                this.prevMposX = Input.mousePosition.x;
                this.currentCampos = this.mytransform.position;
            }
            else if (Input.GetMouseButtonUp(0))
            {
                this.scrollOn = false;
            }
        }
        if (this.scrollOn)
        {
            this.tempx = (0.006f * (Input.mousePosition.x - this.prevMposX)) * (480f / ((float) Screen.width));
            if (Mathf.Abs(this.tempx) > 0.06f)
            {
                this.drag = true;
            }
            this.tempx += this.currentCampos.x;
            this.tempx = Mathf.Clamp(this.tempx, -10.4f, 10.4f);
            this.mytransform.position = new Vector3(this.tempx, 0f, 1f);
            this.cover.transform.position = new Vector3(-this.tempx, -0.15f, -0.5f);
            this.below.transform.position = new Vector3(this.tempx * 0.61f, -0.15f, -1.5f);
        }
        if (this.camsizechange)
        {
            if (this.current_camsize == this.camsize)
            {
                this.camsizechange = false;
            }
            this.current_camsize = Mathf.MoveTowards(this.current_camsize, this.camsize, Time.deltaTime * 3f);
            base.camera.projectionMatrix = Matrix4x4.Ortho(-1.5f * this.current_camsize, 1.5f * this.current_camsize, -this.current_camsize, this.current_camsize, 0.1f, 5f);
        }
    }
}


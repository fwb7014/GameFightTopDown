using System;
using UnityEngine;

public class Ef_swtrail : MonoBehaviour
{
    private Transform mytransform;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mytransform.localScale = Vector3.zero;
    }

    public void OnEnable()
    {
        this.mytransform.localScale = (Vector3) (Vector3.one * 3f);
    }

    private void Update()
    {
        Transform transform = base.transform;
        transform.localScale -= (Vector3) ((Vector3.one * 10f) * Time.deltaTime);
        if (this.mytransform.localScale.x < 0.1f)
        {
            base.gameObject.active = false;
            this.mytransform.localScale = Vector3.zero;
        }
    }
}


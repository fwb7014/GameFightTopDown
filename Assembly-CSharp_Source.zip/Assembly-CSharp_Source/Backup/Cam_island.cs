using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class Cam_island : MonoBehaviour
{
    private AsyncOperation async;
    public Transform bg;
    private Transform mytransform;
    public Texture2D txt_loading;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void OnGUI()
    {
        GUI.matrix = Matrix4x4.Scale(new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.DrawTexture(Crypto.Rect2(370f, 286f, 100f, 25f), this.txt_loading);
    }

    [DebuggerHidden]
    private IEnumerator Start()
    {
        return new <Start>c__Iterator8 { <>f__this = this };
    }

    private void Update()
    {
        this.mytransform.position -= (Vector3) ((Vector3.forward * Time.deltaTime) * 0.12f);
        if ((this.mytransform.position.z < -0.6f) && this.async.isDone)
        {
            UnityEngine.Object.Destroy(this.mytransform.root.gameObject);
            Camera.main.transform.GetChild(0).gameObject.active = true;
            GameObject.FindWithTag("ui").SendMessage("LoadingFinish");
        }
        this.bg.position = Vector3.Lerp(this.bg.position, (Vector3) (Vector3.up * 0.5f), Time.deltaTime * 0.5f);
    }

    [CompilerGenerated]
    private sealed class <Start>c__Iterator8 : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal Cam_island <>f__this;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<>f__this.async = Application.LoadLevelAdditiveAsync("Stage");
                    this.$current = this.<>f__this.async;
                    this.$PC = 1;
                    return true;

                case 1:
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }
}


using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct stagestat
{
    public short _index;
    public short _bosscount;
    public short _basemon1;
    public short _basemon2;
    public short _mainmon;
    public short _stagenum;
    public short _boss1;
    public short _boss2;
    public short _boss3;
    public short _extramon;
    public short _reward;
}


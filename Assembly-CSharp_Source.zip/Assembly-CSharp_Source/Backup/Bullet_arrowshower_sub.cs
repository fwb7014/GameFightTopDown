using System;
using UnityEngine;

public class Bullet_arrowshower_sub : MonoBehaviour
{
    private Transform mytransform;

    private void Awake()
    {
        this.mytransform = base.transform;
        UnityEngine.Object.Destroy(base.gameObject, 1f);
    }

    private void Update()
    {
        if (this.mytransform.position.y > 0.2f)
        {
            this.mytransform.position -= (Vector3) ((Vector3.up * Time.deltaTime) * 3f);
        }
        else if (this.mytransform.localScale.y > 0f)
        {
            this.mytransform.position -= (Vector3) (Vector3.up * Time.deltaTime);
            this.mytransform.localScale -= (Vector3) (Vector3.up * Time.deltaTime);
        }
    }
}


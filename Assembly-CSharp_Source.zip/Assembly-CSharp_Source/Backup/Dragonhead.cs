using System;
using UnityEngine;

public class Dragonhead : MonoBehaviour
{
    private float active_delay;
    private int impact;
    private AnimationState impact_ani;
    private Animation myanimation;
    private SphereCollider mycollider;
    private Transform mytransform;
    public Transform pt_body;
    public AudioClip snd_bite;
    public AudioClip snd_water;
    public Transform zwater;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = (SphereCollider) base.collider;
        this.myanimation = base.animation;
        this.myanimation["bite_ready"].speed = 0.15f;
    }

    private void OnEnable()
    {
        this.mycollider.enabled = false;
        this.myanimation.Play("bite_ready");
        this.impact_ani = this.myanimation.PlayQueued("bite");
        this.impact_ani.speed = 0.15f;
        this.impact_ani = this.myanimation.PlayQueued("bite_i");
        this.impact_ani.speed = 0.25f;
        this.impact = 0;
        this.pt_body.particleEmitter.emit = true;
        this.zwater.localScale = (Vector3) (Vector3.one * 0.32f);
    }

    private void Update()
    {
        if (this.myanimation.IsPlaying("bite_i"))
        {
            if (this.impact != 2)
            {
                Rigidbody rigidbody = base.rigidbody;
                rigidbody.mass *= 4f;
                this.mycollider.center = (Vector3) (Vector3.forward * 0.1f);
                this.mycollider.enabled = true;
                this.impact = 2;
                this.active_delay = 0f;
                base.audio.clip = this.snd_bite;
                base.audio.Play();
            }
            else
            {
                this.active_delay += Time.deltaTime;
                if (this.active_delay > 3f)
                {
                    this.mycollider.enabled = false;
                    base.gameObject.active = false;
                    this.mytransform.position = (Vector3) (Vector3.one * 16f);
                    this.pt_body.particleEmitter.emit = false;
                    this.active_delay = 0f;
                }
                else if (this.active_delay > 2f)
                {
                    this.zwater.localScale -= (Vector3) ((Vector3.right * Time.deltaTime) * 0.3f);
                }
                else if (this.active_delay > 0.5f)
                {
                    this.mycollider.enabled = false;
                }
            }
            this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * 0.1f);
        }
        else if (this.myanimation.IsPlaying("bite"))
        {
            if (this.impact != 1)
            {
                base.audio.clip = this.snd_water;
                base.audio.Play();
                this.active_delay = 0f;
                this.mycollider.center = Vector3.zero;
                this.mycollider.enabled = true;
                this.impact = 1;
            }
            else
            {
                this.active_delay += Time.deltaTime;
                if (this.active_delay > 0.5f)
                {
                    this.mycollider.enabled = false;
                }
            }
        }
        else if (this.myanimation.IsPlaying("bite_ready"))
        {
            this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * 0.8f);
        }
    }
}


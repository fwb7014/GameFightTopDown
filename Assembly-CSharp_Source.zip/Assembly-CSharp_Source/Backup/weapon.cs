using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct weapon
{
    public short _name;
    public short _info;
    public short _power;
    public float _speed;
    public short _mesh;
    public short _kind;
    public short _jadecost;
}


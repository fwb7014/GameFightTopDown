using System;
using UnityEngine;

public class Bullet_magicmissile : MonoBehaviour
{
    private Transform cha1;
    public float closetime = 3f;
    private float delay;
    private Vector3 directionVector;
    public float homingrate;
    public float homingspeed;
    private Transform mytransform;
    private Vector3 originscale;
    private Vector3 reduceVector;
    private Quaternion rotate;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.originscale = this.mytransform.localScale;
    }

    private void OnEnable()
    {
        this.delay = 0f;
        this.mytransform.localScale = this.originscale;
    }

    public void SetDir()
    {
        this.directionVector = this.cha1.position - this.mytransform.position;
        this.directionVector[1] = 0f;
        if (this.directionVector != Vector3.zero)
        {
            this.rotate = Quaternion.LookRotation(this.directionVector);
        }
    }

    private void Start()
    {
        this.cha1 = GameObject.FindWithTag("Player").transform;
        base.InvokeRepeating("SetDir", 0f, 0.1f);
        this.reduceVector = new Vector3(0.5f, 1f, 1f);
    }

    private void Update()
    {
        this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, this.rotate, Time.deltaTime * this.homingrate);
        this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * this.homingspeed);
        this.delay += Time.deltaTime;
        if (this.delay > this.closetime)
        {
            this.mytransform.localScale -= (Vector3) ((this.reduceVector * Time.deltaTime) * 1.5f);
            if (this.mytransform.localScale.z < 0.02f)
            {
                base.gameObject.active = false;
                this.mytransform.position = (Vector3) (Vector3.one * 4f);
            }
        }
    }
}


using System;
using UnityEngine;

public class Tower_base : MonoBehaviour
{
    private Vector3 attackdir;
    private short cur_stage_index;
    private float damage;
    private short hp;
    private Transform hpbar;
    public bool iscastle;
    private bool istower;
    private bool life = true;
    private short maxhp;
    public Transform mydestroy;
    private Transform mytransform;
    private Cam_Move script_cam;
    private Cha_Control script_cha;
    private Hp_bar_fixed script_hpbar;

    private void Awake()
    {
        this.mytransform = base.transform;
        if (this.mytransform.childCount != 0)
        {
            this.istower = true;
        }
    }

    public void CastleBreak()
    {
        this.life = false;
        base.collider.enabled = false;
        UnityEngine.Object.Destroy(this.hpbar.gameObject);
        UnityEngine.Object.Destroy(this.mytransform.GetChild(0).gameObject);
        if (this.iscastle)
        {
            GameObject.FindWithTag("ui").GetComponent<UI_Ingame>().WaveSet(100);
        }
    }

    public void Grabed()
    {
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer >= 20)
        {
            switch (other.gameObject.layer)
            {
                case 0x12:
                    this.damage = this.script_cha.atk;
                    break;

                case 0x13:
                    this.damage = this.script_cha.atk;
                    break;

                case 20:
                    this.attackdir = this.mytransform.position - other.transform.position;
                    this.attackdir[1] = 0f;
                    this.attackdir = Vector3.Normalize(this.attackdir);
                    other.transform.root.rigidbody.AddForce((Vector3) (this.attackdir * -90f));
                    this.damage = this.script_cha.atk;
                    this.script_cam.Hitcam();
                    break;

                case 0x15:
                    this.damage = this.script_cha.atk;
                    this.script_cam.Hitcam2(1f);
                    break;

                case 0x16:
                    this.damage = other.rigidbody.mass;
                    this.script_cam.Hitcam();
                    break;

                case 0x17:
                    this.damage = other.rigidbody.mass * 2f;
                    this.script_cam.Hitcam();
                    break;

                case 0x18:
                    this.damage = other.rigidbody.mass;
                    this.script_cam.Hitcam();
                    break;

                case 0x19:
                    this.damage = this.script_cha.atk;
                    break;

                case 0x1a:
                    this.damage = other.rigidbody.mass;
                    this.hp = (short) (this.hp - ((short) this.damage));
                    break;

                case 0x1b:
                    this.damage = 2f;
                    break;

                case 0x1c:
                    this.damage = this.script_cha.atk;
                    break;

                case 0x1d:
                    this.damage = this.script_cha.atk * 0.4f;
                    break;

                case 30:
                    this.damage = this.script_cha.atk;
                    break;

                case 0x1f:
                    this.damage = this.script_cha.atk;
                    break;
            }
            this.hp = (short) (this.hp - ((short) this.damage));
            this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, 0.2f, -1);
            base.audio.Play();
            if ((this.hp <= 0) && this.life)
            {
                this.life = false;
                base.collider.enabled = false;
                if (this.iscastle)
                {
                    this.CastleBreak();
                }
                else
                {
                    GameObject.FindWithTag("Respawn").GetComponent<Spawn>().TowerBreak(this.istower);
                    Transform transform = (Transform) UnityEngine.Object.Instantiate(this.mydestroy, this.mytransform.position, this.mytransform.rotation);
                    transform.animation["destroy_tower"].speed = 0.3f;
                    UnityEngine.Object.Destroy(transform.gameObject, 3f);
                    UnityEngine.Object.Destroy(this.hpbar.gameObject);
                    UnityEngine.Object.Destroy(base.gameObject);
                }
            }
        }
    }

    private void Start()
    {
        this.cur_stage_index = (short) Crypto.Load_int_key("cur_stage_index");
        if (this.iscastle)
        {
            this.maxhp = (short) (this.maxhp + ((short) (((((0.1445f * this.cur_stage_index) * this.cur_stage_index) + (6.3873f * this.cur_stage_index)) - 5f) * 20f)));
        }
        else
        {
            this.maxhp = (short) (this.maxhp + ((short) (((((0.1445f * this.cur_stage_index) * this.cur_stage_index) + (6.3873f * this.cur_stage_index)) - 5f) * 3f)));
        }
        this.hp = this.maxhp;
        this.hpbar = GameObject.FindWithTag("efs_mon").GetComponent<Monster_efs>().CreatHpbar(new Vector2(0.1f, 0.02f), true, false);
        this.hpbar.parent = this.mytransform;
        this.script_hpbar = this.hpbar.GetComponent<Hp_bar_fixed>();
        this.script_cha = GameObject.FindWithTag("Player").transform.gameObject.GetComponent<Cha_Control>();
        this.script_cam = Camera.main.GetComponent<Cam_Move>();
        this.hpbar.position = (Vector3) ((this.mytransform.position + (Vector3.forward * -0.08f)) + (Vector3.up * 0.2f));
        this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, 0.2f, -1);
    }

    public bool TankDamage()
    {
        this.hp = (short) (this.hp - (this.maxhp * 0.1f));
        this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, 0.2f, -1);
        base.audio.Play();
        if ((this.hp <= 0) && this.life)
        {
            this.CastleBreak();
        }
        return this.life;
    }
}


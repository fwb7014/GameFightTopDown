using System;
using UnityEngine;

public class Trap_Extreme : MonoBehaviour
{
    public float accuracy = 0.1f;
    private int damage = 1;
    public float duration = 1f;
    public float firerate = 4f;
    public float growScaleSpeed;
    public Transform liveObj;
    public Vector3 movedir;
    private bool moveOn;
    private Collider mycollider;
    private Transform mytransform;
    private Vector3 originTrapScale;
    public bool playAutomatically;
    public bool rndRotation;
    private bool scaleDown;
    private bool scaleUp;
    public float startdelay = 0.5f;
    public float startPosY;
    public Vector3 startScale;
    private Transform target;
    private bool trapOn;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
        this.originTrapScale = this.mytransform.localScale;
        this.target = GameObject.FindWithTag("Player").transform;
        this.mytransform.position = (Vector3) (Vector3.up * 56f);
        this.mytransform.rotation = Quaternion.identity;
        this.mycollider.enabled = false;
    }

    public void DirectFire(Vector3 _pos)
    {
        if (this.trapOn)
        {
            this.mytransform.position = _pos;
            this.Emit_trap();
            if (this.rndRotation)
            {
                this.mytransform.rotation = Quaternion.Euler(0f, (float) UnityEngine.Random.Range(0, 360), 0f);
            }
        }
    }

    private void Disappear_trap()
    {
        if (this.trapOn)
        {
            this.scaleUp = false;
            this.scaleDown = true;
            this.moveOn = false;
            if (this.playAutomatically)
            {
                base.Invoke("Ready_trap", this.firerate + UnityEngine.Random.Range((float) 0f, (float) 2f));
            }
            this.mycollider.enabled = false;
        }
    }

    private void Emit_trap()
    {
        if (this.trapOn)
        {
            this.mytransform.localScale = this.originTrapScale;
            if (this.growScaleSpeed != 0f)
            {
                this.scaleUp = true;
            }
            if (this.movedir != Vector3.zero)
            {
                this.moveOn = true;
            }
            this.mycollider.enabled = true;
            base.Invoke("Disappear_trap", this.duration);
        }
    }

    private void LiveObjOn()
    {
        this.liveObj.SendMessage("StartShoot");
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == 15)
        {
            Vector3.Normalize(other.transform.position - this.mytransform.position)[1] = 0f;
            other.transform.root.SendMessage("Damaged", this.mytransform.forward + (Vector3.up * this.damage));
        }
    }

    private void Ready_trap()
    {
        if (this.trapOn)
        {
            Vector3 vector = this.target.position + ((Vector3) (UnityEngine.Random.onUnitSphere * this.accuracy));
            if (this.startPosY != 0f)
            {
                vector.y = this.startPosY;
            }
            else
            {
                vector.y = 0f;
            }
            this.mytransform.position = vector;
            this.mytransform.localScale = this.startScale;
            if (this.rndRotation)
            {
                this.mytransform.rotation = Quaternion.Euler(0f, (float) UnityEngine.Random.Range(0, 360), 0f);
            }
            base.Invoke("Emit_trap", this.startdelay);
        }
    }

    public void SetDamage(int _damage)
    {
        if (this.liveObj != null)
        {
            base.InvokeRepeating("LiveObjOn", 3f, this.firerate);
        }
        this.damage = _damage;
        base.Invoke("Ready_trap", (this.firerate + UnityEngine.Random.Range((float) 0f, (float) 2f)) + 3f);
        this.trapOn = true;
    }

    public void StopActive()
    {
        if (this.liveObj != null)
        {
            this.liveObj.SendMessage("FisnishShoot");
        }
        base.CancelInvoke();
        this.trapOn = false;
        this.scaleUp = false;
        this.scaleDown = false;
        this.moveOn = false;
        this.mycollider.enabled = false;
        this.mytransform.position = (Vector3) (Vector3.up * 45f);
    }

    private void Update()
    {
        if (this.scaleUp)
        {
            this.mytransform.localScale = Vector3.MoveTowards(this.mytransform.localScale, this.originTrapScale, this.growScaleSpeed * Time.deltaTime);
        }
        else if (this.scaleDown)
        {
            this.mytransform.localScale = Vector3.MoveTowards(this.mytransform.localScale, Vector3.zero, Time.deltaTime);
            if (this.mytransform.localScale.x < 0.01f)
            {
                this.mytransform.position = (Vector3) (Vector3.up * 45f);
                this.scaleDown = false;
            }
        }
        if (this.moveOn && (this.mytransform.position.y > 0f))
        {
            this.mytransform.position += (Vector3) (this.movedir * Time.deltaTime);
        }
    }
}


using System;
using UnityEngine;

public class Sk_fincanon : MonoBehaviour
{
    public Transform beam;
    private CapsuleCollider beamcollider;
    private float delay;
    private Transform mytransform;
    private Vector3 originscale = new Vector3(1f, 1f, 0.1f);
    private bool stat;

    private void Awake()
    {
        this.mytransform = base.transform;
        base.animation["wait"].speed = 1.2f;
        base.animation["creat"].speed = 0.25f;
        base.animation["destroy"].speed = 0.25f;
        base.animation["beam"].speed = 0.8f;
        this.beam.gameObject.active = false;
        this.beamcollider = (CapsuleCollider) this.beam.collider;
    }

    private void OnEnable()
    {
        this.mytransform.localScale = (Vector3) (Vector3.one * 1.5f);
        this.stat = false;
        this.beam.localScale = Vector3.zero;
        this.delay = 0f;
        this.beamcollider.enabled = false;
        this.beamcollider.height = 0f;
        base.InvokeRepeating("Shoot", 0.1f, 0.2f);
        this.beam.gameObject.active = true;
        base.animation.Play("wait");
    }

    public void Shoot()
    {
        if (this.delay > 0.5f)
        {
            this.beamcollider.enabled = false;
            this.beamcollider.enabled = true;
        }
    }

    private void Start()
    {
        this.beam.rigidbody.mass = base.rigidbody.mass;
    }

    private void Update()
    {
        this.delay += Time.deltaTime;
        if (this.delay > 3.4f)
        {
            base.gameObject.active = false;
            this.mytransform.localScale = Vector3.zero;
            this.beam.gameObject.active = false;
            base.CancelInvoke("Shoot");
        }
        else if (this.delay > 2.2f)
        {
            base.animation.Play("destroy");
            if (!this.stat)
            {
                this.beamcollider.enabled = false;
                this.stat = true;
            }
            this.beam.localScale = Vector3.Lerp(this.beam.localScale, Vector3.forward, Time.deltaTime * 15f);
        }
        else if (this.delay > 1f)
        {
            this.beam.localScale = Vector3.Lerp(this.beam.localScale, Vector3.one, Time.deltaTime * 15f);
            base.animation.Play("beam");
        }
        else if (this.delay > 0.8f)
        {
            this.beamcollider.height = Mathf.Lerp(this.beamcollider.height, 0.7f, Time.deltaTime * 6f);
            this.beam.localScale = Vector3.Lerp(this.beam.localScale, this.originscale, Time.deltaTime * 6f);
            this.stat = false;
        }
        else if (this.delay > 0.2f)
        {
            if (!this.stat)
            {
                this.mytransform.parent = null;
                this.stat = true;
            }
            base.animation.Play("creat");
        }
    }
}


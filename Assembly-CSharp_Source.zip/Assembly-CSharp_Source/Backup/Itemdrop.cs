using System;
using UnityEngine;

public class Itemdrop : MonoBehaviour
{
    private Transform cha1;
    private float distime;
    private bool drop;
    private int itemindex;
    private int itemlevel;
    private float maxy = 1.4f;
    private Renderer myrenderer;
    private Transform mytransform;
    private Cha_Control script_cha;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myrenderer = base.renderer;
        base.renderer.sharedMaterial.renderQueue = 0xfa3;
        this.cha1 = GameObject.FindWithTag("Player").transform;
        this.script_cha = this.cha1.GetComponent<Cha_Control>();
    }

    public void Disappear()
    {
        this.mytransform.position = (Vector3) (Vector3.one * 5f);
        base.collider.enabled = false;
        base.gameObject.active = false;
        this.maxy = 1.4f;
        this.distime = 0f;
        this.drop = false;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.transform.IsChildOf(this.cha1))
        {
            this.script_cha.GetItem(this.itemindex, this.itemlevel);
            this.Disappear();
        }
    }

    private void Start()
    {
        base.gameObject.active = false;
    }

    private void Update()
    {
        this.distime += Time.deltaTime;
        if (this.distime > 14f)
        {
            this.Disappear();
        }
        else if (this.distime > 10f)
        {
            if (((this.distime * 10f) % 4f) > 2f)
            {
                this.myrenderer.enabled = true;
            }
            else
            {
                this.myrenderer.enabled = false;
            }
        }
        if (!this.drop)
        {
            if (this.mytransform.position.y >= 0.05f)
            {
                this.maxy -= 4.5f * Time.deltaTime;
                this.mytransform.position += (Vector3) ((Vector3.up * this.maxy) * Time.deltaTime);
            }
            else
            {
                this.drop = true;
                this.script_cha.FindItem(this.mytransform);
                base.collider.enabled = true;
                this.mytransform.position = (Vector3) ((Vector3.right * this.mytransform.position.x) + (Vector3.forward * this.mytransform.position.z));
            }
        }
    }

    public void Whatsindex(int _index, int _level)
    {
        this.itemindex = _index;
        this.itemlevel = _level;
    }
}


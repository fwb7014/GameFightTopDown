using System;
using UnityEngine;

public class RiseAttack : MonoBehaviour
{
    public float destroy_time;
    public float emitfinish_time;
    public float movespeed;
    private Collider mycollider;
    private Transform mytransform;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
    }

    public void DestroyEmitter()
    {
        base.gameObject.active = false;
    }

    public void EmitFinish()
    {
        base.particleEmitter.emit = false;
        this.mycollider.enabled = false;
    }

    private void OnEnable()
    {
        base.Invoke("EmitFinish", this.emitfinish_time);
        base.Invoke("DestroyEmitter", this.destroy_time);
        this.mycollider.enabled = true;
        base.particleEmitter.emit = true;
    }

    private void Update()
    {
        this.mytransform.position += (Vector3) ((this.mytransform.up * Time.deltaTime) * this.movespeed);
    }
}


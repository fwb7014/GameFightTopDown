using System;
using UnityEngine;

public class Bullet_particle : MonoBehaviour
{
    public float active_delay;
    private bool colliderexist;
    private float current_time;
    public float disable_delay;
    private Collider mycollider;
    private ParticleEmitter myemitter;
    public float start_delay;

    private void Awake()
    {
        this.myemitter = base.particleEmitter;
        if (base.collider != null)
        {
            this.mycollider = base.collider;
            this.colliderexist = true;
        }
        base.gameObject.active = false;
    }

    private void OnEnable()
    {
        this.current_time = 0f;
        this.myemitter.emit = false;
        if (this.colliderexist)
        {
            this.mycollider.enabled = false;
        }
    }

    private void Update()
    {
        this.current_time += Time.deltaTime;
        if (this.current_time >= this.disable_delay)
        {
            base.gameObject.active = false;
        }
        if (this.current_time >= this.active_delay)
        {
            this.myemitter.emit = false;
            if (this.colliderexist)
            {
                this.mycollider.enabled = false;
            }
        }
        else if (this.current_time >= this.start_delay)
        {
            this.myemitter.emit = true;
            if (this.colliderexist)
            {
                this.mycollider.enabled = true;
            }
        }
    }
}


using System;
using UnityEngine;

public class Tutorial_ride : MonoBehaviour
{
    public GUISkin basicSkin;
    public GUIStyle bt_yesno;
    private int guide_curent_subindex;
    private Texture guide_img;
    private int language;
    public Texture pop_blank;

    private void OnGUI()
    {
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.skin = this.basicSkin;
        GUI.depth = 0;
        GUI.DrawTexture(Crypto.Rect2(112f, 96f, 256f, 128f), this.pop_blank);
        GUI.Label(Crypto.Rect2(124f, 102f, 232f, 36f), string.Empty + Language.intxt[this.language, 0x185 + this.guide_curent_subindex], "txt12_0");
        GUI.Label(Crypto.Rect2(124f, 200f, 232f, 14f), string.Empty + (this.guide_curent_subindex + 1) + " / 2", "txt12_0");
        GUI.DrawTexture(Crypto.Rect2(170f, 134f, 128f, 64f), this.guide_img);
        if (this.guide_curent_subindex >= 1)
        {
            if (GUI.Button(Crypto.Rect2(290f, 184f, 64f, 32f), Language.intxt[this.language, 4], this.bt_yesno))
            {
                Time.timeScale = 1f;
                base.gameObject.active = false;
                GameObject.FindWithTag("general").audio.Play();
            }
        }
        else if (GUI.Button(Crypto.Rect2(290f, 184f, 64f, 32f), Language.intxt[this.language, 0x2f], this.bt_yesno))
        {
            this.guide_curent_subindex++;
            this.guide_img = Resources.Load("guide9" + this.guide_curent_subindex.ToString()) as Texture2D;
        }
    }

    private void Start()
    {
        this.guide_img = Resources.Load("guide9" + this.guide_curent_subindex.ToString()) as Texture2D;
        this.language = PlayerPrefs.GetInt("language");
    }
}


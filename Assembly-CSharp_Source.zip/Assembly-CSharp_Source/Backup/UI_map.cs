using System;
using UnityEngine;

public class UI_map : MonoBehaviour
{
    public Transform ani_walk;
    private bool b_delay;
    private bool b_scenario;
    public GUIStyle bar_slide;
    public GUISkin basicSkin;
    private Vector3 battleposition;
    public Texture2D bg_asset;
    public Texture2D bg_asset_key;
    public Texture2D bg_asset_lv;
    public Texture2D bg_general;
    public Texture2D bg_mission;
    public Texture2D bg_mission_clear;
    public Texture2D bg_option;
    public Transform bg_popui;
    public Texture2D bg_red;
    public Texture2D bg_titlename;
    private Transform bg_worldmap;
    public Texture2D black;
    public Texture2D black_all;
    private bool bosscutin;
    public GUIStyle bt_bonus;
    public GUIStyle bt_empty;
    public GUIStyle bt_explore;
    public GUIStyle bt_general;
    public GUIStyle bt_general_small;
    public GUIStyle bt_gift;
    public Texture2D bt_lockmenu;
    public GUIStyle bt_menu;
    public GUIStyle bt_shop;
    public GUIStyle bt_sqbox;
    public GUIStyle bt_stagestart;
    public GUIStyle bt_yesno;
    private Transform c_battleicon;
    private Transform c_eficon_break;
    private Transform c_eficon_creat;
    private Transform c_iconef;
    private GameObject cashshop;
    private int chaexp;
    private int chalv;
    private bool changescene;
    private bool clickButton;
    private int coin;
    private short confirm;
    private int cur_difficulty;
    private int cur_general = -1;
    private float cur_generalmaxhp = 1500f;
    private Vector3 cur_stage_iconpos;
    private int cur_stage_kind;
    private string cur_stage_name;
    private int[] cur_workdelay = new int[2];
    private int cutinXpos = 480;
    public Transform ef_breakicon;
    public Transform ef_creaticon;
    public Texture2D empty;
    private int event_stage = -1;
    private Transform eventicon;
    private short explore_method;
    private short explore_progress;
    private int explorekind;
    private bool exploreMode;
    private int extra_info;
    private float f_delay;
    private float g_atkspd;
    private short g_def;
    private short g_grade;
    private short g_level;
    private short g_maxatk;
    private short g_maxhp;
    public Texture2D gauge_exp;
    public Texture2D gauge_hp;
    private int general_cur_hp;
    private int general_hp;
    private short general_index;
    private short general_kind;
    private int[] general_seed = new int[12];
    public Texture2D[] general_weapon = new Texture2D[5];
    private int getslot;
    public Texture2D gift_bg_item;
    public Texture2D gift_coin;
    public Texture2D gift_five_percnt;
    public Texture2D gift_skill;
    public Texture2D gift_skill_bg;
    public Texture2D gift_title;
    private int haveGiftBox;
    public Texture2D hpbase;
    public Texture2D ico_new;
    public Texture2D ico_slide;
    public Texture2D ico_warn;
    public Transform icon_active;
    public Texture2D icon_clear;
    public Texture2D icon_coin;
    public Transform icon_dun;
    public Transform icon_ef;
    public Transform icon_explore;
    public Texture2D[] icon_explorekind = new Texture2D[2];
    public Transform icon_folder;
    public Texture2D icon_jade;
    public Texture2D icon_key;
    public Transform icon_mainbattle;
    public Transform[] icon_mainbattle_clear = new Transform[3];
    public Texture2D[] icon_mission = new Texture2D[3];
    private int icon_size;
    public Texture2D[] icon_stagekind = new Texture2D[5];
    private Texture2D icon_treasure;
    private bool iconactive = true;
    private Vector2 iconmove;
    public Texture2D[] img_menu = new Texture2D[5];
    public Texture2D img_skill_slot;
    private int jade;
    private int key_cave;
    private int language;
    private float length_exp;
    private int max_stage_index;
    private const int MAXGENERAL = 12;
    private const int MAXPET = 2;
    private const int MAXRANKING = 10;
    private const int MAXSTAGE = 90;
    private const int MAXWORK = 2;
    private int[] menuarray = new int[] { 1, 2, 3, 4, 6 };
    private short menuopen = 1;
    public Texture2D mission_lock;
    private bool newarchive;
    private bool newtreasure;
    public Transform obj_scenario;
    private int on_stage_index;
    private bool option;
    private bool overui;
    private bool pause;
    public GUIStyle pausemenu;
    private int[] pet_hunger = new int[2];
    private int play_kind;
    public Texture2D please_touch;
    public Texture2D pop_blank;
    public Texture2D pop_blank2;
    public Texture2D pop_stage;
    private Rect poprect;
    private Texture2D prt_general;
    private Texture2D prt_general_get;
    private Transform ranking;
    private int rnd_speech;
    private LoopArchive script_archive;
    private CamScroll script_cam;
    private General_Stat script_generalstat;
    private Language_Name script_name;
    private SoundEf_UI script_soundUI;
    private int sel_general = -1;
    public GUIStyle sel_lang;
    private int sel_stage_index;
    private bool showAds;
    private int[] skill_slot = new int[5];
    private Texture2D[] skillicon = new Texture2D[5];
    private bool slideon;
    private bool slideon2;
    private int slot_general;
    private const int SLOTPRICE = 3;
    public Transform sound_dummy;
    private Transform sound_UI;
    private int[] stage_clear_grade = new int[90];
    private short stageon;
    public Texture2D star_grade;
    private int storycutin;
    public Texture tex_eventicon;
    public Texture2D titlebase;
    public Texture2D titlebase3;
    public Transform total_collider;
    private float trans_delay;
    private short transmode;
    private int treasureindex;
    private short treasurekind;
    private int tutorial = -1;
    public Texture2D txt_loading;
    public Texture2D txt_start;
    public Texture2D txt_story;
    private Transform uicam;
    private Vector2 v2;
    private float vol_bgm;
    private float vol_master;
    private bool warning_hungry;
    private bool warning_new;
    private short zoom_total;

    public void AniFinish(bool _success)
    {
        if (_success)
        {
            this.Delay(1.5f);
            this.explore_progress = 5;
            this.rnd_speech = UnityEngine.Random.Range(0x5c, 0x60);
        }
        else
        {
            this.explore_progress = 7;
        }
    }

    private void Awake()
    {
        this.vol_bgm = PlayerPrefs.GetFloat("vol_bgm");
        this.vol_master = PlayerPrefs.GetFloat("vol_master");
        AudioListener.volume = this.vol_master;
        TimeControl.InitStart();
        this.uicam = Camera.main.transform;
        this.script_cam = this.uicam.GetComponent<CamScroll>();
        this.poprect = Crypto.Rect2(112f, 204f, 256f, 100f);
        this.script_archive = GameObject.FindWithTag("Finish").GetComponent<LoopArchive>();
        this.haveGiftBox = PlayerPrefs.GetInt("haveDrawedGift", 0);
    }

    public void BattleStart()
    {
        PlayerPrefsX.SetVector3("uiCampos", this.uicam.position);
        TimeControl.SetDelay(1);
        Crypto.Save_int_key("cur_stage_index", this.sel_stage_index);
        Crypto.Save_int_key("cur_stage_kind", this.cur_stage_kind);
        Crypto.Save_int_key("n37", -1);
        Crypto.Save_int_key("play_kind", this.play_kind);
        UnityEngine.Object.Destroy(this.sound_UI.gameObject);
        UnityEngine.Object.Destroy(this.bg_worldmap.gameObject);
    }

    public void CashshopOpen()
    {
        if (this.cashshop == null)
        {
            this.cashshop = Resources.Load("CashShop") as GameObject;
        }
        UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
        this.script_cam.DisableMove();
        this.bg_popui.localScale = Vector3.zero;
    }

    public void CurGeneralStat(bool _start)
    {
        if (_start)
        {
            if (this.cur_general != -1)
            {
                this.script_generalstat.SetGeneral(this.general_seed[this.cur_general]);
                this.cur_generalmaxhp = this.script_generalstat.g_maxhp;
            }
        }
        else
        {
            this.cur_generalmaxhp = this.g_maxhp;
        }
    }

    public void Delay(float t)
    {
        this.b_delay = true;
        this.f_delay = t;
    }

    public void DelayWorkTime()
    {
        for (int i = 0; i < 2; i++)
        {
            this.cur_workdelay[i] = TimeControl.SubtractDelay(i);
        }
        this.general_cur_hp = this.general_hp + ((int) (this.cur_workdelay[1] * 0.2f));
        this.general_cur_hp = Mathf.Min(this.general_cur_hp, (int) this.cur_generalmaxhp);
    }

    public void ExploreIconArray()
    {
        this.exploreMode = true;
        this.icon_folder.position = (Vector3) (Vector3.one * 10f);
        this.icon_dun.position = (Vector3) (Vector3.one * 20f);
        this.Zoom_finger(true, Vector3.zero);
        this.icon_explore.position = Vector3.zero;
    }

    public void ExploreIconFinish()
    {
        this.icon_folder.position = Vector3.zero;
        this.icon_dun.position = Vector3.zero;
        this.exploreMode = false;
        this.Zoom_finger(false, this.icon_folder.GetChild(this.max_stage_index).position);
        this.icon_explore.position = (Vector3) (Vector3.one * 50f);
    }

    public void GeneralKindOnly()
    {
        int num = (this.general_seed[this.cur_general] % 0x989680) / 0x186a0;
        int num2 = num + 1;
        this.prt_general = Resources.Load("prt_general" + num2.ToString()) as Texture2D;
    }

    public void GeneralStat(int _seed, bool _exist)
    {
        this.script_generalstat.SetGeneral(_seed);
        this.general_index = this.script_generalstat.general_index;
        this.general_kind = this.script_generalstat.general_kind;
        this.g_maxatk = this.script_generalstat.g_maxatk;
        this.g_def = this.script_generalstat.g_def;
        this.g_maxhp = this.script_generalstat.g_maxhp;
        this.g_atkspd = this.script_generalstat.g_atkspd;
        this.g_grade = this.script_generalstat.g_grade;
        this.g_level = this.script_generalstat.g_level;
        if (!_exist)
        {
            int num = (this.general_seed[this.getslot] % 0x989680) / 0x186a0;
            int num2 = num + 1;
            this.prt_general_get = Resources.Load("prt_general" + num2.ToString()) as Texture2D;
            int[] intArray = PlayerPrefsX.GetIntArray("n33");
            intArray[this.getslot] = this.g_maxhp;
            PlayerPrefsX.SetIntArray("n33", intArray);
            int[] numArray2 = PlayerPrefsX.GetIntArray("staff");
            numArray2[this.general_index] = Mathf.Max(numArray2[this.general_index], this.g_grade + 1);
            PlayerPrefsX.SetIntArray("staff", numArray2);
        }
    }

    public bool GetGeneral()
    {
        int num = Crypto.Load_int_key("generalsearch") + 1;
        Crypto.Save_int_key("generalsearch", num);
        int num2 = UnityEngine.Random.Range(0, 0x3e8);
        int num3 = 0;
        if (this.tutorial == 4)
        {
            if (this.general_seed[1] == 0)
            {
                num3 = 0xc06a4b;
            }
            else
            {
                num3 = 0x98e51b;
            }
        }
        else
        {
            if (this.explore_method == 1)
            {
                if (num2 > 990)
                {
                    num2 = 4;
                }
                else if (num2 > 850)
                {
                    num2 = 3;
                }
                else
                {
                    num2 = 2;
                }
            }
            else if (this.explore_method == 0)
            {
                if (num2 <= 970)
                {
                    if (num2 <= 770)
                    {
                        if (num2 <= 200)
                        {
                            return false;
                        }
                        num2 = 0;
                    }
                    else
                    {
                        num2 = 1;
                    }
                }
                else
                {
                    num2 = 2;
                }
            }
            int num4 = UnityEngine.Random.Range(0, 90);
            if (this.explore_method == 1)
            {
                num4 = num4 % 20;
            }
            else if (num2 >= 2)
            {
                num4 = num4 % 20;
            }
            else
            {
                num4 = num4 % 30;
            }
            num4 *= 0x186a0;
            num3 = ((UnityEngine.Random.Range(0, 0x2710) + (num2 * 0x2710)) + 0x989680) + num4;
        }
        for (int i = 0; i < this.slot_general; i++)
        {
            if (this.general_seed[i] == 0)
            {
                this.getslot = i;
                this.general_seed[i] = num3;
                PlayerPrefsX.SetIntArray("n13", this.general_seed);
                this.GeneralStat(num3, false);
                break;
            }
        }
        this.newarchive = this.script_archive.FindArchive();
        return true;
    }

    public void GetTreasure()
    {
        int num = UnityEngine.Random.Range(0, 100);
        if (num < 0x37)
        {
            this.treasurekind = 1;
            this.treasureindex = UnityEngine.Random.Range(0, 0x18);
            int num2 = this.treasureindex + 1;
            this.icon_treasure = Resources.Load("treasure" + num2.ToString()) as Texture2D;
            int[] intArray = PlayerPrefsX.GetIntArray("treasure");
            intArray[this.treasureindex]++;
            PlayerPrefsX.SetIntArray("treasure", intArray);
            this.explore_progress = 4;
            this.ani_walk.GetComponent<Ef_ani_walk>().AniStart(4);
            this.newtreasure = this.script_archive.FindTreasure();
        }
        else if (num < 0x39)
        {
            this.treasurekind = 2;
            this.treasureindex = 1;
            this.jade += this.treasureindex;
            Crypto.Property_change(1, true);
            this.explore_progress = 4;
            this.ani_walk.GetComponent<Ef_ani_walk>().AniStart(4);
        }
        else if (num < 70)
        {
            this.treasurekind = 3;
            this.treasureindex = 1;
            this.key_cave++;
            Crypto.Save_int_key("n10", this.key_cave);
            this.explore_progress = 4;
            this.ani_walk.GetComponent<Ef_ani_walk>().AniStart(4);
        }
        else
        {
            this.explore_progress = 8;
            this.ani_walk.gameObject.active = false;
        }
    }

    private void OnEnable()
    {
        this.key_cave = Crypto.Load_int_key("n10");
        this.coin = Crypto.Load_int_key("n17");
        this.jade = Crypto.Load_int_key("n24");
        if (this.explore_progress >= 2)
        {
            this.bg_popui.localScale = (Vector3) (Vector3.one * 5.2f);
            this.bg_popui.localPosition = new Vector3(0f, -0.24f, 0.5f);
        }
        else
        {
            this.script_cam.EnableMove();
        }
    }

    private void OnGUI()
    {
        if (!this.b_scenario && (this.transmode <= 0))
        {
            GUI.skin = this.basicSkin;
            GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
            if (this.zoom_total <= 0)
            {
                if (this.confirm > 0)
                {
                    this.iconactive = false;
                    GUI.enabled = false;
                }
                GUI.DrawTexture(Crypto.Rect2(112f, 0f, 256f, 32f), this.bg_asset);
                GUI.Label(Crypto.Rect2(146f, 6f, 80f, 14f), string.Empty + this.coin, "txt12_w");
                GUI.Label(Crypto.Rect2(280f, 6f, 64f, 14f), string.Empty + this.jade, "txt12_w");
                GUI.DrawTexture(Crypto.Rect2(50f, 0f, 64f, 32f), this.bg_asset_lv);
                GUI.Label(Crypto.Rect2(52f, 3f, 80f, 14f), string.Empty + this.chalv, "txt12_w");
                GUI.DrawTexture(Crypto.Rect2(57f, 20f, this.length_exp, 3f), this.gauge_exp);
                if (this.option)
                {
                    if (this.slideon)
                    {
                        this.vol_bgm = ((Input.mousePosition.x * (480f / ((float) Screen.width))) - 214f) / 126f;
                        this.vol_bgm = Mathf.Clamp(this.vol_bgm, 0f, 1f);
                    }
                    else if (this.slideon2)
                    {
                        this.vol_master = ((Input.mousePosition.x * (480f / ((float) Screen.width))) - 214f) / 126f;
                        this.vol_master = Mathf.Clamp(this.vol_master, 0f, 1f);
                    }
                    GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.black);
                    GUI.DrawTexture(Crypto.Rect2(112f, 85f, 256f, 256f), this.bg_option);
                    GUI.Label(Crypto.Rect2(128f, 108f, 70f, 16f), Language.intxt[this.language, 0x12e], "txt12_w");
                    GUI.Label(Crypto.Rect2(128f, 143f, 70f, 16f), Language.intxt[this.language, 0xf4], "txt12_w");
                    GUI.Label(Crypto.Rect2(128f, 180f, 70f, 16f), Language.intxt[this.language, 0xf5], "txt12_w");
                    if (GUI.Button(Crypto.Rect2(212f, 172f, 128f, 32f), Language.intxt[this.language, 0xf6], this.sel_lang))
                    {
                        short num = 2;
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        this.language = (this.language + 1) % num;
                        PlayerPrefs.SetInt("language", this.language);
                    }
                    if (GUI.RepeatButton(Crypto.Rect2(200f, 101f, 152f, 32f), string.Empty, this.bar_slide))
                    {
                        this.slideon2 = true;
                    }
                    else if (this.slideon2)
                    {
                        AudioListener.volume = this.vol_master;
                        this.slideon2 = false;
                    }
                    GUI.DrawTexture(Crypto.Rect2((this.vol_master * 126f) + 206f, 109f, 16f, 16f), this.ico_slide);
                    if (GUI.RepeatButton(Crypto.Rect2(200f, 136f, 152f, 32f), string.Empty, this.bar_slide))
                    {
                        this.slideon = true;
                    }
                    else if (this.slideon)
                    {
                        this.script_soundUI.SetBGM(this.vol_bgm);
                        this.slideon = false;
                    }
                    GUI.DrawTexture(Crypto.Rect2((this.vol_bgm * 126f) + 206f, 144f, 16f, 16f), this.ico_slide);
                    if (GUI.Button(Crypto.Rect2(208f, 210f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        this.option = false;
                        PlayerPrefs.SetFloat("vol_bgm", this.vol_bgm);
                        PlayerPrefs.SetFloat("vol_master", this.vol_master);
                    }
                }
                else if (this.pause)
                {
                    GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.black);
                    this.stageon = 0;
                    if (GUI.Button(Crypto.Rect2(112f, 80f, 256f, 64f), Language.intxt[this.language, 30], this.pausemenu))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        this.pause = false;
                        Input.multiTouchEnabled = true;
                        this.script_cam.EnableMove();
                    }
                    if (GUI.Button(Crypto.Rect2(112f, 140f, 256f, 64f), Language.intxt[this.language, 0x1f], this.pausemenu))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        this.option = true;
                    }
                    if (GUI.Button(Crypto.Rect2(112f, 200f, 256f, 64f), Language.intxt[this.language, 0x20], this.pausemenu))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        this.pause = false;
                        this.changescene = true;
                        Application.LoadLevel("Intro");
                        PlayerPrefsX.SetVector3("uiCampos", this.uicam.position);
                        this.iconactive = false;
                        UnityEngine.Object.Destroy(this.sound_UI.gameObject);
                        UnityEngine.Object.Destroy(this.bg_worldmap.gameObject);
                    }
                }
                else if (!this.exploreMode)
                {
                    if (GUI.Button(Crypto.Rect2(448f, -1f, 32f, 32f), string.Empty, this.bt_menu))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        this.pause = true;
                        Input.multiTouchEnabled = false;
                        this.script_cam.DisableMove();
                        if (ChannelMgr.GetInstance().getChannelId() == "000116")
                        {
                            AndroidScript.i.loadWDJAds();
                            this.showAds = false;
                        }
                    }
                    else
                    {
                        if ((this.haveGiftBox == 0) && GUI.Button(Crypto.Rect2(4f, 175f, 64f, 64f), string.Empty, this.bt_gift))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            this.confirm = 0x12;
                        }
                        if (!this.exploreMode)
                        {
                            if (GUI.Button(Crypto.Rect2(144f, 2f, 100f, 24f), string.Empty, this.bt_empty))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(0);
                                }
                                Crypto.Save_int_key("cashshopkind", 2);
                                this.CashshopOpen();
                            }
                            if (GUI.Button(Crypto.Rect2(272f, 2f, 88f, 24f), string.Empty, this.bt_empty))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(0);
                                }
                                Crypto.Save_int_key("cashshopkind", 1);
                                this.CashshopOpen();
                            }
                            if (GUI.Button(Crypto.Rect2(366f, 0f, 64f, 28f), string.Empty, this.bt_empty))
                            {
                                Crypto.Save_int_key("gamemode", 1);
                                UnityEngine.Object.Destroy(this.bg_worldmap.gameObject);
                                this.changescene = true;
                                Application.LoadLevel("Extreme");
                            }
                            GUI.DrawTexture(Crypto.Rect2(366f, 1f, 64f, 26f), this.txt_story);
                        }
                        if ((this.stageon == 0) && (this.event_stage >= 0))
                        {
                            if (GUI.Button(Crypto.Rect2(340f, 254f, 64f, 64f), string.Empty, this.bt_bonus))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(0);
                                }
                                this.iconactive = false;
                                this.stageon = 0;
                                this.script_cam.MoveTarget(this.eventicon, true);
                            }
                            if (this.tutorial != 5)
                            {
                                GUI.DrawTexture(Crypto.Rect2(370f, 254f, (float) (this.icon_size * 0x20), (float) (this.icon_size * 0x20)), this.ico_warn);
                            }
                        }
                        if ((this.max_stage_index >= 4) && GUI.Button(Crypto.Rect2(410f, 254f, 64f, 64f), Language.intxt[this.language, 0x191], this.bt_explore))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            if (this.tutorial == 4)
                            {
                                if (this.general_seed[2] != 0)
                                {
                                    this.confirm = 0x10;
                                    this.Delay(1f);
                                }
                                else
                                {
                                    this.iconactive = false;
                                    this.confirm = 1;
                                }
                            }
                            else
                            {
                                this.iconactive = false;
                                this.confirm = 1;
                            }
                            this.script_cam.MoveTargetCancel();
                            this.stageon = 0;
                        }
                        if (GUI.Button(Crypto.Rect2(4f, 106f, 64f, 64f), string.Empty, this.bt_general_small))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            PlayerPrefsX.SetVector3("uiCampos", this.uicam.position);
                            this.iconactive = false;
                            this.stageon = 0;
                            Application.LoadLevel("General");
                        }
                        if (this.cur_general != -1)
                        {
                            GUI.DrawTexture(Crypto.Rect2(16f, 118f, 40f, 40f), this.prt_general);
                            GUI.DrawTexture(Crypto.Rect2(18f, 161f, 36f * (((float) this.general_cur_hp) / this.cur_generalmaxhp), 4f), this.gauge_hp);
                            if (this.general_cur_hp < 20)
                            {
                                GUI.DrawTexture(Crypto.Rect2(16f, 118f, (float) (this.icon_size * 40), 40f), this.bg_red);
                            }
                        }
                        else
                        {
                            GUI.DrawTexture(Crypto.Rect2(16f, 118f, (float) (this.icon_size * 40), 40f), this.empty);
                        }
                        if (GUI.Button(Crypto.Rect2(4f, 254f, 64f, 64f), Language.intxt[this.language, 400], this.bt_shop))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            Crypto.Save_int_key("cashshopkind", 0);
                            this.CashshopOpen();
                        }
                        for (int i = 0; i < 5; i++)
                        {
                            if (i < this.menuopen)
                            {
                                GUI.DrawTexture(Crypto.Rect2((float) (10 + (80 * i)), 30f, 64f, 64f), this.img_menu[i]);
                                if (GUI.Button(Crypto.Rect2((float) (10 + (80 * i)), 30f, 64f, 64f), Language.intxt[this.language, 0x18b + i], this.bt_empty))
                                {
                                    if (this.sound_UI != null)
                                    {
                                        this.script_soundUI.SoundOn(0);
                                    }
                                    PlayerPrefsX.SetVector3("uiCampos", this.uicam.position);
                                    this.iconactive = false;
                                    this.stageon = 0;
                                    switch (i)
                                    {
                                        case 0:
                                            Application.LoadLevel("Skill");
                                            break;

                                        case 1:
                                            Application.LoadLevel("Archive");
                                            break;

                                        case 2:
                                            Application.LoadLevel("Status");
                                            break;

                                        case 3:
                                            Application.LoadLevel("Forge");
                                            break;

                                        case 4:
                                            Application.LoadLevel("Pet");
                                            break;
                                    }
                                }
                                if (this.warning_new && (i == (this.menuopen - 1)))
                                {
                                    GUI.DrawTexture(Crypto.Rect2((float) (10 + (80 * i)), 30f, (float) (this.icon_size * 0x20), (float) (this.icon_size * 0x10)), this.ico_new);
                                }
                                continue;
                            }
                            GUI.DrawTexture(Crypto.Rect2((float) (10 + (80 * i)), 30f, 64f, 64f), this.bt_lockmenu);
                            GUI.Label(Crypto.Rect2((float) (10 + (80 * i)), 77f, 64f, 16f), Language.intxt[this.language, 0x40] + this.menuarray[i] + Language.intxt[this.language, 0x1af], "txt12_r");
                        }
                        if (this.warning_hungry)
                        {
                            GUI.DrawTexture(Crypto.Rect2(370f, 22f, (float) (this.icon_size * 0x20), (float) (this.icon_size * 0x20)), this.ico_warn);
                            GUI.Box(Crypto.Rect2(80f, 100f, 320f, 24f), Language.intxt[this.language, 0x119]);
                        }
                        if (this.newarchive || this.newtreasure)
                        {
                            GUI.DrawTexture(Crypto.Rect2(130f, 22f, (float) (this.icon_size * 0x20), (float) (this.icon_size * 0x20)), this.ico_warn);
                        }
                        for (int j = 0; j < 5; j++)
                        {
                            if (this.skill_slot[j] >= 0)
                            {
                                GUI.DrawTexture(Crypto.Rect2(446f, (float) (0x44 + (j * 0x24)), 28f, 28f), this.skillicon[j]);
                            }
                            else
                            {
                                GUI.DrawTexture(Crypto.Rect2(446f, (float) (0x44 + (j * 0x24)), 28f, 28f), this.black);
                            }
                            GUI.DrawTexture(Crypto.Rect2(444f, (float) (0x42 + (j * 0x24)), 32f, 32f), this.img_skill_slot);
                        }
                        if (GUI.Button(Crypto.Rect2(440f, 60f, 40f, 186f), string.Empty, this.bt_empty))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(1);
                            }
                            this.confirm = 15;
                            this.Delay(1f);
                        }
                        if (this.tutorial >= 0)
                        {
                            switch (this.tutorial)
                            {
                                case 0:
                                    GUI.Box(Crypto.Rect2(112f, 140f, 256f, 32f), Language.intxt[this.language, 0xdd]);
                                    GUI.DrawTexture(Crypto.Rect2(14f, 34f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                                    break;

                                case 1:
                                    GUI.Box(Crypto.Rect2(112f, 140f, 256f, 32f), Language.intxt[this.language, 0xde]);
                                    GUI.DrawTexture(Crypto.Rect2(94f, 34f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                                    break;

                                case 2:
                                    this.tutorial = -1;
                                    Crypto.Save_int_key("tutorial", -1);
                                    break;

                                case 3:
                                    GUI.Box(Crypto.Rect2(112f, 140f, 256f, 32f), Language.intxt[this.language, 0xe0]);
                                    GUI.DrawTexture(Crypto.Rect2(254f, 34f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                                    break;

                                case 4:
                                    if (this.general_seed[1] != 0)
                                    {
                                        if (this.general_seed[2] == 0)
                                        {
                                            GUI.Box(Crypto.Rect2(112f, 140f, 256f, 32f), Language.intxt[this.language, 0xdf]);
                                            if (this.confirm == 0)
                                            {
                                                GUI.DrawTexture(Crypto.Rect2(414f, 252f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                                            }
                                        }
                                        else
                                        {
                                            GUI.Box(Crypto.Rect2(112f, 140f, 256f, 32f), Language.intxt[this.language, 0xe2]);
                                            GUI.DrawTexture(Crypto.Rect2(4f, 110f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                                        }
                                        break;
                                    }
                                    GUI.Box(Crypto.Rect2(112f, 140f, 256f, 32f), Language.intxt[this.language, 0xe1]);
                                    if (this.confirm == 0)
                                    {
                                        GUI.DrawTexture(Crypto.Rect2(414f, 252f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                                    }
                                    break;

                                case 5:
                                    if (this.stageon != 0)
                                    {
                                        GUI.DrawTexture(Crypto.Rect2(310f, 236f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                                        break;
                                    }
                                    GUI.Box(Crypto.Rect2(112f, 140f, 256f, 32f), Language.intxt[this.language, 0xe5]);
                                    GUI.DrawTexture(Crypto.Rect2(344f, 256f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                                    break;

                                case 6:
                                {
                                    int[] intArray = new int[] { 3, 3 };
                                    PlayerPrefsX.SetIntArray("n25", intArray);
                                    this.tutorial = -1;
                                    Crypto.Save_int_key("tutorial", -1);
                                    break;
                                }
                                case 14:
                                    GUI.Box(Crypto.Rect2(112f, 140f, 256f, 32f), Language.intxt[this.language, 0xe3]);
                                    GUI.DrawTexture(Crypto.Rect2(4f, 110f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                                    break;
                            }
                        }
                    }
                }
                else if (this.explore_progress == 0)
                {
                    GUI.DrawTexture(Crypto.Rect2(112f, 250f, 256f, 64f), this.pop_blank);
                    GUI.Label(Crypto.Rect2(112f, 260f, 256f, 14f), Language.intxt[this.language, 0x11a], "txt12_0");
                    if (GUI.Button(Crypto.Rect2(208f, 276f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.ExploreIconFinish();
                        this.stageon = 0;
                    }
                }
                else if (this.explore_progress == 1)
                {
                    this.iconactive = true;
                    GUI.DrawTexture(Crypto.Rect2(112f, 234f, 256f, 64f), this.pop_blank);
                    GUI.DrawTexture(Crypto.Rect2(130f, 242f, 220f, 18f), this.bg_titlename);
                    GUI.Label(Crypto.Rect2(112f, 243f, 256f, 16f), string.Empty + this.cur_stage_name, "txt12_w");
                    GUI.DrawTexture(Crypto.Rect2(106f, 260f, 128f, 32f), this.icon_stagekind[this.cur_stage_kind - 1]);
                    if (GUI.Button(Crypto.Rect2(218f, 260f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        this.explore_progress = 2;
                        this.bg_popui.localScale = (Vector3) (Vector3.one * 5.2f);
                        this.bg_popui.localPosition = new Vector3(0f, -0.24f, 0.5f);
                        this.icon_explore.position = (Vector3) (Vector3.one * 50f);
                    }
                    else if (GUI.Button(Crypto.Rect2(286f, 260f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.explore_progress = 0;
                        this.stageon = 0;
                    }
                }
                else if (this.explore_progress == 2)
                {
                    this.iconactive = false;
                    GUI.DrawTexture(Crypto.Rect2(130f, 78f, 220f, 18f), this.bg_titlename);
                    GUI.Label(Crypto.Rect2(112f, 79f, 256f, 16f), string.Empty + this.cur_stage_name, "txt12_w");
                    if (this.explorekind == 1)
                    {
                        GUI.Label(Crypto.Rect2(120f, 106f, 240f, 16f), Language.intxt[this.language, 0x125], "txt12_0");
                        if (GUI.Button(Crypto.Rect2(112f, 124f, 256f, 64f), Language.intxt[this.language, 0x11c], this.pausemenu))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            if (this.tutorial == 4)
                            {
                                if (this.general_seed[1] != 0)
                                {
                                    this.Delay(1f);
                                    this.confirm = 0x10;
                                }
                                else
                                {
                                    this.explore_progress = 3;
                                    this.ani_walk.GetComponent<Ef_ani_walk>().AniStart(0);
                                    this.explore_method = 0;
                                }
                            }
                            else if (this.coin >= 200)
                            {
                                if (Crypto.Property_change(-200, false))
                                {
                                    this.coin -= 200;
                                    this.explore_progress = 3;
                                    this.ani_walk.GetComponent<Ef_ani_walk>().AniStart(0);
                                    this.explore_method = 0;
                                }
                            }
                            else
                            {
                                this.Delay(1f);
                                this.confirm = 8;
                            }
                        }
                        else if (GUI.Button(Crypto.Rect2(112f, 176f, 256f, 64f), Language.intxt[this.language, 0x11d], this.pausemenu))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            if (this.tutorial == 4)
                            {
                                if (this.general_seed[1] == 0)
                                {
                                    this.Delay(1f);
                                    this.confirm = 0x10;
                                }
                                else
                                {
                                    this.explore_progress = 3;
                                    this.ani_walk.GetComponent<Ef_ani_walk>().AniStart(0);
                                    this.explore_method = 1;
                                }
                            }
                            else if (this.jade >= 5)
                            {
                                if (Crypto.Property_change(-5, true))
                                {
                                    this.jade -= 5;
                                    this.ani_walk.GetComponent<Ef_ani_walk>().AniStart(0);
                                    this.explore_method = 1;
                                    this.explore_progress = 3;
                                    PurchaseLog.LogOn(string.Concat(new object[] { Language.intxt[this.language, 0xea], " (", 5, ")\t", Language.intxt[this.language, 0x11d] }));
                                }
                            }
                            else
                            {
                                this.Delay(1f);
                                this.confirm = 6;
                            }
                        }
                        if (this.tutorial == 4)
                        {
                            GUI.Box(Crypto.Rect2(112f, 276f, 256f, 22f), Language.intxt[this.language, 0x183]);
                            GUI.Box(Crypto.Rect2(158f, 146f, 38f, 20f), "0");
                            GUI.Box(Crypto.Rect2(158f, 198f, 38f, 20f), "0");
                        }
                        else
                        {
                            GUI.Box(Crypto.Rect2(158f, 146f, 38f, 20f), "200");
                            GUI.Box(Crypto.Rect2(158f, 198f, 38f, 20f), string.Empty + 5);
                        }
                        GUI.DrawTexture(Crypto.Rect2(140f, 148f, 16f, 16f), this.icon_coin);
                        GUI.DrawTexture(Crypto.Rect2(140f, 200f, 16f, 16f), this.icon_jade);
                        GUI.DrawTexture(Crypto.Rect2(284f, 148f, 16f, 16f), this.star_grade);
                        GUI.DrawTexture(Crypto.Rect2(284f, 200f, 16f, 16f), this.star_grade);
                        GUI.Label(Crypto.Rect2(286f, 148f, 64f, 16f), "1 ~ 3", "txt12_w");
                        GUI.Label(Crypto.Rect2(286f, 200f, 64f, 16f), "3 ~ 5", "txt12_w");
                    }
                    else
                    {
                        GUI.Label(Crypto.Rect2(112f, 120f, 256f, 16f), Language.intxt[this.language, 0x124], "txt12_0");
                        if (GUI.Button(Crypto.Rect2(112f, 150f, 256f, 64f), Language.intxt[this.language, 0x11c], this.pausemenu))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            if (this.coin >= 100)
                            {
                                if (Crypto.Property_change(-100, false))
                                {
                                    this.coin -= 100;
                                    this.explore_progress = 3;
                                    this.ani_walk.GetComponent<Ef_ani_walk>().AniStart(1);
                                }
                            }
                            else
                            {
                                this.Delay(1f);
                                this.confirm = 8;
                            }
                        }
                        GUI.DrawTexture(Crypto.Rect2(140f, 174f, 16f, 16f), this.icon_coin);
                        GUI.Box(Crypto.Rect2(158f, 172f, 38f, 20f), "100");
                    }
                    if (GUI.Button(Crypto.Rect2(208f, 234f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.explore_progress = 1;
                        this.icon_explore.position = Vector3.zero;
                        this.bg_popui.localScale = Vector3.zero;
                    }
                }
                else if (this.explore_progress == 3)
                {
                    this.iconactive = false;
                    if (this.explorekind == 1)
                    {
                        GUI.Label(Crypto.Rect2(140f, 204f, 200f, 32f), Language.intxt[this.language, 0xbb], "txt12_0");
                    }
                    else
                    {
                        GUI.Label(Crypto.Rect2(140f, 204f, 200f, 32f), Language.intxt[this.language, 0x11b], "txt12_0");
                    }
                }
                else if (this.explore_progress != 4)
                {
                    if (this.explore_progress == 5)
                    {
                        GUI.DrawTexture(Crypto.Rect2(196f, 100f, 88f, 88f), this.prt_general_get);
                        GUI.Label(Crypto.Rect2(140f, 204f, 200f, 32f), this.script_name.txt_name[this.language, this.rnd_speech], "txt12_0");
                        if (this.f_delay == 0f)
                        {
                            this.explore_progress = 6;
                            this.ani_walk.gameObject.active = false;
                        }
                    }
                    else if (this.explore_progress == 6)
                    {
                        this.iconactive = false;
                        GUI.Label(Crypto.Rect2(112f, 86f, 256f, 16f), Language.intxt[this.language, 0x126], "txt12_0");
                        GUI.DrawTexture(Crypto.Rect2(130f, 84f, 220f, 18f), this.bg_titlename);
                        GUI.Label(Crypto.Rect2(130f, 84f, 220f, 16f), this.script_name.txt_name[this.language, 0x15 + this.general_index], "txt12_w");
                        GUI.DrawTexture(Crypto.Rect2(322f, 80f, 26f, 26f), this.general_weapon[this.general_kind]);
                        GUI.DrawTexture(Crypto.Rect2(140f, 127f, 64f, 64f), this.prt_general_get);
                        GUI.DrawTexture(Crypto.Rect2(140f, 112f, 64f, 110f), this.bg_general);
                        GUI.Label(Crypto.Rect2(144f, 193f, 70f, 16f), string.Concat(new object[] { " ", this.g_level, " / ", (this.g_grade + 1) * 20 }), "txt12_w");
                        for (int k = 0; k < (this.g_grade + 1); k++)
                        {
                            GUI.DrawTexture(Crypto.Rect2((float) ((0xa6 - (this.g_grade * 5)) + (k * 10)), 114f, 12f, 12f), this.star_grade);
                        }
                        for (int m = 0; m < 3; m++)
                        {
                            GUI.DrawTexture(Crypto.Rect2(220f, (float) (0x90 + (m * 20)), 128f, 16f), this.titlebase);
                        }
                        GUI.DrawTexture(Crypto.Rect2(220f, 204f, 128f, 16f), this.titlebase3);
                        GUI.DrawTexture(Crypto.Rect2(220f, 112f, 128f, 32f), this.hpbase);
                        GUI.DrawTexture(Crypto.Rect2(225f, 131f, 112f, 5f), this.gauge_hp);
                        GUI.Label(Crypto.Rect2(190f, 111f, 128f, 16f), "HP", "txt12_0");
                        GUI.Label(Crypto.Rect2(190f, 144f, 128f, 16f), Language.intxt[this.language, 0x8d], "txt12_0");
                        GUI.Label(Crypto.Rect2(190f, 164f, 128f, 16f), Language.intxt[this.language, 0x8e], "txt12_0");
                        GUI.Label(Crypto.Rect2(190f, 184f, 128f, 16f), Language.intxt[this.language, 0x127], "txt12_0");
                        GUI.Label(Crypto.Rect2(290f, 111f, 64f, 16f), string.Empty + this.g_maxhp, "txt12_0");
                        GUI.Label(Crypto.Rect2(290f, 144f, 64f, 16f), string.Empty + this.g_maxatk, "txt12_0");
                        GUI.Label(Crypto.Rect2(290f, 164f, 64f, 16f), string.Empty + this.g_def, "txt12_0");
                        GUI.Label(Crypto.Rect2(290f, 184f, 64f, 16f), string.Empty + ((this.g_atkspd * 100f)).ToString("F1"), "txt12_0");
                        if (this.g_grade >= 2)
                        {
                            GUI.Label(Crypto.Rect2(220f, 204f, 128f, 16f), this.script_name.txt_name[this.language, 1 + this.general_index], "txt12_b");
                        }
                        else
                        {
                            GUI.Label(Crypto.Rect2(220f, 204f, 128f, 16f), this.script_name.txt_name[this.language, 0], "txt12_0");
                        }
                        if (GUI.Button(Crypto.Rect2(208f, 230f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            this.bg_popui.localScale = Vector3.zero;
                            this.explore_progress = 0;
                            this.ExploreIconFinish();
                        }
                    }
                    else if (this.explore_progress == 7)
                    {
                        this.iconactive = false;
                        GUI.Label(Crypto.Rect2(140f, 204f, 200f, 32f), Language.intxt[this.language, 0x120], "txt12_0");
                        if (GUI.Button(Crypto.Rect2(208f, 230f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            this.bg_popui.localScale = Vector3.zero;
                            this.explore_progress = 0;
                            this.ExploreIconFinish();
                            this.ani_walk.gameObject.active = false;
                        }
                    }
                    else if (this.explore_progress == 8)
                    {
                        this.iconactive = false;
                        GUI.Label(Crypto.Rect2(140f, 120f, 200f, 32f), Language.intxt[this.language, 240], "txt12_0");
                        if (GUI.Button(Crypto.Rect2(208f, 230f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            this.bg_popui.localScale = Vector3.zero;
                            this.explore_progress = 0;
                            this.ExploreIconFinish();
                        }
                    }
                }
                else
                {
                    this.iconactive = false;
                    GUI.Label(Crypto.Rect2(112f, 204f, 256f, 16f), Language.intxt[this.language, 0x11f], "txt12_0");
                    switch (this.treasurekind)
                    {
                        case 1:
                            GUI.DrawTexture(Crypto.Rect2(224f, 120f, 32f, 32f), this.icon_treasure);
                            break;

                        case 2:
                            GUI.DrawTexture(Crypto.Rect2(224f, 120f, 32f, 32f), this.icon_jade);
                            break;

                        case 3:
                            GUI.DrawTexture(Crypto.Rect2(224f, 120f, 32f, 32f), this.icon_key);
                            break;

                        case 4:
                            GUI.DrawTexture(Crypto.Rect2(224f, 120f, 32f, 32f), this.icon_coin);
                            break;
                    }
                    if (GUI.Button(Crypto.Rect2(208f, 230f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        this.ani_walk.gameObject.active = false;
                        this.bg_popui.localScale = Vector3.zero;
                        this.explore_progress = 0;
                        this.ExploreIconFinish();
                    }
                }
                if (this.confirm > 0)
                {
                    GUI.enabled = true;
                    switch (this.confirm)
                    {
                        case 1:
                            GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 128f), this.pop_blank2);
                            GUI.Label(Crypto.Rect2(112f, 120f, 256f, 14f), Language.intxt[this.language, 0x121], "txt12_0");
                            for (int n = 0; n < 2; n++)
                            {
                                if (GUI.Button(Crypto.Rect2((float) (0xa6 + (0x54 * n)), 136f, 64f, 64f), string.Empty, this.bt_general))
                                {
                                    if (this.sound_UI != null)
                                    {
                                        this.script_soundUI.SoundOn(0);
                                    }
                                    if (n == 1)
                                    {
                                        int num7 = 0;
                                        for (int num8 = 0; num8 < this.slot_general; num8++)
                                        {
                                            if (this.general_seed[num8] == 0)
                                            {
                                                num7++;
                                            }
                                        }
                                        if (num7 == 0)
                                        {
                                            if (this.slot_general >= 12)
                                            {
                                                this.confirm = 9;
                                                this.Delay(1f);
                                            }
                                            else
                                            {
                                                this.confirm = 3;
                                            }
                                            return;
                                        }
                                    }
                                    else if (this.tutorial == 4)
                                    {
                                        this.confirm = 0x10;
                                        this.Delay(1f);
                                        return;
                                    }
                                    this.explorekind = n;
                                    this.ExploreIconArray();
                                    this.confirm = 0;
                                }
                                GUI.DrawTexture(Crypto.Rect2((float) (0xa6 + (0x54 * n)), 136f, 64f, 64f), this.icon_explorekind[n]);
                                GUI.Label(Crypto.Rect2((float) (0xa6 + (0x54 * n)), 137f, 64f, 16f), Language.intxt[this.language, 290 + n], "txt12_w");
                            }
                            if (GUI.Button(Crypto.Rect2(208f, 200f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(1);
                                }
                                this.confirm = 0;
                            }
                            break;

                        case 3:
                            GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                            GUI.Label(Crypto.Rect2(120f, 130f, 230f, 16f), Language.intxt[this.language, 0x12a], "txt12_0");
                            if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(0);
                                }
                                PlayerPrefs.SetInt("n57", 1);
                                Application.LoadLevel("General");
                            }
                            else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(0);
                                }
                                this.confirm = 0;
                            }
                            break;

                        case 6:
                            GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                            GUI.Label(Crypto.Rect2(120f, 130f, 230f, 16f), Language.intxt[this.language, 0x15], "txt12_0");
                            if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(0);
                                }
                                Crypto.Save_int_key("cashshopkind", 1);
                                this.confirm = 0;
                                this.CashshopOpen();
                            }
                            else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(0);
                                }
                                this.confirm = 0;
                                if (this.cur_general >= 0)
                                {
                                    this.sel_general = this.cur_general;
                                    this.GeneralStat(this.general_seed[this.sel_general], true);
                                    this.bg_popui.localScale = (Vector3) (Vector3.one * 5.2f);
                                    if (this.exploreMode)
                                    {
                                        this.bg_popui.localPosition = new Vector3(0f, -0.24f, 0.5f);
                                    }
                                }
                            }
                            break;

                        case 8:
                            GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                            GUI.Label(Crypto.Rect2(120f, 130f, 240f, 16f), Language.intxt[this.language, 0x16], "txt12_0");
                            if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(0);
                                }
                                Crypto.Save_int_key("cashshopkind", 2);
                                this.confirm = 0;
                                this.CashshopOpen();
                            }
                            else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(0);
                                }
                                this.confirm = 0;
                            }
                            break;

                        case 9:
                            GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                            GUI.Label(Crypto.Rect2(112f, 110f, 256f, 64f), Language.intxt[this.language, 0x10b], "txt12_0");
                            if (this.f_delay == 0f)
                            {
                                this.confirm = 0;
                            }
                            break;

                        case 13:
                            GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                            GUI.Label(Crypto.Rect2(112f, 110f, 256f, 64f), Language.intxt[this.language, 0xd0], "txt12_0");
                            if (this.f_delay == 0f)
                            {
                                this.confirm = 0;
                            }
                            break;

                        case 14:
                            GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                            GUI.Label(Crypto.Rect2(120f, 110f, 240f, 64f), Language.intxt[this.language, this.extra_info], "txt12_0");
                            if (this.f_delay == 0f)
                            {
                                this.confirm = 0;
                            }
                            break;

                        case 15:
                            GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                            GUI.Label(Crypto.Rect2(120f, 110f, 240f, 64f), Language.intxt[this.language, 0x5d], "txt12_0");
                            if (this.f_delay == 0f)
                            {
                                this.confirm = 0;
                            }
                            break;

                        case 0x10:
                            GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                            GUI.Label(Crypto.Rect2(120f, 110f, 240f, 64f), Language.intxt[this.language, 0x62], "txt12_0");
                            if (this.f_delay == 0f)
                            {
                                this.confirm = 0;
                            }
                            break;

                        case 0x11:
                            GUI.Box(Crypto.Rect2(112f, 140f, 256f, 32f), Language.intxt[this.language, 0x103]);
                            if (this.f_delay == 0f)
                            {
                                this.confirm = 0;
                            }
                            break;

                        case 0x12:
                            GUI.DrawTexture(Crypto.Rect2(90f, 80f, 300f, 230f), this.pop_blank2);
                            GUI.DrawTexture(Crypto.Rect2(140f, 56f, 200f, 42f), this.gift_title);
                            GUI.DrawTexture(Crypto.Rect2(350f, 70f, 40f, 48f), this.gift_five_percnt);
                            GUI.DrawTexture(Crypto.Rect2(240f, 110f, 64f, 84f), this.gift_skill);
                            GUI.DrawTexture(Crypto.Rect2(240f, 110f, 64f, 84f), this.gift_skill_bg);
                            GUI.DrawTexture(Crypto.Rect2(170f, 110f, 64f, 84f), this.gift_bg_item);
                            GUI.DrawTexture(Crypto.Rect2(170f, 110f, 64f, 64f), this.gift_coin);
                            GUI.DrawTexture(Crypto.Rect2(170f, 174f, 16f, 16f), this.icon_coin);
                            GUI.Label(Crypto.Rect2(176f, 172f, 64f, 20f), "8000", "txt12_w");
                            GUI.Label(Crypto.Rect2(120f, 220f, 240f, 16f), Language.intxt[this.language, 0x1d2], "txt12_0");
                            if (GUI.Button(Crypto.Rect2(160f, 256f, 80f, 32f), Language.intxt[this.language, 0x1d3], this.bt_yesno))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(0);
                                }
                                this.confirm = 0;
                            }
                            else if (GUI.Button(Crypto.Rect2(245f, 256f, 80f, 32f), Language.intxt[this.language, 0x1d4], this.bt_yesno))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(0);
                                }
                                AndroidScript.i.pay("100", "0", 15f, 0, "pay_offline", "010", "5104768", "010", "30000744622508", "10");
                                this.confirm = 0;
                            }
                            break;
                    }
                }
                if (this.stageon > 0)
                {
                    if (this.stageon == 1)
                    {
                        this.overui = true;
                        if (Event.current.isMouse)
                        {
                            this.v2 = new Vector2(Event.current.mousePosition.x, Event.current.mousePosition.y);
                        }
                        if (!this.poprect.Contains(this.v2))
                        {
                            this.overui = false;
                        }
                        GUI.DrawTexture(this.poprect, this.pop_stage);
                        GUI.Label(Crypto.Rect2(120f, 213f, 240f, 16f), string.Concat(new object[] { string.Empty, this.sel_stage_index + 1, ".  ", this.cur_stage_name }), "txt12_w");
                        GUI.DrawTexture(Crypto.Rect2(104f, 230f, 128f, 32f), this.icon_stagekind[this.cur_stage_kind - 1]);
                        GUI.Box(Crypto.Rect2(210f, 234f, 84f, 24f), Language.intxt[this.language, 0x40] + "  " + (this.sel_stage_index + 1));
                        GUI.DrawTexture(Crypto.Rect2((float) (0x7a + (0x39 * this.cur_difficulty)), 262f, 64f, 32f), this.bg_mission);
                        int num9 = this.stage_clear_grade[this.sel_stage_index];
                        for (int num10 = 0; num10 < 3; num10++)
                        {
                            if ((num9 > 0) || (num10 == 0))
                            {
                                GUI.DrawTexture(Crypto.Rect2((float) (140 + (num10 * 0x39)), 262f, 32f, 32f), this.icon_mission[num10]);
                                if (GUI.Button(Crypto.Rect2((float) (0x7e + (num10 * 0x39)), 261f, 56f, 33f), string.Empty, this.bt_empty))
                                {
                                    if (this.sound_UI != null)
                                    {
                                        this.script_soundUI.SoundOn(0);
                                    }
                                    this.cur_difficulty = num10;
                                }
                            }
                            else
                            {
                                GUI.DrawTexture(Crypto.Rect2((float) (140 + (num10 * 0x39)), 262f, 32f, 32f), this.mission_lock);
                            }
                        }
                        if (num9 > 0)
                        {
                            if (num9 > 100)
                            {
                                GUI.DrawTexture(Crypto.Rect2(236f, 262f, 64f, 32f), this.bg_mission_clear);
                            }
                            else
                            {
                                GUI.DrawTexture(Crypto.Rect2(238f, 252f, (float) (this.icon_size * 0x20), 32f), this.ico_warn);
                            }
                            if ((num9 % 100) > 10)
                            {
                                GUI.DrawTexture(Crypto.Rect2(179f, 262f, 64f, 32f), this.bg_mission_clear);
                            }
                            else
                            {
                                GUI.DrawTexture(Crypto.Rect2(181f, 252f, (float) (this.icon_size * 0x20), 32f), this.ico_warn);
                            }
                            GUI.DrawTexture(Crypto.Rect2(122f, 262f, 64f, 32f), this.bg_mission_clear);
                        }
                        GUI.Box(Crypto.Rect2(112f, 166f, 256f, 32f), Language.intxt[this.language, 0x132 + this.cur_difficulty]);
                        if (GUI.Button(Crypto.Rect2(296f, 234f, 64f, 64f), string.Empty, this.bt_stagestart))
                        {
                            Crypto.Save_int_key("n14", this.cur_difficulty);
                            this.BattleStart();
                            this.changescene = true;
                            Application.LoadLevel("Loading");
                        }
                        GUI.DrawTexture(Crypto.Rect2(312f, 256f, 32f, 32f), this.icon_mission[this.cur_difficulty]);
                        GUI.DrawTexture(Crypto.Rect2(296f, 234f, 64f, 32f), this.txt_start);
                    }
                    else if (this.stageon == 2)
                    {
                        GUI.DrawTexture(Crypto.Rect2(112f, 234f, 256f, 64f), this.pop_blank);
                        GUI.DrawTexture(Crypto.Rect2(124f, 244f, 180f, 16f), this.bg_titlename);
                        GUI.Label(Crypto.Rect2(144f, 243f, 128f, 16f), string.Empty + this.cur_stage_name, "txt12_w");
                        GUI.DrawTexture(Crypto.Rect2(144f, 260f, 128f, 32f), this.icon_stagekind[this.cur_stage_kind - 1]);
                        if (GUI.Button(Crypto.Rect2(296f, 234f, 64f, 64f), string.Empty, this.bt_stagestart))
                        {
                            this.BattleStart();
                            this.changescene = true;
                            Application.LoadLevel("Loading");
                        }
                        GUI.DrawTexture(Crypto.Rect2(296f, 250f, 64f, 32f), this.txt_start);
                        if (this.tutorial == 5)
                        {
                            GUI.DrawTexture(Crypto.Rect2(300f, 236f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                        }
                    }
                }
                else
                {
                    this.bosscutin = false;
                    this.cutinXpos = 480;
                }
                if (this.tutorial == 4)
                {
                    if (this.explore_progress == 2)
                    {
                        if (this.confirm == 0)
                        {
                            if (this.general_seed[1] == 0)
                            {
                                GUI.DrawTexture(Crypto.Rect2(212f, 120f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                            }
                            else
                            {
                                GUI.DrawTexture(Crypto.Rect2(212f, 176f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                            }
                        }
                    }
                    else if (this.explore_progress == 1)
                    {
                        GUI.DrawTexture(Crypto.Rect2(222f, 242f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                    }
                    else if (this.confirm == 1)
                    {
                        if (this.general_seed[2] == 0)
                        {
                            GUI.DrawTexture(Crypto.Rect2(254f, 136f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                        }
                    }
                    else if (this.confirm == 10)
                    {
                        GUI.DrawTexture(Crypto.Rect2(174f, 122f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                    }
                }
                if (this.changescene)
                {
                    GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.black_all);
                    GUI.DrawTexture(Crypto.Rect2(370f, 292f, 100f, 25f), this.txt_loading);
                }
            }
        }
    }

    public void ScenarioFinish(int _txt)
    {
        this.b_scenario = false;
        this.extra_info = _txt;
        if (this.storycutin == 1)
        {
            this.transmode = 1;
        }
        else
        {
            this.battleposition = (Vector3) ((this.icon_folder.GetChild(0).position + (Vector3.forward * 0.2f)) + (Vector3.up * 0.09f));
            this.icon_folder.GetChild(0).collider.enabled = true;
            this.c_battleicon = (Transform) UnityEngine.Object.Instantiate(this.icon_mainbattle, this.battleposition - ((Vector3) (Vector3.up * 0.08f)), Quaternion.identity);
            this.icon_folder.GetChild(0).localScale = Vector3.one;
            this.script_cam.MoveTarget(this.icon_folder.GetChild(0), false);
            this.c_iconef = (Transform) UnityEngine.Object.Instantiate(this.icon_ef, this.battleposition + new Vector3(0f, -0.1f, -0.3f), Quaternion.identity);
            this.transmode = 0;
            this.script_cam.EnableMove();
            this.max_stage_index++;
            Crypto.Save_int_key("n06", this.max_stage_index);
            Crypto.Save_int_key("storycutin", 0);
            this.SetMenuOpen();
            this.confirm = 14;
            this.Delay(2f);
        }
        this.storycutin = 0;
    }

    private void SceneStart_Delay()
    {
        this.obj_scenario.GetComponent<Scenario>().SceneStart(this.max_stage_index + 1);
    }

    public void SetMenuOpen()
    {
        if (this.max_stage_index >= 7)
        {
            this.menuopen = 5;
            this.warning_new = false;
        }
        else if (this.max_stage_index >= 6)
        {
            this.menuopen = 5;
            this.warning_new = true;
        }
        else if (this.max_stage_index >= 4)
        {
            this.menuopen = 4;
            this.warning_new = false;
        }
        else if (this.max_stage_index >= 3)
        {
            this.menuopen = 4;
            this.warning_new = false;
        }
        else if (this.max_stage_index >= 2)
        {
            this.menuopen = 3;
            this.warning_new = true;
        }
        else if (this.max_stage_index >= 1)
        {
            this.menuopen = 2;
            this.warning_new = false;
        }
        else
        {
            this.menuopen = 1;
            this.warning_new = false;
        }
    }

    private void SetServerTime()
    {
        TimeControl.RequestServerTime();
        this.DelayWorkTime();
    }

    public void SetStage(int index, int kind, Vector3 pos, int _play)
    {
        if (((this.tutorial != 5) || this.exploreMode) || (this.event_stage == index))
        {
            this.cur_difficulty = 0;
            this.sel_stage_index = index;
            this.cur_stage_kind = kind;
            this.cur_stage_iconpos = pos;
            this.play_kind = _play;
            if (this.sel_stage_index == 100)
            {
                this.changescene = true;
                UnityEngine.Object.Destroy(this.bg_worldmap.gameObject);
                Crypto.Save_int_key("gamemode", 1);
                Application.LoadLevel("Extreme");
            }
            else if (this.exploreMode)
            {
                this.cur_stage_name = this.script_name.txt_name[this.language, 0x42 + this.sel_stage_index];
                this.explore_progress = 1;
            }
            else if (this.event_stage == index)
            {
                this.cur_stage_name = this.script_name.txt_name[this.language, 0x40];
                this.play_kind = 4;
                this.stageon = 2;
            }
            else if (this.tutorial < 0)
            {
                this.cur_stage_name = this.script_name.txt_name[this.language, 0x3d];
                switch (this.play_kind)
                {
                    case 5:
                        this.cur_stage_name = this.script_name.txt_name[this.language, 0x41];
                        break;

                    case 6:
                        this.cur_stage_name = this.script_name.txt_name[this.language, 0x3e];
                        break;

                    case 7:
                        this.cur_stage_name = this.script_name.txt_name[this.language, 0x3f];
                        break;
                }
                this.stageon = 1;
            }
        }
    }

    private void Start()
    {
        int num = Crypto.Load_int_key("n58");
        int num2 = Crypto.Load_int_key("n59");
        if (num != 0)
        {
            Crypto.Property_change(num, true);
            Crypto.Save_int_key("n58", 0);
        }
        else if (num2 != 0)
        {
            Crypto.Property_change(num2, false);
            Crypto.Save_int_key("n59", 0);
        }
        GameObject obj2 = GameObject.Find("bg_worldmap");
        if (obj2 == null)
        {
            GameObject obj3 = Resources.Load("bg_worldmap") as GameObject;
            this.bg_worldmap = (Transform) UnityEngine.Object.Instantiate(obj3.transform, Vector3.zero, Quaternion.identity);
            this.bg_worldmap.name = "bg_worldmap";
        }
        else
        {
            this.bg_worldmap = obj2.transform;
        }
        this.stage_clear_grade = PlayerPrefsX.GetIntArray("n15");
        this.script_name = base.GetComponent<Language_Name>();
        this.script_generalstat = base.GetComponent<General_Stat>();
        this.language = PlayerPrefs.GetInt("language");
        this.tutorial = Crypto.Load_int_key("tutorial");
        this.chalv = Crypto.Load_int_key("n47");
        this.chaexp = Crypto.Load_int_key("n11");
        this.skill_slot = PlayerPrefsX.GetIntArray("skill_slot");
        this.slot_general = Crypto.Load_int_key("n09");
        this.pet_hunger = PlayerPrefsX.GetIntArray("n25");
        this.max_stage_index = Crypto.Load_int_key("n06");
        this.storycutin = Crypto.Load_int_key("storycutin");
        this.cur_general = Crypto.Load_int_key("cur_general");
        this.general_seed = PlayerPrefsX.GetIntArray("n13");
        if (this.cur_general >= 0)
        {
            int[] intArray = PlayerPrefsX.GetIntArray("n33");
            this.general_hp = intArray[this.cur_general];
            this.GeneralKindOnly();
            this.CurGeneralStat(true);
        }
        this.length_exp = (((float) this.chaexp) / ((float) (this.chalv * 100))) * 50f;
        for (int i = 0; i < 5; i++)
        {
            if (this.skill_slot[i] >= 0)
            {
                int num8 = this.skill_slot[i] + 1;
                this.skillicon[i] = Resources.Load("sk_" + num8.ToString()) as Texture2D;
            }
        }
        if (this.max_stage_index > 6)
        {
            for (int k = 0; k < 2; k++)
            {
                if (this.pet_hunger[k] == 0)
                {
                    this.warning_hungry = true;
                }
            }
        }
        if (GameObject.FindWithTag("sound") == null)
        {
            this.sound_UI = (Transform) UnityEngine.Object.Instantiate(this.sound_dummy, Vector3.zero, Quaternion.identity);
        }
        else
        {
            this.sound_UI = GameObject.FindWithTag("sound").transform;
        }
        if (this.storycutin > 0)
        {
            base.Invoke("SceneStart_Delay", 1f);
            this.b_scenario = true;
            this.script_cam.DisableMove();
        }
        else if (this.max_stage_index >= 1)
        {
            this.newarchive = this.script_archive.FindArchive();
        }
        this.event_stage = Crypto.Load_int_key("n37");
        if (this.tutorial == 5)
        {
            this.event_stage = 2;
        }
        short index = 0;
        int num6 = 0;
        for (int j = 0; j < 90; j++)
        {
            this.battleposition = (Vector3) ((this.icon_folder.GetChild(j).position + (Vector3.forward * 0.2f)) + (Vector3.up * 0.09f));
            if (j == this.max_stage_index)
            {
                this.icon_folder.GetChild(this.max_stage_index).collider.enabled = true;
                this.c_battleicon = (Transform) UnityEngine.Object.Instantiate(this.icon_mainbattle, this.battleposition - ((Vector3) (Vector3.up * 0.08f)), Quaternion.identity);
                this.c_battleicon.parent = this.icon_folder;
                this.c_iconef = (Transform) UnityEngine.Object.Instantiate(this.icon_ef, this.battleposition + new Vector3(0f, -0.1f, -0.3f), Quaternion.identity);
                this.c_iconef.parent = this.icon_folder;
                this.icon_folder.GetChild(this.max_stage_index).localScale = Vector3.one;
            }
            else if (j == this.event_stage)
            {
                this.eventicon = this.icon_folder.GetChild(this.event_stage);
                this.eventicon.renderer.material.mainTexture = this.tex_eventicon;
                this.eventicon.localScale = (Vector3) (Vector3.one * 1.4f);
                this.eventicon.collider.enabled = true;
            }
            else if (j < this.max_stage_index)
            {
                this.icon_folder.GetChild(j).collider.enabled = true;
                if (this.stage_clear_grade[j] > 0)
                {
                    if (this.stage_clear_grade[j] == 0x6f)
                    {
                        num6++;
                        index = 2;
                    }
                    else if (this.stage_clear_grade[j] > 1)
                    {
                        index = 1;
                    }
                    else
                    {
                        index = 0;
                    }
                    this.c_battleicon = (Transform) UnityEngine.Object.Instantiate(this.icon_mainbattle_clear[index], this.battleposition, Quaternion.identity);
                    this.c_battleicon.parent = this.icon_folder;
                }
                this.icon_folder.GetChild(j).localScale = Vector3.one;
            }
            else
            {
                this.icon_folder.GetChild(j).localScale = Vector3.zero;
                this.icon_folder.GetChild(j).collider.enabled = false;
            }
        }
        Crypto.Save_int_key("perfectplay", num6);
        this.SetMenuOpen();
        this.script_soundUI = this.sound_UI.GetComponent<SoundEf_UI>();
        this.newtreasure = this.script_archive.FindTreasure();
        base.InvokeRepeating("Warning_iconsize", 1f, 0.34f);
        this.SetServerTime();
        base.InvokeRepeating("SetServerTime", 29f, 30f);
    }

    private void Update()
    {
        if (this.b_delay)
        {
            this.f_delay -= Time.deltaTime;
            if (this.f_delay <= 0f)
            {
                this.b_delay = false;
                this.f_delay = 0f;
            }
        }
        if (this.bosscutin)
        {
            this.cutinXpos = Mathf.Max(0xe0, this.cutinXpos - ((int) (Time.deltaTime * 800f)));
        }
        if (!this.b_scenario)
        {
            if (this.transmode > 0)
            {
                if (this.trans_delay < 1f)
                {
                    this.trans_delay += Time.deltaTime;
                }
                else
                {
                    this.trans_delay = 0f;
                    this.transmode = (short) (this.transmode + 1);
                }
                if (this.transmode == 2)
                {
                    this.battleposition = (Vector3) ((this.icon_folder.GetChild(this.max_stage_index).position + (Vector3.forward * 0.2f)) + (Vector3.up * 0.09f));
                    UnityEngine.Object.Destroy(this.c_battleicon.gameObject);
                    UnityEngine.Object.Destroy(this.c_iconef.gameObject);
                    short index = 0;
                    if (this.stage_clear_grade[this.max_stage_index] == 0x6f)
                    {
                        index = 2;
                    }
                    else if (this.stage_clear_grade[this.max_stage_index] > 1)
                    {
                        index = 1;
                    }
                    else
                    {
                        index = 0;
                    }
                    this.c_battleicon = (Transform) UnityEngine.Object.Instantiate(this.icon_mainbattle_clear[index], this.battleposition, Quaternion.identity);
                    this.c_battleicon.parent = this.icon_folder;
                    this.c_eficon_break = (Transform) UnityEngine.Object.Instantiate(this.ef_breakicon, this.battleposition, Quaternion.identity);
                    UnityEngine.Object.Destroy(this.c_eficon_break.gameObject, 1f);
                    this.max_stage_index++;
                    Crypto.Save_int_key("storycutin", 0);
                    Crypto.Save_int_key("n06", this.max_stage_index);
                    if (this.max_stage_index >= 1)
                    {
                        this.newarchive = this.script_archive.FindArchive();
                    }
                    if (this.max_stage_index >= 90)
                    {
                        this.transmode = 0;
                        UnityEngine.Object.Destroy(this.sound_UI.gameObject);
                        UnityEngine.Object.Destroy(this.bg_worldmap.gameObject);
                        Application.LoadLevel("Ending");
                        return;
                    }
                    this.script_cam.MoveTarget(this.icon_folder.GetChild(this.max_stage_index), false);
                    this.SetMenuOpen();
                    this.transmode = 3;
                }
                else if (this.transmode == 3)
                {
                    this.battleposition = (Vector3) ((this.icon_folder.GetChild(this.max_stage_index).position + (Vector3.forward * 0.2f)) + (Vector3.up * 0.09f));
                    this.c_eficon_creat = (Transform) UnityEngine.Object.Instantiate(this.ef_creaticon, this.battleposition, Quaternion.identity);
                    UnityEngine.Object.Destroy(this.c_eficon_creat.gameObject, 1f);
                    this.transmode = 4;
                }
                else if (this.transmode == 5)
                {
                    this.battleposition = (Vector3) ((this.icon_folder.GetChild(this.max_stage_index).position + (Vector3.forward * 0.2f)) + (Vector3.up * 0.09f));
                    this.icon_folder.GetChild(this.max_stage_index).collider.enabled = true;
                    this.c_battleicon = (Transform) UnityEngine.Object.Instantiate(this.icon_mainbattle, this.battleposition - ((Vector3) (Vector3.up * 0.08f)), Quaternion.identity);
                    this.c_battleicon.parent = this.icon_folder;
                    this.icon_folder.GetChild(this.max_stage_index).localScale = Vector3.one;
                    this.c_iconef = (Transform) UnityEngine.Object.Instantiate(this.icon_ef, this.battleposition + new Vector3(0f, -0.1f, -0.3f), Quaternion.identity);
                    this.c_iconef.parent = this.icon_folder;
                    this.transmode = 0;
                    this.script_cam.EnableMove();
                    if ((this.extra_info > 0) && (this.extra_info < 0x3e8))
                    {
                        this.confirm = 14;
                        this.Delay(2f);
                    }
                }
            }
            else
            {
                if (this.pause)
                {
                    return;
                }
                if ((Input.touchCount == 2) && !this.exploreMode)
                {
                    float num2 = 0f;
                    if (Input.GetTouch(1).phase == TouchPhase.Began)
                    {
                        num2 = Vector2.Distance(Input.GetTouch(0).position, Input.GetTouch(1).position);
                    }
                    else if (((Input.GetTouch(0).phase == TouchPhase.Moved) || (Input.GetTouch(1).phase == TouchPhase.Moved)) && (Mathf.Abs((float) (Vector2.Distance(Input.GetTouch(0).position, Input.GetTouch(1).position) - num2)) > 1.5f))
                    {
                        this.zoom_total = 1;
                        this.Zoom_finger(true, Vector3.one);
                    }
                }
                else if (this.zoom_total == 1)
                {
                    if (Input.GetMouseButtonDown(0))
                    {
                        this.zoom_total = 2;
                    }
                }
                else if (Input.GetMouseButtonUp(0))
                {
                    RaycastHit hit;
                    if (this.script_cam.drag)
                    {
                        return;
                    }
                    Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    if (this.zoom_total == 2)
                    {
                        this.total_collider.gameObject.active = true;
                        Physics.Raycast(ray, out hit);
                        this.Zoom_finger(false, hit.point);
                        this.zoom_total = 0;
                        this.total_collider.gameObject.active = false;
                    }
                    else if (Physics.Raycast(ray, out hit) && this.iconactive)
                    {
                        hit.transform.GetComponent<Icon_Stage>().IconDown();
                        this.iconactive = false;
                    }
                    else
                    {
                        if ((this.stageon == 1) && this.overui)
                        {
                            return;
                        }
                        this.iconactive = true;
                        this.stageon = 0;
                    }
                }
            }
        }
        if (this.stageon > 0)
        {
            this.icon_active.position = this.cur_stage_iconpos;
        }
        else
        {
            this.icon_active.position = (Vector3) (Vector3.forward * -1f);
        }
        this.haveGiftBox = PlayerPrefs.GetInt("haveDrawedGift", 0);
        if (this.haveGiftBox == 1)
        {
            this.coin = Crypto.Load_int_key("n17");
        }
    }

    public void Warning_iconsize()
    {
        this.icon_size = (this.icon_size + 1) % 2;
    }

    public void Zoom_finger(bool _zoomout, Vector3 _pos)
    {
        if (_zoomout)
        {
        }
        this.stageon = 0;
        this.script_cam.Zoom(_zoomout, _pos);
    }
}


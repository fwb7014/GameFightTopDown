using System;
using UnityEngine;

public class Ef_splash : MonoBehaviour
{
    private Transform cha1;
    private bool collidsionOn;
    private float dis;
    private Collider mycollider;
    private Renderer myrenderer;
    private Transform mytransform;
    private Color originTintcolor;
    public Transform rising_fire;
    private bool showon;
    private float showtime = 1.5f;
    private Color tintcolor;
    private Color transColor;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
        this.myrenderer = base.renderer;
    }

    public void ShowOn()
    {
        base.gameObject.active = true;
        this.rising_fire.gameObject.active = true;
        this.myrenderer.enabled = true;
        if (this.collidsionOn)
        {
            this.mycollider.enabled = true;
        }
        this.mytransform.rotation = this.cha1.rotation;
        this.mytransform.position = (Vector3) ((this.cha1.position + (Vector3.up * 0.02f)) + (this.cha1.forward * this.dis));
        this.mytransform.localRotation = Quaternion.identity;
        this.showon = true;
    }

    public void SplashOff()
    {
        if (this.mycollider.enabled)
        {
            this.mycollider.enabled = false;
        }
        base.gameObject.active = false;
        base.CancelInvoke("ShowOn");
    }

    public void SplashOn(bool col, float _dis, float _delay)
    {
        this.collidsionOn = col;
        this.showtime = 1.5f;
        this.myrenderer.material.SetColor("_TintColor", this.originTintcolor);
        this.dis = _dis;
        base.Invoke("ShowOn", _delay);
    }

    private void Start()
    {
        this.cha1 = GameObject.FindWithTag("Player").transform;
        this.myrenderer.enabled = false;
        this.mycollider.enabled = false;
        this.originTintcolor = this.myrenderer.material.GetColor("_TintColor");
        base.gameObject.active = false;
    }

    private void Update()
    {
        if (this.showon)
        {
            this.showtime -= Time.deltaTime;
            if (this.showtime <= 1.3f)
            {
                if (this.showtime > 0.5f)
                {
                    if (this.mycollider.enabled)
                    {
                        this.mycollider.enabled = false;
                    }
                }
                else if (this.showtime > 0f)
                {
                    if (this.mycollider.enabled)
                    {
                        this.mycollider.enabled = false;
                    }
                    this.tintcolor = this.myrenderer.material.GetColor("_TintColor");
                    this.transColor = Color.Lerp(this.tintcolor, Color.clear, Time.deltaTime * 14f);
                    this.myrenderer.material.SetColor("_TintColor", this.transColor);
                }
                else
                {
                    base.gameObject.active = false;
                    this.mytransform.position = (Vector3) (Vector3.one * 14f);
                }
            }
        }
    }
}


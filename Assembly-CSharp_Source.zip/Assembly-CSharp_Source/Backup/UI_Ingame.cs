using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class UI_Ingame : MonoBehaviour
{
    public bool angelOn;
    private int atk;
    public Transform bg_popui;
    public Texture2D[] card = new Texture2D[3];
    private Transform cha1;
    private float chaexp;
    private int chahp = 100;
    private int chalv = 1;
    private int chamaxhp = 100;
    private float chamaxsp = 100f;
    private int chaprevlv;
    private bool chargeon;
    private float chasp = 100f;
    private int coin;
    private float combo_length;
    private int cur_angel;
    public int cur_difficulty;
    private int cur_general = -1;
    private int cur_stage_index;
    public Transform[] cut_extreme = new Transform[2];
    private int damagecount;
    private int def;
    private int dropcoin;
    private int dropjade;
    private int enemykill;
    private int exattack;
    private float exp_height;
    private TextMesh extreme_num;
    private int extreme_point;
    private float extreme_point_cur;
    private float f_charge;
    private float f_soul;
    private int finalstage;
    private float finishdelay;
    private Transform g_combo;
    private Transform g_hp;
    private Transform g_mp;
    private Transform g_power;
    private Gauge_UV gauge_combo;
    private Gauge_UV gauge_exp;
    private Gauge_UV gauge_hp;
    private Gauge_UV gauge_mp;
    private Gauge_UV gauge_power;
    private bool gauge_scalechange;
    private Gauge_UV gauge_sp;
    private Gauge_UV gauge_stage;
    private bool general;
    private bool generaldead;
    private int getcoin;
    private Transform getcoin_num;
    private Transform giftbox;
    private int grappling;
    private int hit;
    private float hp_length;
    private bool infinitymode;
    private int jade;
    private short killcount;
    private bool loadingfinish;
    private int max_stage_index;
    private float mp_length;
    public Transform num_level;
    public Transform pack;
    private int play_kind;
    private float playtime;
    private TextMesh point_num;
    public Transform pt_levelup;
    private bool returnmap;
    private short rewardkind;
    private Cha_Control script_cha;
    private Icon_Skill script_icon;
    private UI_Ingame_GUI script_OnGUI;
    private MakeUI script_pack;
    private Spawn script_spawn;
    private int soul = 1;
    private float soulgain;
    private float sp_length;
    private int spr;
    private TextMesh stage_num;
    private short stage_progress;
    private bool stageRegen = true;
    private bool supermode;
    private int total_star;
    private int totalkillcount;
    private int tutorial = -1;
    private int tutorial_maxcombo;
    public Transform txt_maxcombo;
    private Transform txt_result;
    private Transform txt_star;
    public Transform ui_ingame_gui;
    private int wave;

    public bool CallGeneral(short _dead)
    {
        if (this.cur_general < 0)
        {
            return false;
        }
        if (!this.script_cha.life || this.generaldead)
        {
            return false;
        }
        if (this.chasp < 10f)
        {
            return false;
        }
        if (!this.general)
        {
            this.general = true;
            this.script_icon.SkillIcon_Move(true);
            this.script_icon.PetIcon_Move(true);
            this.script_icon.GeneralSkillFillbox(true);
        }
        else
        {
            this.general = false;
            this.script_icon.SkillIcon_Move(false);
            this.script_icon.PetIcon_Move(false);
            this.script_icon.GeneralSkillFillbox(false);
        }
        this.g_hp.localScale = -Vector3.one;
        this.gauge_scalechange = true;
        this.script_spawn.CallGeneral(this.general, this.chahp, this.chamaxhp);
        this.script_cha.GeneralOnOff(this.general, _dead);
        return true;
    }

    public void ComboPlus(float _amount)
    {
        if (!this.supermode && (this.combo_length < 0.5f))
        {
            this.combo_length += _amount;
            this.gauge_combo.UvMove((Vector2) (Vector2.right * -this.combo_length));
            if (this.combo_length >= 0.5f)
            {
                this.supermode = true;
                this.txt_maxcombo.gameObject.active = true;
                this.txt_maxcombo.GetChild(0).gameObject.active = true;
                this.g_combo.position = (Vector3) (Vector3.up * 5f);
                this.script_cha.MaxCombo();
                if (this.tutorial_maxcombo == 0)
                {
                    this.ui_ingame_gui.gameObject.active = true;
                    this.script_OnGUI.SetTutorial(7, 0);
                    this.tutorial_maxcombo = 1;
                    PlayerPrefs.SetInt("tutorial2", 1);
                }
            }
        }
    }

    private void CountDown()
    {
        int num = (int) (this.playtime / 60f);
        int num2 = ((int) this.playtime) % 60;
        string str = " : ";
        if (num2 < 10)
        {
            str = " : 0";
        }
        this.stage_num.text = num + str + num2;
    }

    public void Damaged()
    {
        this.hp_length += 0.0625f;
        this.gauge_hp.UvMove((Vector2) (Vector2.right * this.hp_length));
        this.damagecount++;
        if (this.damagecount >= 3)
        {
            this.WaveSet(-1);
            this.script_cha.MissionFail();
            this.script_cha.StopControl();
        }
    }

    public void Damaged_Extreme()
    {
        this.damagecount++;
    }

    public void GainCoin(int a)
    {
        this.coin += a;
        this.dropcoin += a;
        Crypto.Property_change(a, false);
    }

    public void GainJade(int a)
    {
        this.jade += a;
        this.dropjade += a;
        Crypto.Property_change(a, true);
    }

    public bool GainSoul(float _amount)
    {
        bool flag = false;
        this.f_soul += _amount;
        if (!this.infinitymode)
        {
            this.f_soul = Mathf.Clamp(this.f_soul, 0f, 8f);
        }
        if (((int) this.f_soul) != this.soul)
        {
            this.soul = (int) this.f_soul;
            this.mp_length = (1f - (((float) this.soul) / 8f)) * 0.5f;
            if (!this.infinitymode)
            {
                this.gauge_mp.UvMove((Vector2) (Vector2.right * this.mp_length));
            }
            flag = true;
        }
        this.script_icon.SoulMeasure(this.soul);
        return flag;
    }

    public void GameOver()
    {
        int num = Crypto.Load_int_key("death") + 1;
        Crypto.Save_int_key("death", num);
        this.ui_ingame_gui.gameObject.active = true;
        this.script_OnGUI.ChanceOn();
    }

    public void GeneralDead()
    {
        this.general = false;
        this.generaldead = true;
        this.script_icon.SkillIcon_Move(false);
        this.script_icon.PetIcon_Move(false);
        this.script_icon.GeneralSkillFillbox(false);
        this.script_icon.GeneralDead();
    }

    public void GetAngel()
    {
        Texture texture = Resources.Load("petkind_angel" + this.cur_angel.ToString()) as Texture;
        this.bg_popui.renderer.material.mainTexture = texture;
        this.bg_popui.gameObject.active = true;
        this.bg_popui.localPosition = new Vector3(0f, 5f, 1.5f);
        base.Invoke("GetAngel_GUI", 1f);
    }

    private void GetAngel_GUI()
    {
        this.ui_ingame_gui.gameObject.active = true;
        this.script_OnGUI.GetAngel(this.cur_angel);
    }

    public void GetCoin()
    {
        this.getcoin += (int) (((this.wave * 4) + 80) * ((this.total_star * 0.1f) + 1f));
        Crypto.Property_change(this.getcoin, false);
        this.getcoin_num.GetComponent<CaveGetCoinNum>().GetOn(this.getcoin);
    }

    public bool GetExp(int _grab)
    {
        bool flag = false;
        this.script_cha.KillEnemy();
        if (!this.infinitymode)
        {
            flag = this.GainSoul(this.soulgain);
        }
        else
        {
            this.extreme_point += this.wave * 200;
            this.point_num.text = this.extreme_point.ToString();
        }
        this.chaexp = this.script_cha.exp;
        this.chalv = this.script_cha.level;
        this.killcount = (short) (this.killcount + 1);
        this.totalkillcount++;
        if (this.play_kind <= 5)
        {
            if (this.infinitymode)
            {
                if (this.killcount >= 10)
                {
                    this.stage_progress = (short) (this.stage_progress - 1);
                    this.gauge_stage.UvMove((Vector2) ((Vector2.right * 0.03125f) * this.stage_progress));
                    this.killcount = 0;
                }
            }
            else if (this.killcount >= 15)
            {
                this.stage_progress = (short) (this.stage_progress - 1);
                this.gauge_stage.UvMove((Vector2) ((Vector2.right * 0.03125f) * this.stage_progress));
                this.killcount = 0;
            }
        }
        this.exp_height = (1f - (this.chaexp / ((float) (this.chalv * 100)))) * 0.125f;
        this.gauge_exp.UvMove((Vector2) (Vector2.up * this.exp_height));
        if (this.chalv != this.chaprevlv)
        {
            UnityEngine.Object.Instantiate(this.pt_levelup, new Vector3(-1.35f, 2.84f, 1f), Quaternion.identity);
            this.num_level.GetComponent<TextMesh>().text = this.chalv.ToString();
            this.chaprevlv = this.chalv;
            Crypto.Save_int_key("changelevel", 1);
        }
        if (this.tutorial == -2)
        {
            this.ui_ingame_gui.gameObject.active = true;
            this.script_OnGUI.SetTutorial(2, 0);
            this.tutorial = -10;
        }
        return flag;
    }

    public void GetGeneral()
    {
        int[] intArray = PlayerPrefsX.GetIntArray("n53");
        int num = -1;
        int num2 = UnityEngine.Random.Range(0, 720 + (this.wave * 12));
        if (num2 > 990)
        {
            num2 = 4;
        }
        else if (num2 > 970)
        {
            num2 = 3;
        }
        else if (num2 > 800)
        {
            num2 = 2;
        }
        else if (num2 > 500)
        {
            num2 = 1;
        }
        else
        {
            num2 = 0;
        }
        int num3 = 0;
        if (num2 > 850)
        {
            num3 = 3;
        }
        else if (num2 > 600)
        {
            num3 = 2;
        }
        else
        {
            num3 = 1;
        }
        int num4 = UnityEngine.Random.Range(0, 90);
        if (num2 >= 2)
        {
            num4 = num4 % 20;
        }
        else
        {
            num4 = num4 % 30;
        }
        num4 *= 0x186a0;
        int num5 = ((UnityEngine.Random.Range(0, 0x2710) + (num2 * 0x2710)) + (num3 * 0x989680)) + num4;
        for (int i = 0; i < 50; i++)
        {
            if (intArray[i] == 0)
            {
                num = i;
                intArray[i] = num5;
                PlayerPrefsX.SetIntArray("n53", intArray);
                break;
            }
        }
        this.bg_popui.renderer.material.mainTexture = this.card[num3 - 1];
        this.bg_popui.gameObject.active = true;
        this.bg_popui.localPosition = new Vector3(0f, 5f, 1.5f);
        if (num == -1)
        {
        }
    }

    public void GrabCharge()
    {
        this.g_power.gameObject.active = true;
        this.f_charge += 0.02f;
        this.gauge_power.UvMove((Vector2) (Vector2.right * -this.f_charge));
    }

    public void IntermissionOff()
    {
        GC.Collect();
        this.script_spawn.OpenDundoor();
    }

    public void IntermissionOn()
    {
        Vector3 a = this.cha1.position + ((Vector3) (this.cha1.forward * 0.05f));
        if (Vector3.SqrMagnitude(a) > 1f)
        {
            a = (Vector3) (Vector3.Normalize(a) * 0.95f);
        }
        this.giftbox.gameObject.transform.position = a;
        this.giftbox.gameObject.active = true;
    }

    public void LoadingFinish()
    {
        this.loadingfinish = true;
        this.script_cha.LoadingFinish();
        this.exp_height = (1f - (this.chaexp / ((float) (this.chalv * 100)))) * 0.125f;
        this.gauge_exp.UvMove((Vector2) (Vector2.up * this.exp_height));
        this.mp_length = (1f - (this.f_soul / 8f)) * 0.5f;
        this.num_level.GetComponent<TextMesh>().text = this.chalv.ToString();
        if (!this.infinitymode)
        {
            this.g_mp.localScale = Vector3.one;
            this.gauge_mp.UvMove((Vector2) (Vector2.right * this.mp_length));
            this.script_spawn.RegenStart();
            switch ((this.tutorial + 4))
            {
                case 0:
                    this.ui_ingame_gui.gameObject.active = true;
                    this.script_OnGUI.SetTutorial(5, 0);
                    break;

                case 1:
                    this.ui_ingame_gui.gameObject.active = true;
                    this.script_OnGUI.SetTutorial(6, 0);
                    break;

                case 2:
                    this.ui_ingame_gui.gameObject.active = true;
                    this.script_OnGUI.SetTutorial(1, 0);
                    break;
            }
            Crypto.Save_int_key("tutorial", -1);
        }
    }

    private void OnApplicationPause(bool pocus)
    {
        if (pocus && ((this.script_OnGUI != null) && !this.ui_ingame_gui.gameObject.active))
        {
            this.PauseOn();
        }
    }

    public void PauseOn()
    {
        if (this.loadingfinish)
        {
            this.script_OnGUI.PauseOn();
        }
    }

    public void PowerCharge()
    {
        this.chargeon = true;
        this.g_power.gameObject.active = true;
    }

    public void ResetExtreme()
    {
        this.giftbox.transform.position = (Vector3) (Vector3.up * 60f);
        this.giftbox.gameObject.active = false;
        this.gauge_stage.UvMove(Vector2.zero);
        this.script_icon.RegenGeneralSkill();
    }

    public void ResetPower()
    {
        this.chargeon = false;
        this.f_charge = 0f;
        this.gauge_power.UvMove(Vector2.zero);
        this.g_power.gameObject.active = false;
    }

    public void ResetTime()
    {
        this.extreme_num.text = this.wave.ToString();
        this.playtime = 0f;
        this.damagecount = 0;
        base.InvokeRepeating("CountDown", 0.1f, 1f);
        this.stageRegen = true;
    }

    public void Resurrection()
    {
        this.coin = Crypto.Load_int_key("n17");
        this.jade = Crypto.Load_int_key("n24");
    }

    private void ScorePlus()
    {
        float num = this.extreme_point - this.extreme_point_cur;
        if (num > 1f)
        {
            this.extreme_point_cur = Mathf.Lerp(this.extreme_point_cur, (float) this.extreme_point, Time.deltaTime * 5f);
            this.point_num.text = ((int) this.extreme_point_cur).ToString();
        }
        else
        {
            base.CancelInvoke("ScorePlus");
        }
    }

    public void ShowTxt(int isSuccess)
    {
        Vector2 vector = (Vector2) ((Vector2.up * 0.5f) + (Vector2.up * (isSuccess * 0.25f)));
        if (isSuccess == 0)
        {
            this.txt_star.gameObject.active = true;
            this.txt_star.GetComponent<Txt_star>().SetStar(this.total_star);
            int num = (this.wave * this.total_star) * 15;
            this.extreme_point_cur = this.extreme_point;
            this.extreme_point += num;
            base.InvokeRepeating("ScorePlus", 0.5f, 0.05f);
        }
        this.txt_result.gameObject.active = true;
        this.txt_result.GetComponent<Txt_result>().UvMove(vector);
    }

    public void SkillPlus(int _index)
    {
        this.script_icon.SkillPlus(_index, this.general);
    }

    public void SoulStartplus()
    {
        this.soul = 5;
    }

    public void Stagefinish()
    {
        this.returnmap = true;
    }

    private void Start()
    {
        this.max_stage_index = Crypto.Load_int_key("n06");
        this.chalv = Crypto.Load_int_key("n47");
        this.chaprevlv = this.chalv;
        this.chaexp = Crypto.Load_int_key("n11");
        this.tutorial_maxcombo = PlayerPrefs.GetInt("tutorial2");
        this.script_OnGUI = this.ui_ingame_gui.GetComponent<UI_Ingame_GUI>();
        this.cha1 = GameObject.FindWithTag("Player").transform;
        this.script_cha = this.cha1.GetComponent<Cha_Control>();
        this.script_icon = GameObject.FindWithTag("icon_skill").GetComponent<Icon_Skill>();
        this.script_spawn = GameObject.FindWithTag("Respawn").GetComponent<Spawn>();
        this.script_pack = this.pack.GetComponent<MakeUI>();
        this.infinitymode = this.script_spawn.infinitymode;
        this.finalstage = this.script_spawn.finalstage;
        this.soulgain = (this.chalv * 0.003f) + 0.05f;
        this.play_kind = Crypto.Load_int_key("play_kind");
        this.cur_difficulty = Crypto.Load_int_key("n14");
        GameObject obj2 = Resources.Load("stagenum_cave") as GameObject;
        if (this.infinitymode)
        {
            this.wave = Crypto.Load_int_key("n49");
            this.extreme_num = ((Transform) UnityEngine.Object.Instantiate(obj2.transform, obj2.transform.localPosition + new Vector3(0.03f, -0.02f, 0f), Quaternion.identity)).GetComponent<TextMesh>();
            this.extreme_num.characterSize = 0.03f;
            this.extreme_num.text = this.wave.ToString();
            GameObject obj3 = Resources.Load("getcoin_num") as GameObject;
            this.getcoin_num = (Transform) UnityEngine.Object.Instantiate(obj3.transform, obj3.transform.localPosition, Quaternion.identity);
            this.cur_difficulty = 0;
            this.script_pack.CreatCustomPlane(new Vector2(0.72f, 0.16f), 0f, new Vector3(0.9f, 2.81f, 2.1f), new Vector2(0f, 0.75f), new Vector2(0.25f, 0.8125f), "bg_point", null, 0f, 0);
            this.script_pack.CreatCustomPlane((Vector2) (Vector2.one * 0.15f), 0f, new Vector3(0f, 2.9f, 2.1f), new Vector2(0.375f, 0.625f), new Vector2(0.4375f, 0.6875f), "icon_clock", null, 0f, 0);
            Transform transform2 = (Transform) UnityEngine.Object.Instantiate(obj2.transform, obj2.transform.localPosition, Quaternion.identity);
            transform2.position -= new Vector3(0.26f, 0.05f, 0f);
            this.stage_num = transform2.GetComponent<TextMesh>();
            this.stage_num.characterSize = 0.02f;
            Transform transform3 = (Transform) UnityEngine.Object.Instantiate(obj2.transform, obj2.transform.localPosition, Quaternion.identity);
            transform3.position -= new Vector3(-0.55f, 0.13f, 0f);
            this.point_num = transform3.GetComponent<TextMesh>();
            this.point_num.characterSize = 0.03f;
            this.point_num.text = "0";
            this.txt_star = this.script_pack.Creat_star(new Vector2(1.2f, 0.3f));
            this.txt_star.gameObject.active = false;
            GameObject obj4 = Resources.Load("giftbox") as GameObject;
            this.giftbox = (Transform) UnityEngine.Object.Instantiate(obj4.transform, (Vector3) (Vector3.up * 60f), Quaternion.identity);
            base.InvokeRepeating("CountDown", 0.1f, 1f);
        }
        else
        {
            this.tutorial = Crypto.Load_int_key("tutorial");
            this.g_mp = this.script_pack.CreatCustomPlane(new Vector2(1.06f, 0.1f), 0f, new Vector3(-0.6775f, 2.78f, 1.8f), new Vector2(0f, 0.588f), new Vector2(0.5f, 0.625f), "gauge_mp", "Gauge_UV", 0f, 0);
            this.gauge_mp = this.g_mp.GetComponent<Gauge_UV>();
            this.g_mp.localScale = Vector3.zero;
            if (this.cur_difficulty == 1)
            {
                if (this.play_kind == 5)
                {
                    this.playtime = 300f;
                }
                else if (this.play_kind == 6)
                {
                    this.playtime = 240f;
                }
                else if (this.play_kind == 7)
                {
                    this.playtime = 240f;
                }
                else
                {
                    this.playtime = 240f;
                }
                this.script_pack.CreatCustomPlane((Vector2) (Vector2.one * 0.15f), 0f, new Vector3(0.2f, 2.9f, 2.1f), new Vector2(0.375f, 0.625f), new Vector2(0.4375f, 0.6875f), "icon_clock", null, 0f, 0);
                Transform transform4 = (Transform) UnityEngine.Object.Instantiate(obj2.transform, obj2.transform.localPosition, Quaternion.identity);
                transform4.position -= new Vector3(0.04f, 0.02f, 0f);
                this.stage_num = transform4.GetComponent<TextMesh>();
                this.stage_num.characterSize = 0.03f;
                base.InvokeRepeating("CountDown", 0.1f, 1f);
            }
        }
        this.jade = Crypto.Load_int_key("n24");
        this.coin = Crypto.Load_int_key("n17");
        this.f_soul = this.soul;
        this.cur_general = this.script_spawn.cur_general;
        this.chamaxsp = this.script_cha.maxsp;
        this.script_pack.CreatCustomPlane(new Vector2(0.25f, 0.25f), 0f, new Vector3(-1.35f, 2.85f, 2f), new Vector2(0.5f, 0.625f), new Vector2(0.625f, 0.75f), "bg_hp", null, 0f, 0);
        if (this.cur_difficulty != 2)
        {
            this.g_hp = this.script_pack.CreatCustomPlane(new Vector2(0.9f, 0.1f), 0f, new Vector3(-0.757f, 2.92f, 1.8f), new Vector2(0f, 0.5f), new Vector2(0.5f, 0.5625f), "gauge_hp", "Gauge_UV", 0.2f, 0);
        }
        else
        {
            this.g_hp = this.script_pack.CreatCustomPlane(new Vector2(0.4f, 0.12f), 0f, new Vector3(-0.9f, 2.94f, 1.8f), new Vector2(0f, 0.625f), new Vector2(0.1875f, 0.6875f), "gauge_hp", "Gauge_UV", 0f, 0);
        }
        this.g_power = this.script_pack.CreatCustomPlane(new Vector2(0.4f, 0.05f), 0f, new Vector3(0f, 2.4f, 2.1f), new Vector2(0.5f, 0.5f), new Vector2(1f, 0.5625f), "gauge_power", "Gauge_UV", 0f, 0);
        this.g_combo = this.script_pack.CreatCustomPlane(new Vector2(0.6f, 0.05f), 0f, new Vector3(0f, 2.74f, 2.1f), new Vector2(0.5f, 0.4375f), new Vector2(1f, 0.47f), "gauge_combo", "Gauge_UV", 0f, 0);
        this.script_pack.CreatCustomPlane(new Vector2(0.3f, 0.1f), 0f, new Vector3(0f, 2.79f, 2.1f), new Vector2(0.0625f, 0.8125f), new Vector2(0.25f, 0.875f), "txt_combo", null, 0f, 0).parent = this.g_combo;
        Transform transform6 = this.script_pack.CreatCustomPlane(new Vector2(1.06f, 0.05f), 0f, new Vector3(-0.6775f, 2.85f, 1.8f), new Vector2(0f, 0.47f), new Vector2(0.5f, 0.498f), "gauge_sp", "Gauge_UV", 0.12f, 0);
        Transform transform7 = this.script_pack.CreatCustomPlane((Vector2) (Vector2.one * 0.186f), 0f, new Vector3(-1.352f, 2.85f, 2.1f), new Vector2(0.875f, 0.75f), new Vector2(1f, 0.875f), "gauge_exp", "Gauge_UV", 0f, 0);
        if (this.play_kind <= 5)
        {
            this.script_pack.CreatCustomPlane(new Vector2(0.24f, 0.08f), 0f, new Vector3(0.63f, 2.91f, 2.1f), new Vector2(0.8125f, 0.6875f), new Vector2(1f, 0.75f), "stage", null, 0f, 0);
            this.gauge_stage = this.script_pack.CreatCustomPlane(new Vector2(0.5f, 0.12f), 0f, new Vector3(1f, 2.91f, 2.1f), new Vector2(0.25f, 0.6875f), new Vector2(0.5f, 0.75f), "cur_stage", "Gauge_UV", 0f, 0).GetComponent<Gauge_UV>();
        }
        this.gauge_hp = this.g_hp.GetComponent<Gauge_UV>();
        this.gauge_sp = transform6.GetComponent<Gauge_UV>();
        this.gauge_exp = transform7.GetComponent<Gauge_UV>();
        this.gauge_power = this.g_power.GetComponent<Gauge_UV>();
        this.gauge_combo = this.g_combo.GetComponent<Gauge_UV>();
        this.script_icon.SoulMeasure(this.soul);
        if (GameObject.Find("Loading_f") == null)
        {
            this.LoadingFinish();
            Camera.main.transform.GetChild(0).gameObject.active = true;
        }
        this.g_power.gameObject.active = false;
        this.txt_result = this.script_pack.Creat_result(new Vector2(1.6f, 0.4f), new Vector3(0f, 2.2f, 2f), "txt_result");
        this.txt_result.gameObject.active = false;
    }

    public void StatUpdate_hp(int _hp, int _maxhp)
    {
        float num = 0f;
        if (this.cur_difficulty != 2)
        {
            this.chahp = _hp;
            this.chamaxhp = _maxhp;
            num = 1f - (((float) this.chahp) / ((float) this.chamaxhp));
            this.hp_length = num * 0.5f;
            this.gauge_hp.UvMove((Vector2) (Vector2.right * this.hp_length));
        }
    }

    public void StatUpdate_sp(float _sp)
    {
        this.chasp = _sp;
        this.sp_length = (1f - (this.chasp / this.chamaxsp)) * 0.5f;
        if (this.chasp >= 50f)
        {
            this.gauge_sp.UvMove((Vector2) (Vector2.right * this.sp_length));
        }
        else
        {
            this.gauge_sp.UvMove((Vector2) ((Vector2.right * this.sp_length) - (Vector2.up * 0.03125f)));
        }
        if ((this.cur_general != -1) && !this.generaldead)
        {
            this.script_icon.ShortSp(this.chasp);
        }
    }

    public void SuperModeOn()
    {
        this.cut_extreme[0].gameObject.active = true;
        this.cut_extreme[1].gameObject.active = true;
        this.supermode = false;
        this.combo_length = 0f;
        this.gauge_combo.UvMove((Vector2) (Vector2.right * -this.combo_length));
        this.txt_maxcombo.gameObject.active = false;
        this.txt_maxcombo.GetChild(0).gameObject.active = true;
    }

    private void Update()
    {
        if (!this.supermode)
        {
            if (this.combo_length > 0f)
            {
                if (this.stageRegen)
                {
                    this.g_combo.position = new Vector3(0f, 2.74f, 2.1f);
                    this.combo_length -= Time.deltaTime * 0.01f;
                    this.gauge_combo.UvMove((Vector2) (Vector2.right * -this.combo_length));
                }
            }
            else
            {
                this.g_combo.position = (Vector3) (Vector3.up * 5f);
            }
        }
        if (this.chargeon)
        {
            if (this.f_charge < 0.5f)
            {
                this.f_charge += Time.deltaTime * 0.6f;
            }
            else
            {
                this.f_charge = 0f;
                this.script_cha.Eximpact();
                this.chargeon = false;
                this.g_power.gameObject.active = false;
            }
            this.gauge_power.UvMove((Vector2) (Vector2.right * -this.f_charge));
        }
        if (this.returnmap)
        {
            if (this.finishdelay < 2f)
            {
                this.finishdelay += Time.deltaTime;
            }
            else if (!this.infinitymode)
            {
                Application.LoadLevel("Result");
            }
            else
            {
                Application.LoadLevel("Result_Extreme");
            }
        }
        if (this.cur_difficulty == 1)
        {
            this.playtime -= Time.deltaTime;
            if (this.playtime < 0f)
            {
                this.WaveSet(-1);
            }
        }
        else if (this.infinitymode)
        {
            this.playtime += Time.deltaTime;
        }
        if (this.gauge_scalechange)
        {
            this.g_hp.localScale = Vector3.MoveTowards(this.g_hp.localScale, Vector3.one, Time.deltaTime * 8f);
            if (this.g_hp.localScale == Vector3.one)
            {
                this.gauge_scalechange = false;
            }
        }
    }

    [DebuggerHidden]
    public IEnumerator WaveClear()
    {
        return new <WaveClear>c__Iterator1F { <>f__this = this };
    }

    public void WaveSet(int _count)
    {
        this.enemykill = this.script_spawn.enemykill;
        this.grappling = this.script_spawn.grappling;
        this.exattack = this.script_cha.exattack;
        Crypto.Save_int_key("enemykill", this.enemykill);
        Crypto.Save_int_key("grappling", this.grappling);
        Crypto.Save_int_key("exattack", this.exattack);
        Crypto.Save_int_key("n58", this.dropjade);
        Crypto.Save_int_key("n59", this.dropcoin);
        Crypto.Save_int_key("n47", this.chalv);
        Crypto.Save_int_key("n11", (int) this.chaexp);
        this.script_icon.SaveSkillUse();
        this.script_spawn.GeneralHP(false);
        if (_count == -1)
        {
            if (this.infinitymode)
            {
                Crypto.Save_int_key("stage_clear", -1000);
                int num = Crypto.Load_int_key("n54");
                if (this.extreme_point > num)
                {
                    Crypto.Save_int_key("n54", this.extreme_point);
                }
                int num2 = Crypto.Load_int_key("n48");
                if (this.wave > num2)
                {
                    Crypto.Save_int_key("n48", this.wave);
                }
            }
            else
            {
                Crypto.Save_int_key("stage_clear", 0);
            }
            this.Stagefinish();
            this.ShowTxt(-1);
            this.total_star = 0;
        }
        else if (_count >= this.finalstage)
        {
            this.cur_stage_index = Crypto.Load_int_key("cur_stage_index");
            this.rewardkind = this.script_spawn.rewardkind;
            if (this.cur_stage_index == this.max_stage_index)
            {
                Crypto.Save_int_key("storycutin", 1);
                if (this.max_stage_index < 6)
                {
                    Crypto.Save_int_key("tutorial", this.max_stage_index + 1);
                    if (this.max_stage_index == 4)
                    {
                        Crypto.Save_int_key("n37", 2);
                    }
                }
            }
            short num3 = 1;
            if (this.cur_difficulty == 2)
            {
                num3 = (short) (num3 + 100);
            }
            else if (this.cur_difficulty == 1)
            {
                num3 = (short) (num3 + 10);
            }
            if (this.infinitymode)
            {
                Crypto.Save_int_key("stage_clear", -1000);
            }
            else
            {
                Crypto.Save_int_key("stage_clear", (this.rewardkind * 0x3e8) + num3);
            }
            this.Stagefinish();
            this.ShowTxt(1);
            if ((this.max_stage_index > 4) && (UnityEngine.Random.Range(0, 100) < 20))
            {
                Crypto.Save_int_key("n37", UnityEngine.Random.Range(0, this.max_stage_index - 1));
            }
        }
        else
        {
            if (this.infinitymode)
            {
                int num5 = (90 - ((int) this.playtime)) + ((5 - this.damagecount) * 10);
                if (num5 > 100)
                {
                    this.total_star = 3;
                }
                else if (num5 > 60)
                {
                    this.total_star = 2;
                }
                else
                {
                    this.total_star = 1;
                }
                int[] intArray = new int[100];
                intArray = PlayerPrefsX.GetIntArray("n52");
                if (intArray[_count - 1] < this.total_star)
                {
                    intArray[_count - 1] = this.total_star;
                    PlayerPrefsX.SetIntArray("n52", intArray);
                }
                this.stage_progress = 0;
                this.killcount = 0;
                this.wave = _count + 1;
                int num6 = Crypto.Load_int_key("n48");
                if (this.wave > num6)
                {
                    if (((this.wave - 1) % 8) == 0)
                    {
                        if (this.wave != 1)
                        {
                            this.angelOn = true;
                            this.cur_angel = (this.wave - 1) / 8;
                        }
                    }
                    else
                    {
                        this.angelOn = false;
                    }
                    Crypto.Save_int_key("n48", this.wave);
                }
                this.ShowTxt(0);
                base.CancelInvoke("CountDown");
                this.stageRegen = false;
            }
            base.StartCoroutine(this.WaveClear());
        }
    }

    [CompilerGenerated]
    private sealed class <WaveClear>c__Iterator1F : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal UI_Ingame <>f__this;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.$current = new WaitForSeconds(2f);
                    this.$PC = 1;
                    return true;

                case 1:
                    if (this.<>f__this.infinitymode)
                    {
                        this.<>f__this.IntermissionOn();
                        break;
                    }
                    this.<>f__this.script_spawn.RegenStart();
                    break;

                default:
                    goto Label_0120;
            }
            this.<>f__this.script_cha.Spcharge(100f);
            if (this.<>f__this.tutorial == -10)
            {
                this.<>f__this.ui_ingame_gui.gameObject.active = true;
                this.<>f__this.script_OnGUI.SetTutorial(3, 0);
                this.<>f__this.tutorial = -20;
            }
            else if (this.<>f__this.tutorial == -20)
            {
                this.<>f__this.ui_ingame_gui.gameObject.active = true;
                this.<>f__this.script_OnGUI.SetTutorial(4, 0);
                this.<>f__this.tutorial = -1;
            }
            GC.Collect();
            this.$PC = -1;
        Label_0120:
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }
}


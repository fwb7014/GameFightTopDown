using System;
using UnityEngine;

public class CostumeAniSpeed : MonoBehaviour
{
    private void Start()
    {
        base.animation["costume"].speed = 0.24f;
    }
}


using System;
using UnityEngine;

public class Ef_swing1 : MonoBehaviour
{
    private int addforce;
    private Rigidbody cha_rigidbody;
    private float delay;
    private bool efon;
    private int framesPerSecond = 20;
    private int impactframe = 1;
    private int index;
    private int lastframe;
    private bool layerchange;
    private short layerindex;
    private Collider mycollider;
    private Renderer myrenderer;
    private Vector2 offset;
    private int oldindex = -1;
    private int originlayer = 20;
    public Transform pt_hit;
    private bool pton;
    private short rndefamount;
    private Cha_Control script_cha;
    private Pt_hit script_pthit;
    private Vector2 size;
    private float starttime;
    private float uIndex;
    private int uvAnimationTileX;
    private int uvAnimationTileY;
    private int vIndex;

    private void Awake()
    {
        this.myrenderer = base.renderer;
        this.mycollider = base.collider;
        this.originlayer = base.gameObject.layer;
    }

    public void RndEfOn(int _index, int _amount)
    {
        this.rndefamount = (short) _amount;
        switch (_amount)
        {
            case 2:
                this.rndefamount = 5;
                break;

            case 3:
                this.rndefamount = 10;
                break;

            case 4:
                this.rndefamount = 20;
                break;
        }
        this.layerchange = true;
        switch (_index)
        {
            case 0:
                this.layerindex = 20;
                this.layerchange = false;
                break;

            case 1:
                this.layerindex = 30;
                break;

            case 2:
                this.layerindex = 0x1f;
                break;

            case 3:
                this.layerindex = 0x12;
                break;

            case 4:
                this.layerindex = 0x13;
                break;
        }
    }

    private void Start()
    {
        GameObject gameObject = base.transform.root.gameObject;
        this.cha_rigidbody = gameObject.rigidbody;
        this.script_pthit = this.pt_hit.GetComponent<Pt_hit>();
        this.script_cha = gameObject.GetComponent<Cha_Control>();
        Physics.IgnoreCollision(gameObject.collider, this.mycollider);
        this.starttime = 0f;
        this.myrenderer.enabled = false;
        this.mycollider.isTrigger = true;
        this.mycollider.enabled = false;
        this.delay = 0f;
        base.gameObject.active = false;
    }

    public void SwingOff()
    {
        this.efon = false;
        base.gameObject.active = false;
        this.myrenderer.enabled = false;
        this.mycollider.enabled = false;
        this.pton = false;
        this.oldindex = -1;
        this.index = 0;
        this.starttime = 0f;
    }

    public void SwingOn(float _delay, int cnt_x, int cnt_y, int uvspeed, int impact, int _addforce)
    {
        base.gameObject.layer = this.originlayer;
        base.gameObject.active = true;
        this.delay = _delay;
        this.efon = true;
        this.uvAnimationTileX = cnt_x;
        this.uvAnimationTileY = cnt_y;
        this.lastframe = this.uvAnimationTileX * this.uvAnimationTileY;
        this.framesPerSecond = uvspeed;
        this.impactframe = impact;
        this.addforce = _addforce;
        this.size = new Vector2(1f / ((float) this.uvAnimationTileX), 1f / ((float) this.uvAnimationTileY));
        if (this.layerchange && (UnityEngine.Random.Range(0, 100) < this.rndefamount))
        {
            base.gameObject.layer = this.layerindex;
        }
    }

    private void Update()
    {
        if (this.efon)
        {
            if (this.delay > 0f)
            {
                this.delay -= Time.deltaTime;
            }
            else
            {
                if (this.addforce > 0)
                {
                    this.cha_rigidbody.AddForce(base.transform.root.forward * this.addforce);
                }
                this.myrenderer.enabled = true;
                this.starttime = 0f;
                this.efon = false;
                this.script_cha.SwingStart();
            }
        }
        if (this.myrenderer.enabled)
        {
            this.starttime += Time.deltaTime;
            this.index = (int) (this.starttime * this.framesPerSecond);
            this.uIndex = this.index % this.uvAnimationTileX;
            this.vIndex = this.index / this.uvAnimationTileX;
            if (this.index != this.oldindex)
            {
                if (this.index >= this.lastframe)
                {
                    this.myrenderer.enabled = false;
                    base.gameObject.active = false;
                    this.mycollider.enabled = false;
                    this.pton = false;
                    this.oldindex = -1;
                }
                else if ((this.index == this.impactframe) || (this.index == (this.impactframe + 1)))
                {
                    this.mycollider.enabled = true;
                    if (!this.pton)
                    {
                        this.script_pthit.ParticleOn();
                        this.pton = true;
                    }
                }
                else
                {
                    this.mycollider.enabled = false;
                }
                this.offset = (Vector2) (((Vector2.right * this.uIndex) * this.size.x) + (Vector2.up * ((1f - this.size.y) - (this.vIndex * this.size.y))));
                this.myrenderer.material.mainTextureOffset = this.offset;
                this.myrenderer.material.mainTextureScale = this.size;
                this.oldindex = this.index;
            }
        }
    }
}


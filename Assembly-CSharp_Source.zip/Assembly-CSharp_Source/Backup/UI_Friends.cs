using SimpleJSON;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using UnityEngine;

public class UI_Friends : MonoBehaviour
{
    private string access_token = "abcdef";
    public GUISkin basicSkin;
    public Texture2D bg_title;
    public Texture2D bg_title_me;
    public GUIStyle bt_back;
    public GUIStyle bt_empty;
    public GUIStyle bt_plus;
    public GUIStyle bt_remove;
    public GUIStyle bt_start;
    public GUIStyle bt_yesno;
    private short confirm;
    private float curMousePosY;
    private short currenttab;
    private int detail_count;
    public Texture2D errorimg;
    private bool facebook_load;
    private bool facebooklogin;
    private int fb_friend_num = 5;
    private facebookfriend[] ff = new facebookfriend[0x1388];
    private hspfriend[] hf = new hspfriend[100];
    private int hsp_friend_num;
    public Texture2D icon_key;
    public Texture2D[] icon_ranktab = new Texture2D[5];
    private int icon_size;
    private short keyboardactive;
    private int language;
    private const int MAX_FB_FRIENDS = 0x1388;
    private const int MAX_HSP_FRIENDS = 100;
    private short mode;
    private Texture2D myimage;
    private TouchScreenKeyboard mykeyboard;
    public Texture2D please_touch;
    private float posX_l = -100f;
    private float posX_r = 500f;
    private float posY = 114f;
    private Vector2 prev_scrollPosition;
    private const int RECOMMEND_FRIENDS = 30;
    private int recommend_num;
    private bool reload;
    private recommend[] rf = new recommend[100];
    private Vector2 scrollPosition;
    private float startMousePosY;
    private string tempnick;
    public Texture2D toggle_active;
    private GameObject ui;
    private short version;

    private void Awake()
    {
        this.language = PlayerPrefs.GetInt("language");
    }

    public void ChangeNickName()
    {
    }

    private void Delay()
    {
        this.confirm = 0;
    }

    public void FaceLoginFinish()
    {
        this.facebooklogin = true;
        base.StartCoroutine(this.GetFaceBookFriends());
    }

    [DebuggerHidden]
    private IEnumerator GetFaceBookFriends()
    {
        return new <GetFaceBookFriends>c__Iterator1C { <>f__this = this };
    }

    [DebuggerHidden]
    private IEnumerator GetFacebookImg(string _url, int _index)
    {
        return new <GetFacebookImg>c__Iterator1D { _url = _url, _index = _index, <$>_url = _url, <$>_index = _index, <>f__this = this };
    }

    [DebuggerHidden]
    private IEnumerator GetFaceBookMe()
    {
        return new <GetFaceBookMe>c__Iterator1A { <>f__this = this };
    }

    public void GetHSPFriends()
    {
        this.hf = new hspfriend[100];
        this.reload = true;
    }

    [DebuggerHidden]
    private IEnumerator GetMyFacebookImg(string _url)
    {
        return new <GetMyFacebookImg>c__Iterator1B { _url = _url, <$>_url = _url };
    }

    [DebuggerHidden]
    private IEnumerator GetProfileImg(string _url, int _index)
    {
        return new <GetProfileImg>c__Iterator1E { _url = _url, _index = _index, <$>_url = _url, <$>_index = _index, <>f__this = this };
    }

    public void HSPFriendsImg(List<string> _urls)
    {
        int num = 0;
        foreach (string str in _urls)
        {
            base.StartCoroutine(this.GetProfileImg(str, num));
            num++;
        }
    }

    public void JudgeFriend(bool _isfriend)
    {
        this.rf[this.detail_count]._isfriend = _isfriend;
        this.detail_count++;
    }

    [DebuggerHidden]
    private IEnumerator MyImageLoading(string _url)
    {
        return new <MyImageLoading>c__Iterator19 { _url = _url, <$>_url = _url, <>f__this = this };
    }

    private void OnGUI()
    {
        GUI.depth = -8;
        GUI.skin = this.basicSkin;
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        if (this.confirm > 0)
        {
            GUI.enabled = false;
        }
        if (GUI.Button(Crypto.Rect2(416f, 0f, 64f, 64f), string.Empty, this.bt_back))
        {
            Application.LoadLevel("Extreme");
        }
        if (Input.anyKeyDown)
        {
            if (Crypto.Rect2(this.posX_r - 74f, this.posY - 26f, 258f, 218f).Contains(Event.current.mousePosition))
            {
                this.startMousePosY = Input.mousePosition.y;
                this.prev_scrollPosition = this.scrollPosition;
            }
        }
        else if (Input.anyKey && Crypto.Rect2(this.posX_r - 74f, this.posY - 26f, 258f, 218f).Contains(Event.current.mousePosition))
        {
            this.curMousePosY = Input.mousePosition.y;
            this.scrollPosition = this.prev_scrollPosition + ((Vector2) ((Vector2.up * (this.curMousePosY - this.startMousePosY)) * (640f / ((float) Screen.height))));
        }
        GUI.Box(Crypto.Rect2(this.posX_r - 74f, this.posY - 42f, 262f, 240f), string.Empty, "blank_box");
        GUI.Box(Crypto.Rect2(this.posX_r - 69f, this.posY - 74f, 96f, 32f), string.Empty, "blank_tab");
        if (GUI.Button(Crypto.Rect2(this.posX_r - 69f, this.posY - 74f, 96f, 32f), string.Empty, this.bt_empty))
        {
            this.currenttab = 0;
            if (!this.reload)
            {
                this.GetHSPFriends();
            }
        }
        if (this.currenttab == 0)
        {
            this.scrollPosition = GUI.BeginScrollView(Crypto.Rect2(this.posX_r - 74f, this.posY - 26f, 258f, 218f), this.scrollPosition, Crypto.Rect2(0f, 0f, 242f, (float) (this.hsp_friend_num * 0x2c)));
            for (short j = 0; j < this.hsp_friend_num; j = (short) (j + 1))
            {
                if (((this.scrollPosition.y - (j * 0x58)) <= 80f) && ((this.scrollPosition.y - (j * 0x58)) >= -438f))
                {
                    GUI.Box(Crypto.Rect2(12f, (float) (j * 0x2c), 234f, 40f), string.Empty, "blank_white");
                    if (this.hf[j]._picture != null)
                    {
                        GUI.DrawTexture(Crypto.Rect2(16f, (float) ((j * 0x2c) + 2), 36f, 36f), this.hf[j]._picture);
                    }
                    else
                    {
                        GUI.DrawTexture(Crypto.Rect2(16f, (float) ((j * 0x2c) + 2), 36f, 36f), this.errorimg);
                    }
                    if (this.hf[j]._name != null)
                    {
                        GUI.Label(Crypto.Rect2(60f, (float) (j * 0x2c), 128f, 40f), this.hf[j]._name, "txt12_0");
                    }
                }
            }
            GUI.EndScrollView();
            GUI.DrawTexture(Crypto.Rect2(this.posX_r - 69f, this.posY - 74f, 96f, 32f), this.toggle_active);
        }
        else if (this.currenttab == 1)
        {
            this.scrollPosition = GUI.BeginScrollView(Crypto.Rect2(this.posX_r - 74f, this.posY - 26f, 258f, 218f), this.scrollPosition, Crypto.Rect2(0f, 0f, 242f, (float) (this.fb_friend_num * 0x2c)));
            for (short k = 0; k < this.fb_friend_num; k = (short) (k + 1))
            {
                if (((this.scrollPosition.y - (k * 0x58)) <= 80f) && ((this.scrollPosition.y - (k * 0x58)) >= -438f))
                {
                    if (this.ff[k]._isfriend)
                    {
                        GUI.Box(Crypto.Rect2(12f, (float) (k * 0x2c), 234f, 40f), string.Empty, "blank_red");
                    }
                    else
                    {
                        GUI.Box(Crypto.Rect2(12f, (float) (k * 0x2c), 234f, 40f), string.Empty, "blank_white");
                    }
                    if (this.ff[k]._picture != null)
                    {
                        GUI.DrawTexture(Crypto.Rect2(16f, (float) ((k * 0x2c) + 2), 36f, 36f), this.ff[k]._picture);
                    }
                    else
                    {
                        GUI.DrawTexture(Crypto.Rect2(16f, (float) ((k * 0x2c) + 2), 36f, 36f), this.errorimg);
                    }
                    if (this.ff[k]._name != null)
                    {
                        GUI.Label(Crypto.Rect2(60f, (float) (k * 0x2c), 128f, 40f), this.ff[k]._name, "txt12_0");
                    }
                    if (!this.facebook_load)
                    {
                        GUI.Box(Crypto.Rect2(178f, (float) ((k * 0x2c) + 4), 64f, 32f), "...", "blank_red");
                    }
                    else if (!this.ff[k]._isfriend)
                    {
                        if (this.ff[k]._hspNo != 0)
                        {
                            if (GUI.Button(Crypto.Rect2(204f, (float) ((k * 0x2c) - 4), 48f, 48f), string.Empty, this.bt_plus))
                            {
                                List<long> list = new List<long>(1) {
                                    this.ff[k]._hspNo
                                };
                                this.reload = false;
                                this.ff[k]._isfriend = true;
                            }
                        }
                        else if (GUI.Button(Crypto.Rect2(178f, (float) ((k * 0x2c) + 4), 64f, 32f), Language.intxt[this.language, 410], this.bt_yesno))
                        {
                            List<string> list2 = new List<string> {
                                this.ff[k]._fbid
                            };
                        }
                    }
                }
            }
            GUI.EndScrollView();
        }
        else if (this.currenttab > 1)
        {
            this.scrollPosition = GUI.BeginScrollView(Crypto.Rect2(this.posX_r - 74f, this.posY - 26f, 258f, 218f), this.scrollPosition, Crypto.Rect2(0f, 0f, 242f, (float) (this.recommend_num * 0x2c)));
            for (short m = 0; m < this.recommend_num; m = (short) (m + 1))
            {
                if (((this.scrollPosition.y - (m * 0x58)) <= 80f) && ((this.scrollPosition.y - (m * 0x58)) >= -438f))
                {
                    if (this.rf[m]._isfriend)
                    {
                        GUI.Box(Crypto.Rect2(12f, (float) (m * 0x2c), 234f, 40f), string.Empty, "blank_red");
                    }
                    else
                    {
                        GUI.Box(Crypto.Rect2(12f, (float) (m * 0x2c), 234f, 40f), string.Empty, "blank_white");
                    }
                    if (this.rf[m]._picture != null)
                    {
                        GUI.DrawTexture(Crypto.Rect2(16f, (float) ((m * 0x2c) + 2), 36f, 36f), this.rf[m]._picture);
                    }
                    else
                    {
                        GUI.DrawTexture(Crypto.Rect2(16f, (float) ((m * 0x2c) + 2), 36f, 36f), this.errorimg);
                    }
                    if (this.rf[m]._name != null)
                    {
                        GUI.Label(Crypto.Rect2(60f, (float) (m * 0x2c), 128f, 40f), this.rf[m]._name, "txt12_0");
                    }
                    if (!this.rf[m]._isfriend && ((this.rf[m]._memberNo != 0) && GUI.Button(Crypto.Rect2(204f, (float) ((m * 0x2c) - 4), 48f, 48f), string.Empty, this.bt_plus)))
                    {
                        this.rf[m]._isfriend = true;
                        List<long> list3 = new List<long>(1) {
                            this.rf[m]._memberNo
                        };
                        this.reload = false;
                    }
                }
            }
            GUI.EndScrollView();
        }
        if (this.mode > 0)
        {
            GUI.Box(Crypto.Rect2(this.posX_r + 33f, this.posY - 74f, 96f, 32f), string.Empty, "blank_tab");
            if (this.currenttab > 0)
            {
                GUI.DrawTexture(Crypto.Rect2(this.posX_r + 33f, this.posY - 74f, 96f, 32f), this.toggle_active);
            }
            if (GUI.Button(Crypto.Rect2(this.posX_r + 33f, this.posY - 74f, 96f, 32f), string.Empty, this.bt_empty))
            {
                this.currenttab = this.mode;
            }
            GUI.DrawTexture(Crypto.Rect2(this.posX_r + 37f, this.posY - 68f, 20f, 20f), this.icon_ranktab[this.mode]);
            GUI.Label(Crypto.Rect2(this.posX_r + 60f, this.posY - 74f, 64f, 32f), Language.intxt[this.language, 0x195 + this.mode], "txt12_w");
        }
        GUI.DrawTexture(Crypto.Rect2(this.posX_r - 64f, this.posY - 68f, 20f, 20f), this.icon_ranktab[0]);
        GUI.Box(Crypto.Rect2(this.posX_l - 63f, this.posY - 74f, 140f, 104f), string.Empty, "blank_box");
        if (this.myimage != null)
        {
            GUI.DrawTexture(Crypto.Rect2(this.posX_l - 25f, this.posY - 66f, 64f, 64f), this.myimage);
        }
        else
        {
            GUI.DrawTexture(Crypto.Rect2(this.posX_l - 25f, this.posY - 66f, 64f, 64f), this.errorimg);
        }
        if (GUI.Button(Crypto.Rect2(this.posX_l - 25f, this.posY - 64f, 64f, 64f), string.Empty, this.bt_empty))
        {
        }
        if (GUI.Button(Crypto.Rect2(this.posX_l - 57f, this.posY + 4f, 128f, 20f), string.Empty, this.bt_empty))
        {
            this.mykeyboard = TouchScreenKeyboard.Open(Language.intxt[this.language, 0x1a8]);
            this.keyboardactive = 1;
        }
        GUI.Label(Crypto.Rect2(this.posX_r - 69f, this.posY - 74f, 114f, 32f), Language.intxt[this.language, 0x195], "txt12_w");
        for (short i = this.version; i < 4; i = (short) (i + 1))
        {
            GUI.Box(Crypto.Rect2(this.posX_l - 73f, (this.posY + 44f) + (i * 0x26), 160f, 32f), "     " + Language.intxt[this.language, 0x196 + i], "blank_red");
            GUI.DrawTexture(Crypto.Rect2(this.posX_l - 70f, (this.posY + 50f) + (i * 0x26), 20f, 20f), this.icon_ranktab[i + 1]);
            if (GUI.Button(Crypto.Rect2(this.posX_l - 73f, (this.posY + 44f) + (i * 0x26), 160f, 32f), string.Empty, this.bt_empty))
            {
                this.mode = (short) (i + 1);
                this.currenttab = this.mode;
                switch (this.currenttab)
                {
                    case 4:
                        goto Label_0E81;
                }
            }
            continue;
        Label_0E81:
            this.mykeyboard = TouchScreenKeyboard.Open(Language.intxt[this.language, 0x1a9]);
            this.keyboardactive = 2;
        }
        if (this.confirm > 0)
        {
            switch (this.confirm)
            {
                case 1:
                    GUI.enabled = true;
                    GUI.Box(Crypto.Rect2(112f, 140f, 256f, 48f), Language.intxt[this.language, 0x1aa], "blank_white");
                    break;
            }
        }
    }

    public void RemoveHSPFriends(long _memberNo)
    {
        List<long> list = new List<long>(1) {
            _memberNo
        };
    }

    public void SetMemberNos(List<long> _memberNos)
    {
        this.rf = new recommend[100];
        this.recommend_num = 0;
        int index = 0;
        foreach (long num2 in _memberNos)
        {
            if (this.currenttab == 0)
            {
                this.hf[index]._memberNo = num2;
                index++;
                this.hsp_friend_num = index;
            }
            else
            {
                this.rf[index]._memberNo = num2;
                index++;
                this.recommend_num = index;
            }
        }
    }

    public void SetMyImage(bool _ischange)
    {
    }

    private void Start()
    {
        this.GetHSPFriends();
        this.SetMyImage(false);
        base.InvokeRepeating("Warning_iconsize", 1f, 0.34f);
    }

    private void Update()
    {
        this.posX_l = Mathf.MoveTowards(this.posX_l, 100f, Time.deltaTime * 1000f);
        this.posX_r = Mathf.MoveTowards(this.posX_r, 284f, Time.deltaTime * 1000f);
        if ((this.keyboardactive > 0) && this.mykeyboard.done)
        {
            string text = this.mykeyboard.text;
            if (Encoding.Default.GetBytes(text).Length < 4)
            {
                if (this.keyboardactive == 2)
                {
                    this.recommend_num = 0;
                }
                this.confirm = 1;
                base.Invoke("Delay", 1f);
            }
            else if (text != string.Empty)
            {
                switch (this.keyboardactive)
                {
                    case 1:
                        this.tempnick = text;
                        break;
                }
            }
            else if (this.keyboardactive == 2)
            {
                this.recommend_num = 0;
            }
            this.keyboardactive = 0;
        }
    }

    public void Warning_iconsize()
    {
        this.icon_size = (this.icon_size + 1) % 2;
    }

    [CompilerGenerated]
    private sealed class <GetFaceBookFriends>c__Iterator1C : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal UI_Friends <>f__this;
        internal JSONNode <aa>__3;
        internal List<string> <facebookid>__4;
        internal string <friendslist>__2;
        internal int <i>__5;
        internal string <url>__0;
        internal WWW <www>__1;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<url>__0 = "https://graph.facebook.com/me/friends?access_token=" + this.<>f__this.access_token + "&fields=id,name,picture";
                    this.<www>__1 = new WWW(this.<url>__0);
                    this.$current = this.<www>__1;
                    this.$PC = 1;
                    return true;

                case 1:
                    this.<friendslist>__2 = this.<www>__1.text;
                    this.<aa>__3 = JSON.Parse(this.<friendslist>__2);
                    this.<>f__this.fb_friend_num = this.<aa>__3["data"].Count;
                    this.<facebookid>__4 = new List<string>();
                    this.<i>__5 = 0;
                    while (this.<i>__5 < this.<>f__this.fb_friend_num)
                    {
                        this.<>f__this.ff[this.<i>__5]._fbid = (string) this.<aa>__3["data"][this.<i>__5]["id"];
                        this.<>f__this.ff[this.<i>__5]._name = (string) this.<aa>__3["data"][this.<i>__5]["name"];
                        this.<>f__this.StartCoroutine(this.<>f__this.GetFacebookImg((string) this.<aa>__3["data"][this.<i>__5]["picture"]["data"]["url"], this.<i>__5));
                        this.<facebookid>__4.Add(this.<>f__this.ff[this.<i>__5]._fbid);
                        this.<i>__5++;
                    }
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [CompilerGenerated]
    private sealed class <GetFacebookImg>c__Iterator1D : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal int _index;
        internal string _url;
        internal int <$>_index;
        internal string <$>_url;
        internal UI_Friends <>f__this;
        internal WWW <www>__0;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<www>__0 = new WWW(this._url);
                    this.$current = this.<www>__0;
                    this.$PC = 1;
                    return true;

                case 1:
                    if (this.<www>__0.texture.height > 8)
                    {
                        this.<>f__this.ff[this._index]._picture = this.<www>__0.texture;
                    }
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [CompilerGenerated]
    private sealed class <GetFaceBookMe>c__Iterator1A : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal UI_Friends <>f__this;
        internal JSONNode <aa>__3;
        internal string <myprofile>__2;
        internal string <url>__0;
        internal WWW <www>__1;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<url>__0 = "https://graph.facebook.com/me?fields=id,name,picture";
                    this.<www>__1 = new WWW(this.<url>__0);
                    this.$current = this.<www>__1;
                    this.$PC = 1;
                    return true;

                case 1:
                    this.<myprofile>__2 = this.<www>__1.text;
                    this.<aa>__3 = JSON.Parse(this.<myprofile>__2);
                    this.<>f__this.StartCoroutine(this.<>f__this.GetMyFacebookImg((string) this.<aa>__3["picture"]["data"]["url"]));
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [CompilerGenerated]
    private sealed class <GetMyFacebookImg>c__Iterator1B : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal string _url;
        internal string <$>_url;
        internal WWW <www>__0;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<www>__0 = new WWW(this._url);
                    this.$current = this.<www>__0;
                    this.$PC = 1;
                    return true;

                case 1:
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [CompilerGenerated]
    private sealed class <GetProfileImg>c__Iterator1E : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal int _index;
        internal string _url;
        internal int <$>_index;
        internal string <$>_url;
        internal UI_Friends <>f__this;
        internal WWW <www>__0;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<www>__0 = new WWW(this._url);
                    this.$current = this.<www>__0;
                    this.$PC = 1;
                    return true;

                case 1:
                    if (this.<www>__0.texture.height > 8)
                    {
                        if (this.<>f__this.currenttab == 0)
                        {
                            this.<>f__this.hf[this._index]._picture = this.<www>__0.texture;
                            break;
                        }
                        this.<>f__this.rf[this._index]._picture = this.<www>__0.texture;
                    }
                    break;

                default:
                    goto Label_00D5;
            }
            this.$PC = -1;
        Label_00D5:
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [CompilerGenerated]
    private sealed class <MyImageLoading>c__Iterator19 : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal string _url;
        internal string <$>_url;
        internal UI_Friends <>f__this;
        internal WWW <www>__0;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<www>__0 = new WWW(this._url);
                    this.$current = this.<www>__0;
                    this.$PC = 1;
                    return true;

                case 1:
                    if (this.<www>__0.texture.height > 8)
                    {
                        this.<>f__this.myimage = this.<www>__0.texture;
                    }
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct facebookfriend
    {
        public string _fbid;
        public long _hspNo;
        public string _name;
        public Texture2D _picture;
        public bool _isfriend;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct hspfriend
    {
        public long _memberNo;
        public string _name;
        public Texture2D _picture;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct recommend
    {
        public long _memberNo;
        public string _name;
        public Texture2D _picture;
        public bool _isfriend;
    }
}


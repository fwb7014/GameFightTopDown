using System;
using UnityEngine;

public class Splash_angel_ice : MonoBehaviour
{
    private float delay = 2.5f;
    private Transform mytransform;
    private Vector3 targetPos;

    private void Awake()
    {
        this.mytransform = base.transform;
        base.gameObject.active = false;
    }

    private void OnEnable()
    {
        this.delay = 2.5f;
        this.targetPos = this.mytransform.position;
        Vector3 targetPos = this.targetPos;
        targetPos.y = -0.4f;
        this.mytransform.position = targetPos;
    }

    private void Update()
    {
        if (this.delay < 0f)
        {
            this.mytransform.position -= (Vector3) ((Vector3.up * Time.deltaTime) * 2f);
            if (this.mytransform.position.y < -0.4f)
            {
                this.mytransform.position = (Vector3) (Vector3.up * 12f);
                base.gameObject.active = false;
            }
        }
        else
        {
            this.mytransform.position = Vector3.MoveTowards(this.mytransform.position, this.targetPos, Time.deltaTime * 2f);
            this.delay -= Time.deltaTime;
        }
    }
}


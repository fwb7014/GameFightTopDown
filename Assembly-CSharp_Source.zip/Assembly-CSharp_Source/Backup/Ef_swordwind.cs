using System;
using UnityEngine;

public class Ef_swordwind : MonoBehaviour
{
    private float delay;
    private bool movestart;
    private Renderer myrenderer;
    private Transform mytransform;
    private Vector3 originscale;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myrenderer = base.renderer;
    }

    private void OnEnable()
    {
        for (int i = 0; i < 2; i++)
        {
            base.transform.GetChild(i).gameObject.active = true;
        }
    }

    private void Start()
    {
        this.originscale = base.transform.localScale;
        this.myrenderer.enabled = false;
    }

    private void Update()
    {
        if (!this.movestart)
        {
            if (this.delay < 0.8f)
            {
                this.delay += Time.deltaTime;
            }
            else
            {
                this.movestart = true;
                this.myrenderer.enabled = true;
                this.delay = 0f;
            }
        }
        else if (this.mytransform.localScale.z > 1f)
        {
            this.mytransform.position += (Vector3) (this.mytransform.forward * Time.deltaTime);
            this.mytransform.localScale -= (Vector3) ((Vector3.forward * 3f) * Time.deltaTime);
        }
        else
        {
            base.transform.localScale = this.originscale;
            this.mytransform.position = (Vector3) (Vector3.one * 22f);
            base.renderer.enabled = false;
            base.gameObject.active = false;
            this.movestart = false;
        }
    }
}


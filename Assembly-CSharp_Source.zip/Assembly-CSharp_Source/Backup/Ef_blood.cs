using System;
using UnityEngine;

public class Ef_blood : MonoBehaviour
{
    private int index;
    private Renderer myrenderer;
    private Transform mytransform;
    private Vector2 offset;
    private int oldindex = -1;
    private Vector2 size;
    private float starttime;
    private float uIndex;
    private int vIndex;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myrenderer = base.renderer;
        this.size = (Vector2) (Vector2.one * 0.25f);
        base.gameObject.active = false;
    }

    private void Update()
    {
        if (this.mytransform.position.y < 1f)
        {
            this.starttime += Time.deltaTime;
            this.index = (int) (this.starttime * 22f);
            this.uIndex = this.index % 4;
            this.vIndex = this.index / 4;
            this.offset = new Vector2(this.uIndex * this.size.x, (1f - this.size.y) - (this.vIndex * this.size.y));
            if (this.index != this.oldindex)
            {
                if (this.index >= 0x10)
                {
                    this.mytransform.position = (Vector3) (Vector3.one * 3f);
                    this.starttime = 0f;
                    this.index = 0;
                    base.gameObject.active = false;
                }
                this.myrenderer.material.mainTextureOffset = this.offset;
                this.myrenderer.material.mainTextureScale = this.size;
                this.oldindex = this.index;
            }
        }
    }
}


using System;
using UnityEngine;

public class Icon_Skill : MonoBehaviour
{
    private float[] _duration = new float[2];
    private Transform[] clone_fillbox = new Transform[0x15];
    private Transform[] clone_itemicon = new Transform[3];
    private Transform[] clone_peticon = new Transform[2];
    private Transform[] clone_skillicon = new Transform[20];
    private int[] cur_skill_grade = new int[5];
    private int current_costume;
    private int currentpetskill;
    private float duration_delay;
    public Transform ef_activeskill;
    private bool generalskill_exist;
    private int generalSkillcount = 1;
    private Transform icon_pause;
    public Transform icon_pet_folder;
    private Transform icon_rotate;
    private Transform icon_shortsp;
    private bool infinitymode;
    public bool[] ispetready = new bool[2];
    public int[] isskillready = new int[] { 
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
        1, 1, 1, 1, 1
     };
    private Vector3 item_iconpos = new Vector3(-0.9f, 2.74f, 2f);
    private int[] item_slot = new int[5];
    private int lastlist_skill;
    private int max_skillset;
    private const int MAXPET = 2;
    private const int MAXSKILL = 20;
    private const int MAXSLOT = 5;
    public bool move_icon_pet;
    public bool move_icon_skill;
    private Vector3 movepos = ((Vector3) (Vector3.right * 0.3f));
    private Transform mytransform;
    public Transform num_skill;
    public Transform pack;
    private int page_skillset;
    private int[] pet_activeskill = new int[2];
    private int[] pet_hunger = new int[2];
    private Vector3 pet_iconpos = new Vector3(-1.4f, 2f, 2f);
    private int[] pet_passiveskill = new int[2];
    private int[] pet_skill_use = new int[2];
    private Cha_Control script_cha;
    private MakeUI script_pack;
    private float[] skill_colltime = new float[20];
    private Vector3 skill_iconpos = new Vector3(1.4f, 2.6f, 2f);
    private int[] skill_slot = new int[20];
    private short[] skill_soulcost = new short[0x15];
    private int[] skill_use = new int[20];
    private int[] skillcount = new int[20];
    private int soulamount;
    private int startlist_skill;
    private bool timereduce;

    public void ArrayIcon()
    {
        int num = 0;
        this.max_skillset = 0;
        for (int i = 0; i < 20; i++)
        {
            if (this.skillcount[i] > 0)
            {
                this.clone_skillicon[i].position = (Vector3) (Vector3.one * 200f);
                this.clone_fillbox[i].position = (Vector3) (Vector3.one * 200f);
                if ((i >= this.startlist_skill) && (num < 5))
                {
                    this.clone_skillicon[i].localPosition = new Vector3(1.4f, 2.6f, 2f) - ((Vector3) ((Vector3.up * 0.28f) * num));
                    this.clone_fillbox[i].localPosition = new Vector3(1.4f, 2.6f, 1.5f) - ((Vector3) ((Vector3.up * 0.28f) * num));
                    num++;
                    this.lastlist_skill = i;
                }
                this.max_skillset++;
            }
        }
        this.max_skillset = ((this.max_skillset - 1) / 5) + 1;
        if (this.max_skillset > 1)
        {
            this.icon_rotate.localPosition = new Vector3(1.376f, 1.14f, 2f);
        }
        else
        {
            this.icon_rotate.localPosition = (Vector3) (Vector3.one * 12f);
        }
    }

    private void Awake()
    {
        this.mytransform = base.transform;
        this.cur_skill_grade = PlayerPrefsX.GetIntArray("n22");
        this.pet_activeskill = PlayerPrefsX.GetIntArray("n23");
        this.pet_passiveskill = PlayerPrefsX.GetIntArray("n27");
        this.pet_hunger = PlayerPrefsX.GetIntArray("n25");
        this.script_pack = this.pack.GetComponent<MakeUI>();
        this.script_cha = GameObject.FindWithTag("Player").GetComponent<Cha_Control>();
        this.current_costume = Crypto.Load_int_key("n05");
    }

    public void Duration_reduce(int i)
    {
        this.pet_skill_use[i]++;
        this.ispetready[i] = false;
        this.timereduce = true;
        this.clone_peticon[i].position = (Vector3) (Vector3.one * 9f);
        this.currentpetskill = i;
        this.pet_hunger[i]--;
        PlayerPrefsX.SetIntArray("n25", this.pet_hunger);
    }

    public void Ef_SkillUse(Vector3 useiconpos)
    {
        this.ef_activeskill.position = useiconpos - ((Vector3) (Vector3.forward * 1.2f));
        this.ef_activeskill.GetComponent<Ef_twirl>().TwirlOn(4, 4, 20, false);
    }

    public void GeneralDead()
    {
        this.icon_shortsp.gameObject.active = false;
    }

    public void GeneralSkillFillbox(bool _active)
    {
        if (this.generalskill_exist)
        {
            if (!_active)
            {
                this.clone_fillbox[20].position = (Vector3) (Vector3.one * 5f);
            }
            else
            {
                this.clone_fillbox[20].position = new Vector3(1.39f, 2.45f, 1.5f);
            }
        }
    }

    public void ItemUse(int _index)
    {
        UnityEngine.Object.Destroy(this.clone_itemicon[_index].gameObject);
        this.script_cha.Heal(50);
    }

    public void PetIcon_Move(bool _move)
    {
        this.move_icon_pet = _move;
    }

    public void PetSkill_Generation()
    {
        int num = 0;
        for (int i = 0; i < 2; i++)
        {
            if (this.pet_hunger[i] > 0)
            {
                this.clone_peticon[i].position = (this.pet_iconpos + ((Vector3) ((Vector3.up * -0.32f) * num))) + this.icon_pet_folder.position;
                this.ispetready[i] = true;
                num++;
            }
        }
    }

    public void RegenGeneralSkill()
    {
        if (this.generalskill_exist)
        {
            this.generalSkillcount = 1;
            this.clone_fillbox[20].GetChild(0).GetComponent<TextMesh>().text = this.generalSkillcount.ToString();
        }
    }

    public bool ResetCooltime_general()
    {
        bool flag = true;
        if (!this.infinitymode)
        {
            this.isskillready[20] = 0;
            this.clone_fillbox[20].GetComponent<Icon_FillBox>().ResetScale();
            return flag;
        }
        if (this.generalSkillcount <= 0)
        {
            return false;
        }
        this.generalSkillcount--;
        this.clone_fillbox[20].GetChild(0).GetComponent<TextMesh>().text = this.generalSkillcount.ToString();
        this.clone_fillbox[20].GetComponent<Icon_FillBox>().ResetScale();
        return flag;
    }

    public void ResetCooltime_skill(int _currentslot)
    {
        if (!this.infinitymode)
        {
            this.skill_use[this.skill_slot[_currentslot]]++;
            this.isskillready[_currentslot] = 0;
            this.clone_fillbox[_currentslot].GetComponent<Icon_FillBox>().ResetScale();
        }
        else
        {
            this.skillcount[_currentslot]--;
            this.clone_skillicon[_currentslot].GetChild(0).GetComponent<TextMesh>().text = this.skillcount[_currentslot].ToString();
            if (this.skillcount[_currentslot] <= 0)
            {
                this.clone_skillicon[_currentslot].position = (Vector3) (Vector3.one * 200f);
                this.clone_fillbox[_currentslot].position = (Vector3) (Vector3.one * 200f);
                this.startlist_skill = 0;
                this.page_skillset = 0;
                base.Invoke("ArrayIcon", 0.2f);
            }
            else
            {
                this.isskillready[_currentslot] = 0;
                this.clone_fillbox[_currentslot].GetComponent<Icon_FillBox>().ResetScale();
            }
        }
    }

    public void SaveSkillUse()
    {
        PlayerPrefsX.SetIntArray("skill_use", this.skill_use);
        PlayerPrefsX.SetIntArray("pet_skill_use", this.pet_skill_use);
    }

    public void Set_General(short _soulcost, float _cooltime, short _generalkind, bool _infinitymode)
    {
        this.clone_fillbox[20] = this.script_pack.CreatCustomPlane((Vector2) (Vector2.one * 0.16f), 0f, (Vector3) (Vector3.one * 5f), new Vector2(0.625f, 0.25f), new Vector2(0.6875f, 0.3125f), "fillbox_skill", "Icon_FillBox", 0f, 0);
        this.generalskill_exist = true;
        if (!_infinitymode)
        {
            this.skill_soulcost[20] = _soulcost;
            Transform transform = (Transform) UnityEngine.Object.Instantiate(this.num_skill, ((Vector3) (Vector3.one * 5f)) + new Vector3(-0.01f, 0.09f, 0.1f), Quaternion.identity);
            transform.parent = this.clone_fillbox[20];
            TextMesh component = transform.GetComponent<TextMesh>();
            component.text = _soulcost.ToString();
            component.characterSize = 0.02f;
            this.script_pack.CreatCustomPlane(new Vector2(0.2f, 0.1f), 0f, ((Vector3) (Vector3.one * 5f)) + new Vector3(0.01f, 0.054f, 0.2f), new Vector2(0.25f, 0.75f), new Vector2(0.375f, 0.8125f), "bg_point", null, 0f, 0).parent = this.clone_fillbox[20];
        }
        else
        {
            this.skill_soulcost[20] = 0;
            Transform transform3 = (Transform) UnityEngine.Object.Instantiate(this.num_skill, this.clone_fillbox[20].position - ((Vector3) (Vector3.right * 0.1f)), Quaternion.identity);
            transform3.parent = this.clone_fillbox[20];
            _cooltime = 0.1f;
        }
        this.clone_fillbox[20].GetComponent<Icon_FillBox>().SkillKind(20, _cooltime);
    }

    public void ShortSp(float _sp)
    {
        if (_sp >= 10f)
        {
            this.icon_shortsp.gameObject.active = false;
        }
        else
        {
            this.icon_shortsp.gameObject.active = true;
        }
    }

    public void Skill_Possible(int _index)
    {
        if (this.skill_soulcost[_index] <= this.soulamount)
        {
            this.isskillready[_index] = 2;
        }
        else
        {
            this.isskillready[_index] = 1;
            this.clone_fillbox[_index].GetComponent<Icon_FillBox>().SoulLack();
        }
    }

    public void SkillIcon_Move(bool _move)
    {
        this.move_icon_skill = _move;
    }

    public bool SkillPlus(int _index, bool _isgeneral)
    {
        bool flag = false;
        if (this.skillcount[_index] < 9)
        {
            this.skillcount[_index]++;
            this.clone_skillicon[_index].GetChild(0).GetComponent<TextMesh>().text = this.skillcount[_index].ToString();
        }
        else
        {
            flag = true;
        }
        this.ArrayIcon();
        return flag;
    }

    public void Skillset_roll()
    {
        for (int i = 0; i < 20; i++)
        {
            this.clone_skillicon[i].position = (Vector3) (Vector3.one * 5f);
            this.clone_fillbox[i].position = (Vector3) (Vector3.one * 5f);
        }
        this.page_skillset = (this.page_skillset + 1) % this.max_skillset;
        if (this.page_skillset == 0)
        {
            this.startlist_skill = 0;
        }
        else
        {
            this.startlist_skill = this.lastlist_skill + 1;
        }
        this.ArrayIcon();
    }

    public void SoulMeasure(int _soul)
    {
        this.soulamount = _soul;
        for (int i = 0; i < 6; i++)
        {
            if (this.isskillready[i] > 0)
            {
                if (this.skill_soulcost[i] <= this.soulamount)
                {
                    this.isskillready[i] = 2;
                    this.clone_fillbox[i].GetComponent<Icon_FillBox>().SoulFull();
                }
                else
                {
                    this.isskillready[i] = 1;
                    this.clone_fillbox[i].GetComponent<Icon_FillBox>().SoulLack();
                }
            }
        }
    }

    private void Start()
    {
        this.infinitymode = GameObject.FindWithTag("Respawn").GetComponent<Spawn>().infinitymode;
        if (!this.infinitymode)
        {
            this.skill_slot = PlayerPrefsX.GetIntArray("skill_slot");
        }
        else
        {
            this.skill_slot = new int[20];
        }
        this.item_slot = PlayerPrefsX.GetIntArray("n50");
        DB_PetSkill component = GameObject.FindWithTag("ui").GetComponent<DB_PetSkill>();
        DB_Skill skill2 = GameObject.FindWithTag("ui").GetComponent<DB_Skill>();
        if (!this.infinitymode)
        {
            for (int i = 0; i < 5; i++)
            {
                if (this.skill_slot[i] >= 0)
                {
                    this.skill_colltime[i] = skill2.ss[this.skill_slot[i], this.cur_skill_grade[this.skill_slot[i]]]._cooltime;
                    if (this.current_costume != 15)
                    {
                        this.skill_soulcost[i] = skill2.ss[this.skill_slot[i], this.cur_skill_grade[this.skill_slot[i]]]._soulprice;
                    }
                    Vector2 vector = new Vector2(0.125f * (this.skill_slot[i] % 8), 0.125f * (this.skill_slot[i] / 8));
                    this.clone_skillicon[i] = this.script_pack.CreatCustomPlane((Vector2) (Vector2.one * 0.16f), 0.15f, this.skill_iconpos, vector, vector + ((Vector2) (Vector2.one * 0.125f)), "skill_icon", "Icon_Skill_p", 0f, 1);
                    this.clone_fillbox[i] = this.script_pack.CreatCustomPlane((Vector2) (Vector2.one * 0.16f), 0f, this.skill_iconpos - ((Vector3) (Vector3.forward * 0.5f)), new Vector2(0.625f, 0.25f), new Vector2(0.6875f, 0.3125f), "fillbox_skill", "Icon_FillBox", 0f, 1);
                    this.clone_skillicon[i].GetComponent<Icon_Skill_p>().SkillKind(i, this.skill_slot[i], 0, this.skill_soulcost[i]);
                    this.clone_fillbox[i].GetComponent<Icon_FillBox>().SkillKind(i, this.skill_colltime[i]);
                    this.skill_iconpos -= (Vector3) (Vector3.up * 0.32f);
                    Transform transform = (Transform) UnityEngine.Object.Instantiate(this.num_skill, this.clone_skillicon[i].position + new Vector3(-0.01f, 0.09f, -0.1f), Quaternion.identity);
                    transform.parent = this.clone_skillicon[i];
                    TextMesh mesh = transform.GetComponent<TextMesh>();
                    mesh.text = this.skill_soulcost[i].ToString();
                    mesh.characterSize = 0.02f;
                    this.script_pack.CreatCustomPlane(new Vector2(0.2f, 0.1f), 0f, this.clone_skillicon[i].position + new Vector3(0.01f, 0.054f, -0.05f), new Vector2(0.25f, 0.75f), new Vector2(0.375f, 0.8125f), "bg_point", null, 0f, 0).parent = this.clone_skillicon[i];
                }
            }
            for (int j = 0; j < 2; j++)
            {
                this._duration[j] = component.ps[j, this.pet_activeskill[j]]._duration;
                Vector2 vector2 = new Vector2(0.75f + (0.125f * j), 0.25f);
                this.clone_peticon[j] = this.script_pack.CreatCustomPlane((Vector2) (Vector2.one * 0.16f), 0.15f, (Vector3) (Vector3.one * 9f), vector2, vector2 + ((Vector2) (Vector2.one * 0.125f)), "pet_icon", "Icon_Skill_p", 0f, 2);
                this.clone_peticon[j].GetComponent<Icon_Skill_p>().SkillKind(j, j, 1, 0);
            }
        }
        else
        {
            for (int k = 0; k < 20; k++)
            {
                if (this.cur_skill_grade[k] < 0)
                {
                    this.cur_skill_grade[k] = 0;
                }
                this.skill_colltime[k] = skill2.ss[this.skill_slot[k], this.cur_skill_grade[k]]._cooltime;
                Vector2 vector3 = new Vector2(0.125f * (k % 8), 0.125f * (k / 8));
                this.clone_skillicon[k] = this.script_pack.CreatCustomPlane((Vector2) (Vector2.one * 0.16f), 0.15f, (Vector3) (Vector3.up * 200f), vector3, vector3 + ((Vector2) (Vector2.one * 0.125f)), "skill_icon", "Icon_Skill_p", 0f, 1);
                this.clone_fillbox[k] = this.script_pack.CreatCustomPlane((Vector2) (Vector2.one * 0.16f), 0f, (Vector3) (Vector3.up * 200f), new Vector2(0.625f, 0.25f), new Vector2(0.6875f, 0.3125f), "fillbox_skill", "Icon_FillBox", 0f, 1);
                this.clone_skillicon[k].GetComponent<Icon_Skill_p>().SkillKind(k, k, 0, 0);
                this.clone_fillbox[k].GetComponent<Icon_FillBox>().SkillKind(k, this.skill_colltime[k]);
                Transform transform3 = (Transform) UnityEngine.Object.Instantiate(this.num_skill, this.clone_skillicon[k].position - ((Vector3) (Vector3.right * 0.1f)), Quaternion.identity);
                transform3.parent = this.clone_skillicon[k];
            }
            for (int m = 0; m < 3; m++)
            {
                if (this.item_slot[m] > 0)
                {
                    Vector2 vector4 = new Vector2(0.125f * (this.item_slot[m] - 1), 0.875f);
                    this.clone_itemicon[m] = this.script_pack.CreatCustomPlane((Vector2) (Vector2.one * 0.16f), 0f, this.item_iconpos, vector4, vector4 + ((Vector2) (Vector2.one * 0.125f)), "item_icon", null, 0f, 0);
                    this.item_iconpos += (Vector3) (Vector3.right * 0.2f);
                    this.script_cha.ItemBuff(this.item_slot[m]);
                }
            }
            this.icon_rotate = this.script_pack.CreatCustomPlane((Vector2) (Vector2.one * 0.24f), 0.23f, (Vector3) (Vector3.one * 6f), new Vector2(0.75f, 0.75f), new Vector2(0.875f, 0.875f), "icon_rotate", "Icon_Skill_p", 0f, 1);
            this.icon_rotate.GetComponent<Icon_Skill_p>().ThisisRoll();
        }
        this.icon_pause = this.script_pack.CreatCustomPlane((Vector2) (Vector2.one * 0.16f), 0.15f, new Vector3(1.38f, 2.9f, 2f), new Vector2(0.625f, 0.75f), new Vector2(0.75f, 0.875f), "icon_pause", "Icon_Skill_p", 0f, 0);
        this.icon_pause.GetComponent<Icon_Skill_p>().ThisisPause();
        this.icon_shortsp = this.script_pack.CreatCustomPlane((Vector2) (Vector2.one * 0.25f), 0f, new Vector3(-1.37f, 2.5f, 1.8f), new Vector2(0.625f, 0.625f), new Vector2(0.75f, 0.75f), "icon_shortsp", null, 0f, 0);
        this.icon_shortsp.gameObject.active = false;
        this.script_cha.SetPetSkillLV(component.ps[1, this.pet_passiveskill[1]]._passive, component.ps[0, this.pet_activeskill[0]]._attackpoint, component.ps[1, this.pet_activeskill[1]]._attackpoint);
        this.skill_use = PlayerPrefsX.GetIntArray("skill_use");
        this.pet_skill_use = PlayerPrefsX.GetIntArray("pet_skill_use");
        if (!this.infinitymode)
        {
            this.PetSkill_Generation();
        }
        else
        {
            int[] intArray = PlayerPrefsX.GetIntArray("skill_slot");
            for (int n = 0; n < 5; n++)
            {
                if (intArray[n] >= 0)
                {
                    this.SkillPlus(intArray[n], false);
                }
            }
        }
    }

    private void Update()
    {
        if (this.timereduce)
        {
            this.duration_delay += Time.deltaTime;
            if (this.duration_delay >= this._duration[this.currentpetskill])
            {
                this.duration_delay = 0f;
                this.timereduce = false;
                this.script_cha.PetSkillFinish(this.currentpetskill);
            }
        }
        if (this.move_icon_skill)
        {
            this.mytransform.position = Vector3.Lerp(this.mytransform.position, this.movepos, Time.deltaTime * 9f);
        }
        else
        {
            this.mytransform.position = Vector3.Lerp(this.mytransform.position, Vector3.zero, Time.deltaTime * 12f);
        }
        if (this.move_icon_pet)
        {
            this.icon_pet_folder.position = Vector3.Lerp(this.icon_pet_folder.position, -this.movepos, Time.deltaTime * 9f);
        }
        else
        {
            this.icon_pet_folder.position = Vector3.Lerp(this.icon_pet_folder.position, Vector3.zero, Time.deltaTime * 12f);
        }
    }
}


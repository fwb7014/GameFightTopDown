using System;
using UnityEngine;

public class Sk_flybug : MonoBehaviour
{
    private float delay;
    private Collider mycollider;
    private Transform mytransform;
    private bool shootfinish;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
    }

    private void OnEnable()
    {
        this.shootfinish = false;
        this.delay = 0f;
        base.InvokeRepeating("Shoot", 0.5f, 0.3f);
        base.particleEmitter.emit = true;
        this.mytransform.GetChild(0).particleEmitter.emit = true;
        this.mycollider.enabled = false;
    }

    public void Shoot()
    {
        this.mycollider.enabled = false;
        this.mycollider.enabled = true;
    }

    private void Update()
    {
        this.delay += Time.deltaTime;
        if (this.delay > 6f)
        {
            base.gameObject.active = false;
            this.mytransform.GetChild(0).gameObject.active = false;
        }
        else if ((this.delay > 3f) && !this.shootfinish)
        {
            base.particleEmitter.emit = false;
            this.mytransform.GetChild(0).particleEmitter.emit = false;
            base.CancelInvoke("Shoot");
            this.mycollider.enabled = false;
            this.shootfinish = true;
        }
    }
}


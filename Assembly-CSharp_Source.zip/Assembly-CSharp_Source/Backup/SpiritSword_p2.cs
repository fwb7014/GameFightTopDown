using System;
using UnityEngine;

public class SpiritSword_p2 : MonoBehaviour
{
    private Vector3 directionVector;
    private float dt;
    private bool fireon;
    private Collider mycollider;
    private Transform myparent;
    private TrailRenderer mytrail;
    private Transform mytransform;
    private Transform target;
    private Vector3 targetpos;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
        this.mytrail = base.GetComponent<TrailRenderer>();
    }

    public void FinishSword()
    {
        this.mycollider.enabled = false;
        this.fireon = false;
        this.dt = 0f;
    }

    public void FireSword(Transform enemy)
    {
        this.mycollider.enabled = true;
        this.target = enemy;
    }

    private void OnEnable()
    {
        this.mycollider.enabled = false;
        this.dt = 0f;
        this.mytrail.enabled = true;
        this.fireon = true;
    }

    private void Start()
    {
        this.myparent = this.mytransform.parent;
        this.FireSword(this.myparent);
        this.mytransform.parent = null;
    }

    private void Update()
    {
        if (this.fireon)
        {
            if (this.mytransform.position.y > 0f)
            {
                if (this.target == this.myparent)
                {
                    this.dt = 2f;
                }
                else if (this.dt < 10f)
                {
                    this.dt += Time.deltaTime * 5f;
                }
                if (this.target != null)
                {
                    this.targetpos = this.target.position;
                }
                this.directionVector = this.targetpos - this.mytransform.position;
                if (this.directionVector != Vector3.zero)
                {
                    this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, Quaternion.LookRotation(this.directionVector), (4f * this.dt) * Time.deltaTime);
                }
                this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * 1.8f);
            }
            else
            {
                this.mycollider.enabled = false;
                this.target = this.myparent;
                this.mytransform.forward = Vector3.up;
                this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * 1.8f);
                this.dt = 0f;
            }
        }
        else
        {
            this.mytransform.forward = Vector3.up;
            this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * 1.8f);
            if (this.mytransform.position.y > 1f)
            {
                base.gameObject.active = false;
                this.mytrail.enabled = false;
            }
        }
    }
}


using System;
using UnityEngine;

public class QuitGUI : MonoBehaviour
{
    public GUISkin basicSkin;
    public Texture2D bg_black;
    public GUIStyle bt_yesno;
    private int language = 1;
    public Texture2D pop_blank;
    private float timescale = 1f;
    private GameObject ui;
    private GameObject ui2;

    private void OnGUI()
    {
        GUI.skin = this.basicSkin;
        GUI.depth = -100;
        GUI.matrix = Matrix4x4.Scale(new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.bg_black);
        GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
        GUI.Label(Crypto.Rect2(112f, 120f, 256f, 14f), Language.intxt[this.language, 260], "txt12_0");
        if (GUI.Button(Crypto.Rect2(170f, 138f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
        {
            Time.timeScale = 0f;
            Application.Quit();
        }
        else if (GUI.Button(Crypto.Rect2(240f, 138f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
        {
            Time.timeScale = this.timescale;
            if (this.ui != null)
            {
                this.ui.active = true;
            }
            if (this.ui2 != null)
            {
                this.ui2.active = true;
            }
            UnityEngine.Object.Destroy(base.gameObject);
        }
    }

    private void Start()
    {
        this.ui = GameObject.Find("scenario");
        if (this.ui == null)
        {
            this.ui = GameObject.FindWithTag("ui");
        }
        if (this.ui != null)
        {
            this.ui.active = false;
        }
        this.ui2 = GameObject.FindWithTag("ranking");
        if (this.ui2 != null)
        {
            this.ui2.active = false;
        }
        this.timescale = Time.timeScale;
        Time.timeScale = 0f;
        this.language = PlayerPrefs.GetInt("language");
    }
}


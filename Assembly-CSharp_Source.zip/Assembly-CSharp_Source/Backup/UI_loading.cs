using System;
using UnityEngine;

public class UI_loading : MonoBehaviour
{
    private void Start()
    {
        base.audio.volume = PlayerPrefs.GetFloat("vol_bgm");
    }
}


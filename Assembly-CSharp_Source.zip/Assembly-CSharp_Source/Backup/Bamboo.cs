using System;
using UnityEngine;

public class Bamboo : MonoBehaviour
{
    public int collideroff;
    private float delay;
    public float finishdelay = 4.2f;
    private Collider mycollider;
    private Transform mytransform;
    private bool next;
    private Vector3 originpos;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
    }

    private void OnEnable()
    {
        this.originpos = this.mytransform.position;
        this.originpos[1] = 0f;
        this.delay = 0f;
        this.mycollider.enabled = true;
        this.mycollider.isTrigger = true;
    }

    private void Update()
    {
        this.delay += Time.deltaTime;
        if (this.delay > this.finishdelay)
        {
            this.mytransform.position -= (Vector3) ((Vector3.up * Time.deltaTime) * 2f);
            if (this.mytransform.position.y < -1f)
            {
                this.next = false;
                base.gameObject.active = false;
                this.mytransform.position = (Vector3) (Vector3.one * 5f);
            }
        }
        else if (this.delay > 0.5f)
        {
            if (!this.next)
            {
                if (this.collideroff == 0)
                {
                    this.mycollider.enabled = false;
                    this.mytransform.position = this.originpos;
                }
                else if (this.collideroff == 1)
                {
                    this.mycollider.isTrigger = false;
                    this.mytransform.position = this.originpos;
                }
                this.next = true;
            }
        }
        else if (this.mytransform.position.y >= 0f)
        {
            this.mytransform.position = this.originpos;
        }
        else
        {
            this.mytransform.position += (Vector3) ((Vector3.up * Time.deltaTime) * 3f);
        }
    }
}


using System;
using UnityEngine;

public class Gauge_UV : MonoBehaviour
{
    private Vector2[] originUV = new Vector2[4];
    private Mesh thismesh;

    private void Awake()
    {
        this.thismesh = base.GetComponent<MeshFilter>().mesh;
        this.originUV = this.thismesh.uv;
    }

    public void UvMove(Vector2 _amount)
    {
        this.thismesh.uv = new Vector2[] { this.originUV[0] + _amount, this.originUV[1] + _amount, this.originUV[2] + _amount, this.originUV[3] + _amount };
    }
}


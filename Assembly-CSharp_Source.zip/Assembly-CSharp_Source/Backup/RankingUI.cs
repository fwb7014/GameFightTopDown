using System;
using UnityEngine;

public class RankingUI : MonoBehaviour
{
    public GUISkin basicSkin;
    public Texture2D bg_title;
    public Texture2D bg_title_me;
    public GUIStyle bt_back;
    public GUIStyle bt_empty;
    public GUIStyle bt_start;
    private float curMousePosY;
    public Texture2D errorimg;
    public Texture2D icon_key;
    public Texture2D[] icon_ranktab = new Texture2D[3];
    public Texture2D[] icon_toprank = new Texture2D[3];
    private int language;
    private short MAXRANKING = 50;
    private Texture2D myimage;
    private float posX = 112f;
    private float posY = 114f;
    private Vector2 prev_scrollPosition;
    private short scopemode;
    private RankingManager script_ranking;
    private Vector2 scrollPosition;
    private float startMousePosY;
    public Texture2D toggle_active;
    private GameObject ui;

    private void Awake()
    {
        this.language = PlayerPrefs.GetInt("language");
        this.script_ranking = GameObject.FindWithTag("ranking").GetComponent<RankingManager>();
    }

    private void OnGUI()
    {
        GUI.depth = -8;
        GUI.skin = this.basicSkin;
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        if (Input.anyKeyDown)
        {
            if (Crypto.Rect2(this.posX, this.posY + 40f, 256f, 142f).Contains(Event.current.mousePosition))
            {
                this.startMousePosY = Input.mousePosition.y;
                this.prev_scrollPosition = this.scrollPosition;
            }
        }
        else if (Input.anyKey && Crypto.Rect2(this.posX, this.posY + 40f, 256f, 142f).Contains(Event.current.mousePosition))
        {
            this.curMousePosY = Input.mousePosition.y;
            this.scrollPosition = this.prev_scrollPosition + ((Vector2) ((Vector2.up * (this.curMousePosY - this.startMousePosY)) * (640f / ((float) Screen.height))));
        }
        GUI.Box(Crypto.Rect2(this.posX - 74f, this.posY - 42f, 262f, 240f), string.Empty, "blank_box");
        if (this.script_ranking.loadfinish)
        {
            int maxfriend = this.script_ranking.maxfriend;
            this.scrollPosition = GUI.BeginScrollView(Crypto.Rect2(this.posX - 74f, this.posY + 18f, 258f, 174f), this.scrollPosition, Crypto.Rect2(0f, 0f, 242f, (float) (maxfriend * 0x2c)));
            for (short i = 0; i < maxfriend; i = (short) (i + 1))
            {
                if (((this.scrollPosition.y - (i * 0x58)) <= 80f) && ((this.scrollPosition.y - (i * 0x58)) >= -350f))
                {
                    if (this.script_ranking.userimg[i] != null)
                    {
                        GUI.DrawTexture(Crypto.Rect2(49f, (float) ((i * 0x2c) + 2), 36f, 36f), this.script_ranking.userimg[i]);
                    }
                    else
                    {
                        GUI.DrawTexture(Crypto.Rect2(49f, (float) ((i * 0x2c) + 2), 36f, 36f), this.errorimg);
                    }
                    GUI.DrawTexture(Crypto.Rect2(12f, (float) (i * 0x2c), 234f, 40f), this.bg_title);
                    if (this.script_ranking.userpoint[i] != 0)
                    {
                        GUI.Label(Crypto.Rect2(150f, (float) (i * 0x2c), 128f, 40f), string.Empty + this.script_ranking.userpoint[i], "txt12_0");
                    }
                    if (this.script_ranking.username[i] != null)
                    {
                        GUI.Label(Crypto.Rect2(92f, (float) (i * 0x2c), 90f, 40f), this.script_ranking.username[i], "txt12_0");
                    }
                    if (i < 3)
                    {
                        GUI.DrawTexture(Crypto.Rect2(12f, (float) ((i * 0x2c) + 2), 36f, 36f), this.icon_toprank[i]);
                    }
                    GUI.Label(Crypto.Rect2(-3f, (float) (i * 0x2c), 64f, 40f), string.Empty + (i + 1), "imagenum");
                }
            }
            GUI.EndScrollView();
            if (this.myimage != null)
            {
                GUI.DrawTexture(Crypto.Rect2(this.posX - 25f, this.posY - 26f, 36f, 36f), this.myimage);
            }
            else
            {
                GUI.DrawTexture(Crypto.Rect2(this.posX - 25f, this.posY - 24f, 36f, 36f), this.errorimg);
            }
            GUI.DrawTexture(Crypto.Rect2(this.posX - 62f, this.posY - 26f, 234f, 40f), this.bg_title_me);
            if (this.script_ranking.mygrade < 0x3e8)
            {
                GUI.Label(Crypto.Rect2(this.posX - 76f, this.posY - 26f, 64f, 40f), string.Empty + this.script_ranking.mygrade, "imagenum");
            }
            else if (this.script_ranking.mygrade < 0xf4240)
            {
                GUI.Label(Crypto.Rect2(this.posX - 76f, this.posY - 26f, 64f, 40f), string.Empty + this.script_ranking.mygrade, "txt12_w");
            }
            else
            {
                GUI.Label(Crypto.Rect2(this.posX - 76f, this.posY - 26f, 64f, 40f), "...", "txt12_w");
            }
            GUI.Label(Crypto.Rect2(this.posX + 76f, this.posY - 26f, 128f, 40f), string.Empty + this.script_ranking.mypoint, "txt12_w");
        }
        else
        {
            GUI.Label(Crypto.Rect2(this.posX - 82f, this.posY - 36f, 284f, 210f), Language.intxt[this.language, 0x12f], "txt12_w");
        }
        GUI.Box(Crypto.Rect2(this.posX - 69f, this.posY - 74f, 80f, 32f), string.Empty, "blank_tab");
        GUI.Box(Crypto.Rect2(this.posX + 17f, this.posY - 74f, 80f, 32f), string.Empty, "blank_tab");
        GUI.Box(Crypto.Rect2(this.posX + 103f, this.posY - 74f, 80f, 32f), string.Empty, "blank_tab");
        if (this.scopemode == 0)
        {
            GUI.DrawTexture(Crypto.Rect2(this.posX - 69f, this.posY - 74f, 80f, 32f), this.toggle_active);
            GUI.Label(Crypto.Rect2(this.posX - 84f, this.posY - 44f, 284f, 18f), Language.intxt[this.language, 0x180] + "    " + this.script_ranking.resettime, "txt12_w");
        }
        else
        {
            GUI.DrawTexture(Crypto.Rect2(this.posX + 17f, this.posY - 74f, 80f, 32f), this.toggle_active);
        }
        GUI.DrawTexture(Crypto.Rect2(this.posX - 64f, this.posY - 68f, 20f, 20f), this.icon_ranktab[0]);
        GUI.DrawTexture(Crypto.Rect2(this.posX + 21f, this.posY - 68f, 20f, 20f), this.icon_ranktab[1]);
        GUI.DrawTexture(Crypto.Rect2(this.posX + 107f, this.posY - 68f, 20f, 20f), this.icon_ranktab[2]);
        GUI.Label(Crypto.Rect2(this.posX - 48f, this.posY - 74f, 56f, 32f), Language.intxt[this.language, 0xc2], "txt12_w");
        GUI.Label(Crypto.Rect2(this.posX + 38f, this.posY - 74f, 56f, 32f), Language.intxt[this.language, 0xc1], "txt12_w");
        GUI.Label(Crypto.Rect2(this.posX + 124f, this.posY - 74f, 56f, 32f), Language.intxt[this.language, 410], "txt12_w");
        if (GUI.Button(Crypto.Rect2(this.posX - 69f, this.posY - 74f, 80f, 32f), string.Empty, this.bt_empty))
        {
            this.scopemode = 0;
            this.script_ranking.S_LoadRanking(1, this.scopemode, this.MAXRANKING);
        }
        if (GUI.Button(Crypto.Rect2(this.posX + 17f, this.posY - 74f, 80f, 32f), string.Empty, this.bt_empty))
        {
            this.scopemode = 1;
            this.script_ranking.S_LoadRanking(1, this.scopemode, this.MAXRANKING);
        }
        if (GUI.Button(Crypto.Rect2(this.posX + 103f, this.posY - 74f, 80f, 32f), string.Empty, this.bt_empty))
        {
            Application.LoadLevel("Friends");
        }
        GUI.enabled = true;
    }

    public void RankingOn()
    {
    }

    private void Start()
    {
        this.script_ranking.S_LoadRanking(1, 0, 30);
    }

    private void Update()
    {
        this.posX = Mathf.MoveTowards(this.posX, 183f, Time.deltaTime * 1000f);
    }
}


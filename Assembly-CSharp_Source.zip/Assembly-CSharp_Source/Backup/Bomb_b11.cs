using System;
using UnityEngine;

public class Bomb_b11 : MonoBehaviour
{
    private float delay;
    public float finishdelay = 3f;
    public float hitrate = 0.2f;
    private Collider mycollider;
    private Material mymaterial;
    private Transform mytransform;
    private Vector2 offset;
    private bool particleoff;
    private float scalefactor = 12f;
    public float startdelay = 0.1f;
    public float uvspeed = 1f;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mymaterial = base.renderer.sharedMaterial;
        this.mycollider = base.collider;
    }

    private void DanceHit()
    {
        this.mycollider.enabled = false;
        this.mycollider.enabled = true;
    }

    private void OnEnable()
    {
        this.offset = Vector2.zero;
        this.mymaterial.mainTextureOffset = Vector2.zero;
        base.InvokeRepeating("DanceHit", this.startdelay, this.hitrate);
        this.mytransform.localScale = (Vector3) (Vector3.one * 2f);
        this.delay = 0f;
        this.scalefactor = 12f;
        this.mytransform.GetChild(0).particleEmitter.emit = true;
    }

    private void Update()
    {
        this.offset += (Vector2) ((Vector2.up * Time.deltaTime) * this.uvspeed);
        if (this.delay > this.finishdelay)
        {
            base.CancelInvoke();
            this.mycollider.enabled = false;
            this.mytransform.position = (Vector3) (Vector3.one * 38f);
            base.gameObject.active = false;
            this.delay = 0f;
        }
        else
        {
            this.scalefactor -= Time.deltaTime * 10f;
            this.delay += Time.deltaTime;
            this.mymaterial.mainTextureOffset = this.offset;
            this.mytransform.localScale += (Vector3) ((Vector3.one * Time.deltaTime) * this.scalefactor);
            if (!this.particleoff && (this.delay > 0.5f))
            {
                this.mytransform.GetChild(0).particleEmitter.emit = false;
            }
        }
    }
}


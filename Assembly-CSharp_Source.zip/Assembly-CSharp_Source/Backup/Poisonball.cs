using System;
using UnityEngine;

public class Poisonball : MonoBehaviour
{
    private Transform boom;
    private bool explode;
    private ParticleEmitter myparticle;
    private Transform mytransform;
    private float shoot_delay;
    private Vector3 shootdir;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myparticle = base.particleEmitter;
    }

    private void Start()
    {
        this.shootdir = this.mytransform.parent.forward - ((Vector3) (Vector3.up * 0.5f));
        this.mytransform.parent = null;
        this.boom = GameObject.FindWithTag("skill").transform;
    }

    private void Update()
    {
        if (!this.explode)
        {
            if (this.shoot_delay > 1f)
            {
                this.mytransform.position += (Vector3) ((this.shootdir * Time.deltaTime) * 2.5f);
                if (this.mytransform.position.y <= 0f)
                {
                    base.collider.enabled = true;
                    UnityEngine.Object.Destroy(base.collider, 0.4f);
                    UnityEngine.Object.Destroy(base.gameObject, 1.2f);
                    this.explode = true;
                    this.myparticle.rndVelocity = Vector3.one;
                    this.boom.GetComponent<Ef_boom>().SetTex(2, this.mytransform.position, true);
                }
            }
            else
            {
                this.shoot_delay += Time.deltaTime;
            }
        }
    }
}


using System;
using UnityEngine;

public class ChannelMgr
{
    private string channelId = "000000";
    private static ChannelMgr instance;

    private ChannelMgr()
    {
    }

    public string getChannelId()
    {
        return this.channelId;
    }

    public static ChannelMgr GetInstance()
    {
        if (instance == null)
        {
            instance = new ChannelMgr();
        }
        return instance;
    }

    public void init()
    {
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.common.libs.Config"))
        {
            this.channelId = JSONObject.Parse(class2.CallStatic<string>("getConfigInfo", new object[0])).Get<string>("channel");
        }
    }

    public bool IsCM()
    {
        return (this.channelId == "000266");
    }

    public bool IsCMM()
    {
        return (this.channelId == "000013");
    }

    public bool IsCT()
    {
        return (this.channelId == "000032");
    }

    public bool IsCU()
    {
        return (this.channelId == "000056");
    }
}


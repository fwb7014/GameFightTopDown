using System;
using UnityEngine;

public class Ef_energy_gather : MonoBehaviour
{
    private bool anistart;
    private Color currentColor;
    private float dt;
    public Texture[] eftex = new Texture[2];
    private float finish_delay = 1.2f;
    private int fogalpha = 2;
    private Vector3 growVector;
    private Material mymaterial;
    private Transform mytransform;
    private Vector2 offset;
    private float plustimescale;
    private float show_delay = 0.1f;
    private Vector3 smoothgrowVector;
    private Color targetColor;
    private Color transColor;
    private Color whiteclear = new Color(0.5f, 0.5f, 0.5f, 0f);

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mymaterial = base.renderer.sharedMaterial;
    }

    public void SetTex(int _index, float _finishdelay)
    {
        this.mymaterial.mainTexture = this.eftex[_index];
        this.finish_delay = _finishdelay;
    }

    private void Start()
    {
        this.targetColor = Color.gray;
        base.gameObject.active = false;
        this.offset = Vector2.zero;
        this.mymaterial.SetColor("_TintColor", this.whiteclear);
    }

    private void Update()
    {
        if (this.dt > this.finish_delay)
        {
            this.mytransform.position = (Vector3) (Vector3.one * 4f);
            base.gameObject.active = false;
            this.dt = 0f;
            this.mymaterial.SetColor("_TintColor", this.whiteclear);
            this.offset = Vector2.zero;
            this.targetColor = Color.gray;
            this.anistart = false;
        }
        else if (this.dt > (this.finish_delay - 0.4f))
        {
            this.targetColor = Color.clear;
        }
        else if (this.dt > this.show_delay)
        {
            this.anistart = true;
        }
        this.dt += Time.deltaTime;
        if (this.anistart)
        {
            this.plustimescale = ((float) this.fogalpha) / Time.timeScale;
            this.currentColor = this.mymaterial.GetColor("_TintColor");
            this.transColor = Color.Lerp(this.currentColor, this.targetColor, Time.deltaTime * this.plustimescale);
            this.mymaterial.SetColor("_TintColor", this.transColor);
            this.offset -= (Vector2) (((Vector2.up * Time.deltaTime) * this.plustimescale) * 0.5f);
            this.mymaterial.SetTextureOffset("_MainTex", this.offset);
        }
    }
}


using System;
using UnityEngine;

public class UI_Ready : MonoBehaviour
{
    public Texture2D anzhi_bg;
    public GUISkin basicSkin;
    public Texture2D black_bg;
    private string channelId = string.Empty;
    public Texture2D ci;
    public Texture2D coco_bg;
    public Texture2D coco_cha;
    public Texture2D coco_logo;
    public Texture2D duoku_bg;
    public Texture2D jinshan_bg;
    private int language;
    public Texture2D menhu_bg;
    public Texture2D muzhiwan_bg;
    public Texture2D review_icon;
    private int step;
    public Texture2D txt_loading;
    public Texture2D uc_bg;
    private bool usimCheck;

    private void Awake()
    {
        this.language = PlayerPrefs.GetInt("language");
    }

    public void GetUsim(string index)
    {
        Crypto.SetUsim(index);
        this.usimCheck = true;
    }

    private void NextScreen()
    {
        this.step++;
    }

    private void OnGUI()
    {
        GUI.skin = this.basicSkin;
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        if (this.step == 1)
        {
            Application.LoadLevel("Intro");
            GUI.DrawTexture(Crypto.Rect2(370f, 292f, 100f, 25f), this.txt_loading);
            this.step = 2;
        }
        else if (this.step == 0)
        {
            this.channelId = ChannelMgr.GetInstance().getChannelId();
            if (this.channelId == "000215")
            {
                GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.duoku_bg);
            }
            else if (this.channelId == "000007")
            {
                GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.duoku_bg);
            }
            else if (this.channelId == "000255")
            {
                GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.uc_bg);
            }
            else if (this.channelId == "000441")
            {
                GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.jinshan_bg);
            }
            else if (this.channelId == "000072")
            {
                GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.menhu_bg);
            }
            else if (this.channelId == "000005")
            {
                GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.anzhi_bg);
            }
            else if (this.channelId == "000247")
            {
                GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.muzhiwan_bg);
            }
        }
    }

    private void Start()
    {
        Crypto.Init();
        int @int = PlayerPrefs.GetInt("IsContinue");
        base.InvokeRepeating("NextScreen", 2f, 1.5f);
        ChannelMgr.GetInstance().init();
        if (ChannelMgr.GetInstance().getChannelId() == "000266")
        {
            if (!AndroidScript.i.MusicEnabled())
            {
                PlayerPrefs.SetFloat("vol_bgm", 0f);
                PlayerPrefs.SetFloat("vol_master", 0f);
            }
            else
            {
                PlayerPrefs.SetFloat("vol_bgm", 1f);
                PlayerPrefs.SetFloat("vol_master", 1f);
            }
        }
    }
}


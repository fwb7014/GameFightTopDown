using System;
using UnityEngine;

public class Shadow_eagle : MonoBehaviour
{
    private Transform mytransform;
    private Vector3 shadowpos;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void Start()
    {
    }

    private void Update()
    {
        this.shadowpos = this.mytransform.position;
        this.shadowpos[1] = 0.002f;
        this.mytransform.position = this.shadowpos;
    }
}


using System;
using UnityEngine;

public class Bullet_delay : MonoBehaviour
{
    private float current_time;
    public float disable_delay;
    private Collider mycollider;
    private Renderer myrenderer;
    private Transform mytransform;
    private Vector3 originscale;
    private bool renderOn;
    public float show_delay;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
        this.originscale = this.mytransform.localScale;
        this.mytransform.localScale = (Vector3) (this.originscale * 0.1f);
        if (base.renderer != null)
        {
            this.myrenderer = base.renderer;
        }
        else
        {
            this.renderOn = true;
        }
    }

    private void OnEnable()
    {
        this.current_time = 0f;
        base.renderer.enabled = false;
        this.mycollider.enabled = false;
    }

    private void Update()
    {
        this.current_time += Time.deltaTime;
        if (this.current_time >= this.disable_delay)
        {
            base.gameObject.active = false;
            this.current_time = 0f;
            this.renderOn = false;
            base.renderer.enabled = false;
            this.mycollider.enabled = false;
            this.mytransform.localScale = (Vector3) (this.originscale * 0.1f);
        }
        else if (this.renderOn)
        {
            if (this.mytransform.localScale.x < this.originscale.x)
            {
                this.mytransform.localScale += (Vector3) ((Vector3.one * Time.deltaTime) * 4f);
            }
        }
        else if (this.current_time >= this.show_delay)
        {
            this.mycollider.enabled = true;
            if (this.myrenderer != null)
            {
                this.myrenderer.enabled = true;
                this.renderOn = true;
            }
        }
    }
}


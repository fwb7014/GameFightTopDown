using System;
using UnityEngine;

public class Bullet_wheelwind : MonoBehaviour
{
    private int monmovestat;
    private Collider mycollider;
    private Transform myparent;
    private Transform mytransform;
    private AI_Enemy01 script_mon;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myparent = this.mytransform.root;
    }

    private void Start()
    {
        this.myparent = this.mytransform.root;
        this.script_mon = this.myparent.GetComponent<AI_Enemy01>();
    }

    private void Update()
    {
        this.mytransform.Rotate((Vector3) ((Vector3.up * Time.deltaTime) * -1000f));
        this.monmovestat = this.script_mon.monmovestat;
        if (this.monmovestat <= 0)
        {
            base.gameObject.active = false;
        }
    }
}


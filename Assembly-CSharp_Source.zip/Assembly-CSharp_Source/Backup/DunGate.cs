using System;
using UnityEngine;

public class DunGate : MonoBehaviour
{
    private Transform arrow;
    private Transform cha1;
    private float delay_open;
    private Transform mytransform;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.arrow = this.mytransform.GetChild(0);
        this.arrow.position = (Vector3) (Vector3.one * 22f);
    }

    private void OnEnable()
    {
        base.collider.enabled = false;
        this.delay_open = 1.5f;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.transform.root == this.cha1)
        {
            this.cha1.GetComponent<Cha_Control>().GateEnter(base.transform.position);
            base.gameObject.active = false;
            this.arrow.position = (Vector3) (Vector3.one * 22f);
        }
    }

    private void Start()
    {
        this.cha1 = GameObject.FindWithTag("Player").transform;
    }

    private void Update()
    {
        if (this.delay_open > 0f)
        {
            this.delay_open -= Time.deltaTime;
            if (this.delay_open <= 0f)
            {
                base.collider.enabled = true;
            }
        }
        Vector3 forward = Vector3.Normalize(this.mytransform.position - this.cha1.position);
        if (forward != Vector3.zero)
        {
            this.arrow.rotation = Quaternion.LookRotation(forward);
        }
        forward = (Vector3) ((this.cha1.position + (Vector3.up * 0.02f)) + (forward * 0.3f));
        this.arrow.position = forward;
    }
}


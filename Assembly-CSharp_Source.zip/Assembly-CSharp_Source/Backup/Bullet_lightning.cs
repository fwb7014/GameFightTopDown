using System;
using UnityEngine;

public class Bullet_lightning : MonoBehaviour
{
    private Transform cha1;
    private Transform mytransform;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.cha1 = GameObject.FindWithTag("Player").transform;
    }

    private void OnEnable()
    {
        this.mytransform.position = this.cha1.transform.position + new Vector3(UnityEngine.Random.Range((float) -0.02f, (float) 0.04f), 1.5f, UnityEngine.Random.Range((float) -0.02f, (float) 0.04f));
    }

    private void Update()
    {
        if (base.renderer.enabled)
        {
            if (this.mytransform.position.y > 0f)
            {
                this.mytransform.position -= (Vector3) ((Vector3.up * 5f) * Time.deltaTime);
            }
            else
            {
                this.mytransform.position = (Vector3) ((Vector3.right * this.mytransform.position.x) + (Vector3.forward * this.mytransform.position.z));
            }
        }
    }
}


using System;
using UnityEngine;

public class Ending : MonoBehaviour
{
    private void Start()
    {
        Application.LoadLevel("Story");
    }
}


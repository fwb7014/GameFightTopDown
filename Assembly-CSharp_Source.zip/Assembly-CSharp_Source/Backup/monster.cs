using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct monster
{
    public short _level;
    public short _maxhp;
    public short _power;
    public short _haveExp;
    public short _block;
    public short _sizekind;
    public float _runspeed;
    public float _backspeed;
    public float _firerange;
    public float _moving_atk;
    public bool _attach_ef;
    public short _dash;
    public float _speed_move;
    public float _speed_m_attack1;
    public float _speed_m_attack1_i;
    public float _speed_idle;
    public short _kind;
}


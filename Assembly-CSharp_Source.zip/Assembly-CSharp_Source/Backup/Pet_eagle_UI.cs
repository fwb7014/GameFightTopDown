using System;
using UnityEngine;

public class Pet_eagle_UI : MonoBehaviour
{
    private void Start()
    {
        base.animation["fly_glide"].layer = 1;
        base.animation["fly_flap"].layer = 1;
        base.animation["fly_glide"].speed = 0.4f;
        base.animation["fly_flap"].speed = 0.4f;
        base.animation.Play("fly_flap");
    }

    private void Update()
    {
    }
}


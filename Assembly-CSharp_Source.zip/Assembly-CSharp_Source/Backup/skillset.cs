using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct skillset
{
    public short _requireLV;
    public short _txtkind;
    public short _name;
    public short _info;
    public short _attackpoint;
    public short _price;
    public short _pricekind;
    public short _soulprice;
    public short _kind;
    public float _cooltime;
}


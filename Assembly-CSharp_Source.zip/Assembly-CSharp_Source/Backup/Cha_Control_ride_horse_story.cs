using System;
using UnityEngine;

public class Cha_Control_ride_horse_story : MonoBehaviour
{
    private short changeScene = 1;
    public AudioClip cry;

    private void Awake()
    {
        UnityEngine.Object.DontDestroyOnLoad(base.transform.gameObject);
    }

    public void Scene_third()
    {
        this.changeScene = 3;
    }

    private void Start()
    {
        base.transform.position = Vector3.forward;
        base.animation["horse_run"].speed = 0.7f;
        base.animation["horse_cry"].speed = 0.25f;
        base.animation.Play("horse_run");
    }

    private void Update()
    {
        if (this.changeScene <= 2)
        {
            Transform transform = base.transform;
            transform.position += (Vector3) (Vector3.forward * Time.deltaTime);
        }
        else if (this.changeScene == 3)
        {
            base.transform.position = Vector3.zero;
            base.animation.Play("horse_stand");
            if (Application.loadedLevelName == "Story_3")
            {
                base.audio.Stop();
                base.animation.Stop();
                base.animation.Play("horse_cry");
                base.audio.PlayOneShot(this.cry);
                base.animation.PlayQueued("horse_stand").speed = 0.2f;
                this.changeScene = 4;
            }
        }
        if ((base.transform.position.z > 5.5f) && (this.changeScene == 2))
        {
            this.changeScene = 3;
            UnityEngine.Object.Destroy(base.transform.Find("ride_stepfog").gameObject);
        }
        else if ((base.transform.position.z > 4.55f) && (this.changeScene == 1))
        {
            GameObject.Find("scene_trans").GetComponent<Story_trans>().ScreenOn(2f);
            GameObject.Find("Cam_loading").GetComponent<Cam_Loading_Story>().DisappearCam();
            base.transform.Find("ride_stepfog").particleEmitter.minEnergy = 0.4f;
            base.transform.Find("ride_stepfog").particleEmitter.maxEnergy = 0.4f;
            this.changeScene = 2;
        }
    }
}


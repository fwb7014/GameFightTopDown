using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class UI_intro : MonoBehaviour
{
    public GUIStyle bar_slide;
    public GUISkin basicSkin;
    public Texture2D bg_option;
    public Texture2D bg_pause;
    public Texture2D bi;
    public Texture2D black;
    public GUIStyle bt_cgp;
    public GUIStyle bt_empty;
    public GUIStyle bt_menu;
    public GUIStyle bt_new;
    public GUIStyle bt_redeem;
    public GUIStyle bt_yesno;
    public Texture2D cl_over15;
    public Texture2D cl_vioence;
    private bool classmark;
    private short confirm;
    public Font font;
    private bool freecash;
    private bool guion;
    public Texture2D ico_slide;
    public Texture2D[] img_mode = new Texture2D[2];
    public Texture2D img_start;
    private int iscontinue;
    private int language;
    private const int MAXGENERAL = 12;
    private const int MAXGENERALPOOL = 30;
    private const int MAXPET = 2;
    private const int MAXSKILL = 20;
    private const int MAXSTAGE = 90;
    private const int MAXTREASURE = 0x18;
    private const int MAXWORK = 2;
    private int[] negative = new int[20];
    private bool option;
    public Texture2D pop_blank;
    private bool promotion_exist;
    private bool redeemOn;
    private string s_version = string.Empty;
    public GUIStyle sel_lang;
    private bool showAds;
    private bool slideon;
    private bool slideon2;
    private Color transalpha;
    public Texture2D txt_extreme;
    private int txt_getJade;
    public Texture2D txt_story;
    private string userdata;
    private float vol_bgm;
    private float vol_master;
    private bool warning;

    public void CGPButtonLoadStart(string _bturl)
    {
        base.StartCoroutine(this.ImageLoading(_bturl));
    }

    private void Delay()
    {
        this.confirm = 0;
    }

    public void GetCGPReward(string _rewardkind, int _rewardamount)
    {
        if (_rewardkind == "UDJR")
        {
            Crypto.Property_change(_rewardamount, false);
        }
        else if (_rewardkind == "UDGR")
        {
            Crypto.Property_change(_rewardamount, true);
        }
    }

    [DebuggerHidden]
    private IEnumerator ImageLoading(string _url)
    {
        return new <ImageLoading>c__Iterator20 { _url = _url, <$>_url = _url, <>f__this = this };
    }

    public void InitStat()
    {
        this.iscontinue = 0;
        for (int i = 0; i < 20; i++)
        {
            this.negative[i] = -2;
        }
        PlayerPrefs.SetInt("IsInit", 1);
        PlayerPrefs.SetString("notice", "If key and value are modified, application data will be crashed or initialized.");
        PlayerPrefs.SetFloat("vol_master", 1f);
        PlayerPrefs.SetFloat("vol_bgm", 1f);
        PlayerPrefs.SetString("charge", "false");
        Crypto.Save_int_key("camfov", 0);
        Crypto.Save_int_key("cashshopkind", 0);
        PlayerPrefsX.SetVector3("uiCampos", new Vector3(0f, 0.6f, 1f));
        PlayerPrefsX.SetVector3("uiCampos2", Vector3.zero);
        PlayerPrefs.SetInt("IsContinue", 0);
        Crypto.Save_int_key("n47", 1);
        Crypto.Save_int_key("n11", 0);
        Crypto.Save_int_key("n17", 0x4b0);
        Crypto.Save_int_key("n24", 5);
        Crypto.Save_int_key("n09", 4);
        Crypto.Save_int_key("n03", 3);
        Crypto.Save_int_key("n42", 3);
        Crypto.Save_int_key("n06", -1);
        Crypto.Save_int_key("n10", 5);
        Crypto.Save_int_key("n12", 1);
        Crypto.Save_int_key("n16", 3);
        Crypto.Save_int_key("n14", 0);
        PlayerPrefsX.SetIntArray("n15", new int[90]);
        PlayerPrefsX.SetIntArray("n18", new int[20]);
        PlayerPrefsX.SetIntArray("n40", new int[20]);
        PlayerPrefsX.SetIntArray("n20", new int[6]);
        PlayerPrefsX.SetIntArray("n22", this.negative);
        PlayerPrefsX.SetIntArray("n23", new int[2]);
        PlayerPrefsX.SetIntArray("n27", new int[2]);
        PlayerPrefsX.SetIntArray("n25", new int[2]);
        Crypto.Save_int_key("n08", 1);
        Crypto.Save_int_key("n21", 1);
        Crypto.Save_int_key("n28", 1);
        Crypto.Save_int_key("n26", 100);
        Crypto.Save_int_key("n30", 1);
        Crypto.Save_int_key("n32", 5);
        Crypto.Save_int_key("n05", 0);
        Crypto.Save_int_key("n44", 0);
        Crypto.Save_int_key("n43", 0);
        int[] intArray = new int[12];
        intArray[0] = 0xc1e88b;
        PlayerPrefsX.SetIntArray("n13", intArray);
        int[] numArray2 = new int[12];
        numArray2[0] = 100;
        PlayerPrefsX.SetIntArray("n33", numArray2);
        PlayerPrefsX.SetIntArray("n29", new int[12]);
        PlayerPrefsX.SetIntArray("n36", new int[6]);
        Crypto.Save_int_key("cur_general", 0);
        Crypto.Save_int_key("n34", 0);
        Crypto.Save_int_key("n31", 10);
        Crypto.Save_int_key("n04", 8);
        Crypto.Save_int_key("n35", 2);
        Crypto.Save_int_key("n38", 0);
        Crypto.Save_int_key("cur_stage_index", 0);
        Crypto.Save_int_key("play_kind", 0);
        Crypto.Save_int_key("n37", -1);
        Crypto.Save_int_key("n46", 3);
        Crypto.Save_int_key("n48", 1);
        Crypto.Save_int_key("n49", 1);
        PlayerPrefsX.SetIntArray("n50", new int[3]);
        PlayerPrefsX.SetIntArray("n51", new int[2]);
        PlayerPrefsX.SetIntArray("n52", new int[100]);
        PlayerPrefsX.SetIntArray("n53", new int[50]);
        Crypto.Save_int_key("n54", 0);
        Crypto.Save_int_key("n55", 0);
        Crypto.Save_int_key("n56", 0);
        Crypto.Save_int_key("n58", 0);
        Crypto.Save_int_key("n59", 0);
        Crypto.Save_int_key("n61", 0);
        Crypto.Save_int_key("generalsearch", 0);
        Crypto.Save_int_key("caveplay", 0);
        Crypto.Save_int_key("perfectplay", 0);
        PlayerPrefsX.SetIntArray("skill_slot", new int[] { -1, -1, -1, -1, -1 });
        PlayerPrefsX.SetIntArray("n41", new int[] { 
            0x292c, 0, 0, 0, 0, 0, 0xf4c297, 0x1040ca7, 0x1134aff, 0x1228d3f, 0x131cb97, 0x141198f, 0x15057e7, 0x15f9e0f, 0x16ed497, 0x17e2e47, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0
         });
        PlayerPrefsX.SetIntArray("n45", new int[] { 
            0x2710, 0, 0, 0, 0, 0, 0x24f6f, 0x316a8, 0x3dde1, 0x49962, 0x5609b, 0x627d4, 0x7a6a5, 0x86dde, 0x93517, 0xabfa0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0
         });
        PlayerPrefsX.SetIntArray("n19", new int[0x1a]);
        int[] numArray3 = new int[5];
        numArray3[0] = 1;
        PlayerPrefsX.SetIntArray("n39", numArray3);
        PlayerPrefsX.SetIntArray("treasure", new int[0x18]);
        int[] numArray4 = new int[30];
        numArray4[0x1b] = 1;
        PlayerPrefsX.SetIntArray("staff", numArray4);
        PlayerPrefsX.SetIntArray("archive", new int[0x4c]);
        PlayerPrefsX.SetIntArray("bosskill", new int[12]);
        PlayerPrefsX.SetIntArray("skill_use", new int[20]);
        PlayerPrefsX.SetIntArray("pet_skill_use", new int[2]);
        Crypto.Save_int_key("enemykill", 0);
        Crypto.Save_int_key("grappling", 0);
        Crypto.Save_int_key("exattack", 0);
        Crypto.Save_int_key("death", 0);
        Crypto.Save_int_key("resurrection", 0);
        Crypto.Save_int_key("changelevel", 0);
        Crypto.Save_int_key("storycutin", 2);
        Crypto.Save_int_key("tutorial", 0);
        Crypto.Save_int_key("cashing", 0);
        TimeControl.EraseAll();
        TimeControl.InitStart();
        PurchaseLog.FileCreat();
        this.warning = false;
    }

    public void ItemDelivery(string _itemindex)
    {
        string[] strArray = new string[] { "10009", "10016", "10036", "10060", "10120", "10360", "10900" };
        int[] numArray = new int[] { 9, 0x10, 0x24, 60, 120, 360, 900 };
        for (int i = 0; i < 6; i++)
        {
            if (strArray[i] == _itemindex)
            {
                this.txt_getJade = numArray[i];
                Crypto.Property_change(numArray[i], true);
                this.confirm = 3;
                base.Invoke("Delay", 1f);
                break;
            }
        }
    }

    private void OnApplicationPause(bool pocus)
    {
        if (!pocus)
        {
        }
    }

    private void OnGUI()
    {
        GUI.skin = this.basicSkin;
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        if (this.guion)
        {
            if (this.confirm > 0)
            {
                GUI.enabled = false;
            }
            GUI.color = this.transalpha;
            GUI.DrawTexture(Crypto.Rect2(108f, 6f, 256f, 128f), this.bi);
            if (this.classmark)
            {
                GUI.DrawTexture(Crypto.Rect2(330f, 0f, 64f, 64f), this.cl_over15);
                GUI.DrawTexture(Crypto.Rect2(384f, 0f, 64f, 64f), this.cl_vioence);
            }
            if (this.transalpha.a >= 0.9f)
            {
                GUI.color = Color.white;
                if (this.warning || this.option)
                {
                    GUI.enabled = false;
                }
                GUI.Box(Crypto.Rect2(66f, 136f, 128f, 128f), string.Empty, "blank_box");
                GUI.Box(Crypto.Rect2(286f, 136f, 128f, 128f), string.Empty, "blank_box");
                if (GUI.Button(Crypto.Rect2(66f, 136f, 128f, 128f), Language.intxt[this.language, 0x1a1], this.bt_empty))
                {
                    if (this.iscontinue == 0)
                    {
                        this.InitStat();
                        Crypto.Save_int_key("gamemode", 0);
                        Application.LoadLevel("Story");
                    }
                    else if (this.SetVersionStart())
                    {
                        Crypto.Save_int_key("gamemode", 0);
                        Application.LoadLevel("Map");
                    }
                }
                else if (GUI.Button(Crypto.Rect2(286f, 136f, 128f, 128f), Language.intxt[this.language, 0x1a2], this.bt_empty))
                {
                    if (this.iscontinue == 0)
                    {
                        this.InitStat();
                        Crypto.Save_int_key("gamemode", 1);
                        Application.LoadLevel("Story");
                    }
                    else if (this.SetVersionStart())
                    {
                        Crypto.Save_int_key("gamemode", 1);
                        Application.LoadLevel("Extreme");
                    }
                }
                GUI.DrawTexture(Crypto.Rect2(84f, 136f, 90f, 32f), this.txt_story);
                GUI.DrawTexture(Crypto.Rect2(304f, 136f, 90f, 32f), this.txt_extreme);
                GUI.DrawTexture(Crypto.Rect2(70f, 236f, 120f, 32f), this.img_start);
                GUI.DrawTexture(Crypto.Rect2(290f, 236f, 120f, 32f), this.img_start);
                GUI.DrawTexture(Crypto.Rect2(74f, 190f, 112f, 56f), this.img_mode[0]);
                GUI.DrawTexture(Crypto.Rect2(294f, 190f, 112f, 56f), this.img_mode[1]);
                if (this.iscontinue == 0)
                {
                    GUI.Label(Crypto.Rect2(66f, 230f, 128f, 32f), Language.intxt[this.language, 0x39], "txt12_0");
                    GUI.Label(Crypto.Rect2(286f, 230f, 128f, 32f), Language.intxt[this.language, 0x39], "txt12_0");
                }
                else
                {
                    GUI.Label(Crypto.Rect2(66f, 230f, 128f, 32f), Language.intxt[this.language, 0x3a], "txt12_0");
                    GUI.Label(Crypto.Rect2(286f, 230f, 128f, 32f), Language.intxt[this.language, 0x3a], "txt12_0");
                }
                if (this.option)
                {
                    GUI.enabled = true;
                    if (this.slideon)
                    {
                        this.vol_bgm = ((Input.mousePosition.x * (480f / ((float) Screen.width))) - 214f) / 126f;
                        this.vol_bgm = Mathf.Clamp(this.vol_bgm, 0f, 1f);
                    }
                    else if (this.slideon2)
                    {
                        this.vol_master = ((Input.mousePosition.x * (480f / ((float) Screen.width))) - 214f) / 126f;
                        this.vol_master = Mathf.Clamp(this.vol_master, 0f, 1f);
                    }
                    GUI.DrawTexture(Crypto.Rect2(0f, 0f, 480f, 320f), this.bg_pause);
                    GUI.DrawTexture(Crypto.Rect2(112f, 85f, 256f, 256f), this.bg_option);
                    GUI.Label(Crypto.Rect2(128f, 108f, 70f, 16f), Language.intxt[this.language, 0x12e], "txt12_w");
                    GUI.Label(Crypto.Rect2(128f, 143f, 70f, 16f), Language.intxt[this.language, 0xf4], "txt12_w");
                    GUI.Label(Crypto.Rect2(128f, 180f, 70f, 16f), Language.intxt[this.language, 0xf5], "txt12_w");
                    if (GUI.Button(Crypto.Rect2(212f, 172f, 128f, 32f), Language.intxt[this.language, 0xf6], this.sel_lang))
                    {
                        short num = 2;
                        this.language = (this.language + 1) % num;
                        PlayerPrefs.SetInt("language", this.language);
                    }
                    if (GUI.RepeatButton(Crypto.Rect2(200f, 101f, 152f, 32f), string.Empty, this.bar_slide))
                    {
                        this.slideon2 = true;
                    }
                    else if (this.slideon2)
                    {
                        AudioListener.volume = this.vol_master;
                        this.slideon2 = false;
                    }
                    GUI.DrawTexture(Crypto.Rect2((this.vol_master * 126f) + 206f, 109f, 16f, 16f), this.ico_slide);
                    if (GUI.RepeatButton(Crypto.Rect2(200f, 136f, 152f, 32f), string.Empty, this.bar_slide))
                    {
                        this.slideon = true;
                    }
                    else if (this.slideon)
                    {
                        base.audio.volume = this.vol_bgm;
                        this.slideon = false;
                    }
                    GUI.DrawTexture(Crypto.Rect2((this.vol_bgm * 126f) + 206f, 144f, 16f, 16f), this.ico_slide);
                    if (GUI.Button(Crypto.Rect2(208f, 210f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                    {
                        this.option = false;
                        PlayerPrefs.SetFloat("vol_bgm", this.vol_bgm);
                        PlayerPrefs.SetFloat("vol_master", this.vol_master);
                    }
                    if (this.iscontinue != 0)
                    {
                        GUI.Box(Crypto.Rect2(120f, 48f, 240f, 32f), string.Empty, "blank_box");
                        GUI.Label(Crypto.Rect2(160f, 48f, 190f, 32f), Language.intxt[this.language, 0x1a3], "txt12_r");
                        if (GUI.Button(Crypto.Rect2(122f, 48f, 32f, 32f), string.Empty, this.bt_new))
                        {
                            this.warning = true;
                        }
                    }
                    GUI.enabled = false;
                }
                if (GUI.Button(Crypto.Rect2(442f, 0f, 32f, 32f), string.Empty, this.bt_menu))
                {
                    this.option = true;
                    if (ChannelMgr.GetInstance().getChannelId() == "000116")
                    {
                        AndroidScript.i.loadWDJAds();
                        this.showAds = false;
                    }
                }
                if (this.warning)
                {
                    GUI.enabled = true;
                    GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 128f), this.pop_blank);
                    GUI.Label(Crypto.Rect2(120f, 140f, 240f, 40f), Language.intxt[this.language, 0x30], "txt12_0");
                    if (GUI.Button(Crypto.Rect2(160f, 192f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                    {
                        this.InitStat();
                        PlayerPrefs.SetInt("haveDrawedGift", 0);
                    }
                    else if (GUI.Button(Crypto.Rect2(256f, 192f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                    {
                        this.warning = false;
                    }
                }
                GUI.Box(Crypto.Rect2(70f, 4f, 64f, 24f), Language.intxt[this.language, 0x1ca]);
                GUI.Box(Crypto.Rect2(4f, 4f, 64f, 24f), Language.intxt[this.language, 0x1ac]);
                string str2 = ChannelMgr.GetInstance().getChannelId();
                if (ChannelMgr.GetInstance().IsCT() || ChannelMgr.GetInstance().IsCM())
                {
                    GUI.Box(Crypto.Rect2(294f, 4f, 80f, 24f), Language.intxt[this.language, 0x1ce]);
                    GUI.Box(Crypto.Rect2(376f, 4f, 64f, 24f), Language.intxt[this.language, 0x1cf]);
                }
                if (GUI.Button(Crypto.Rect2(70f, 4f, 64f, 24f), string.Empty, this.bt_empty))
                {
                    this.confirm = 6;
                }
                if (GUI.Button(Crypto.Rect2(4f, 4f, 64f, 24f), string.Empty, this.bt_empty))
                {
                    this.confirm = 2;
                }
                if (ChannelMgr.GetInstance().IsCT() || ChannelMgr.GetInstance().IsCMM())
                {
                    if (GUI.Button(Crypto.Rect2(294f, 4f, 80f, 24f), string.Empty, this.bt_empty))
                    {
                        this.confirm = 4;
                    }
                    if (GUI.Button(Crypto.Rect2(376f, 4f, 64f, 24f), string.Empty, this.bt_empty))
                    {
                        this.confirm = 5;
                    }
                }
                GUI.Box(Crypto.Rect2(20f, 294f, 440f, 20f), Language.intxt[this.language, 380]);
                if (this.confirm > 0)
                {
                    GUI.enabled = true;
                    switch (this.confirm)
                    {
                        case 2:
                            GUI.skin.font = this.font;
                            if (!ChannelMgr.GetInstance().IsCT())
                            {
                                GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 170f), this.pop_blank);
                                GUI.Label(Crypto.Rect2(120f, 150f, 240f, 40f), Language.intxt[this.language, 0x1d0], "txt2");
                                if (GUI.Button(Crypto.Rect2(208f, 222f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                                {
                                    this.confirm = 0;
                                }
                                break;
                            }
                            GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 170f), this.pop_blank);
                            GUI.Label(Crypto.Rect2(140f, 165f, 200f, 30f), Language.intxt[this.language, 430], "txt2");
                            if (GUI.Button(Crypto.Rect2(208f, 235f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                            {
                                this.confirm = 0;
                            }
                            break;

                        case 3:
                            GUI.Box(Crypto.Rect2(112f, 160f, 256f, 38f), Language.intxt[this.language, 0xe9] + " " + this.txt_getJade);
                            break;

                        case 4:
                            try
                            {
                                AndroidScript.i.MoreGames();
                            }
                            catch (Exception)
                            {
                                this.confirm = 0;
                            }
                            this.confirm = 0;
                            break;

                        case 5:
                            if (Time.timeScale != 0f)
                            {
                                if (Application.loadedLevel == 0)
                                {
                                    return;
                                }
                                int @int = PlayerPrefs.GetInt("IsInit");
                                int num3 = 0;
                                int num4 = 0;
                                if (@int == 1)
                                {
                                    num4 = Crypto.Load_int_key("n24");
                                    num3 = Crypto.Load_int_key("n06");
                                }
                                if (num3 < 0)
                                {
                                    num3 = 0;
                                }
                                string isFirst = PlayerPrefs.GetString("isFirst");
                                AndroidScript.i.QuitGame(num4 + string.Empty, num3 + string.Empty, isFirst);
                                this.confirm = 0;
                                break;
                            }
                            return;

                        case 6:
                            AndroidScript.i.StartRedeemService();
                            this.confirm = 0;
                            break;
                    }
                }
            }
        }
    }

    public bool SetVersionStart()
    {
        if (this.iscontinue < 3)
        {
            this.iscontinue = 3;
            Crypto.Save_int_key("n46", 3);
            PlayerPrefs.SetInt("IsContinue", 3);
            int a = Crypto.Load_int_key("n07");
            if (a > 0x63)
            {
                a = 0x63 + ((a - 0x63) / 100);
                a = Mathf.Min(a, 0xc7);
            }
            Crypto.Save_int_key("n47", a);
        }
        if (this.iscontinue < 4)
        {
            this.iscontinue = 4;
            Crypto.Save_int_key("n48", 1);
            Crypto.Save_int_key("n49", 1);
            PlayerPrefsX.SetIntArray("n50", new int[3]);
            PlayerPrefsX.SetIntArray("n51", new int[2]);
            PlayerPrefsX.SetVector3("uiCampos2", Vector3.zero);
            PlayerPrefsX.SetIntArray("n52", new int[100]);
            PlayerPrefsX.SetIntArray("n53", new int[50]);
            Crypto.Save_int_key("n54", 0);
            Crypto.Save_int_key("n55", 0);
            Crypto.Save_int_key("n56", 0);
            Crypto.Save_int_key("n58", 0);
            Crypto.Save_int_key("n59", 0);
            TimeControl.EraseAll();
            PlayerPrefs.SetInt("IsContinue", 4);
            PlayerPrefs.SetInt("IsContinue", 4);
        }
        if (this.iscontinue < 6)
        {
            Crypto.Save_int_key("n48", 1);
            Crypto.Save_int_key("n49", 1);
            PlayerPrefsX.SetIntArray("n50", new int[3]);
            PlayerPrefsX.SetIntArray("n51", new int[2]);
            PlayerPrefsX.SetVector3("uiCampos2", Vector3.zero);
            PlayerPrefsX.SetIntArray("n52", new int[100]);
            PlayerPrefsX.SetIntArray("n53", new int[50]);
            Crypto.Save_int_key("n54", 0);
            Crypto.Save_int_key("n55", 0);
            Crypto.Save_int_key("n56", 0);
            Crypto.Save_int_key("n58", 0);
            Crypto.Save_int_key("n59", 0);
            Crypto.Save_int_key("n61", 0);
            Crypto.Save_int_key("n16", 3);
            TimeControl.EraseAll();
            PlayerPrefs.SetInt("IsContinue", 6);
        }
        TimeControl.InitStart();
        return true;
    }

    private void Start()
    {
        Input.multiTouchEnabled = false;
        Application.targetFrameRate = 60;
        this.iscontinue = PlayerPrefs.GetInt("IsContinue");
        if (this.iscontinue > 0)
        {
            this.vol_bgm = PlayerPrefs.GetFloat("vol_bgm");
            this.vol_master = PlayerPrefs.GetFloat("vol_master");
            base.audio.volume = this.vol_bgm;
            AudioListener.volume = this.vol_master;
            this.language = PlayerPrefs.GetInt("language");
            try
            {
                string str = Language.intxt[this.language, 1];
            }
            catch (IndexOutOfRangeException)
            {
                this.language = 0;
                PlayerPrefs.SetInt("language", this.language);
            }
            if (ChannelMgr.GetInstance().getChannelId() == "000023")
            {
                AndroidScript.i.loginQihoo();
            }
        }
        else
        {
            string str3 = ChannelMgr.GetInstance().getChannelId();
            if (str3 == "000023")
            {
                AndroidScript.i.loginQihoo();
            }
            this.language = 1;
            PlayerPrefs.SetInt("language", this.language);
            if (str3 == "000266")
            {
                base.audio.volume = PlayerPrefs.GetFloat("vol_bgm");
            }
        }
        TextAsset asset = Resources.Load("hsp_version") as TextAsset;
        this.s_version = asset.text;
    }

    public void StartGUI()
    {
        this.guion = true;
    }

    private void Update()
    {
        if (this.guion)
        {
            this.transalpha = Color.Lerp(this.transalpha, Color.white, Time.deltaTime * 3f);
        }
        if (this.redeemOn)
        {
        }
        if (Input.GetKeyDown("a"))
        {
            this.ItemDelivery("10360");
        }
    }

    [CompilerGenerated]
    private sealed class <ImageLoading>c__Iterator20 : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal string _url;
        internal string <$>_url;
        internal UI_intro <>f__this;
        internal WWW <www>__0;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<www>__0 = new WWW(this._url);
                    this.$current = this.<www>__0;
                    this.$PC = 1;
                    return true;

                case 1:
                    this.<>f__this.bt_cgp.normal.background = this.<www>__0.texture;
                    this.<>f__this.promotion_exist = true;
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }
}


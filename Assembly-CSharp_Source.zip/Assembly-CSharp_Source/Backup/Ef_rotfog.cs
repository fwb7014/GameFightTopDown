using System;
using UnityEngine;

public class Ef_rotfog : MonoBehaviour
{
    private Color currentColor;
    private int fogalpha;
    private float fogheight;
    private int fogrotation;
    private float fogspeed;
    private Material mymaterial;
    private Transform mytransform;
    private Vector3 plusV;
    private Color targetColor;
    private Color transColor;
    private float xyratio;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mymaterial = base.renderer.material;
    }

    public void RotfogOn(float limit_height, float _scale_speed, int _rot_speed, int _fogalpha, float _xyratio)
    {
        base.gameObject.active = true;
        this.mytransform.localScale = (Vector3) (Vector3.one * 0.3f);
        this.fogheight = limit_height;
        this.fogspeed = _scale_speed;
        this.fogrotation = _rot_speed;
        this.fogalpha = _fogalpha;
        this.xyratio = _xyratio;
        this.mymaterial.SetColor("_TintColor", Color.gray);
        this.plusV = new Vector3(this.fogspeed, this.fogspeed * this.xyratio, this.fogspeed);
    }

    private void Start()
    {
        this.mytransform.localScale = Vector3.zero;
        this.targetColor = new Color(0.5f, 0.5f, 0.5f, 0f);
    }

    private void Update()
    {
        this.currentColor = this.mymaterial.GetColor("_TintColor");
        if (this.mytransform.localScale.y > this.fogheight)
        {
            base.gameObject.active = false;
        }
        else if (this.mytransform.localScale.y > (this.fogheight * 0.5f))
        {
            this.mytransform.localScale += (Vector3) (this.plusV * Time.deltaTime);
            this.transColor = Color.Lerp(this.currentColor, this.targetColor, Time.deltaTime * this.fogalpha);
            this.mymaterial.SetColor("_TintColor", this.transColor);
        }
        else
        {
            this.mytransform.localScale += (Vector3) (this.plusV * Time.deltaTime);
            this.mytransform.eulerAngles += (Vector3) ((Vector3.up * this.fogrotation) * Time.deltaTime);
        }
    }
}


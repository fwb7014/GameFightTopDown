using System;
using UnityEngine;

public class Bullet_tornado_b : MonoBehaviour
{
    private Transform mytransform;
    private Vector3 originscale;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.originscale = this.mytransform.localScale;
    }

    private void OnEnable()
    {
        this.mytransform.localScale = this.originscale;
    }

    private void Start()
    {
        base.animation["tornado"].speed = 0.3f;
        this.mytransform.position += (Vector3) (this.mytransform.forward * 0.1f);
    }

    private void Update()
    {
        float y = 0.5f * Time.deltaTime;
        this.mytransform.localScale += new Vector3(-5f * y, y, -5f * y);
        this.mytransform.position += (Vector3) (this.mytransform.forward * y);
        if (this.mytransform.localScale.y > 4f)
        {
            base.gameObject.active = false;
            this.mytransform.position = (Vector3) (Vector3.one * 5f);
        }
    }
}


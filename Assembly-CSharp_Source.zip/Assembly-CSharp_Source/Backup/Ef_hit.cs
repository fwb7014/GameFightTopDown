using System;
using UnityEngine;

public class Ef_hit : MonoBehaviour
{
    private Vector3 growVector = new Vector3(-3f, 0f, 10f);
    private Transform mytransform;
    private Vector3 originscale;
    private float showdelay;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void Start()
    {
        this.originscale = this.mytransform.localScale;
        base.renderer.sharedMaterial.renderQueue = 0xfd3;
    }

    private void Update()
    {
        if (this.showdelay < 0.25f)
        {
            this.mytransform.localScale += (Vector3) (this.growVector * Time.deltaTime);
            this.showdelay += Time.deltaTime;
        }
        else
        {
            this.showdelay = 0f;
            this.mytransform.position = (Vector3) (Vector3.one * 3f);
            this.mytransform.localScale = this.originscale;
            base.gameObject.active = false;
        }
    }
}


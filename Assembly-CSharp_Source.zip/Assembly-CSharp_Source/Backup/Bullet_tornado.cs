using System;
using UnityEngine;

public class Bullet_tornado : MonoBehaviour
{
    private int monmovestat;
    private float movedelay;
    private bool movestart;
    private Transform myparent;
    private Transform mytransform;
    private Vector3 originscale;
    private int rnddir;
    private AI_Enemy01 script_mon;
    private float sintime;
    private Vector3 targetpod;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myparent = this.mytransform.parent;
        this.originscale = this.mytransform.localScale;
    }

    public void Disappear()
    {
        base.gameObject.active = false;
        this.mytransform.position = (Vector3) (Vector3.one * 5f);
    }

    private void OnEnable()
    {
        this.rnddir = UnityEngine.Random.Range(0, 2);
        this.rnddir = (this.rnddir * 2) - 1;
        this.mytransform.localScale = this.originscale;
        this.targetpod = Vector3.zero;
        this.movestart = false;
        this.movedelay = 0f;
        this.sintime = 0f;
        this.mytransform.parent = this.myparent;
        this.mytransform.position += (Vector3) (Vector3.up * 0.1f);
    }

    private void Start()
    {
        base.animation["tornado"].speed = 0.3f;
        this.script_mon = this.mytransform.root.GetComponent<AI_Enemy01>();
    }

    private void Update()
    {
        this.movedelay += Time.deltaTime;
        if (!this.movestart)
        {
            this.monmovestat = this.script_mon.monmovestat;
            if (this.movedelay < 1.2f)
            {
                if (this.monmovestat <= 0)
                {
                    this.Disappear();
                }
                this.mytransform.localScale += (Vector3) ((Vector3.one * 0.5f) * Time.deltaTime);
            }
            else
            {
                this.mytransform.parent = null;
                this.movestart = true;
                this.mytransform.localScale = (Vector3) (Vector3.one * 2f);
            }
        }
        else
        {
            this.sintime += Time.deltaTime;
            this.targetpod = (Vector3) ((this.mytransform.forward * 0.8f) + (((this.mytransform.right * 0.1f) * Mathf.Cos(this.sintime * 8f)) * this.rnddir));
            this.mytransform.rotation = Quaternion.LookRotation(this.targetpod);
            this.mytransform.position += (Vector3) (this.targetpod * Time.deltaTime);
            if (this.mytransform.localScale.y > 2.2f)
            {
                this.mytransform.localScale += (Vector3) (((Vector3.right * -1f) + (Vector3.forward * -1f)) * Time.deltaTime);
                if (this.mytransform.localScale.x < 1f)
                {
                    this.Disappear();
                }
            }
            else
            {
                this.mytransform.localScale += (Vector3) (Vector3.up * 0.2f);
            }
        }
    }
}


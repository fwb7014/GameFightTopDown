using System;
using UnityEngine;

public class UI_forge : MonoBehaviour
{
    public Texture2D arrow_upgrade;
    private bool b_delay;
    public GUISkin basicSkin;
    public Texture2D bg_asset;
    public Texture2D bg_black;
    public Transform bg_cha1;
    public Texture2D bg_hammerhit;
    public Texture2D bg_hitgauge;
    private int bg_posX_l;
    private int bg_posX_r;
    public Texture2D bg_status;
    public Texture2D bg_upgrade;
    private int[] bottom_equipicon = new int[6];
    private int[] bottom_weaponicon = new int[6];
    public GUIStyle bt_back;
    public GUIStyle bt_empty;
    public GUIStyle bt_equip;
    public GUIStyle bt_init;
    public GUIStyle bt_plus;
    public GUIStyle bt_upgrade;
    public GUIStyle bt_yesno;
    public Texture2D c_equip;
    private GameObject cashshop;
    private Transform cha1;
    private int chalv;
    private int coin;
    private int confirm;
    private int[] cost_armor = new int[] { 1, 1, 1, 1, 1, 1, 40, 80, 80, 70, 150, 150, 100, 290, 290, 150 };
    private int[] costume_seed = new int[0x1a];
    private int cur_equip;
    private Vector2 cur_iconpos;
    private Vector2 cur_iconpos2;
    private int cur_weapon;
    private float currentX;
    private bool dragOn;
    private float dragposX;
    private float dragrange;
    public Transform ef_hammer;
    public Transform ef_result;
    private Color empty = new Color(0f, 0f, 0f, 0.5f);
    public Texture2D emptyslot;
    public Texture2D[] equipicon = new Texture2D[0x11];
    public GUIStyle erase;
    private float f_delay;
    public Texture2D fillbox_normal;
    public Texture2D fillbox_unique;
    public Texture2D gauge;
    public Texture2D[] gem_color = new Texture2D[4];
    private int[] gem_inven = new int[5];
    public Texture2D[] gem_tex = new Texture2D[5];
    private int hitcount;
    private float hitgaugeX;
    public Texture2D icon_coin;
    public Texture2D icon_jade;
    public Texture2D icon_lock;
    private int icon_posY;
    private int icon_size;
    public Texture2D icon_unlock;
    private bool imagemovefinish;
    public Texture2D[] invenkind = new Texture2D[2];
    private int jade;
    private int language;
    private bool maxupgrade;
    private int menu_kind;
    private int oldplusfactor;
    private int oldweapon_kind;
    private int oldweapon_meshkind;
    public Texture2D please_touch;
    private int plusfactor;
    public Texture2D pop_blank;
    public Texture2D pop_blank2;
    private short pop_upgrade;
    private float prevposX;
    public Transform pt_plus;
    private int[] reqLvFactor_equip = new int[] { 0, 10, 10, 20, 20, 30, 30, 40, 40, 50 };
    private int[] reqLvFactor_weapon = new int[] { 0, 10, 10, 30, 30, 30, 40, 40, 40, 50 };
    private Cha_Costume script_costume;
    private Ef_forge_hammer script_hammer;
    private Language_Costume script_name;
    private SoundEf_UI script_soundUI;
    private Cha_Weapon script_weapon;
    private WeaponStat script_weaponstat;
    private bool scrollOn;
    private int select_gem;
    private int selectequip;
    private int selectweapon;
    private int selequip_cost;
    private int selequip_hp;
    private int selequip_index;
    private int selequip_special;
    private int selweapon_cost;
    private int selweapon_grade;
    private int selweapon_index;
    private int selweapon_kind;
    private int selweapon_maxatk;
    private int selweapon_meshkind;
    private int selweapon_minatk;
    private int selweapon_name;
    private float selweapon_spd;
    private int selweapon_special;
    private int selweapon_special_txt;
    private int selweapon_upgrade;
    public Texture2D slot_circle;
    private int slot_costume;
    private int slot_weapon;
    public Transform sound_dummy;
    private Transform sound_UI;
    public Texture2D star_grade;
    public Texture2D stat_arrow;
    public GUIStyle sub_menu;
    private int subkind;
    public Texture2D tab_1;
    public Texture2D tab_2;
    public Texture2D tab_over;
    private float targetgaugeX;
    private Vector2 targetpos = new Vector2(294f, 82f);
    private Vector2 targetpos2 = new Vector2(310f, 96f);
    public Texture2D titlebase;
    public Texture2D titlebase_w;
    private int tutorial;
    public Texture2D txt_name;
    private int[] unlock_costume = new int[20];
    private int[] unlock_weapon = new int[20];
    public Texture2D upgrade_emptyslot;
    public Texture2D upgrade_slot;
    private int upgradecost;
    private int upgradelimit;
    public Transform weapon_dummy;
    private short[] weapon_grade = new short[6];
    public Texture2D[] weapon_kindicon = new Texture2D[3];
    private int[] weapon_plusup = new int[0x1a];
    private int[] weapon_seed = new int[0x1a];
    public Texture2D[] weaponicon = new Texture2D[0x23];

    private void Awake()
    {
        this.cha1 = GameObject.FindWithTag("Player").transform;
        this.weapon_seed = PlayerPrefsX.GetIntArray("n41");
        this.costume_seed = PlayerPrefsX.GetIntArray("n45");
        this.chalv = Crypto.Load_int_key("n47");
        this.script_hammer = this.ef_hammer.GetComponent<Ef_forge_hammer>();
        this.script_weaponstat = base.GetComponent<WeaponStat>();
        this.script_name = base.GetComponent<Language_Costume>();
        this.script_costume = this.cha1.GetComponent<Cha_Costume>();
        this.script_weapon = this.weapon_dummy.GetComponent<Cha_Weapon>();
        this.slot_weapon = Crypto.Load_int_key("n03");
        this.slot_costume = Crypto.Load_int_key("n42");
        this.language = PlayerPrefs.GetInt("language");
        this.weapon_plusup = PlayerPrefsX.GetIntArray("n19");
    }

    public void CashshopOpen()
    {
        if (this.cashshop == null)
        {
            this.cashshop = Resources.Load("CashShop") as GameObject;
        }
        UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
    }

    public void Cost_upgrade()
    {
        if (this.tutorial != 3)
        {
            this.upgradecost = (int) (((((this.selweapon_index * 12) + 7) * 0.5f) * ((0.4f * (this.select_gem + 1)) + 0.6f)) * 13f);
        }
        else
        {
            this.upgradecost = 0;
        }
    }

    public void Delay(float t)
    {
        this.b_delay = true;
        this.f_delay = t;
    }

    public void HideCha(bool _hide)
    {
        if (_hide)
        {
            this.cha1.position = new Vector3(-0.03f, -0.28f, 2f);
            this.bg_cha1.localScale = Vector3.zero;
        }
        else
        {
            this.cha1.position = new Vector3(-0.03f, -0.28f, -1f);
            this.bg_cha1.localScale = new Vector3(1.7f, 2.4f, 1f);
        }
    }

    public void Impact()
    {
        base.audio.Play();
        this.targetgaugeX = UnityEngine.Random.Range(6, 0x20) + this.hitgaugeX;
        this.targetgaugeX = Mathf.Min(this.targetgaugeX, 208f);
    }

    private void OnEnable()
    {
        this.coin = Crypto.Load_int_key("n17");
        this.jade = Crypto.Load_int_key("n24");
        this.gem_inven = PlayerPrefsX.GetIntArray("n39");
        this.unlock_costume = PlayerPrefsX.GetIntArray("n18");
        this.unlock_weapon = PlayerPrefsX.GetIntArray("n40");
    }

    private void OnGUI()
    {
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.skin = this.basicSkin;
        GUI.DrawTexture(Crypto.Rect2((float) this.bg_posX_l, 0f, 320f, 320f), this.bg_status);
        GUI.DrawTexture(Crypto.Rect2(120f, 30f, 100f, 50f), this.txt_name);
        GUI.Box(Crypto.Rect2(212f, 35f, 80f, 24f), Language.intxt[this.language, 0x49]);
        GUI.DrawTexture(Crypto.Rect2(112f, 0f, 256f, 32f), this.bg_asset);
        GUI.Label(Crypto.Rect2(146f, 6f, 80f, 14f), string.Empty + this.coin, "txt12_w");
        GUI.Label(Crypto.Rect2(280f, 6f, 64f, 14f), string.Empty + this.jade, "txt12_w");
        if (GUI.Button(Crypto.Rect2(144f, 2f, 100f, 24f), string.Empty, this.bt_empty))
        {
            if (this.sound_UI != null)
            {
                this.script_soundUI.SoundOn(0);
            }
            Crypto.Save_int_key("cashshopkind", 2);
            this.CashshopOpen();
        }
        if (GUI.Button(Crypto.Rect2(272f, 2f, 88f, 24f), string.Empty, this.bt_empty))
        {
            if (this.sound_UI != null)
            {
                this.script_soundUI.SoundOn(0);
            }
            Crypto.Save_int_key("cashshopkind", 1);
            this.CashshopOpen();
        }
        if (this.confirm > 0)
        {
            GUI.enabled = false;
        }
        else
        {
            GUI.enabled = true;
        }
        if (this.menu_kind == 0)
        {
            GUI.Label(Crypto.Rect2(204f, 66f, 240f, 32f), Language.intxt[this.language, 0x13], "txt12_0");
            for (int i = 0; i < 2; i++)
            {
                GUI.DrawTexture(Crypto.Rect2((float) (0xf3 + (i * 100)), 100f, 64f, 64f), this.invenkind[i]);
                if (GUI.Button(Crypto.Rect2((float) (0xf3 + (i * 100)), 100f, 64f, 64f), string.Empty, this.sub_menu))
                {
                    this.HideCha(false);
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    this.menu_kind = i + 1;
                    if (this.menu_kind == 1)
                    {
                        this.selectweapon = this.cur_weapon;
                        this.SetUpWeapon(this.weapon_seed[this.selectweapon]);
                        this.script_weapon.SetWeapon(this.selweapon_meshkind, this.selweapon_kind);
                    }
                    this.bg_posX_r = 480;
                    this.icon_posY = 320;
                    this.imagemovefinish = false;
                }
            }
            for (int j = 0; j < 5; j++)
            {
                if (this.gem_inven[j] > 0)
                {
                    GUI.color = Color.white;
                }
                else
                {
                    GUI.color = this.empty;
                }
                GUI.DrawTexture(Crypto.Rect2((float) (0xd8 + (j * 0x2e)), 177f, 32f, 32f), this.gem_tex[j]);
                GUI.color = Color.white;
                GUI.Box(Crypto.Rect2((float) (0xd8 + (j * 0x2e)), 208f, 32f, 16f), string.Empty + this.gem_inven[j]);
            }
            if (GUI.Button(Crypto.Rect2(416f, 0f, 64f, 64f), string.Empty, this.bt_back))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(1);
                }
                if (Crypto.Load_int_key("gamemode") == 0)
                {
                    Application.LoadLevel("Map");
                }
                else
                {
                    Application.LoadLevel("Extreme");
                }
            }
            if (this.tutorial == 3)
            {
                GUI.DrawTexture(Crypto.Rect2(247f, 102f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
            }
        }
        else
        {
            if (this.pop_upgrade <= 0)
            {
                GUI.DrawTexture(Crypto.Rect2(90f, (float) (this.icon_posY - 30), 64f, 32f), this.tab_1);
                GUI.DrawTexture(Crypto.Rect2(20f, (float) (this.icon_posY - 30), 64f, 32f), this.tab_2);
                GUI.DrawTexture(Crypto.Rect2((float) this.bg_posX_r, 242f, 480f, 100f), this.bg_black);
                if (this.subkind == 0)
                {
                    GUI.DrawTexture(Crypto.Rect2((float) this.bg_posX_r, 242f, 480f, 4f), this.fillbox_normal);
                }
                else
                {
                    GUI.DrawTexture(Crypto.Rect2((float) this.bg_posX_r, 242f, 480f, 4f), this.fillbox_unique);
                }
                if (GUI.Button(Crypto.Rect2(20f, (float) (this.icon_posY - 30), 64f, 32f), string.Empty, this.bt_empty))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    this.subkind = 0;
                }
                else if (GUI.Button(Crypto.Rect2(90f, (float) (this.icon_posY - 30), 64f, 32f), string.Empty, this.bt_empty))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    this.subkind = 1;
                }
            }
            if (this.menu_kind == 1)
            {
                if (this.pop_upgrade == 1)
                {
                    GUI.DrawTexture(Crypto.Rect2(294f, 82f, 64f, 64f), this.bg_upgrade);
                    GUI.DrawTexture(Crypto.Rect2(230f, 78f, 192f, 72f), this.bg_black);
                    GUI.DrawTexture(Crypto.Rect2(294f, 82f, 64f, 64f), this.emptyslot);
                    if (this.selweapon_upgrade > 0)
                    {
                        GUI.Label(Crypto.Rect2(363f, 80f, 64f, 32f), string.Concat(new object[] { this.selweapon_upgrade, " / ", this.upgradelimit, "\r\n", Language.intxt[this.language, 0x180] }), "txt12_w");
                        if (GUI.Button(Crypto.Rect2(378f, 110f, 32f, 32f), string.Empty, this.bt_init))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            this.confirm = 11;
                        }
                    }
                    if (!this.maxupgrade)
                    {
                        GUI.Label(Crypto.Rect2(197f, 164f, 256f, 14f), Language.intxt[this.language, 0x1d], "txt12_0");
                        GUI.DrawTexture(Crypto.Rect2(197f, 232f, 256f, 64f), this.pop_blank);
                        for (int k = 0; k < 5; k++)
                        {
                            if (this.gem_inven[k] > 0)
                            {
                                GUI.color = Color.white;
                                if (GUI.Button(Crypto.Rect2((float) (0xd8 + (k * 0x2e)), 240f, 32f, 32f), string.Empty, this.sub_menu))
                                {
                                    if (this.sound_UI != null)
                                    {
                                        this.script_soundUI.SoundOn(0);
                                    }
                                    if ((this.tutorial == 3) && (k != 0))
                                    {
                                        this.Delay(1f);
                                        this.confirm = 8;
                                        return;
                                    }
                                    this.cur_iconpos2 = new Vector2((float) (0xd8 + (k * 0x2e)), 230f);
                                    this.select_gem = k;
                                    this.Cost_upgrade();
                                    this.pop_upgrade = 2;
                                }
                            }
                            else
                            {
                                GUI.color = this.empty;
                            }
                            GUI.DrawTexture(Crypto.Rect2((float) (0xd8 + (k * 0x2e)), 240f, 32f, 32f), this.gem_tex[k]);
                            GUI.color = Color.white;
                            GUI.Box(Crypto.Rect2((float) (0xd8 + (k * 0x2e)), 270f, 32f, 16f), string.Empty + this.gem_inven[k]);
                        }
                    }
                    else
                    {
                        GUI.Label(Crypto.Rect2(197f, 164f, 256f, 14f), Language.intxt[this.language, 0x179], "txt12_0");
                    }
                    if (GUI.Button(Crypto.Rect2(378f, 198f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.HideCha(false);
                        this.pop_upgrade = 0;
                    }
                    GUI.DrawTexture(Crypto.Rect2(this.cur_iconpos.x, this.cur_iconpos.y, 64f, 64f), this.weaponicon[this.selweapon_meshkind]);
                }
                else if (this.pop_upgrade == 2)
                {
                    GUI.DrawTexture(Crypto.Rect2(294f, 82f, 64f, 64f), this.bg_upgrade);
                    GUI.DrawTexture(Crypto.Rect2(294f, 82f, 64f, 64f), this.weaponicon[this.selweapon_meshkind]);
                    GUI.DrawTexture(Crypto.Rect2(294f, 82f, 64f, 64f), this.emptyslot);
                    GUI.DrawTexture(Crypto.Rect2(340f, 158f, 16f, 16f), this.icon_coin);
                    GUI.DrawTexture(Crypto.Rect2(212f, 130f, 50f, 50f), this.bg_hammerhit);
                    GUI.Label(Crypto.Rect2(232f, 150f, 16f, 16f), string.Empty + ((this.select_gem + 4) - this.hitcount), "txt12_0");
                    GUI.Label(Crypto.Rect2(270f, 158f, 64f, 14f), Language.intxt[this.language, 0x3f], "txt12_0");
                    GUI.Label(Crypto.Rect2(340f, 158f, 64f, 14f), string.Empty + this.upgradecost, "txt12_0");
                    if (GUI.Button(Crypto.Rect2(308f, 198f, 64f, 32f), Language.intxt[this.language, 0xcd], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        if (this.coin >= this.upgradecost)
                        {
                            if (this.tutorial == 3)
                            {
                                Crypto.Save_int_key("tutorial", -1);
                            }
                            if (Crypto.Property_change(-this.upgradecost, false))
                            {
                                this.coin -= this.upgradecost;
                                this.gem_inven[this.select_gem]--;
                                PlayerPrefsX.SetIntArray("n39", this.gem_inven);
                                this.f_delay = 1f;
                                this.plusfactor = 0;
                                this.pop_upgrade = 3;
                                this.ef_hammer.gameObject.active = true;
                            }
                        }
                        else
                        {
                            this.confirm = 3;
                            this.Delay(1f);
                        }
                    }
                    else if (GUI.Button(Crypto.Rect2(378f, 198f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.pop_upgrade = 1;
                    }
                    GUI.DrawTexture(Crypto.Rect2(this.cur_iconpos2.x, this.cur_iconpos2.y, 32f, 32f), this.gem_tex[this.select_gem]);
                }
                else if (this.pop_upgrade == 3)
                {
                    this.plusfactor = (int) (this.hitgaugeX / 50f);
                    if (this.plusfactor != this.oldplusfactor)
                    {
                        UnityEngine.Object.Instantiate(this.pt_plus, new Vector3((-0.3f * this.plusfactor) + 0.1f, -0.22f, -0.4f), Quaternion.identity);
                        this.oldplusfactor = this.plusfactor;
                    }
                    GUI.DrawTexture(Crypto.Rect2(200f, 168f, 256f, 64f), this.bg_hitgauge);
                    GUI.DrawTexture(Crypto.Rect2(218f, 196f, this.hitgaugeX, 13f), this.gauge);
                    GUI.DrawTexture(Crypto.Rect2(212f, 130f, 50f, 50f), this.bg_hammerhit);
                    GUI.Label(Crypto.Rect2(232f, 150f, 16f, 16f), string.Empty + ((this.select_gem + 4) - this.hitcount), "txt12_0");
                    for (int m = 0; m < 4; m++)
                    {
                        if (this.hitgaugeX >= ((50 * m) + 50))
                        {
                            GUI.Label(Crypto.Rect2((float) ((50 * m) + 250), 163f, 40f, 40f), "+ " + ((this.weapon_plusup[this.selectweapon] + 1) + m), "txt12_w");
                        }
                        else
                        {
                            GUI.Label(Crypto.Rect2((float) ((50 * m) + 250), 163f, 40f, 40f), "+ " + ((this.weapon_plusup[this.selectweapon] + 1) + m), "txt12_0");
                        }
                    }
                }
                else if (this.pop_upgrade == 4)
                {
                    GUI.DrawTexture(Crypto.Rect2(294f, 82f, 64f, 64f), this.weaponicon[this.selweapon_meshkind]);
                    GUI.DrawTexture(Crypto.Rect2(200f, 168f, 256f, 64f), this.bg_hitgauge);
                    GUI.DrawTexture(Crypto.Rect2(218f, 196f, this.hitgaugeX, 13f), this.gauge);
                    if (this.f_delay == 0f)
                    {
                        this.pop_upgrade = 5;
                    }
                    for (int n = 0; n < 4; n++)
                    {
                        if (this.hitgaugeX >= ((50 * n) + 50))
                        {
                            GUI.Label(Crypto.Rect2((float) ((50 * n) + 250), 163f, 40f, 40f), "+ " + (((this.weapon_plusup[this.selectweapon] + 1) - this.plusfactor) + n), "txt12_w");
                        }
                        else
                        {
                            GUI.Label(Crypto.Rect2((float) ((50 * n) + 250), 163f, 40f, 40f), "+ " + (((this.weapon_plusup[this.selectweapon] + 1) - this.plusfactor) + n), "txt12_0");
                        }
                    }
                }
                else if (this.pop_upgrade == 5)
                {
                    GUI.DrawTexture(Crypto.Rect2(294f, 82f, 64f, 64f), this.weaponicon[this.selweapon_meshkind]);
                    GUI.DrawTexture(Crypto.Rect2(222f, 187f, 200f, 16f), this.titlebase);
                    GUI.DrawTexture(Crypto.Rect2(340f, 187f, 16f, 16f), this.stat_arrow);
                    GUI.DrawTexture(Crypto.Rect2(276f, 150f, 98f, 20f), this.bg_black);
                    if (this.weapon_plusup[this.selectweapon] > 0)
                    {
                        GUI.Label(Crypto.Rect2(276f, 150f, 98f, 20f), this.script_name.txt_cos[this.language, this.selweapon_name] + " + " + this.weapon_plusup[this.selectweapon], "txt12_w");
                    }
                    else
                    {
                        GUI.Label(Crypto.Rect2(276f, 150f, 98f, 20f), this.script_name.txt_cos[this.language, this.selweapon_name], "txt12_w");
                    }
                    GUI.Label(Crypto.Rect2(224f, 188f, 64f, 14f), Language.intxt[this.language, 0x8d], "txt12_w");
                    GUI.Label(Crypto.Rect2(244f, 188f, 128f, 14f), (this.selweapon_minatk - this.plusfactor) + " - " + (this.selweapon_maxatk - this.plusfactor), "txt12_w");
                    GUI.Label(Crypto.Rect2(324f, 188f, 128f, 14f), this.selweapon_minatk + " - " + this.selweapon_maxatk, "txt12_w");
                    if (GUI.Button(Crypto.Rect2(378f, 144f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        this.HideCha(false);
                        this.pop_upgrade = 0;
                        this.ef_result.gameObject.active = false;
                        this.ef_hammer.gameObject.active = false;
                        if (this.tutorial == 3)
                        {
                            this.tutorial = -1;
                            this.Delay(1f);
                            this.confirm = 9;
                        }
                    }
                }
                else
                {
                    GUI.DrawTexture(Crypto.Rect2(256f, 69f, 146f, 16f), this.titlebase);
                    if (this.weapon_plusup[this.selectweapon] > 0)
                    {
                        GUI.Label(Crypto.Rect2(266f, 70f, 128f, 14f), this.script_name.txt_cos[this.language, this.selweapon_name] + " + " + this.weapon_plusup[this.selectweapon], "txt12_w");
                    }
                    else
                    {
                        GUI.Label(Crypto.Rect2(266f, 70f, 128f, 14f), this.script_name.txt_cos[this.language, this.selweapon_name], "txt12_w");
                    }
                    GUI.DrawTexture(Crypto.Rect2(410f, 64f, 26f, 26f), this.weapon_kindicon[this.selweapon_kind]);
                    if (GUI.Button(Crypto.Rect2(378f, 198f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.selectweapon = -1;
                        this.script_weapon.SetWeapon(this.oldweapon_meshkind, this.oldweapon_kind);
                        this.selectweapon = this.cur_weapon;
                        this.menu_kind = 0;
                        this.subkind = 0;
                        this.HideCha(true);
                    }
                    if (this.selweapon_upgrade < this.upgradelimit)
                    {
                        if (GUI.Button(Crypto.Rect2(306f, 88f, 128f, 32f), Language.intxt[this.language, 0xcd], this.bt_upgrade))
                        {
                            if ((this.subkind > 0) && (this.unlock_weapon[this.selectweapon] == 0))
                            {
                                return;
                            }
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            this.maxupgrade = false;
                            if (this.tutorial == 3)
                            {
                                if (this.cur_weapon != 0)
                                {
                                    this.confirm = 8;
                                    this.Delay(1f);
                                }
                                else
                                {
                                    this.cur_iconpos = (Vector2.right * ((this.selectweapon * 0x4c) + 0x12)) + (Vector2.up * (this.icon_posY + 8));
                                    this.hitgaugeX = 0f;
                                    this.targetgaugeX = 0f;
                                    this.pop_upgrade = 1;
                                    this.HideCha(true);
                                }
                            }
                            else
                            {
                                int selectweapon = this.selectweapon;
                                if (selectweapon >= 6)
                                {
                                    selectweapon -= 6;
                                }
                                this.cur_iconpos = ((Vector2) (Vector2.right * (((selectweapon * 0x4c) + 0x12) + this.dragposX))) + (Vector2.up * (this.icon_posY + 8));
                                this.hitgaugeX = 0f;
                                this.targetgaugeX = 0f;
                                this.pop_upgrade = 1;
                                this.HideCha(true);
                            }
                        }
                    }
                    else if (GUI.Button(Crypto.Rect2(306f, 88f, 128f, 32f), "MAX", this.bt_upgrade))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.maxupgrade = true;
                        this.cur_iconpos = (Vector2.right * ((this.selectweapon * 0x4c) + 0x12)) + (Vector2.up * (this.icon_posY + 8));
                        this.hitgaugeX = 0f;
                        this.targetgaugeX = 0f;
                        this.pop_upgrade = 1;
                        this.HideCha(true);
                    }
                    for (int num8 = 0; num8 < this.upgradelimit; num8++)
                    {
                        if (num8 < this.selweapon_upgrade)
                        {
                            GUI.DrawTexture(Crypto.Rect2((float) ((0x19c - (this.upgradelimit * 3)) + (num8 * 6)), 98f, 3f, 12f), this.upgrade_slot);
                        }
                        else
                        {
                            GUI.DrawTexture(Crypto.Rect2((float) ((0x19c - (this.upgradelimit * 3)) + (num8 * 6)), 98f, 3f, 12f), this.upgrade_emptyslot);
                        }
                    }
                    if (this.selectweapon >= 6)
                    {
                        for (int num9 = 0; num9 < 4; num9++)
                        {
                            GUI.DrawTexture(Crypto.Rect2(302f, (float) (120 + (num9 * 20)), 140f, 16f), this.titlebase_w);
                        }
                        GUI.Label(Crypto.Rect2(300f, 120f, 128f, 16f), string.Concat(new object[] { Language.intxt[this.language, 0x8d], "   ", this.selweapon_minatk, " - ", this.selweapon_maxatk }), "txt12_0");
                        GUI.Label(Crypto.Rect2(306f, 140f, 128f, 16f), Language.intxt[this.language, 0x99] + "   " + ((this.selweapon_spd * 100f)).ToString("F1"), "txt12_0");
                        GUI.Label(Crypto.Rect2(306f, 160f, 128f, 16f), this.script_name.txt_cos[this.language, 120], "txt12_b");
                        GUI.Label(Crypto.Rect2(306f, 180f, 128f, 16f), this.script_name.txt_cos[this.language, this.selweapon_special_txt], "txt12_b");
                        if (this.unlock_weapon[this.selectweapon - 6] == 0)
                        {
                            GUI.Box(Crypto.Rect2(214f, 190f, 64f, 20f), "    " + this.selweapon_cost);
                            GUI.DrawTexture(Crypto.Rect2(218f, 192f, 16f, 16f), this.icon_jade);
                            if (this.chalv >= this.reqLvFactor_weapon[this.selectweapon - 6])
                            {
                                if (GUI.Button(Crypto.Rect2(308f, 198f, 64f, 32f), Language.intxt[this.language, 6], this.bt_yesno))
                                {
                                    if (this.sound_UI != null)
                                    {
                                        this.script_soundUI.SoundOn(0);
                                    }
                                    if (this.selweapon_cost < 0x3e8)
                                    {
                                        if (this.jade >= this.selweapon_cost)
                                        {
                                            this.confirm = 10;
                                        }
                                        else
                                        {
                                            this.confirm = 2;
                                            this.Delay(1f);
                                        }
                                    }
                                    else if (this.coin >= this.selweapon_cost)
                                    {
                                        this.confirm = 10;
                                    }
                                    else
                                    {
                                        this.confirm = 3;
                                        this.Delay(1f);
                                    }
                                }
                            }
                            else
                            {
                                GUI.Label(Crypto.Rect2(308f, 198f, 64f, 32f), Language.intxt[this.language, 0x10a] + this.reqLvFactor_weapon[this.selectweapon - 6], "txt12_r");
                            }
                        }
                        else if ((this.cur_weapon != this.selectweapon) && GUI.Button(Crypto.Rect2(308f, 198f, 64f, 32f), Language.intxt[this.language, 10], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            Crypto.Save_int_key("n44", this.selectweapon);
                            Crypto.Save_int_key("n34", this.selweapon_meshkind + (this.selweapon_kind * 100));
                            Crypto.Save_int_key("n31", this.selweapon_maxatk);
                            Crypto.Save_int_key("n04", this.selweapon_minatk);
                            Crypto.Save_int_key("n35", (int) (this.selweapon_spd * 100f));
                            Crypto.Save_int_key("n38", (this.selweapon_grade * 10) + this.selweapon_special);
                            this.cur_weapon = this.selectweapon;
                            this.oldweapon_meshkind = this.selweapon_meshkind;
                            this.oldweapon_kind = this.selweapon_kind;
                        }
                    }
                    else
                    {
                        for (int num10 = 0; num10 < 3; num10++)
                        {
                            GUI.DrawTexture(Crypto.Rect2(302f, (float) (0x7c + (num10 * 20)), 140f, 16f), this.titlebase_w);
                        }
                        GUI.Label(Crypto.Rect2(300f, 124f, 128f, 16f), string.Concat(new object[] { Language.intxt[this.language, 0x8d], "   ", this.selweapon_minatk, " - ", this.selweapon_maxatk }), "txt12_0");
                        GUI.Label(Crypto.Rect2(306f, 144f, 128f, 16f), Language.intxt[this.language, 0x99] + "   " + ((this.selweapon_spd * 100f)).ToString("F1"), "txt12_0");
                        if (this.selweapon_grade > 1)
                        {
                            GUI.Label(Crypto.Rect2(306f, 164f, 128f, 16f), this.script_name.txt_cos[this.language, this.selweapon_special_txt], "txt12_b");
                        }
                        else
                        {
                            GUI.Label(Crypto.Rect2(306f, 164f, 128f, 16f), this.script_name.txt_cos[this.language, this.selweapon_special_txt], "txt12_0");
                        }
                        for (int num11 = 0; num11 < this.selweapon_grade; num11++)
                        {
                            GUI.DrawTexture(Crypto.Rect2((float) ((0xea - (this.selweapon_grade * 7)) + (num11 * 14)), 70f, 16f, 16f), this.star_grade);
                        }
                        if ((this.cur_weapon != this.selectweapon) && GUI.Button(Crypto.Rect2(308f, 198f, 64f, 32f), Language.intxt[this.language, 10], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            Crypto.Save_int_key("n44", this.selectweapon);
                            Crypto.Save_int_key("n34", this.selweapon_meshkind + (this.selweapon_kind * 100));
                            Crypto.Save_int_key("n31", this.selweapon_maxatk);
                            Crypto.Save_int_key("n04", this.selweapon_minatk);
                            Crypto.Save_int_key("n35", (int) (this.selweapon_spd * 100f));
                            int num12 = Mathf.Min(this.selweapon_grade, 3);
                            Crypto.Save_int_key("n38", (num12 * 10) + this.selweapon_special);
                            this.cur_weapon = this.selectweapon;
                            this.oldweapon_meshkind = this.selweapon_meshkind;
                            this.oldweapon_kind = this.selweapon_kind;
                        }
                        if (GUI.Button(Crypto.Rect2(260f, 198f, 32f, 32f), string.Empty, this.erase))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            if (this.tutorial == 3)
                            {
                                this.confirm = 8;
                                this.Delay(1f);
                            }
                            else if (this.selectweapon != this.cur_weapon)
                            {
                                this.confirm = 4;
                            }
                            else
                            {
                                this.confirm = 6;
                                this.Delay(1f);
                            }
                        }
                    }
                    if (this.subkind == 0)
                    {
                        for (int num13 = 0; num13 < 6; num13++)
                        {
                            if (GUI.Button(Crypto.Rect2((float) ((num13 * 0x4c) + 0x12), (float) (this.icon_posY + 8), 64f, 64f), string.Empty, this.bt_equip))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(0);
                                }
                                if (num13 >= this.slot_weapon)
                                {
                                    this.confirm = 7;
                                }
                                else if ((this.weapon_seed[num13] > 0) && (this.selectweapon != num13))
                                {
                                    this.selectweapon = num13;
                                    this.SetUpWeapon(this.weapon_seed[this.selectweapon]);
                                    this.script_weapon.SetWeapon(this.selweapon_meshkind, this.selweapon_kind);
                                }
                            }
                            if (num13 == this.cur_weapon)
                            {
                                GUI.DrawTexture(Crypto.Rect2((float) ((num13 * 0x4c) + 0x12), (float) (this.icon_posY + 8), 64f, 64f), this.c_equip);
                            }
                            if (this.weapon_seed[num13] > 0)
                            {
                                GUI.DrawTexture(Crypto.Rect2((float) ((num13 * 0x4c) + 0x12), (float) (this.icon_posY + 8), 64f, 64f), this.weaponicon[this.bottom_weaponicon[num13]]);
                                for (int num14 = 0; num14 < this.weapon_grade[num13]; num14++)
                                {
                                    GUI.DrawTexture(Crypto.Rect2((float) ((((num13 * 0x4c) + 0x31) - (this.weapon_grade[num13] * 5)) + (num14 * 10)), (float) (this.icon_posY + 10), 12f, 12f), this.star_grade);
                                }
                                GUI.Box(Crypto.Rect2((float) ((num13 * 0x4c) + 0x1c), (float) (this.icon_posY + 0x3a), 44f, 18f), "+ " + this.weapon_plusup[num13]);
                            }
                            else if (num13 >= this.slot_weapon)
                            {
                                GUI.DrawTexture(Crypto.Rect2((float) ((num13 * 0x4c) + 0x12), (float) (this.icon_posY + 8), 64f, 64f), this.icon_lock);
                            }
                        }
                    }
                    else if (this.subkind > 0)
                    {
                        for (int num15 = 0; num15 < 10; num15++)
                        {
                            if (GUI.Button(Crypto.Rect2(((num15 * 0x4c) + 0x12) + this.dragposX, (float) (this.icon_posY + 8), 64f, 64f), string.Empty, this.bt_equip))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(0);
                                }
                                if ((this.selectweapon != (num15 + 6)) && !this.scrollOn)
                                {
                                    this.selectweapon = num15 + 6;
                                    this.SetUpWeapon(this.weapon_seed[this.selectweapon]);
                                    this.script_weapon.SetWeapon(this.selweapon_meshkind, this.selweapon_kind);
                                }
                            }
                            if ((num15 + 6) == this.cur_weapon)
                            {
                                GUI.DrawTexture(Crypto.Rect2(((num15 * 0x4c) + 0x12) + this.dragposX, (float) (this.icon_posY + 8), 64f, 64f), this.c_equip);
                            }
                            GUI.DrawTexture(Crypto.Rect2(((num15 * 0x4c) + 0x12) + this.dragposX, (float) (this.icon_posY + 8), 64f, 64f), this.weaponicon[num15 + 0x10]);
                            if (this.unlock_weapon[num15] == 0)
                            {
                                GUI.DrawTexture(Crypto.Rect2(((num15 * 0x4c) + 0x12) + this.dragposX, (float) (this.icon_posY + 8), 64f, 64f), this.icon_lock);
                            }
                        }
                    }
                }
                if (this.tutorial == 3)
                {
                    if (this.cur_weapon == 0)
                    {
                        if (this.selectweapon != 0)
                        {
                            if (this.subkind != 0)
                            {
                                GUI.DrawTexture(Crypto.Rect2(22f, (float) (this.icon_posY - 50), (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                            }
                            else
                            {
                                GUI.DrawTexture(Crypto.Rect2(22f, (float) (this.icon_posY + 10), (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                            }
                        }
                        else if (this.pop_upgrade == 5)
                        {
                            GUI.DrawTexture(Crypto.Rect2(382f, 126f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                        }
                        else if (this.pop_upgrade == 2)
                        {
                            GUI.DrawTexture(Crypto.Rect2(312f, 164f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                        }
                        else if (this.pop_upgrade == 1)
                        {
                            GUI.DrawTexture(Crypto.Rect2(204f, 214f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                        }
                        else if (this.pop_upgrade == 0)
                        {
                            GUI.DrawTexture(Crypto.Rect2(330f, 76f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                        }
                    }
                    else if (this.subkind != 0)
                    {
                        GUI.DrawTexture(Crypto.Rect2(22f, (float) (this.icon_posY - 50), (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                    }
                    else if (this.selectweapon != 0)
                    {
                        GUI.DrawTexture(Crypto.Rect2(22f, (float) (this.icon_posY + 10), (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                    }
                    else if (this.cur_weapon != 0)
                    {
                        GUI.DrawTexture(Crypto.Rect2(312f, 166f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                    }
                    else
                    {
                        GUI.DrawTexture(Crypto.Rect2(22f, (float) (this.icon_posY + 10), (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                    }
                }
            }
            else if (this.menu_kind == 2)
            {
                GUI.DrawTexture(Crypto.Rect2(256f, 69f, 146f, 16f), this.titlebase);
                GUI.Label(Crypto.Rect2(266f, 70f, 128f, 14f), string.Empty + this.script_name.txt_cos[this.language, this.selequip_index + 1], "txt12_w");
                if (GUI.Button(Crypto.Rect2(378f, 198f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.selectequip = this.cur_equip;
                    this.SetUpArmor(this.costume_seed[this.selectequip]);
                    this.script_costume.Costume(this.selequip_index);
                    this.menu_kind = 0;
                    this.subkind = 0;
                    this.HideCha(true);
                }
                if (this.selectequip >= 6)
                {
                    for (int num16 = 0; num16 < 3; num16++)
                    {
                        GUI.DrawTexture(Crypto.Rect2(302f, (float) (0x68 + (num16 * 20)), 140f, 16f), this.titlebase_w);
                    }
                    GUI.Label(Crypto.Rect2(292f, 80f, 150f, 64f), Language.intxt[this.language, 0x8e] + " + " + this.selequip_hp, "txt12_0");
                    GUI.Label(Crypto.Rect2(292f, 100f, 150f, 64f), string.Empty + this.script_name.txt_cos[this.language, 0x23], "txt12_b");
                    GUI.Label(Crypto.Rect2(292f, 120f, 150f, 64f), string.Empty + this.script_name.txt_cos[this.language, this.selequip_special + 0x15], "txt12_b");
                    if (this.unlock_costume[this.selectequip - 6] > 0)
                    {
                        if ((this.cur_equip != this.selectequip) && GUI.Button(Crypto.Rect2(308f, 198f, 64f, 32f), Language.intxt[this.language, 10], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            Crypto.Save_int_key("n05", this.selectequip);
                            Crypto.Save_int_key("n43", this.selequip_index);
                            this.cur_equip = this.selectequip;
                        }
                    }
                    else
                    {
                        GUI.Box(Crypto.Rect2(214f, 190f, 64f, 20f), "    " + this.selequip_cost);
                        GUI.DrawTexture(Crypto.Rect2(218f, 192f, 16f, 16f), this.icon_jade);
                        if (this.chalv >= this.reqLvFactor_equip[this.selectequip - 6])
                        {
                            if (GUI.Button(Crypto.Rect2(308f, 198f, 64f, 32f), Language.intxt[this.language, 6], this.bt_yesno))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(0);
                                }
                                if (this.jade >= this.selequip_cost)
                                {
                                    this.confirm = 1;
                                }
                                else
                                {
                                    this.confirm = 2;
                                    this.Delay(1f);
                                }
                            }
                        }
                        else
                        {
                            GUI.Label(Crypto.Rect2(308f, 198f, 64f, 32f), Language.intxt[this.language, 0x10a] + this.reqLvFactor_equip[this.selectequip - 6], "txt12_r");
                        }
                    }
                }
                else
                {
                    for (int num17 = 0; num17 < 2; num17++)
                    {
                        GUI.DrawTexture(Crypto.Rect2(302f, (float) (0x68 + (num17 * 20)), 140f, 16f), this.titlebase_w);
                    }
                    GUI.Label(Crypto.Rect2(292f, 80f, 150f, 64f), Language.intxt[this.language, 0x8e] + " + " + this.selequip_hp, "txt12_0");
                    if (this.selequip_special == 0)
                    {
                        GUI.Label(Crypto.Rect2(292f, 100f, 150f, 64f), string.Empty + this.script_name.txt_cos[this.language, this.selequip_special + 0x15], "txt12_0");
                    }
                    else
                    {
                        GUI.Label(Crypto.Rect2(292f, 100f, 150f, 64f), string.Empty + this.script_name.txt_cos[this.language, this.selequip_special + 0x15], "txt12_b");
                    }
                    if ((this.cur_equip != this.selectequip) && GUI.Button(Crypto.Rect2(308f, 198f, 64f, 32f), Language.intxt[this.language, 10], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        Crypto.Save_int_key("n05", this.selectequip);
                        Crypto.Save_int_key("n43", this.selequip_index);
                        this.cur_equip = this.selectequip;
                    }
                    if (GUI.Button(Crypto.Rect2(260f, 198f, 32f, 32f), string.Empty, this.erase))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        if (this.selectequip != this.cur_equip)
                        {
                            this.confirm = 12;
                        }
                        else
                        {
                            this.confirm = 6;
                            this.Delay(1f);
                        }
                    }
                }
                if (this.subkind == 0)
                {
                    for (int num18 = 0; num18 < 6; num18++)
                    {
                        if (GUI.Button(Crypto.Rect2((float) ((num18 * 0x4c) + 0x12), (float) (this.icon_posY + 8), 64f, 64f), string.Empty, this.bt_equip))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            if (num18 >= this.slot_costume)
                            {
                                this.confirm = 7;
                            }
                            else if (((this.costume_seed[num18] > 0) && (this.selectequip != num18)) && !this.scrollOn)
                            {
                                this.selectequip = num18;
                                this.SetUpArmor(this.costume_seed[this.selectequip]);
                                this.script_costume.Costume(this.selequip_index);
                            }
                        }
                        if (this.costume_seed[num18] > 0)
                        {
                            if (num18 == this.cur_equip)
                            {
                                GUI.DrawTexture(Crypto.Rect2((float) ((num18 * 0x4c) + 0x12), (float) (this.icon_posY + 8), 64f, 64f), this.c_equip);
                            }
                            GUI.DrawTexture(Crypto.Rect2((float) ((num18 * 0x4c) + 0x12), (float) (this.icon_posY + 8), 64f, 64f), this.equipicon[this.bottom_equipicon[num18]]);
                        }
                        else if (num18 >= this.slot_costume)
                        {
                            GUI.DrawTexture(Crypto.Rect2((float) ((num18 * 0x4c) + 0x12), (float) (this.icon_posY + 8), 64f, 64f), this.icon_lock);
                        }
                    }
                }
                else if (this.subkind > 0)
                {
                    for (int num19 = 0; num19 < 10; num19++)
                    {
                        if (GUI.Button(Crypto.Rect2(((num19 * 0x4c) + 0x12) + this.dragposX, (float) (this.icon_posY + 8), 64f, 64f), string.Empty, this.bt_equip))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            if ((this.selectequip != (num19 + 6)) && !this.scrollOn)
                            {
                                this.selectequip = num19 + 6;
                                this.SetUpArmor(this.costume_seed[this.selectequip]);
                                this.script_costume.Costume(this.selequip_index);
                            }
                        }
                        if ((num19 + 6) == this.cur_equip)
                        {
                            GUI.DrawTexture(Crypto.Rect2(((num19 * 0x4c) + 0x12) + this.dragposX, (float) (this.icon_posY + 8), 64f, 64f), this.c_equip);
                        }
                        GUI.DrawTexture(Crypto.Rect2(((num19 * 0x4c) + 0x12) + this.dragposX, (float) (this.icon_posY + 8), 64f, 64f), this.equipicon[num19 + 7]);
                        if (this.unlock_costume[num19] == 0)
                        {
                            GUI.DrawTexture(Crypto.Rect2(((num19 * 0x4c) + 0x12) + this.dragposX, (float) (this.icon_posY + 8), 64f, 64f), this.icon_lock);
                        }
                    }
                }
            }
        }
        if (this.confirm > 0)
        {
            GUI.enabled = true;
            if (this.confirm == 1)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                GUI.Label(Crypto.Rect2(112f, 120f, 256f, 14f), Language.intxt[this.language, 310], "txt12_0");
                GUI.DrawTexture(Crypto.Rect2(200f, 148f, 16f, 16f), this.icon_jade);
                GUI.Label(Crypto.Rect2(224f, 148f, 48f, 16f), string.Empty + this.selequip_cost, "txt12_b");
                if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                {
                    if (Crypto.Property_change(-this.selequip_cost, true))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        this.unlock_costume[this.selectequip - 6] = 1;
                        this.jade -= this.selequip_cost;
                        PlayerPrefsX.SetIntArray("n18", this.unlock_costume);
                        PurchaseLog.LogOn(string.Concat(new object[] { Language.intxt[this.language, 0xea], " (", this.selequip_cost, ")\t", this.script_name.txt_cos[this.language, this.selequip_index + 1] }));
                    }
                    this.confirm = 0;
                }
                else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 2)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                GUI.Label(Crypto.Rect2(120f, 130f, 230f, 16f), Language.intxt[this.language, 0x15], "txt12_0");
                if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    Crypto.Save_int_key("cashshopkind", 1);
                    this.confirm = 0;
                    if (this.cashshop == null)
                    {
                        this.cashshop = Resources.Load("CashShop") as GameObject;
                    }
                    UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
                }
                else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 3)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                GUI.Label(Crypto.Rect2(120f, 130f, 240f, 16f), Language.intxt[this.language, 0x16], "txt12_0");
                if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    Crypto.Save_int_key("cashshopkind", 2);
                    this.confirm = 0;
                    if (this.cashshop == null)
                    {
                        this.cashshop = Resources.Load("CashShop") as GameObject;
                    }
                    UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
                }
                else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 4)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                GUI.Label(Crypto.Rect2(112f, 120f, 256f, 14f), Language.intxt[this.language, 12], "txt12_0");
                GUI.DrawTexture(Crypto.Rect2(200f, 148f, 16f, 16f), this.icon_coin);
                GUI.Label(Crypto.Rect2(224f, 148f, 48f, 16f), string.Empty + ((this.selweapon_index + (this.selweapon_grade * 0.1f)) * 10f), "txt12_b");
                if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    this.confirm = 0;
                    Crypto.Property_change((int) ((this.selweapon_index + (this.selweapon_grade * 0.1f)) * 10f), false);
                    this.coin += (int) ((this.selweapon_index + (this.selweapon_grade * 0.1f)) * 10f);
                    this.weapon_seed[this.selectweapon] = 0;
                    this.weapon_plusup[this.selectweapon] = 0;
                    PlayerPrefsX.SetIntArray("n41", this.weapon_seed);
                    PlayerPrefsX.SetIntArray("n19", this.weapon_plusup);
                    this.script_weapon.SetWeapon(this.oldweapon_meshkind, this.oldweapon_kind);
                    this.selectweapon = this.cur_weapon;
                    this.SetUpWeapon(this.weapon_seed[this.selectweapon]);
                }
                else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 5)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                GUI.Label(Crypto.Rect2(112f, 110f, 256f, 64f), Language.intxt[this.language, 0x10b], "txt12_0");
                if (this.f_delay == 0f)
                {
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 6)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                GUI.Label(Crypto.Rect2(112f, 110f, 256f, 64f), Language.intxt[this.language, 0xce], "txt12_0");
                if (this.f_delay == 0f)
                {
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 7)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                GUI.DrawTexture(Crypto.Rect2(160f, 98f, 160f, 18f), this.titlebase);
                GUI.Label(Crypto.Rect2(120f, 120f, 230f, 16f), Language.intxt[this.language, 300], "txt12_0");
                GUI.DrawTexture(Crypto.Rect2(186f, 134f, 32f, 32f), this.icon_unlock);
                GUI.DrawTexture(Crypto.Rect2(244f, 142f, 16f, 16f), this.icon_jade);
                GUI.Label(Crypto.Rect2(264f, 142f, 16f, 16f), "3", "txt12_b");
                GUI.Label(Crypto.Rect2(112f, 162f, 256f, 16f), Language.intxt[this.language, 350], "txt12_b");
                if (this.menu_kind == 1)
                {
                    GUI.Label(Crypto.Rect2(120f, 98f, 230f, 16f), Language.intxt[this.language, 0xeb] + " +1", "txt12_w");
                }
                else
                {
                    GUI.Label(Crypto.Rect2(120f, 98f, 230f, 16f), Language.intxt[this.language, 0xc6] + " +1", "txt12_w");
                }
                if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    this.confirm = 0;
                    if (this.jade >= 3)
                    {
                        if (Crypto.Property_change(-3, true))
                        {
                            this.jade -= 3;
                            if (this.menu_kind == 1)
                            {
                                this.slot_weapon = Mathf.Min(6, this.slot_weapon + 1);
                                Crypto.Save_int_key("n03", this.slot_weapon);
                                PurchaseLog.LogOn(Language.intxt[this.language, 0xea] + " (3)\t" + Language.intxt[this.language, 0xeb]);
                            }
                            else
                            {
                                this.slot_costume = Mathf.Min(6, this.slot_costume + 1);
                                Crypto.Save_int_key("n42", this.slot_costume);
                                PurchaseLog.LogOn(Language.intxt[this.language, 0xea] + " (3)\t" + Language.intxt[this.language, 0xc6]);
                            }
                        }
                    }
                    else
                    {
                        this.confirm = 2;
                    }
                }
                else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 8)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                GUI.Label(Crypto.Rect2(112f, 110f, 256f, 64f), Language.intxt[this.language, 0x62], "txt12_0");
                if (this.f_delay == 0f)
                {
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 9)
            {
                GUI.Box(Crypto.Rect2(112f, 140f, 256f, 32f), Language.intxt[this.language, 0x102]);
                if (this.f_delay == 0f)
                {
                    this.confirm = 0;
                }
            }
            if (this.confirm == 10)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                GUI.Label(Crypto.Rect2(112f, 120f, 256f, 14f), Language.intxt[this.language, 310], "txt12_0");
                GUI.DrawTexture(Crypto.Rect2(200f, 148f, 16f, 16f), this.icon_jade);
                GUI.Label(Crypto.Rect2(224f, 148f, 48f, 16f), string.Empty + this.selweapon_cost, "txt12_b");
                if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                {
                    if (this.selweapon_cost < 0x3e8)
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        this.confirm = 0;
                        if (Crypto.Property_change(-this.selweapon_cost, true))
                        {
                            this.unlock_weapon[this.selectweapon - 6] = 1;
                            this.jade -= this.selweapon_cost;
                            PurchaseLog.LogOn(string.Concat(new object[] { Language.intxt[this.language, 0xea], " (", this.selweapon_cost, ")\t", this.script_name.txt_cos[this.language, this.selweapon_name] }));
                        }
                        this.confirm = 0;
                    }
                    else
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        this.confirm = 0;
                        if (Crypto.Property_change(-this.selectweapon, false))
                        {
                            this.unlock_weapon[this.selectweapon - 6] = 1;
                            this.coin -= this.selweapon_cost;
                        }
                    }
                    PlayerPrefsX.SetIntArray("n40", this.unlock_weapon);
                }
                else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 11)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                GUI.Label(Crypto.Rect2(125f, 100f, 230f, 16f), Language.intxt[this.language, 0x181], "txt12_0");
                GUI.Label(Crypto.Rect2(125f, 120f, 230f, 22f), Language.intxt[this.language, 0x182], "txt12_r");
                GUI.DrawTexture(Crypto.Rect2(200f, 146f, 16f, 16f), this.icon_jade);
                GUI.Label(Crypto.Rect2(224f, 146f, 48f, 16f), string.Empty + 10, "txt12_b");
                GUI.Label(Crypto.Rect2(125f, 164f, 230f, 16f), Language.intxt[this.language, 350], "txt12_b");
                if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                {
                    if (this.jade >= 10)
                    {
                        if (Crypto.Property_change(-10, true))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            this.jade -= 10;
                            this.weapon_seed[this.selectweapon] -= this.selweapon_upgrade * 0x186a0;
                            this.weapon_plusup[this.selectweapon] = 0;
                            this.selweapon_upgrade = 0;
                            PlayerPrefsX.SetIntArray("n41", this.weapon_seed);
                            PlayerPrefsX.SetIntArray("n19", this.weapon_plusup);
                            this.SetUpWeapon(this.weapon_seed[this.selectweapon]);
                            if (this.selectweapon == this.cur_weapon)
                            {
                                Crypto.Save_int_key("n31", this.selweapon_maxatk);
                                Crypto.Save_int_key("n04", this.selweapon_minatk);
                            }
                            this.maxupgrade = false;
                            PurchaseLog.LogOn(Language.intxt[this.language, 0xea] + " (10)\t" + Language.intxt[this.language, 0x180]);
                        }
                        this.confirm = 0;
                    }
                    else
                    {
                        this.confirm = 2;
                    }
                }
                else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    this.confirm = 0;
                }
            }
            else if (this.confirm == 12)
            {
                GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                GUI.Label(Crypto.Rect2(112f, 120f, 256f, 14f), Language.intxt[this.language, 12], "txt12_0");
                GUI.DrawTexture(Crypto.Rect2(200f, 148f, 16f, 16f), this.icon_coin);
                GUI.Label(Crypto.Rect2(224f, 148f, 48f, 16f), string.Empty + (this.selequip_hp * 5), "txt12_b");
                if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    this.confirm = 0;
                    Crypto.Property_change(this.selequip_hp * 5, false);
                    this.coin += this.selequip_hp * 5;
                    this.costume_seed[this.selectequip] = 0;
                    PlayerPrefsX.SetIntArray("n45", this.costume_seed);
                    this.selectequip = this.cur_equip;
                    this.SetUpArmor(this.costume_seed[this.cur_equip]);
                    this.script_costume.Costume(this.selequip_index);
                }
                else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.confirm = 0;
                }
            }
        }
    }

    public void SetUpArmor(int _index)
    {
        this.selequip_index = _index % 100;
        this.selequip_cost = this.cost_armor[this.selectequip];
        _index /= 100;
        int[] numArray = new int[2];
        for (int i = 0; i < 2; i++)
        {
            numArray[i] = _index % 10;
            _index /= 10;
        }
        this.selequip_special = numArray[1];
        this.selequip_hp = _index;
    }

    public void SetUpWeapon(int _index)
    {
        this.script_weaponstat.SetStat(_index);
        this.selweapon_index = this.script_weaponstat.weapon_index;
        this.selweapon_cost = this.script_weaponstat.weapon_cost;
        this.selweapon_meshkind = this.script_weaponstat.weapon_meshkind;
        this.selweapon_kind = this.script_weaponstat.weapon_kind;
        this.selweapon_grade = this.script_weaponstat.weapon_grade;
        this.selweapon_name = this.script_weaponstat.weapon_name;
        this.selweapon_maxatk = this.script_weaponstat.weapon_maxatk + this.weapon_plusup[this.selectweapon];
        this.selweapon_minatk = this.script_weaponstat.weapon_minatk + this.weapon_plusup[this.selectweapon];
        this.selweapon_spd = this.script_weaponstat.weapon_spd;
        this.selweapon_special = this.script_weaponstat.weapon_special;
        this.selweapon_special_txt = this.script_weaponstat.weapon_special_txt;
        this.selweapon_upgrade = this.script_weaponstat.weapon_upgrade;
        this.upgradelimit = Mathf.Min(this.selweapon_grade + 2, 6);
    }

    private void Start()
    {
        this.tutorial = Crypto.Load_int_key("tutorial");
        if (this.tutorial == 3)
        {
            base.InvokeRepeating("Warning_iconsize", 0.1f, 0.34f);
        }
        this.selectequip = this.cur_equip = Crypto.Load_int_key("n05");
        this.selectweapon = this.cur_weapon = Crypto.Load_int_key("n44");
        this.SetUpWeapon(this.weapon_seed[this.selectweapon]);
        this.SetUpArmor(this.costume_seed[this.cur_equip]);
        this.oldweapon_meshkind = this.selweapon_meshkind;
        this.oldweapon_kind = this.selweapon_kind;
        this.script_weapon.SetWeapon(this.selweapon_meshkind, this.selweapon_kind);
        this.dragrange = Screen.height * 0.375f;
        this.bg_posX_l = -380;
        this.bg_posX_r = 480;
        this.icon_posY = 320;
        this.cha1.animation.Play("costume");
        if (GameObject.FindWithTag("sound") == null)
        {
            this.sound_UI = (Transform) UnityEngine.Object.Instantiate(this.sound_dummy, Vector3.zero, Quaternion.identity);
        }
        else
        {
            this.sound_UI = GameObject.FindWithTag("sound").transform;
        }
        if (this.sound_UI != null)
        {
            this.script_soundUI = this.sound_UI.GetComponent<SoundEf_UI>();
        }
        for (int i = 0; i < this.slot_weapon; i++)
        {
            this.bottom_weaponicon[i] = this.script_weaponstat.IconImage_Only(this.weapon_seed[i]);
            this.weapon_grade[i] = (short) ((this.weapon_seed[i] % 0x186a0) / 0x2710);
        }
        for (int j = 0; j < this.slot_costume; j++)
        {
            this.bottom_equipicon[j] = this.costume_seed[j] % 100;
        }
        this.bg_cha1.localScale = Vector3.zero;
    }

    private void Update()
    {
        if (!this.imagemovefinish)
        {
            if (this.bg_posX_l < -64)
            {
                this.bg_posX_l += (int) Mathf.Min((float) -this.bg_posX_l, Time.deltaTime * 600f);
            }
            else
            {
                this.bg_posX_l = -64;
                this.bg_posX_r -= (int) Mathf.Min((float) this.bg_posX_r, Time.deltaTime * 1500f);
                if (this.bg_posX_r <= 0)
                {
                    this.bg_posX_r = 0;
                    this.icon_posY -= (int) Mathf.Min((float) this.icon_posY, Time.deltaTime * 500f);
                    if (this.icon_posY <= 240)
                    {
                        this.icon_posY = 240;
                        this.imagemovefinish = true;
                    }
                }
            }
        }
        if (Input.GetMouseButtonDown(0))
        {
            if (Input.mousePosition.y < this.dragrange)
            {
                this.dragOn = true;
                this.prevposX = Input.mousePosition.x;
                this.currentX = this.dragposX;
            }
        }
        else if (Input.GetMouseButtonUp(0))
        {
            this.dragOn = false;
            this.scrollOn = false;
        }
        if (this.dragOn)
        {
            if (Mathf.Abs((float) (Input.mousePosition.x - this.prevposX)) > 8f)
            {
                this.scrollOn = true;
            }
            this.dragposX = ((Input.mousePosition.x - this.prevposX) * (480f / ((float) Screen.width))) + this.currentX;
            this.dragposX = Mathf.Min(this.dragposX, 0f);
            this.dragposX = Mathf.Max(this.dragposX, -300f);
        }
        if (this.b_delay)
        {
            this.f_delay -= Time.deltaTime;
            if (this.f_delay <= 0f)
            {
                this.b_delay = false;
                this.f_delay = 0f;
            }
        }
        if (this.pop_upgrade == 1)
        {
            this.cur_iconpos = Vector2.MoveTowards(this.cur_iconpos, this.targetpos, Time.deltaTime * 1000f);
        }
        else if (this.pop_upgrade == 2)
        {
            this.cur_iconpos2 = Vector2.MoveTowards(this.cur_iconpos2, this.targetpos2, Time.deltaTime * 600f);
        }
        else if (this.pop_upgrade == 3)
        {
            if (this.f_delay < 0f)
            {
                if (this.hitcount < (this.select_gem + 4))
                {
                    this.script_hammer.HammerHit();
                    this.hitcount++;
                    this.f_delay = 1.2f;
                }
                else
                {
                    this.ef_result.gameObject.active = true;
                    this.ef_result.localScale = Vector3.zero;
                    this.pop_upgrade = 4;
                    this.hitcount = 0;
                    this.f_delay = 0f;
                    this.Delay(1f);
                    this.weapon_plusup[this.selectweapon] += this.plusfactor;
                    this.weapon_seed[this.selectweapon] += 0x186a0;
                    this.SetUpWeapon(this.weapon_seed[this.selectweapon]);
                    PlayerPrefsX.SetIntArray("n19", this.weapon_plusup);
                    PlayerPrefsX.SetIntArray("n41", this.weapon_seed);
                    if (this.selectweapon == this.cur_weapon)
                    {
                        Crypto.Save_int_key("n31", this.selweapon_maxatk);
                        Crypto.Save_int_key("n04", this.selweapon_minatk);
                    }
                }
            }
            else
            {
                this.f_delay -= Time.deltaTime;
            }
            this.hitgaugeX = Mathf.Lerp(this.hitgaugeX, this.targetgaugeX, Time.deltaTime * 6f);
        }
        else if (this.pop_upgrade >= 4)
        {
            this.ef_result.localScale = Vector3.MoveTowards(this.ef_result.localScale, (Vector3) (Vector3.one * 2.1f), Time.deltaTime * 15f);
        }
        if (this.menu_kind == 1)
        {
            this.cha1.rotation = Quaternion.Lerp(this.cha1.rotation, Quaternion.LookRotation(-Vector3.forward), Time.deltaTime * 4f);
        }
        else
        {
            this.cha1.rotation = Quaternion.Lerp(this.cha1.rotation, Quaternion.LookRotation(Vector3.forward), Time.deltaTime * 4f);
        }
    }

    public void Warning_iconsize()
    {
        this.icon_size = (this.icon_size + 1) % 2;
    }
}


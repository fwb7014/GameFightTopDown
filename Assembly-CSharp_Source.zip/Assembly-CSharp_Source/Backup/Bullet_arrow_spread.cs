using System;
using UnityEngine;

public class Bullet_arrow_spread : MonoBehaviour
{
    private Quaternion a;
    private Quaternion b;
    public float bullet_speed;
    private int damage;
    private Transform mytransform;
    public int spread_angle;
    public int spread_count;
    public Transform sub_arrow;
    private Transform sub1;
    private Transform sub2;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.damage = base.GetComponent<WeaponDamage>().damage;
    }

    private void OnEnable()
    {
        if (this.spread_count > 0)
        {
            for (int i = 0; i < this.spread_count; i++)
            {
                this.a = Quaternion.Euler(this.mytransform.eulerAngles.x, this.mytransform.eulerAngles.y + (this.spread_angle * (i + 1)), 0f);
                this.sub1 = (Transform) UnityEngine.Object.Instantiate(this.sub_arrow, this.mytransform.position, this.a);
                this.sub1.GetComponent<WeaponDamage>().PressDamage(this.damage);
                UnityEngine.Object.Destroy(this.sub1.gameObject, 1f);
                this.b = Quaternion.Euler(this.mytransform.eulerAngles.x, this.mytransform.eulerAngles.y - (this.spread_angle * (i + 1)), 0f);
                this.sub2 = (Transform) UnityEngine.Object.Instantiate(this.sub_arrow, this.mytransform.position, this.b);
                this.sub2.GetComponent<WeaponDamage>().PressDamage(this.damage);
                UnityEngine.Object.Destroy(this.sub2.gameObject, 1f);
            }
        }
    }

    private void Update()
    {
        if (this.mytransform.position.y > 0f)
        {
            this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * this.bullet_speed);
        }
    }
}


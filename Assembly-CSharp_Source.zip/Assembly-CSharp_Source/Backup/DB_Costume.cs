using System;
using UnityEngine;

public class DB_Costume : MonoBehaviour
{
    public coustume[] ci = new coustume[0x11];

    private void Awake()
    {
        this.ci[0]._jadecost = 0;
        this.ci[0]._bossindex = -1;
        this.ci[0]._plushp = 0;
        this.ci[0]._name = 1;
        this.ci[0]._info = 0x15;
        this.ci[1]._jadecost = 0x5dc;
        this.ci[1]._bossindex = -1;
        this.ci[1]._plushp = 20;
        this.ci[1]._name = 2;
        this.ci[1]._info = 0x16;
        this.ci[2]._jadecost = 0xbb8;
        this.ci[2]._bossindex = -1;
        this.ci[2]._plushp = 40;
        this.ci[2]._name = 3;
        this.ci[2]._info = 0x17;
        this.ci[3]._jadecost = 100;
        this.ci[3]._bossindex = -1;
        this.ci[3]._plushp = 20;
        this.ci[3]._name = 4;
        this.ci[3]._info = 0x18;
        this.ci[4]._jadecost = 100;
        this.ci[4]._bossindex = -1;
        this.ci[4]._plushp = 20;
        this.ci[4]._name = 5;
        this.ci[4]._info = 0x19;
        this.ci[5]._jadecost = 100;
        this.ci[5]._bossindex = -1;
        this.ci[5]._plushp = 20;
        this.ci[5]._name = 6;
        this.ci[5]._info = 0x1a;
        this.ci[6]._jadecost = 100;
        this.ci[6]._bossindex = -1;
        this.ci[6]._plushp = 20;
        this.ci[6]._name = 7;
        this.ci[6]._info = 0x1b;
        this.ci[7]._jadecost = 100;
        this.ci[7]._bossindex = -1;
        this.ci[7]._plushp = 20;
        this.ci[7]._name = 8;
        this.ci[7]._info = 0x1c;
        this.ci[8]._jadecost = 100;
        this.ci[8]._bossindex = -1;
        this.ci[8]._plushp = 20;
        this.ci[8]._name = 9;
        this.ci[8]._info = 0x1d;
        this.ci[9]._jadecost = 100;
        this.ci[9]._bossindex = -1;
        this.ci[9]._plushp = 20;
        this.ci[9]._name = 10;
        this.ci[9]._info = 30;
        this.ci[10]._jadecost = 100;
        this.ci[10]._bossindex = -1;
        this.ci[10]._plushp = 20;
        this.ci[10]._name = 11;
        this.ci[10]._info = 0x1f;
        this.ci[11]._jadecost = 100;
        this.ci[11]._bossindex = -1;
        this.ci[11]._plushp = 20;
        this.ci[11]._name = 12;
        this.ci[11]._info = 0x20;
        this.ci[12]._jadecost = 100;
        this.ci[12]._bossindex = -1;
        this.ci[12]._plushp = 20;
        this.ci[12]._name = 13;
        this.ci[12]._info = 0x21;
        this.ci[13]._jadecost = 100;
        this.ci[13]._bossindex = -1;
        this.ci[13]._plushp = 20;
        this.ci[13]._name = 14;
        this.ci[13]._info = 0x22;
        this.ci[14]._jadecost = 100;
        this.ci[14]._bossindex = -1;
        this.ci[14]._plushp = 20;
        this.ci[14]._name = 15;
        this.ci[14]._info = 0x23;
        this.ci[15]._jadecost = 100;
        this.ci[15]._bossindex = -1;
        this.ci[15]._plushp = 20;
        this.ci[15]._name = 0x10;
        this.ci[15]._info = 0x24;
        this.ci[0x10]._jadecost = 300;
        this.ci[0x10]._bossindex = -1;
        this.ci[0x10]._plushp = 20;
        this.ci[0x10]._name = 0x11;
        this.ci[0x10]._info = 0x25;
    }
}


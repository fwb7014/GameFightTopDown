using System;
using UnityEngine;

public class Cha_Control_ride_cha_story1 : MonoBehaviour
{
    public Transform horse;
    public Transform horseSpine;
    private Animation myanimation;
    private Transform mytransform;

    private void Awake()
    {
        UnityEngine.Object.DontDestroyOnLoad(base.gameObject);
        this.mytransform = base.transform;
        this.myanimation = base.animation;
    }

    public void CrynStop()
    {
        this.myanimation.Stop();
        this.myanimation["ride2"].speed = 0.16f;
        this.myanimation["ride2"].wrapMode = WrapMode.Once;
        this.myanimation.Play("ride2");
        AnimationState state = this.myanimation.PlayQueued("getoff_horse");
        state.wrapMode = WrapMode.ClampForever;
        state.speed = 0.15f;
    }

    private void Start()
    {
        this.myanimation["ride2"].speed = 0.7f;
        this.myanimation.Play("ride2");
    }

    private void Update()
    {
        this.mytransform.position = this.horseSpine.position + ((Vector3) (Vector3.up * -0.085f));
        this.mytransform.rotation = this.horse.rotation;
    }
}


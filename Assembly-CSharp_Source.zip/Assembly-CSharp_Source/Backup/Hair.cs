using System;
using UnityEngine;

public class Hair : MonoBehaviour
{
    private int chamovestat;

    private void Start()
    {
        base.GetComponent<TrailRenderer>().enabled = true;
    }

    private void Update()
    {
        this.chamovestat = base.transform.root.GetComponent<Cha_Control>().chamovestat;
        if (this.chamovestat < 2)
        {
            base.GetComponent<TrailRenderer>().enabled = false;
        }
        else
        {
            base.GetComponent<TrailRenderer>().enabled = true;
        }
    }
}


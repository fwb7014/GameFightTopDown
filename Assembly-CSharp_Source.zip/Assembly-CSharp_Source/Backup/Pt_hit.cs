using System;
using UnityEngine;

public class Pt_hit : MonoBehaviour
{
    private ParticleEmitter myparticle;
    private bool pton;
    private float s_delay;

    public void ParticleOn()
    {
        this.myparticle.emit = true;
        this.pton = true;
    }

    private void Start()
    {
        this.myparticle = base.particleEmitter;
        this.myparticle.emit = false;
    }

    private void Update()
    {
        if (this.pton)
        {
            if (this.s_delay > 0.1f)
            {
                this.myparticle.emit = false;
                this.pton = false;
                this.s_delay = 0f;
            }
            else
            {
                this.s_delay += Time.deltaTime;
            }
        }
    }
}


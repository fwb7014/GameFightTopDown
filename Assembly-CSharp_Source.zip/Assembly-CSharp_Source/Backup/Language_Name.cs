using System;
using UnityEngine;

public class Language_Name : MonoBehaviour
{
    public string[,] txt_name;

    public Language_Name()
    {
        string[] textArray1 = new string[,] { { 
            "No special moves", "Double Dragon", "Swiping Slash", "Rising Beetle", "Tiger Shot", "Sealing Palm", "Dancing Attack", "Burst of Spirit", "Death Rain", "Butcher Thrust", "Stonebreaker", "Simulacrum", "Rift Slash", "Snake Strike", "Nine Spears", "Ghostly Strike", 
            "Flying Angel", "Immobilize", "Poison Darts", "Hundred Daggers", "Lightning Wave", "Zhang He", "Xu Chu", "Deng Ai", "Zhang Liao", "Sima Yi", "Yue Jin", "Xu Huang", "Zhong Hui", "Yu Jin", "Guo Jia", "Guo Huai", 
            "Pang De", "Cai Wenji", "Wen Yang", "Cheng Yu", "Lady Zhen", "Hao Zhao", "Weng Yi", "Chen Tai", "Jia Xu", "Hua Xin", "Zhang Ti", "Xun Yu", "Man Chong", "Liu Ye", "Wen Ping", "W.Shuang", 
            "Li Dian", "Yi Feng", "Xun You", string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, "Annihilation", "Escort", "Siege", 
            "Gold (Event)", "Assassination", "Liang Province", "Ji Province", "Yong Province", "Chu Province", "Yan Province", "Jing Province", "Xuchāng", "H\x00e0nzhōng", "Bazhou", "Yangping", "Changsha", "Chu", "Xiangyang", "Eastern Wu", 
            "Kuaiji", "Jianye", "P\x00edngyu\x00e1n", "Daxian", "Hebei", "Changban", "Jīngzhōu", "Ch\x00e1ng'ān", "Ching Province", "Jiaozhi", "Ch\x00e9ngdū", "Cave of Seals", "Can I come with you?", "Nice to meet you.", "I can be a valuable ally.", "You're lucky to find me.", 
            "I gave you all my Energy.", "Wield it with pride...", "I didn't need it anyway.", "I gave you what was little left of my Energy.", "I am sorry I can't help you further.", "It will be difficult without me.", "You leave me like this...", "I am not doing it anymore.", "Bah, what is this?", "Curses, double curses."
         }, { 
            "没有绝杀技。", "双龙出踏", "旋转斩", "非常角逐", "虎标记", "风马冰将", "飞天燥舞", "焰斩风", "天时雨", "地陆枪", "石破天惊", "分身术", "破空斩", "毒射盘踞", "九龙枪", "黑鬼袍", 
            "飞仙", "属金郎", "驱毒使", "百透枪", "雷电破", "张颌", "许禇", "邓艾", "张辽", "司马懿", "乐进", "徐晃", "钟会", "于禁", "郭嘉", "郭淮", 
            "庞德", "蔡琰", "文鸯", "程昱", "甄姬", "郝昭", "王异", "陈泰", "贾珝", "华歆", "张济", "荀彧", "满宠", "刘晔", "文聘", "王双", 
            "李典", "李丰", "荀攸", string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, "消灭敌人战", "护送马车守卫战", "敌阵攻城战", 
            "收取金币(活动)", "敌将讨伐战", "益州 地方", "冀州  地方", "雍州  地方", "西周  地方", "扬州  地方", "荆州  地方", "许昌", "汉中", "自动", "阳平", "长沙", "楚", "阳洋", "吴", 
            "会冀", "建业", "平原", "代县", "南皮", "长板", "江陵", "长安", "江州", "交趾", "成都", "封印之洞", "我可以一起去吗。", "很高兴认识你。", "我将帮助你。", "遇到我是非常幸运的。", 
            "我的内功全部给你了。", "希望我的力量可以帮助你...", "对于如此平凡的我，内功是没有任何用处的。", "请接收我小小的内功。", "不好意思，不能给您更大的帮助。", "没有我，将会非常累的。", "就这样被丢弃了...", "我也不想再继续下去了。", "哼，这算什么。", "瞧瞧会有什么好的结果。"
         } };
        this.txt_name = textArray1;
    }
}


using System;
using UnityEngine;

public class Cam_Move_ride : MonoBehaviour
{
    private Vector3 camPos = new Vector3(0f, 1.3f, -0.8f);
    public Transform cha1;
    private int dx = 1;
    private Vector3 hit_shake1 = new Vector3(0.1f, 0f, 0.06f);
    private Camera mycamera;
    private Transform mytransform;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycamera = base.camera;
    }

    public void Hitcam()
    {
        this.dx = -this.dx;
        this.mytransform.position += this.hit_shake1 * this.dx;
        if (this.mycamera.fieldOfView > 23f)
        {
            this.mycamera.fieldOfView--;
        }
    }

    private void Update()
    {
        this.mytransform.LookAt(this.cha1);
        this.mytransform.position = this.camPos + ((Vector3) ((Vector3.right * Mathf.Sin(Time.time * 0.5f)) * 0.8f));
        if (this.mycamera.fieldOfView < 38f)
        {
            this.mycamera.fieldOfView = Mathf.Lerp(this.mycamera.fieldOfView, 38f, Time.deltaTime * 3f);
        }
        else
        {
            this.mycamera.fieldOfView = 38f;
        }
    }
}


using System;
using UnityEngine;

public class Screen_effect : MonoBehaviour
{
    private Transform mytransform;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void OnEnable()
    {
        this.mytransform.localScale = (Vector3) (Vector3.one * 6.5f);
    }

    private void Update()
    {
        if (this.mytransform.localScale.x < 10f)
        {
            this.mytransform.localScale += (Vector3) ((Vector3.one * Time.deltaTime) * 6f);
        }
        else
        {
            base.gameObject.active = false;
        }
    }
}


using System;
using UnityEngine;

public class UI_general : MonoBehaviour
{
    public Transform ani_walk;
    public Texture2D arrow_combine;
    private bool b_delay;
    public GUISkin basicSkin;
    public Texture2D bg_asset;
    public Transform bg_card;
    public Transform bg_combine;
    public Texture2D bg_general;
    public Texture2D bg_inherit;
    public Transform bg_popui;
    private float bg_posX_r = 480f;
    public Texture2D bg_red;
    public Texture2D bg_speech;
    public Texture2D bg_titlename;
    public Texture2D black;
    public Texture2D black_all;
    public GUIStyle bt_back;
    public GUIStyle bt_dismiss;
    public GUIStyle bt_empty;
    public GUIStyle bt_general;
    public Texture2D bt_general_small;
    public GUIStyle bt_roll;
    public GUIStyle bt_yesno;
    public Texture2D[] card_general = new Texture2D[3];
    private float cardposY = -100f;
    private int[] cardtype_count = new int[3];
    private GameObject cashshop;
    private bool changemode;
    private int coin;
    private float comb_atkspd;
    private short comb_def;
    private float comb_exp;
    private float comb_exp_length;
    private int comb_general = -1;
    private short comb_get_level;
    private short comb_grade;
    private short comb_level;
    private short comb_maxatk;
    private short comb_maxhp;
    private short confirm;
    private int cur_general = -1;
    private float cur_generalmaxhp = 1500f;
    private int[] cur_workdelay = new int[2];
    private float currentX;
    private bool dragOn;
    private float dragposX;
    private float dragrange;
    public Transform ef_card_dis;
    public Transform ef_card_l;
    public Transform ef_card_r;
    public Texture2D empty;
    private float f_delay;
    public Transform fortune_teller;
    private float g_atkspd;
    private short g_def;
    private float g_exp_length;
    private short g_grade;
    private short g_level;
    private short g_maxatk;
    private short g_maxhp;
    public Texture2D gauge_exp;
    public Texture2D gauge_hp;
    private bool gaugeup;
    private int[] general_cur_hp = new int[12];
    private int[] general_exp = new int[12];
    private short[] general_grade = new short[12];
    private int[] general_hp = new int[12];
    private short general_index;
    private short general_kind;
    private short[] general_level = new short[12];
    private int[] general_seed = new int[12];
    public Texture2D[] general_weapon = new Texture2D[5];
    private float get_exp;
    private int getslot;
    private bool giftmode;
    public Texture2D hpbase;
    public Texture2D ico_lock;
    public Texture2D icon_alarm;
    public Texture2D icon_coin;
    public Texture2D icon_jade;
    public Texture2D[] icon_popgeneralkind = new Texture2D[3];
    private float icon_posY = 340f;
    private int icon_size;
    public Texture2D icon_unlock;
    private Vector2 iconmove;
    private bool[] ismaxhp = new bool[12];
    private int jade;
    private int language;
    private const int MAXGENERAL = 12;
    private const int MAXGENERALPOOL = 30;
    private const int MAXTEMPGENERAL = 50;
    private const int MAXWORK = 2;
    public GUIStyle pausemenu;
    public Texture2D please_touch;
    public Texture2D pop_blank;
    public Texture2D pop_blank2;
    private short pop_general;
    private float posX1;
    private float posX2;
    private float prevposX;
    private Texture2D[] prt_general = new Texture2D[12];
    private int rnd_speech;
    private General_Stat script_generalstat;
    private Language_Name script_name;
    private SoundEf_UI script_soundUI;
    private bool scrollOn;
    private int sel_general = -1;
    public Texture2D sel_mark;
    private short show_fortune_teller;
    private short showcard;
    private float showcard_delay;
    private int slot_general;
    private const int SLOTPRICE = 3;
    public Transform sound_dummy;
    private Transform sound_UI;
    public Texture2D star_grade;
    private int[] temp_general = new int[50];
    private int[] temp_general_cardtype = new int[50];
    public Texture2D titlebase;
    public Texture2D titlebase3;
    private int totalcount;
    private int tutorial = -1;
    private int typeslot = -1;

    private void Awake()
    {
        this.script_name = base.GetComponent<Language_Name>();
        this.script_generalstat = base.GetComponent<General_Stat>();
        this.language = PlayerPrefs.GetInt("language");
        this.cur_general = Crypto.Load_int_key("cur_general");
        this.general_seed = PlayerPrefsX.GetIntArray("n13");
        this.general_exp = PlayerPrefsX.GetIntArray("n29");
        this.general_hp = PlayerPrefsX.GetIntArray("n33");
        this.slot_general = Crypto.Load_int_key("n09");
        this.tutorial = Crypto.Load_int_key("tutorial");
        this.temp_general = PlayerPrefsX.GetIntArray("n53");
    }

    public void CashshopOpen()
    {
        if (this.cashshop == null)
        {
            this.cashshop = Resources.Load("CashShop") as GameObject;
        }
        UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
        this.bg_popui.localScale = Vector3.zero;
    }

    public void CurGeneralStat(bool _start)
    {
        if (_start)
        {
            if (this.cur_general != -1)
            {
                this.script_generalstat.SetGeneral(this.general_seed[this.cur_general]);
                this.cur_generalmaxhp = this.script_generalstat.g_maxhp;
            }
        }
        else
        {
            this.cur_generalmaxhp = this.g_maxhp;
        }
    }

    public void Delay(float t)
    {
        this.b_delay = true;
        this.f_delay = t;
    }

    public void DelayWorkTime()
    {
        for (int i = 0; i < 2; i++)
        {
            this.cur_workdelay[i] = TimeControl.SubtractDelay(i);
        }
        for (int j = 0; j < 12; j++)
        {
            if (!this.ismaxhp[j])
            {
                this.general_cur_hp[j] = this.general_hp[j] + ((int) (this.cur_workdelay[1] * 0.2f));
            }
        }
    }

    private int FindCardType(int _type)
    {
        this.typeslot = -1;
        for (int i = 0; i < 50; i++)
        {
            if (this.temp_general_cardtype[i] == _type)
            {
                this.typeslot = i;
                break;
            }
        }
        return this.typeslot;
    }

    public void FortuneTell()
    {
        int[] numArray = new int[4];
        int[] numArray2 = new int[4];
        int num = this.general_seed[this.sel_general];
        for (int i = 0; i < 4; i++)
        {
            numArray2[i] = num % 10;
            num /= 10;
            numArray[(numArray2[i % 4] + this.general_index) % 4]++;
        }
        this.fortune_teller.gameObject.active = true;
        this.fortune_teller.GetComponent<FortuneTeller>().FortuneMesh(numArray[0] + 1, numArray[1] + 1, numArray[2] + 1, numArray[3] + 1);
    }

    public void GeneralKindOnly()
    {
        int num = 0;
        for (int i = 0; i < this.slot_general; i++)
        {
            if (this.general_seed[i] > 0)
            {
                num = (this.general_seed[i] % 0x989680) / 0x186a0;
                this.general_grade[i] = (short) ((this.general_seed[i] % 0x186a0) / 0x2710);
                this.general_level[i] = (short) (((float) this.general_seed[i]) / 1E+07f);
                int num3 = num + 1;
                this.prt_general[i] = Resources.Load("prt_general" + num3.ToString()) as Texture2D;
            }
        }
    }

    private void GeneralMode()
    {
        if (this.sel_general < 0)
        {
            this.sel_general = this.cur_general;
        }
        else if (this.general_seed[this.sel_general] == 0)
        {
            this.pop_general = 0;
            this.bg_popui.localScale = Vector3.zero;
            return;
        }
        if (this.pop_general < 4)
        {
            GUI.DrawTexture(Crypto.Rect2(130f, 54f, 220f, 18f), this.bg_titlename);
            GUI.DrawTexture(Crypto.Rect2(140f, 97f, 64f, 64f), this.prt_general[this.sel_general]);
            GUI.DrawTexture(Crypto.Rect2(140f, 82f, 64f, 110f), this.bg_general);
            GUI.Label(Crypto.Rect2(144f, 163f, 70f, 16f), string.Concat(new object[] { string.Empty, this.g_level, " / ", (this.g_grade + 1) * 20 }), "txt12_w");
            GUI.DrawTexture(Crypto.Rect2(143f, 184f, this.g_exp_length, 5f), this.gauge_exp);
            for (int i = 0; i < (this.g_grade + 1); i++)
            {
                GUI.DrawTexture(Crypto.Rect2((float) ((0xa6 - (this.g_grade * 5)) + (i * 10)), 84f, 12f, 12f), this.star_grade);
            }
            for (int j = 0; j < 3; j++)
            {
                if (GUI.Button(Crypto.Rect2(364f, (float) (0x2a + (j * 0x40)), 64f, 64f), string.Empty, this.bt_empty))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    if (j == 2)
                    {
                        if (this.tutorial == 4)
                        {
                            if (this.general_seed[2] == 0)
                            {
                                this.Delay(1f);
                                this.confirm = 0x10;
                                return;
                            }
                            if ((this.cur_general != 2) || (this.sel_general != 2))
                            {
                                this.Delay(1f);
                                this.confirm = 0x10;
                                return;
                            }
                        }
                        this.comb_general = this.sel_general;
                        this.comb_grade = this.g_grade;
                        this.comb_level = this.g_level;
                        this.comb_exp_length = this.g_exp_length;
                        this.comb_exp = this.general_exp[this.sel_general];
                        this.comb_get_level = 0;
                        this.comb_atkspd = this.g_atkspd;
                        this.comb_def = this.g_def;
                        this.comb_maxatk = this.g_maxatk;
                        this.comb_maxhp = this.g_maxhp;
                        this.gaugeup = false;
                        this.posX1 = 140f;
                        this.posX2 = 276f;
                    }
                    this.pop_general = (short) (j + 2);
                    this.bg_popui.localScale = (Vector3) (Vector3.one * 5.2f);
                    this.bg_popui.localPosition = new Vector3(0f, -0.051f, 0.4f);
                }
                GUI.DrawTexture(Crypto.Rect2(364f, (float) (0x2a + (j * 0x40)), 64f, 64f), this.icon_popgeneralkind[j]);
                GUI.Box(Crypto.Rect2(386f, (float) (80 + (j * 0x40)), 64f, 20f), Language.intxt[this.language, 0xb2 + j]);
            }
            if (this.pop_general == 1)
            {
                GUI.Label(Crypto.Rect2(130f, 54f, 220f, 16f), this.script_name.txt_name[this.language, 0x15 + this.general_index], "txt12_w");
                GUI.DrawTexture(Crypto.Rect2(322f, 50f, 26f, 26f), this.general_weapon[this.general_kind]);
                for (int k = 0; k < 3; k++)
                {
                    GUI.DrawTexture(Crypto.Rect2(220f, (float) (0x72 + (k * 20)), 128f, 16f), this.titlebase);
                }
                GUI.DrawTexture(Crypto.Rect2(220f, 174f, 128f, 16f), this.titlebase3);
                GUI.DrawTexture(Crypto.Rect2(220f, 82f, 128f, 32f), this.hpbase);
                GUI.DrawTexture(Crypto.Rect2(225f, 101f, (112f * this.general_cur_hp[this.sel_general]) / ((float) this.g_maxhp), 5f), this.gauge_hp);
                GUI.Label(Crypto.Rect2(190f, 81f, 128f, 16f), "HP", "txt12_0");
                GUI.Label(Crypto.Rect2(190f, 114f, 128f, 16f), Language.intxt[this.language, 0x8d], "txt12_0");
                GUI.Label(Crypto.Rect2(190f, 134f, 128f, 16f), Language.intxt[this.language, 0x8e], "txt12_0");
                GUI.Label(Crypto.Rect2(190f, 154f, 128f, 16f), Language.intxt[this.language, 0x127], "txt12_0");
                GUI.Label(Crypto.Rect2(260f, 81f, 100f, 16f), this.general_cur_hp[this.sel_general] + " / " + this.g_maxhp, "txt12_0");
                GUI.Label(Crypto.Rect2(290f, 114f, 64f, 16f), string.Empty + this.g_maxatk, "txt12_0");
                GUI.Label(Crypto.Rect2(290f, 134f, 64f, 16f), string.Empty + this.g_def, "txt12_0");
                GUI.Label(Crypto.Rect2(290f, 154f, 64f, 16f), string.Empty + ((this.g_atkspd * 100f)).ToString("F1"), "txt12_0");
                if (this.g_grade >= 2)
                {
                    GUI.Label(Crypto.Rect2(220f, 174f, 128f, 16f), this.script_name.txt_name[this.language, 1 + this.general_index], "txt12_b");
                }
                else
                {
                    GUI.Label(Crypto.Rect2(220f, 174f, 128f, 16f), this.script_name.txt_name[this.language, 0], "txt12_0");
                }
                if (this.cur_general != this.sel_general)
                {
                    if (GUI.Button(Crypto.Rect2(208f, 200f, 64f, 32f), Language.intxt[this.language, 5], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        this.cur_general = this.sel_general;
                        Crypto.Save_int_key("cur_general", this.cur_general);
                        this.CurGeneralStat(false);
                        if (this.tutorial == 14)
                        {
                            this.tutorial = -3;
                            Crypto.Save_int_key("tutorial", -3);
                        }
                    }
                }
                else if (GUI.Button(Crypto.Rect2(208f, 200f, 64f, 32f), Language.intxt[this.language, 0xaf], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    this.cur_general = -1;
                    Crypto.Save_int_key("cur_general", this.cur_general);
                    this.pop_general = 0;
                    this.bg_popui.localScale = Vector3.zero;
                    if (this.tutorial == -3)
                    {
                        this.tutorial = 14;
                        Crypto.Save_int_key("tutorial", 14);
                    }
                }
                if (GUI.Button(Crypto.Rect2(280f, 200f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.pop_general = 0;
                    this.bg_popui.localScale = Vector3.zero;
                    this.bg_posX_r = 480f;
                    this.bg_posX_r = 480f;
                    this.icon_posY = 340f;
                }
                else if (GUI.Button(Crypto.Rect2(124f, 200f, 32f, 32f), string.Empty, this.bt_dismiss))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    if ((this.tutorial == 4) || (this.tutorial == 14))
                    {
                        this.Delay(1f);
                        this.confirm = 0x10;
                    }
                    else
                    {
                        this.confirm = 4;
                    }
                }
                if (GUI.Button(Crypto.Rect2(164f, 200f, 32f, 32f), string.Empty, this.bt_roll))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    this.changemode = true;
                    this.bg_popui.localScale = Vector3.zero;
                    this.pop_general = 0;
                }
                if (((this.tutorial == 4) && (this.general_seed[2] != 0)) && (this.sel_general == 2))
                {
                    if (this.cur_general != 2)
                    {
                        GUI.DrawTexture(Crypto.Rect2(212f, 182f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                    }
                    else
                    {
                        GUI.DrawTexture(Crypto.Rect2(370f, 170f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                    }
                }
            }
            else if (this.pop_general == 2)
            {
                GUI.Label(Crypto.Rect2(130f, 54f, 220f, 16f), Language.intxt[this.language, 0xb2], "txt12_w");
                GUI.DrawTexture(Crypto.Rect2(220f, 82f, 128f, 32f), this.hpbase);
                GUI.DrawTexture(Crypto.Rect2(225f, 101f, (112f * this.general_cur_hp[this.sel_general]) / ((float) this.g_maxhp), 5f), this.gauge_hp);
                GUI.Label(Crypto.Rect2(190f, 81f, 128f, 16f), "HP", "txt12_0");
                GUI.Label(Crypto.Rect2(260f, 81f, 100f, 16f), this.general_cur_hp[this.sel_general] + " / " + this.g_maxhp, "txt12_0");
                GUI.Label(Crypto.Rect2(202f, 118f, 150f, 16f), Language.intxt[this.language, 0x184], "txt12_0");
                GUI.Label(Crypto.Rect2(270f, 170f, 32f, 16f), string.Empty + (this.g_level * 10), "txt12_0");
                GUI.DrawTexture(Crypto.Rect2(256f, 170f, 16f, 16f), this.icon_coin);
                if (GUI.Button(Crypto.Rect2(210f, 134f, 140f, 40f), Language.intxt[this.language, 0xb2], this.pausemenu))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    if (this.general_cur_hp[this.sel_general] >= this.g_maxhp)
                    {
                        this.Delay(1f);
                        this.confirm = 9;
                        this.ismaxhp[this.sel_general] = true;
                    }
                    else if (this.coin >= (this.g_level * 10))
                    {
                        if (Crypto.Property_change(-this.g_level * 10, false))
                        {
                            this.coin -= this.g_level * 10;
                            this.general_cur_hp[this.sel_general] = this.g_maxhp;
                            TimeControl.SetDelay(1);
                            PlayerPrefsX.SetIntArray("n33", this.general_cur_hp);
                            this.general_hp = this.general_cur_hp;
                        }
                    }
                    else
                    {
                        this.Delay(1f);
                        this.confirm = 8;
                    }
                }
                else if (GUI.Button(Crypto.Rect2(280f, 200f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.pop_general = 1;
                }
            }
            else if (this.pop_general == 3)
            {
                GUI.Label(Crypto.Rect2(130f, 54f, 220f, 16f), Language.intxt[this.language, 0xb3], "txt12_w");
                GUI.Label(Crypto.Rect2(202f, 100f, 150f, 16f), Language.intxt[this.language, 0xb8], "txt12_0");
                GUI.Label(Crypto.Rect2(270f, 160f, 32f, 16f), string.Empty + 100, "txt12_0");
                GUI.DrawTexture(Crypto.Rect2(256f, 160f, 16f, 16f), this.icon_coin);
                GUI.Label(Crypto.Rect2(202f, 180f, 150f, 16f), Language.intxt[this.language, 350], "txt12_b");
                if (GUI.Button(Crypto.Rect2(210f, 120f, 140f, 40f), Language.intxt[this.language, 0xb0], this.pausemenu))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    if (this.jade >= 3)
                    {
                        if (Crypto.Property_change(-100, false))
                        {
                            this.FortuneTell();
                            this.coin -= 100;
                            this.pop_general = 0;
                            this.bg_popui.localScale = Vector3.zero;
                            this.show_fortune_teller = 1;
                            this.Delay(3f);
                            this.bg_posX_r = 480f;
                        }
                    }
                    else
                    {
                        this.Delay(1f);
                        this.confirm = 6;
                    }
                }
                else if (GUI.Button(Crypto.Rect2(280f, 200f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.pop_general = 1;
                }
            }
        }
        else
        {
            GUI.DrawTexture(Crypto.Rect2(130f, 54f, 220f, 18f), this.bg_titlename);
            GUI.Label(Crypto.Rect2(130f, 54f, 220f, 16f), Language.intxt[this.language, 180], "txt12_w");
            GUI.DrawTexture(Crypto.Rect2(this.posX1, 97f, 64f, 64f), this.black_all);
            GUI.DrawTexture(Crypto.Rect2(this.posX1, 97f, 64f, 64f), this.prt_general[this.comb_general]);
            GUI.DrawTexture(Crypto.Rect2(this.posX1, 82f, 64f, 110f), this.bg_general);
            GUI.Label(Crypto.Rect2(this.posX1 + 4f, 163f, 70f, 16f), string.Concat(new object[] { string.Empty, this.comb_level, " / ", (this.comb_grade + 1) * 20 }), "txt12_w");
            GUI.DrawTexture(Crypto.Rect2(this.posX1 + 3f, 184f, this.comb_exp_length, 5f), this.gauge_exp);
            for (int m = 0; m < (this.comb_grade + 1); m++)
            {
                GUI.DrawTexture(Crypto.Rect2(((this.posX1 + 26f) - (this.comb_grade * 5)) + (m * 10), 84f, 12f, 12f), this.star_grade);
            }
            if (this.pop_general == 10)
            {
                GUI.DrawTexture(Crypto.Rect2(130f, 54f, 220f, 18f), this.bg_titlename);
                GUI.Label(Crypto.Rect2(130f, 54f, 220f, 16f), this.script_name.txt_name[this.language, 0x15 + this.general_index], "txt12_w");
                GUI.DrawTexture(Crypto.Rect2(322f, 50f, 26f, 26f), this.general_weapon[this.general_kind]);
                for (int n = 0; n < 3; n++)
                {
                    GUI.DrawTexture(Crypto.Rect2(220f, (float) (0x72 + (n * 20)), 128f, 16f), this.titlebase);
                }
                GUI.DrawTexture(Crypto.Rect2(220f, 174f, 128f, 16f), this.titlebase3);
                GUI.DrawTexture(Crypto.Rect2(220f, 82f, 128f, 32f), this.hpbase);
                GUI.DrawTexture(Crypto.Rect2(225f, 101f, (112f * this.general_cur_hp[this.sel_general]) / ((float) this.g_maxhp), 5f), this.gauge_hp);
                GUI.Label(Crypto.Rect2(190f, 81f, 128f, 16f), "HP", "txt12_0");
                GUI.Label(Crypto.Rect2(190f, 114f, 128f, 16f), Language.intxt[this.language, 0x8d], "txt12_0");
                GUI.Label(Crypto.Rect2(190f, 134f, 128f, 16f), Language.intxt[this.language, 0x8e], "txt12_0");
                GUI.Label(Crypto.Rect2(190f, 154f, 128f, 16f), Language.intxt[this.language, 0x127], "txt12_0");
                GUI.Label(Crypto.Rect2(260f, 81f, 100f, 16f), this.general_cur_hp[this.sel_general] + " / " + this.g_maxhp, "txt12_0");
                GUI.Label(Crypto.Rect2(290f, 114f, 64f, 16f), string.Empty + this.g_maxatk, "txt12_0");
                GUI.Label(Crypto.Rect2(290f, 134f, 64f, 16f), string.Empty + this.g_def, "txt12_0");
                GUI.Label(Crypto.Rect2(290f, 154f, 64f, 16f), string.Empty + ((this.g_atkspd * 100f)).ToString("F1"), "txt12_0");
                if ((this.g_maxhp - this.comb_maxhp) > 0)
                {
                    GUI.Box(Crypto.Rect2(346f, 79f, 46f, 20f), "(+" + (this.g_maxhp - this.comb_maxhp) + ")");
                }
                if ((this.g_maxatk - this.comb_maxatk) > 0)
                {
                    GUI.Box(Crypto.Rect2(346f, 112f, 46f, 20f), "(+" + (this.g_maxatk - this.comb_maxatk) + ")");
                }
                if ((this.g_def - this.comb_def) > 0)
                {
                    GUI.Box(Crypto.Rect2(346f, 132f, 46f, 20f), "(+" + (this.g_def - this.comb_def) + ")");
                }
                if (((this.g_atkspd * 100f) - (this.comb_atkspd * 100f)) > 0f)
                {
                    GUI.Box(Crypto.Rect2(346f, 152f, 46f, 20f), "(+" + (((this.g_atkspd * 100f) - (this.comb_atkspd * 100f))).ToString("F1") + ")");
                }
                if (this.g_grade >= 2)
                {
                    GUI.Label(Crypto.Rect2(220f, 174f, 128f, 16f), this.script_name.txt_name[this.language, 1 + this.general_index], "txt12_b");
                }
                else
                {
                    GUI.Label(Crypto.Rect2(220f, 174f, 128f, 16f), this.script_name.txt_name[this.language, 0], "txt12_0");
                }
                if (GUI.Button(Crypto.Rect2(208f, 200f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    this.pop_general = 1;
                }
            }
            else if (this.pop_general == 4)
            {
                GUI.Label(Crypto.Rect2(202f, 90f, 150f, 16f), Language.intxt[this.language, 0xb5], "txt12_0");
                GUI.Label(Crypto.Rect2(120f, 206f, 150f, 16f), Language.intxt[this.language, 0xb9], "txt12_0");
                GUI.DrawTexture(Crypto.Rect2(208f, 120f, 64f, 64f), this.arrow_combine);
                GUI.DrawTexture(Crypto.Rect2(280f, 114f, 64f, 64f), this.bg_inherit);
                if (GUI.Button(Crypto.Rect2(280f, 200f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.sel_general = this.comb_general;
                    this.g_exp_length = this.comb_exp_length;
                    this.GeneralStat(this.general_seed[this.sel_general], true);
                    this.pop_general = 1;
                }
            }
            else if (this.pop_general < 7)
            {
                GUI.DrawTexture(Crypto.Rect2(this.posX2, 97f, 64f, 64f), this.black_all);
                GUI.DrawTexture(Crypto.Rect2(this.iconmove.x, this.iconmove.y, 64f, 64f), this.prt_general[this.sel_general]);
                GUI.DrawTexture(Crypto.Rect2(this.posX2, 82f, 64f, 110f), this.bg_general);
                GUI.Label(Crypto.Rect2(this.posX2 + 4f, 163f, 70f, 16f), string.Concat(new object[] { string.Empty, this.g_level, " / ", (this.g_grade + 1) * 20 }), "txt12_w");
                GUI.DrawTexture(Crypto.Rect2(this.posX2 + 3f, 184f, this.g_exp_length, 5f), this.gauge_exp);
                for (int num6 = 0; num6 < (this.g_grade + 1); num6++)
                {
                    GUI.DrawTexture(Crypto.Rect2(((this.posX2 + 26f) - (this.g_grade * 5)) + (num6 * 10), 84f, 12f, 12f), this.star_grade);
                }
                if (this.pop_general == 5)
                {
                    GUI.DrawTexture(Crypto.Rect2(208f, 120f, 64f, 64f), this.arrow_combine);
                    if (GUI.Button(Crypto.Rect2(208f, 200f, 64f, 32f), Language.intxt[this.language, 0xb1], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        if (this.comb_level < ((this.comb_grade + 1) * 20))
                        {
                            this.confirm = 10;
                        }
                        else
                        {
                            this.Delay(1f);
                            this.confirm = 9;
                        }
                    }
                    else if (GUI.Button(Crypto.Rect2(280f, 200f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.pop_general = 4;
                    }
                    if ((this.tutorial == 4) && (this.confirm == 0))
                    {
                        GUI.DrawTexture(Crypto.Rect2(210f, 184f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                    }
                }
            }
            else if (this.pop_general != 9)
            {
                GUI.DrawTexture(Crypto.Rect2(this.posX2, 97f, 64f, 64f), this.prt_general[this.sel_general]);
            }
        }
    }

    public void GeneralStat(int _seed, bool _exist)
    {
        this.script_generalstat.SetGeneral(_seed);
        this.general_index = this.script_generalstat.general_index;
        this.general_kind = this.script_generalstat.general_kind;
        this.g_maxatk = this.script_generalstat.g_maxatk;
        this.g_def = this.script_generalstat.g_def;
        this.g_maxhp = this.script_generalstat.g_maxhp;
        this.g_atkspd = this.script_generalstat.g_atkspd;
        this.g_grade = this.script_generalstat.g_grade;
        this.g_level = this.script_generalstat.g_level;
        if (!_exist)
        {
            this.general_hp[this.getslot] = this.g_maxhp;
            this.general_cur_hp[this.getslot] = this.g_maxhp;
            PlayerPrefsX.SetIntArray("n33", this.general_cur_hp);
            TimeControl.SetDelay(1);
            int[] intArray = PlayerPrefsX.GetIntArray("staff");
            intArray[this.general_index] = Mathf.Max(intArray[this.general_index], this.g_grade + 1);
            PlayerPrefsX.SetIntArray("staff", intArray);
        }
        else
        {
            if (this.general_cur_hp[this.sel_general] >= this.g_maxhp)
            {
                this.general_cur_hp[this.sel_general] = this.g_maxhp;
                this.ismaxhp[this.sel_general] = true;
            }
            else if (this.general_cur_hp[this.sel_general] <= 0)
            {
                this.general_cur_hp[this.sel_general] = 1;
            }
            this.g_exp_length = ((float) (this.general_exp[this.sel_general] * 0x3a)) / ((100 + (this.g_level * 6)) * (1f + (this.g_grade * 0.2f)));
        }
    }

    private int GetGeneral()
    {
        this.getslot = -1;
        for (int i = 0; i < this.slot_general; i++)
        {
            if (this.general_seed[i] == 0)
            {
                this.getslot = i;
                break;
            }
        }
        return this.getslot;
    }

    private void GiftMode()
    {
        GUI.Label(Crypto.Rect2(110f, this.cardposY - 40f, 260f, 34f), string.Concat(new object[] { Language.intxt[this.language, 0x1a5], "\r\n(", this.totalcount, " / 50)" }), "blank_white");
        for (int i = 0; i < 3; i++)
        {
            GUI.DrawTexture(Crypto.Rect2((float) (90 + (i * 110)), this.cardposY, 80f, 80f), this.card_general[i]);
            if (GUI.Button(Crypto.Rect2((float) (90 + (i * 110)), this.cardposY, 80f, 80f), string.Empty, this.bt_empty))
            {
                this.typeslot = this.FindCardType(i + 1);
                if (this.typeslot != -1)
                {
                    if (this.GetGeneral() != -1)
                    {
                        this.bg_card.renderer.material.mainTexture = this.card_general[i];
                        this.bg_card.gameObject.active = true;
                        this.bg_card.position = new Vector3((i - 1) * -0.5f, 0.05f, 0.5f);
                        this.cardposY = -100f;
                        this.showcard = 1;
                        this.showcard_delay = 0.5f;
                        break;
                    }
                    if (this.slot_general >= 12)
                    {
                        this.confirm = 9;
                        this.Delay(1f);
                    }
                    else
                    {
                        this.Delay(1f);
                        this.confirm = 3;
                    }
                }
            }
            GUI.Box(Crypto.Rect2((float) (0x5e + (i * 110)), this.cardposY + 80f, 72f, 24f), string.Empty, "blank_box");
            GUI.Label(Crypto.Rect2((float) (90 + (i * 110)), this.cardposY + 76f, 80f, 32f), string.Empty + this.cardtype_count[i], "imagenum");
        }
    }

    private void OnEnable()
    {
        this.coin = Crypto.Load_int_key("n17");
        this.jade = Crypto.Load_int_key("n24");
    }

    private void OnGUI()
    {
        GUI.skin = this.basicSkin;
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.DrawTexture(Crypto.Rect2(this.bg_posX_r, 240f, 480f, 100f), this.black);
        if (this.confirm > 0)
        {
            GUI.enabled = false;
        }
        GUI.DrawTexture(Crypto.Rect2(112f, 0f, 256f, 32f), this.bg_asset);
        GUI.Label(Crypto.Rect2(146f, 6f, 80f, 14f), string.Empty + this.coin, "txt12_w");
        GUI.Label(Crypto.Rect2(280f, 6f, 64f, 14f), string.Empty + this.jade, "txt12_w");
        if (GUI.Button(Crypto.Rect2(144f, 2f, 100f, 24f), string.Empty, this.bt_empty))
        {
            if (this.sound_UI != null)
            {
                this.script_soundUI.SoundOn(0);
            }
            Crypto.Save_int_key("cashshopkind", 2);
            this.CashshopOpen();
        }
        if (GUI.Button(Crypto.Rect2(272f, 2f, 88f, 24f), string.Empty, this.bt_empty))
        {
            if (this.sound_UI != null)
            {
                this.script_soundUI.SoundOn(0);
            }
            Crypto.Save_int_key("cashshopkind", 1);
            this.CashshopOpen();
        }
        if (this.show_fortune_teller > 0)
        {
            GUI.DrawTexture(Crypto.Rect2(this.bg_posX_r, 256f, 490f, 74f), this.black_all);
            if (this.f_delay == 0f)
            {
                if (GUI.Button(Crypto.Rect2(390f, 274f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    this.fortune_teller.position = (Vector3) (Vector3.one * 5f);
                    this.fortune_teller.gameObject.active = false;
                    this.show_fortune_teller = 0;
                    this.pop_general = 1;
                    this.bg_popui.localScale = (Vector3) (Vector3.one * 5.2f);
                    this.bg_popui.localPosition = new Vector3(0f, -0.051f, 0.5f);
                }
                GUI.Label(Crypto.Rect2(0f, 270f, 480f, 32f), Language.intxt[this.language, 0xba], "txt12_w");
                GUI.Label(Crypto.Rect2(208f, 112f, 64f, 16f), Language.intxt[this.language, 0x8d], "txt12_w");
                GUI.Label(Crypto.Rect2(208f, 232f, 64f, 16f), "HP", "txt12_w");
                GUI.Label(Crypto.Rect2(140f, 172f, 64f, 16f), Language.intxt[this.language, 0x8e], "txt12_w");
                GUI.Label(Crypto.Rect2(276f, 172f, 64f, 16f), Language.intxt[this.language, 0x127], "txt12_w");
            }
            else
            {
                GUI.Label(Crypto.Rect2(0f, 270f, 480f, 32f), Language.intxt[this.language, 0xbc], "txt12_w");
            }
            GUI.Box(Crypto.Rect2(96f, 84f, 80f, 24f), Language.intxt[this.language, 0x63]);
        }
        else
        {
            for (int i = 0; i < 12; i++)
            {
                if (GUI.Button(Crypto.Rect2(((i * 0x4c) + 0x12) + this.dragposX, this.icon_posY, 64f, 64f), string.Empty, this.bt_general))
                {
                    if (this.scrollOn)
                    {
                        break;
                    }
                    if (this.giftmode)
                    {
                        if (this.showcard > 0)
                        {
                            break;
                        }
                        this.giftmode = false;
                    }
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    if (this.pop_general >= 4)
                    {
                        if ((this.pop_general < 6) && (this.comb_general != i))
                        {
                            if (this.general_seed[i] == 0)
                            {
                                goto Label_07DD;
                            }
                            this.iconmove = new Vector2(((i * 0x4c) + 0x12) + this.dragposX, this.icon_posY);
                            this.sel_general = i;
                            this.GeneralStat(this.general_seed[i], true);
                            this.pop_general = 5;
                        }
                        break;
                    }
                    if (this.changemode)
                    {
                        if (i < this.slot_general)
                        {
                            int num2 = this.general_seed[i];
                            int num3 = this.general_hp[i];
                            int num4 = this.general_cur_hp[i];
                            int num5 = this.general_exp[i];
                            Texture2D textured = this.prt_general[i];
                            this.general_seed[i] = this.general_seed[this.sel_general];
                            this.general_hp[i] = this.general_hp[this.sel_general];
                            this.general_cur_hp[i] = this.general_cur_hp[this.sel_general];
                            this.general_exp[i] = this.general_exp[this.sel_general];
                            this.prt_general[i] = this.prt_general[this.sel_general];
                            this.general_seed[this.sel_general] = num2;
                            this.general_hp[this.sel_general] = num3;
                            this.general_cur_hp[this.sel_general] = num4;
                            this.general_exp[this.sel_general] = num5;
                            this.prt_general[this.sel_general] = textured;
                            if (this.sel_general == this.cur_general)
                            {
                                this.cur_general = i;
                            }
                            this.GeneralKindOnly();
                            this.sel_general = i;
                            this.GeneralStat(this.general_seed[this.sel_general], true);
                            this.changemode = false;
                            Crypto.Save_int_key("cur_general", this.cur_general);
                            PlayerPrefsX.SetIntArray("n13", this.general_seed);
                            PlayerPrefsX.SetIntArray("n29", this.general_exp);
                            PlayerPrefsX.SetIntArray("n33", this.general_hp);
                            this.pop_general = 1;
                            this.bg_popui.localScale = (Vector3) (Vector3.one * 5.2f);
                        }
                        else
                        {
                            this.changemode = false;
                            this.pop_general = 1;
                            this.bg_popui.localScale = (Vector3) (Vector3.one * 5.2f);
                        }
                    }
                    else if (this.general_seed[i] != 0)
                    {
                        this.sel_general = i;
                        this.GeneralStat(this.general_seed[i], true);
                        this.pop_general = 1;
                        this.bg_popui.localScale = (Vector3) (Vector3.one * 5.2f);
                        this.bg_popui.localPosition = new Vector3(0f, -0.051f, 0.5f);
                    }
                    else if (i >= this.slot_general)
                    {
                        this.pop_general = 0;
                        this.bg_popui.localScale = Vector3.zero;
                        this.confirm = 2;
                    }
                }
            Label_07DD:
                if (((this.pop_general < 5) || (this.sel_general != i)) && (this.general_seed[i] > 0))
                {
                    if (this.cur_general == i)
                    {
                        GUI.DrawTexture(Crypto.Rect2(((i * 0x4c) + 0x12) + this.dragposX, this.icon_posY, 64f, 64f), this.sel_mark);
                    }
                    GUI.DrawTexture(Crypto.Rect2(((i * 0x4c) + 0x12) + this.dragposX, this.icon_posY, 64f, 64f), this.prt_general[i]);
                    for (int k = 0; k < (this.general_grade[i] + 1); k++)
                    {
                        GUI.DrawTexture(Crypto.Rect2(((((i * 0x4c) + 0x2c) + this.dragposX) - (this.general_grade[i] * 5)) + (k * 10), this.icon_posY, 12f, 12f), this.star_grade);
                    }
                    if (this.general_level[i] >= ((this.general_grade[i] + 1) * 20))
                    {
                        GUI.Box(Crypto.Rect2(((i * 0x4c) + 0x1c) + this.dragposX, this.icon_posY + 52f, 44f, 18f), "MAX");
                    }
                    else
                    {
                        GUI.Box(Crypto.Rect2(((i * 0x4c) + 0x1c) + this.dragposX, this.icon_posY + 52f, 44f, 18f), "LV " + this.general_level[i]);
                    }
                    if ((this.tutorial == 4) && (this.general_seed[2] != 0))
                    {
                        if (this.pop_general == 4)
                        {
                            if (i == 1)
                            {
                                GUI.DrawTexture(Crypto.Rect2(((i * 0x4c) + 0x16) + this.dragposX, this.icon_posY + 4f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                            }
                        }
                        else if (this.pop_general == 1)
                        {
                            if ((i == 2) && (this.sel_general != 2))
                            {
                                GUI.DrawTexture(Crypto.Rect2(((i * 0x4c) + 0x16) + this.dragposX, this.icon_posY + 4f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                            }
                        }
                        else if ((this.pop_general == 0) && (i == 2))
                        {
                            GUI.DrawTexture(Crypto.Rect2(((i * 0x4c) + 0x16) + this.dragposX, this.icon_posY + 4f, (float) (this.icon_size * 0x40), (float) (this.icon_size * 0x40)), this.please_touch);
                        }
                    }
                }
            }
            for (int j = this.slot_general; j < 12; j++)
            {
                GUI.DrawTexture(Crypto.Rect2(((j * 0x4c) + 0x12) + this.dragposX, this.icon_posY, 64f, 64f), this.ico_lock);
                GUI.DrawTexture(Crypto.Rect2(((j * 0x4c) + 0x18) + this.dragposX, this.icon_posY + 6f, 16f, 16f), this.icon_jade);
                GUI.Label(Crypto.Rect2(((j * 0x4c) + 0x2c) + this.dragposX, this.icon_posY + 6f, 32f, 16f), string.Empty + 3, "txt12_w");
            }
            if (this.showcard > 0)
            {
                if (this.showcard == 4)
                {
                    GUI.DrawTexture(Crypto.Rect2(130f, 54f, 220f, 18f), this.bg_titlename);
                    GUI.DrawTexture(Crypto.Rect2(140f, 97f, 64f, 64f), this.prt_general[this.getslot]);
                    GUI.DrawTexture(Crypto.Rect2(140f, 82f, 64f, 110f), this.bg_general);
                    GUI.Label(Crypto.Rect2(144f, 163f, 70f, 16f), string.Concat(new object[] { string.Empty, this.g_level, " / ", (this.g_grade + 1) * 20 }), "txt12_w");
                    GUI.DrawTexture(Crypto.Rect2(143f, 184f, this.g_exp_length, 5f), this.gauge_exp);
                    for (int m = 0; m < (this.g_grade + 1); m++)
                    {
                        GUI.DrawTexture(Crypto.Rect2((float) ((0xa6 - (this.g_grade * 5)) + (m * 10)), 84f, 12f, 12f), this.star_grade);
                    }
                    GUI.Label(Crypto.Rect2(130f, 54f, 220f, 16f), this.script_name.txt_name[this.language, 0x15 + this.general_index], "txt12_w");
                    GUI.DrawTexture(Crypto.Rect2(322f, 50f, 26f, 26f), this.general_weapon[this.general_kind]);
                    for (int n = 0; n < 3; n++)
                    {
                        GUI.DrawTexture(Crypto.Rect2(220f, (float) (0x72 + (n * 20)), 128f, 16f), this.titlebase);
                    }
                    GUI.DrawTexture(Crypto.Rect2(220f, 174f, 128f, 16f), this.titlebase3);
                    GUI.DrawTexture(Crypto.Rect2(220f, 82f, 128f, 32f), this.hpbase);
                    GUI.DrawTexture(Crypto.Rect2(225f, 101f, (112f * this.general_cur_hp[this.sel_general]) / ((float) this.g_maxhp), 5f), this.gauge_hp);
                    GUI.Label(Crypto.Rect2(190f, 81f, 128f, 16f), "HP", "txt12_0");
                    GUI.Label(Crypto.Rect2(190f, 114f, 128f, 16f), Language.intxt[this.language, 0x8d], "txt12_0");
                    GUI.Label(Crypto.Rect2(190f, 134f, 128f, 16f), Language.intxt[this.language, 0x8e], "txt12_0");
                    GUI.Label(Crypto.Rect2(190f, 154f, 128f, 16f), Language.intxt[this.language, 0x127], "txt12_0");
                    GUI.Label(Crypto.Rect2(260f, 81f, 100f, 16f), this.general_cur_hp[this.sel_general] + " / " + this.g_maxhp, "txt12_0");
                    GUI.Label(Crypto.Rect2(290f, 114f, 64f, 16f), string.Empty + this.g_maxatk, "txt12_0");
                    GUI.Label(Crypto.Rect2(290f, 134f, 64f, 16f), string.Empty + this.g_def, "txt12_0");
                    GUI.Label(Crypto.Rect2(290f, 154f, 64f, 16f), string.Empty + ((this.g_atkspd * 100f)).ToString("F1"), "txt12_0");
                    if (this.g_grade >= 2)
                    {
                        GUI.Label(Crypto.Rect2(220f, 174f, 128f, 16f), this.script_name.txt_name[this.language, 1 + this.general_index], "txt12_b");
                    }
                    else
                    {
                        GUI.Label(Crypto.Rect2(220f, 174f, 128f, 16f), this.script_name.txt_name[this.language, 0], "txt12_0");
                    }
                    if (GUI.Button(Crypto.Rect2(280f, 200f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.showcard = 0;
                        this.bg_popui.localScale = Vector3.zero;
                    }
                }
            }
            else if (this.giftmode)
            {
                this.GiftMode();
                if (GUI.Button(Crypto.Rect2(416f, 0f, 64f, 64f), string.Empty, this.bt_back))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    this.giftmode = false;
                    this.bg_popui.localScale = Vector3.zero;
                    this.pop_general = 0;
                }
            }
            else
            {
                if (GUI.Button(Crypto.Rect2(416f, 0f, 64f, 64f), string.Empty, this.bt_back))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(1);
                    }
                    if (Crypto.Load_int_key("gamemode") == 0)
                    {
                        Application.LoadLevel("Map");
                    }
                    else
                    {
                        Application.LoadLevel("Extreme");
                    }
                }
                if (this.pop_general < 4)
                {
                    GUI.DrawTexture(Crypto.Rect2(16f, 182f, 40f, 40f), this.card_general[2]);
                    if (GUI.Button(Crypto.Rect2(4f, 170f, 64f, 64f), string.Empty, this.bt_empty))
                    {
                        this.giftmode = true;
                        this.bg_popui.localScale = Vector3.zero;
                    }
                    if (this.totalcount > 0)
                    {
                        GUI.DrawTexture(Crypto.Rect2(34f, 196f, (float) (this.icon_size * 0x20), 32f), this.icon_alarm);
                    }
                }
                GUI.DrawTexture(Crypto.Rect2(4f, 106f, 64f, 64f), this.bt_general_small);
                if (this.cur_general != -1)
                {
                    GUI.DrawTexture(Crypto.Rect2(16f, 118f, 40f, 40f), this.prt_general[this.cur_general]);
                    GUI.DrawTexture(Crypto.Rect2(18f, 161f, 36f * Mathf.Min((float) 1f, (float) (((float) this.general_cur_hp[this.cur_general]) / this.cur_generalmaxhp)), 4f), this.gauge_hp);
                    if (this.general_cur_hp[this.cur_general] < 20)
                    {
                        GUI.DrawTexture(Crypto.Rect2(16f, 118f, (float) (this.icon_size * 40), 40f), this.bg_red);
                    }
                    if (((this.pop_general < 4) && !this.changemode) && GUI.Button(Crypto.Rect2(4f, 106f, 64f, 64f), string.Empty, this.bt_empty))
                    {
                        this.sel_general = this.cur_general;
                        this.GeneralStat(this.general_seed[this.cur_general], true);
                        this.pop_general = 1;
                        this.bg_popui.localScale = (Vector3) (Vector3.one * 5.2f);
                        this.bg_popui.localPosition = new Vector3(0f, -0.051f, 0.5f);
                    }
                }
                else
                {
                    GUI.DrawTexture(Crypto.Rect2(16f, 118f, (float) (this.icon_size * 40), 40f), this.empty);
                    if (this.pop_general == 0)
                    {
                        GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                        GUI.Label(Crypto.Rect2(112f, 120f, 256f, 32f), Language.intxt[this.language, 0x129], "txt12_0");
                    }
                }
                if (this.pop_general > 0)
                {
                    this.GeneralMode();
                }
                if ((this.confirm == 0) && this.changemode)
                {
                    GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                    GUI.Label(Crypto.Rect2(112f, 120f, 256f, 16f), Language.intxt[this.language, 0x18a], "txt12_0");
                    if (GUI.Button(Crypto.Rect2(208f, 138f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.bg_popui.localScale = (Vector3) (Vector3.one * 5.2f);
                        this.changemode = false;
                        this.pop_general = 1;
                    }
                }
            }
            if (this.confirm > 0)
            {
                GUI.enabled = true;
                switch (this.confirm)
                {
                    case 2:
                        GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                        GUI.DrawTexture(Crypto.Rect2(160f, 98f, 160f, 18f), this.bg_titlename);
                        GUI.Label(Crypto.Rect2(120f, 98f, 240f, 16f), Language.intxt[this.language, 0xec] + " +1", "txt12_w");
                        GUI.Label(Crypto.Rect2(120f, 120f, 240f, 16f), Language.intxt[this.language, 300], "txt12_0");
                        GUI.DrawTexture(Crypto.Rect2(186f, 134f, 32f, 32f), this.icon_unlock);
                        GUI.DrawTexture(Crypto.Rect2(244f, 142f, 16f, 16f), this.icon_jade);
                        GUI.Label(Crypto.Rect2(264f, 142f, 16f, 16f), string.Empty + 3, "txt12_b");
                        GUI.Label(Crypto.Rect2(112f, 162f, 256f, 16f), Language.intxt[this.language, 350], "txt12_b");
                        if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            if (this.jade >= 3)
                            {
                                if (Crypto.Property_change(-3, true))
                                {
                                    this.Delay(1f);
                                    this.confirm = 0x12;
                                    this.jade -= 3;
                                    this.slot_general++;
                                    Crypto.Save_int_key("n09", this.slot_general);
                                    string[] textArray1 = new string[] { Language.intxt[this.language, 0xea], " (", 3.ToString(), ")\t", Language.intxt[this.language, 0xec] };
                                    PurchaseLog.LogOn(string.Concat(textArray1));
                                }
                            }
                            else
                            {
                                this.confirm = 6;
                            }
                        }
                        else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            this.confirm = 0;
                            if (this.cur_general >= 0)
                            {
                                this.sel_general = this.cur_general;
                                this.GeneralStat(this.general_seed[this.sel_general], true);
                                this.pop_general = 1;
                                this.bg_popui.localScale = (Vector3) (Vector3.one * 5.2f);
                                this.bg_popui.localPosition = new Vector3(0f, -0.051f, 0.5f);
                            }
                            else
                            {
                                this.pop_general = 0;
                            }
                        }
                        break;

                    case 3:
                        GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                        GUI.Label(Crypto.Rect2(120f, 130f, 230f, 16f), Language.intxt[this.language, 0x12a], "txt12_0");
                        if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            this.confirm = 2;
                        }
                        else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            this.confirm = 0;
                        }
                        break;

                    case 4:
                        GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                        GUI.Label(Crypto.Rect2(120f, 120f, 240f, 14f), Language.intxt[this.language, 0x12b], "txt12_0");
                        if (GUI.Button(Crypto.Rect2(170f, 138f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            this.pop_general = 0;
                            this.bg_popui.localScale = Vector3.zero;
                            this.general_seed[this.sel_general] = 0;
                            this.general_exp[this.sel_general] = 0;
                            if (this.sel_general == this.cur_general)
                            {
                                this.cur_general = -1;
                                Crypto.Save_int_key("cur_general", this.cur_general);
                            }
                            PlayerPrefsX.SetIntArray("n13", this.general_seed);
                            PlayerPrefsX.SetIntArray("n29", this.general_exp);
                            this.confirm = 5;
                            this.rnd_speech = UnityEngine.Random.Range(0x65, 0x6a);
                            this.Delay(1.5f);
                        }
                        else if (GUI.Button(Crypto.Rect2(240f, 138f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            this.confirm = 0;
                        }
                        break;

                    case 5:
                        GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                        GUI.DrawTexture(Crypto.Rect2(130f, 105f, 64f, 64f), this.prt_general[this.sel_general]);
                        GUI.Label(Crypto.Rect2(192f, 110f, 176f, 64f), this.script_name.txt_name[this.language, this.rnd_speech], "txt12_0");
                        if (this.f_delay == 0f)
                        {
                            this.confirm = 0;
                        }
                        break;

                    case 6:
                        GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                        GUI.Label(Crypto.Rect2(120f, 130f, 230f, 16f), Language.intxt[this.language, 0x15], "txt12_0");
                        if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            Crypto.Save_int_key("cashshopkind", 1);
                            this.confirm = 0;
                            this.CashshopOpen();
                        }
                        else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            this.confirm = 0;
                            if (this.cur_general >= 0)
                            {
                                this.sel_general = this.cur_general;
                                this.GeneralStat(this.general_seed[this.sel_general], true);
                                this.pop_general = 1;
                                this.bg_popui.localScale = (Vector3) (Vector3.one * 5.2f);
                            }
                            else
                            {
                                this.pop_general = 0;
                            }
                        }
                        break;

                    case 7:
                        GUI.DrawTexture(Crypto.Rect2(146f, 188f, 192f, 48f), this.bg_speech);
                        GUI.Label(Crypto.Rect2(154f, 190f, 176f, 48f), this.script_name.txt_name[this.language, this.rnd_speech], "txt12_0");
                        break;

                    case 8:
                        GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                        GUI.Label(Crypto.Rect2(120f, 130f, 240f, 16f), Language.intxt[this.language, 0x16], "txt12_0");
                        if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            Crypto.Save_int_key("cashshopkind", 2);
                            this.confirm = 0;
                            this.CashshopOpen();
                        }
                        else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            this.confirm = 0;
                        }
                        break;

                    case 9:
                        GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                        GUI.Label(Crypto.Rect2(120f, 110f, 240f, 64f), Language.intxt[this.language, 0x10b], "txt12_0");
                        if (this.f_delay == 0f)
                        {
                            this.confirm = 0;
                        }
                        break;

                    case 10:
                        GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                        GUI.Label(Crypto.Rect2(120f, 120f, 240f, 14f), Language.intxt[this.language, 0xb6], "txt12_b");
                        if (GUI.Button(Crypto.Rect2(170f, 138f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(0);
                            }
                            this.confirm = 0;
                            this.pop_general = 6;
                            this.bg_combine.gameObject.active = true;
                            this.Delay(1f);
                            this.get_exp = (110 + (this.g_grade * 100)) + this.general_exp[this.sel_general];
                            for (int num11 = 0; num11 < (this.g_level - 1); num11++)
                            {
                                this.get_exp += ((100 + (num11 * 6)) * (1f + (this.g_grade * 0.2f))) + 10f;
                            }
                        }
                        else if (GUI.Button(Crypto.Rect2(240f, 138f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                        {
                            if (this.sound_UI != null)
                            {
                                this.script_soundUI.SoundOn(1);
                            }
                            this.confirm = 0;
                        }
                        break;

                    case 0x10:
                        GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                        GUI.Label(Crypto.Rect2(120f, 110f, 240f, 64f), Language.intxt[this.language, 0x62], "txt12_0");
                        if (this.f_delay == 0f)
                        {
                            this.confirm = 0;
                        }
                        break;

                    case 0x11:
                        GUI.Box(Crypto.Rect2(112f, 140f, 256f, 32f), Language.intxt[this.language, 0x103]);
                        if (this.f_delay == 0f)
                        {
                            this.confirm = 0;
                        }
                        break;

                    case 0x12:
                        GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                        GUI.Label(Crypto.Rect2(120f, 110f, 240f, 64f), Language.intxt[this.language, 0x188], "txt12_0");
                        if (this.f_delay != 0f)
                        {
                            break;
                        }
                        if (!this.giftmode && (this.cur_general >= 0))
                        {
                            this.sel_general = this.cur_general;
                            this.GeneralStat(this.general_seed[this.sel_general], true);
                            this.pop_general = 1;
                            this.bg_popui.localScale = (Vector3) (Vector3.one * 5.2f);
                            this.bg_popui.localPosition = new Vector3(0f, -0.051f, 0.5f);
                        }
                        this.confirm = 0;
                        return;
                }
            }
        }
    }

    private void SetGiftCount()
    {
        this.totalcount = 0;
        this.temp_general_cardtype = new int[50];
        this.cardtype_count = new int[3];
        for (int i = 0; i < 50; i++)
        {
            if (this.temp_general[i] != 0)
            {
                int num2 = this.temp_general[i] / 0x989680;
                this.temp_general_cardtype[i] = num2;
                this.cardtype_count[num2 - 1]++;
                this.totalcount++;
            }
        }
    }

    private void SetServerTime()
    {
        TimeControl.RequestServerTime();
        this.DelayWorkTime();
    }

    private void Start()
    {
        this.dragrange = Screen.height * 0.375f;
        if (GameObject.FindWithTag("sound") == null)
        {
            this.sound_UI = (Transform) UnityEngine.Object.Instantiate(this.sound_dummy, Vector3.zero, Quaternion.identity);
        }
        else
        {
            this.sound_UI = GameObject.FindWithTag("sound").transform;
        }
        this.script_soundUI = this.sound_UI.GetComponent<SoundEf_UI>();
        this.GeneralKindOnly();
        this.CurGeneralStat(true);
        this.SetServerTime();
        base.InvokeRepeating("SetServerTime", 29f, 30f);
        if (PlayerPrefs.GetInt("n57") == 1)
        {
            this.confirm = 2;
            PlayerPrefs.SetInt("n57", 0);
        }
        else if (this.cur_general >= 0)
        {
            this.sel_general = this.cur_general;
            this.GeneralStat(this.general_seed[this.sel_general], true);
            this.pop_general = 1;
            this.bg_popui.localPosition = new Vector3(0f, -0.051f, 0.4f);
            this.bg_popui.localScale = (Vector3) (Vector3.one * 5.2f);
        }
        base.InvokeRepeating("Warning_iconsize", 1f, 0.34f);
        this.SetGiftCount();
    }

    private void Update()
    {
        if (this.b_delay)
        {
            this.f_delay -= Time.deltaTime;
            if (this.f_delay <= 0f)
            {
                this.b_delay = false;
                this.f_delay = 0f;
            }
        }
        if (this.showcard > 0)
        {
            if (this.showcard == 3)
            {
                this.showcard_delay -= Time.deltaTime;
                if (this.showcard_delay < 0f)
                {
                    int num = this.temp_general[this.typeslot];
                    this.general_seed[this.getslot] = num;
                    this.GeneralKindOnly();
                    this.GeneralStat(num, false);
                    this.temp_general[this.typeslot] = 0;
                    PlayerPrefsX.SetIntArray("n53", this.temp_general);
                    PlayerPrefsX.SetIntArray("n13", this.general_seed);
                    this.SetGiftCount();
                    this.sel_general = this.getslot;
                    this.showcard = 4;
                    this.bg_popui.localScale = (Vector3) (Vector3.one * 5.2f);
                }
                this.bg_popui.localScale = Vector3.MoveTowards(this.bg_popui.localScale, (Vector3) (Vector3.one * 5.2f), Time.deltaTime * 20f);
            }
            else if (this.showcard == 2)
            {
                this.showcard_delay -= Time.deltaTime;
                if (this.showcard_delay < 0f)
                {
                    this.showcard = 3;
                    this.bg_card.gameObject.active = false;
                    this.showcard_delay = 0.5f;
                }
            }
            else if (this.showcard == 1)
            {
                this.bg_card.position = Vector3.MoveTowards(this.bg_card.position, new Vector3(0f, 0.05f, 0.5f), Time.deltaTime * 2f);
                this.showcard_delay -= Time.deltaTime;
                if (this.showcard_delay < 0f)
                {
                    this.bg_card.GetChild(0).particleEmitter.Emit();
                    this.bg_card.GetChild(1).particleEmitter.Emit();
                    this.showcard = 2;
                    this.showcard_delay = 0.5f;
                }
            }
        }
        else if (this.giftmode)
        {
            this.cardposY = Mathf.MoveTowards(this.cardposY, 110f, Time.deltaTime * 800f);
        }
        if (Input.GetMouseButtonDown(0))
        {
            if (Input.mousePosition.y < this.dragrange)
            {
                this.dragOn = true;
                this.prevposX = Input.mousePosition.x;
                this.currentX = this.dragposX;
            }
        }
        else if (Input.GetMouseButtonUp(0))
        {
            this.dragOn = false;
            this.scrollOn = false;
        }
        if (this.dragOn)
        {
            if (Mathf.Abs((float) (Input.mousePosition.x - this.prevposX)) > 8f)
            {
                this.scrollOn = true;
            }
            this.dragposX = ((Input.mousePosition.x - this.prevposX) * (480f / ((float) Screen.width))) + this.currentX;
            this.dragposX = Mathf.Min(this.dragposX, 0f);
            this.dragposX = Mathf.Max(this.dragposX, -452f);
        }
        if (this.pop_general >= 8)
        {
            this.bg_popui.localScale = Vector3.MoveTowards(this.bg_popui.localScale, (Vector3) (Vector3.one * 5.2f), Time.deltaTime * 30f);
            this.posX1 = Mathf.MoveTowards(this.posX1, 140f, Time.deltaTime * 100f);
            this.posX2 = Mathf.MoveTowards(this.posX2, 276f, Time.deltaTime * 100f);
            if ((this.pop_general == 9) && (this.f_delay == 0f))
            {
                this.general_exp[this.sel_general] = 0;
                this.general_seed[this.sel_general] = 0;
                PlayerPrefsX.SetIntArray("n13", this.general_seed);
                PlayerPrefsX.SetIntArray("n29", this.general_exp);
                if (this.sel_general == this.cur_general)
                {
                    this.cur_general = -1;
                    Crypto.Save_int_key("cur_general", this.cur_general);
                }
                this.pop_general = 10;
                this.sel_general = this.comb_general;
                this.g_exp_length = this.comb_exp_length;
                this.GeneralStat(this.general_seed[this.sel_general], true);
                this.general_level[this.sel_general] = this.g_level;
                if (this.tutorial == 4)
                {
                    this.tutorial = -3;
                    Crypto.Save_int_key("tutorial", -3);
                    this.confirm = 0x11;
                    this.Delay(1f);
                }
            }
            if ((this.pop_general == 8) && (this.f_delay == 0f))
            {
                this.pop_general = 9;
                this.ef_card_dis.gameObject.active = true;
                this.Delay(0.8f);
                this.confirm = 0;
            }
        }
        else if (this.pop_general >= 6)
        {
            this.posX1 = Mathf.MoveTowards(this.posX1, 100f, Time.deltaTime * 100f);
            this.posX2 = Mathf.MoveTowards(this.posX2, 316f, Time.deltaTime * 100f);
            this.iconmove = Vector2.MoveTowards(this.iconmove, (Vector2) ((Vector2.right * this.posX2) + (Vector2.up * 97f)), Time.deltaTime * 1000f);
            this.bg_posX_r = Mathf.MoveTowards(this.bg_posX_r, 480f, Time.deltaTime * 1500f);
            this.icon_posY = Mathf.MoveTowards(this.icon_posY, 340f, Time.deltaTime * 500f);
            this.bg_popui.localScale = Vector3.MoveTowards(this.bg_popui.localScale, Vector3.zero, Time.deltaTime * 30f);
            this.bg_combine.localScale = Vector3.MoveTowards(this.bg_combine.localScale, new Vector3(2.5f, 10f, 1f), Time.deltaTime * 30f);
            if (this.pop_general == 6)
            {
                if (this.f_delay == 0f)
                {
                    this.pop_general = 7;
                    this.bg_combine.GetChild(0).particleEmitter.emit = true;
                    this.ef_card_l.gameObject.active = true;
                    this.ef_card_r.gameObject.active = true;
                    this.Delay(2f);
                }
            }
            else if (this.pop_general == 7)
            {
                if (!this.gaugeup)
                {
                    this.get_exp -= (100 + (this.comb_level * 6)) * Time.deltaTime;
                    this.comb_exp += (100 + (this.comb_level * 6)) * Time.deltaTime;
                    if (this.comb_exp >= ((100 + (this.comb_level * 6)) * (1f + (this.comb_grade * 0.2f))))
                    {
                        this.comb_level = (short) (this.comb_level + 1);
                        this.comb_exp = 0f;
                        this.comb_get_level = (short) (this.comb_get_level + 1);
                        if (this.comb_level >= ((this.comb_grade + 1) * 20))
                        {
                            this.get_exp = 0f;
                        }
                    }
                    if (this.get_exp <= 0f)
                    {
                        this.general_exp[this.comb_general] = (int) this.comb_exp;
                        this.general_seed[this.comb_general] += 0x989680 * this.comb_get_level;
                        this.gaugeup = true;
                    }
                    this.comb_exp_length = (this.comb_exp * 58f) / ((100 + (this.comb_level * 6)) * (1f + (this.comb_grade * 0.2f)));
                }
                if ((this.f_delay == 0f) && this.gaugeup)
                {
                    this.bg_combine.gameObject.active = false;
                    this.bg_combine.GetChild(0).particleEmitter.emit = false;
                    this.ef_card_l.gameObject.active = false;
                    this.ef_card_r.gameObject.active = false;
                    this.pop_general = 8;
                    this.Delay(1.5f);
                    this.confirm = 7;
                    this.rnd_speech = UnityEngine.Random.Range(0x60, 0x65);
                }
            }
        }
        else if (this.pop_general == 5)
        {
            this.iconmove = Vector2.MoveTowards(this.iconmove, (Vector2) ((Vector2.right * this.posX2) + (Vector2.up * 97f)), Time.deltaTime * 1000f);
        }
        else
        {
            this.bg_posX_r = Mathf.MoveTowards(this.bg_posX_r, 0f, Time.deltaTime * 1500f);
            this.icon_posY = Mathf.MoveTowards(this.icon_posY, 250f, Time.deltaTime * 500f);
        }
    }

    public void Warning_iconsize()
    {
        this.icon_size = (this.icon_size + 1) % 2;
    }
}


using System;
using UnityEngine;

public class Bullet_Angel4 : MonoBehaviour
{
    private Transform[] c_spear = new Transform[6];
    private int curFire;
    private int dx = 1;
    private ParticleEmitter ef_splash;
    private const int MAXBULLET = 6;
    private Transform mytransform;
    private AI_Asist script_angel;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.script_angel = GameObject.Find("asist").GetComponent<AI_Asist>();
        for (int i = 0; i < 6; i++)
        {
            this.c_spear[i] = this.mytransform.GetChild(i);
            this.c_spear[i].GetComponent<Bullet_Angel4_m>().Init(this.dx);
            this.dx *= -1;
        }
        this.ef_splash = this.mytransform.GetChild(6).particleEmitter;
        base.gameObject.active = false;
    }

    private void FireOn()
    {
        this.c_spear[this.curFire].position = this.mytransform.position;
        this.c_spear[this.curFire].gameObject.active = true;
        this.curFire++;
        if (this.curFire >= 6)
        {
            base.CancelInvoke();
            this.script_angel.AttackFinish();
            base.gameObject.active = false;
        }
    }

    private void OnEnable()
    {
        this.curFire = 0;
        base.InvokeRepeating("FireOn", 0.1f, 0.2f);
    }

    public void SplashOn(Vector3 _pos)
    {
        _pos.y = 0f;
        this.ef_splash.transform.position = _pos;
        this.ef_splash.Emit();
    }

    private void Update()
    {
    }
}


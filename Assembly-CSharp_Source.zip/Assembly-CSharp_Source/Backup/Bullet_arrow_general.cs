using System;
using UnityEngine;

public class Bullet_arrow_general : MonoBehaviour
{
    public float accel_factor = 3f;
    private float accel_speed;
    public float bullet_speed;
    private float delay;
    public float delay_finish = 3f;
    public int growspeed = 2;
    private Transform mytransform;
    private Vector3 originscale;
    private Vector3 startscale;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.originscale = this.mytransform.localScale;
        this.startscale = this.originscale;
        this.startscale[2] = 0f;
    }

    private void OnEnable()
    {
        this.mytransform.GetChild(0).particleEmitter.emit = true;
        this.mytransform.localScale = this.startscale;
        this.accel_speed = -1f;
        this.delay = 0f;
    }

    private void Update()
    {
        this.mytransform.localScale = Vector3.MoveTowards(this.mytransform.localScale, this.originscale, Time.deltaTime * this.growspeed);
        this.accel_speed = Mathf.MoveTowards(this.accel_speed, this.bullet_speed, Time.deltaTime * this.accel_factor);
        this.delay += Time.deltaTime;
        if (this.delay > this.delay_finish)
        {
            base.gameObject.active = false;
            this.mytransform.GetChild(0).particleEmitter.emit = false;
            this.delay = 0f;
        }
        if (this.accel_speed > 0f)
        {
            this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * this.accel_speed);
        }
    }
}


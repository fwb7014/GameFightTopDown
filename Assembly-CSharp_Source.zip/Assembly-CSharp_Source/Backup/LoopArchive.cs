using System;
using UnityEngine;

public class LoopArchive : MonoBehaviour
{
    private int[] bosskill = new int[12];
    private int cashing;
    private int caveplay;
    private int[] complete_archive = new int[0x4c];
    private int[] cur_skill_grade = new int[20];
    private int death;
    private int enemykill;
    private int exattack;
    private int generalsearch;
    private bool gift_archive;
    private int grappling;
    private int max_stage_index = -1;
    private const int MAXARCHIVE = 0x4c;
    private const int MAXGENERALPOOL = 30;
    private const int MAXSKILL = 20;
    private int perfectplay;
    private int[] pet_skill_use = new int[2];
    private int remain_arch;
    private int resurrection;
    private DB_Archive script_archive;
    private int[] skill_use = new int[20];
    private int[] temp_staff = new int[30];
    private int[] temp_treasure = new int[0x18];
    private int[] unlock_costume = new int[20];

    private void Awake()
    {
        this.complete_archive = PlayerPrefsX.GetIntArray("archive");
        this.bosskill = PlayerPrefsX.GetIntArray("bosskill");
        this.skill_use = PlayerPrefsX.GetIntArray("skill_use");
        this.pet_skill_use = PlayerPrefsX.GetIntArray("pet_skill_use");
        this.enemykill = Crypto.Load_int_key("enemykill");
        this.grappling = Crypto.Load_int_key("grappling");
        this.exattack = Crypto.Load_int_key("exattack");
        this.death = Crypto.Load_int_key("death");
        this.resurrection = Crypto.Load_int_key("resurrection");
        this.max_stage_index = Crypto.Load_int_key("n06");
        this.unlock_costume = PlayerPrefsX.GetIntArray("n18");
        this.script_archive = base.GetComponent<DB_Archive>();
        this.cur_skill_grade = PlayerPrefsX.GetIntArray("n22");
        this.caveplay = Crypto.Load_int_key("caveplay");
        this.perfectplay = Crypto.Load_int_key("perfectplay");
    }

    public bool FindArchive()
    {
        this.temp_staff = PlayerPrefsX.GetIntArray("staff");
        this.generalsearch = Crypto.Load_int_key("generalsearch");
        this.cashing = Crypto.Load_int_key("cashing");
        for (int i = 0; i < 0x4c; i++)
        {
            int num2;
            int num3;
            int num4;
            int num5;
            int num6;
            int num7;
            int num8;
            int num9;
            int num10;
            if (this.complete_archive[i] == 0)
            {
                this.remain_arch++;
                switch (this.script_archive.aci[i]._require_kind)
                {
                    case 1:
                        if (this.enemykill >= this.script_archive.aci[i]._require_amount)
                        {
                            this.gift_archive = true;
                        }
                        break;

                    case 2:
                        if (this.grappling >= this.script_archive.aci[i]._require_amount)
                        {
                            this.gift_archive = true;
                        }
                        break;

                    case 3:
                        if (this.death >= this.script_archive.aci[i]._require_amount)
                        {
                            this.gift_archive = true;
                        }
                        break;

                    case 4:
                        if (this.resurrection >= this.script_archive.aci[i]._require_amount)
                        {
                            this.gift_archive = true;
                        }
                        break;

                    case 5:
                        if (this.exattack >= this.script_archive.aci[i]._require_amount)
                        {
                            this.gift_archive = true;
                        }
                        break;

                    case 6:
                        num2 = 0;
                        goto Label_01CE;

                    case 7:
                        if (this.max_stage_index >= this.script_archive.aci[i]._require_amount)
                        {
                            this.gift_archive = true;
                        }
                        break;

                    case 8:
                        if (this.bosskill[this.script_archive.aci[i]._require_kind_sub] >= this.script_archive.aci[i]._require_amount)
                        {
                            this.gift_archive = true;
                        }
                        break;

                    case 9:
                        if (this.pet_skill_use[this.script_archive.aci[i]._require_kind_sub] >= this.script_archive.aci[i]._require_amount)
                        {
                            this.gift_archive = true;
                        }
                        break;

                    case 10:
                        if (this.skill_use[this.script_archive.aci[i]._require_kind_sub] >= this.script_archive.aci[i]._require_amount)
                        {
                            this.gift_archive = true;
                        }
                        break;

                    case 11:
                        if (this.generalsearch >= this.script_archive.aci[i]._require_amount)
                        {
                            this.gift_archive = true;
                        }
                        break;

                    case 12:
                        num3 = 0;
                        num4 = 0;
                        goto Label_0320;

                    case 13:
                        num5 = 0;
                        num6 = 0;
                        goto Label_0361;

                    case 14:
                        num7 = 0;
                        num8 = 0;
                        goto Label_03B9;

                    case 15:
                        if (this.caveplay >= this.script_archive.aci[i]._require_amount)
                        {
                            this.gift_archive = true;
                        }
                        break;

                    case 0x10:
                        if (this.perfectplay >= this.script_archive.aci[i]._require_amount)
                        {
                            this.gift_archive = true;
                        }
                        break;

                    case 0x12:
                        if (this.cashing >= this.script_archive.aci[i]._require_amount)
                        {
                            this.gift_archive = true;
                        }
                        break;

                    case 0x13:
                        num9 = 0;
                        num10 = 0;
                        goto Label_0498;

                    case 20:
                        if (this.remain_arch <= 0)
                        {
                            this.gift_archive = true;
                        }
                        break;
                }
            }
            continue;
        Label_01B0:
            if (this.temp_staff[num2] == 5)
            {
                this.gift_archive = true;
                continue;
            }
            num2++;
        Label_01CE:
            if (num2 < 30)
            {
                goto Label_01B0;
            }
            continue;
        Label_030A:
            if (this.temp_staff[num4] >= 4)
            {
                num3++;
            }
            num4++;
        Label_0320:
            if (num4 < 30)
            {
                goto Label_030A;
            }
            if (num3 >= 5)
            {
                this.gift_archive = true;
            }
            continue;
        Label_0346:
            if (this.cur_skill_grade[num6] >= 0)
            {
                num5++;
            }
            num6++;
        Label_0361:
            if (num6 < 20)
            {
                goto Label_0346;
            }
            if (num5 >= this.script_archive.aci[i]._require_amount)
            {
                this.gift_archive = true;
            }
            continue;
        Label_039E:
            if (this.cur_skill_grade[num8] >= 4)
            {
                num7++;
            }
            num8++;
        Label_03B9:
            if (num8 < 20)
            {
                goto Label_039E;
            }
            if (num7 >= this.script_archive.aci[i]._require_amount)
            {
                this.gift_archive = true;
            }
            continue;
        Label_047D:
            if (this.unlock_costume[num10] > 0)
            {
                num9++;
            }
            num10++;
        Label_0498:
            if (num10 < 20)
            {
                goto Label_047D;
            }
            if (num9 >= this.script_archive.aci[i]._require_amount)
            {
                this.gift_archive = true;
            }
        }
        return this.gift_archive;
    }

    public bool FindTreasure()
    {
        this.temp_treasure = PlayerPrefsX.GetIntArray("treasure");
        for (int i = 0; i < 6; i++)
        {
            int num2 = 0;
            if (this.temp_treasure[4 * i] > 0)
            {
                num2++;
            }
            if (this.temp_treasure[(4 * i) + 1] > 0)
            {
                num2++;
            }
            if (this.temp_treasure[(4 * i) + 2] > 0)
            {
                num2++;
            }
            if (this.temp_treasure[(4 * i) + 3] > 0)
            {
                num2++;
            }
            if (num2 == 4)
            {
                return true;
            }
        }
        return false;
    }
}


using System;
using UnityEngine;

public class Sk_machinegun : MonoBehaviour
{
    public Transform beam1;
    public Transform beam2;
    private float delay;
    private Collider mycollider;
    private Transform mytransform;
    private bool shooton;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
        base.animation["shoot"].speed = 0.2f;
        base.animation["creat"].speed = 0.5f;
        base.animation["destroy"].speed = 0.4f;
    }

    private void OnEnable()
    {
        this.shooton = false;
        this.delay = 0f;
        base.InvokeRepeating("Shoot", 0.8f, 0.2f);
        base.animation.Play("creat");
        this.beam1.particleEmitter.emit = false;
        this.beam2.particleEmitter.emit = false;
        this.mycollider.enabled = false;
    }

    public void Shoot()
    {
        this.mycollider.enabled = false;
        this.mycollider.enabled = true;
    }

    private void Start()
    {
    }

    private void Update()
    {
        this.delay += Time.deltaTime;
        if (this.delay > 4.5f)
        {
            base.gameObject.active = false;
            this.mytransform.position = (Vector3) (Vector3.one * 40f);
            this.mytransform.parent = null;
        }
        else if (this.delay > 4f)
        {
            this.beam1.particleEmitter.emit = false;
            this.beam2.particleEmitter.emit = false;
            base.animation.Play("destroy");
            base.CancelInvoke("Shoot");
            this.mycollider.enabled = false;
        }
        else if ((this.delay > 0.6f) && !this.shooton)
        {
            this.shooton = true;
            this.beam1.particleEmitter.emit = true;
            this.beam2.particleEmitter.emit = true;
            base.animation.Play("shoot");
        }
    }
}


using System;
using UnityEngine;

public class Delay_extraEf : MonoBehaviour
{
    private float dis_delay;

    private void OnEnable()
    {
        base.animation.Play("uvU_rotY");
        this.dis_delay = 3f;
    }

    private void Start()
    {
    }

    private void Update()
    {
        this.dis_delay -= Time.deltaTime;
        if (this.dis_delay <= 0f)
        {
            base.gameObject.active = false;
            base.animation.Stop();
        }
    }
}


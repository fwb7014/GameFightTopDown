using System;
using UnityEngine;

public class UI_result : MonoBehaviour
{
    private bool b_getgem;
    private bool b_openshop;
    public GUISkin basicSkin;
    public Texture2D bg_asset;
    public Texture2D bg_gauge;
    public Texture2D bg_list;
    public Texture2D bg_speech2;
    public AudioClip bgm_defeat;
    public AudioClip bgm_victory;
    public GUIStyle bt_empty;
    private GameObject cashshop;
    private int chaexp;
    private int chalv;
    private int changelevel;
    private int clear_grade;
    private int coin;
    private int cur_difficulty;
    private int cur_stage_index;
    private int[] curtraining = new int[6];
    private int dropcoin;
    private int dropjade;
    private bool[] efon = new bool[3];
    public Texture2D gauge_exp;
    private int getcoin;
    private float getcoin_f;
    private int getexp;
    private float getexp_f;
    private bool getpoint = true;
    private bool gonext;
    public Texture2D icon_coin;
    public Texture2D icon_jade;
    public Texture2D[] icon_mission = new Texture2D[3];
    private short icon_pluspos;
    private float[] icon_size = new float[] { 300f, 300f, 300f };
    public Texture2D[] img_bts = new Texture2D[5];
    public Transform inven_weapon;
    public int isclear;
    private int jade;
    private int language;
    public int max_stage_index;
    private short[] mission_archive_already = new short[3];
    private short[] mission_archive_current = new short[3];
    private bool movefinish;
    private bool openbox;
    private float posX = 1000f;
    public Transform pt_star;
    private Transform ranking;
    private float show_delay;
    public Texture2D star_big;
    private bool starmove;
    private bool startexpgain;
    private bool trainmax;

    public void AmountCoin(int _coin)
    {
        this.coin = _coin;
    }

    public void AmountJade(int _jade)
    {
        this.jade = _jade;
    }

    private void Awake()
    {
        int num = Crypto.Load_int_key("stage_clear");
        this.cur_difficulty = Crypto.Load_int_key("n14");
        this.isclear = (short) (num / 0x3e8);
        this.clear_grade = num % 0x3e8;
        for (int i = 0; i < 3; i++)
        {
            this.mission_archive_current[i] = (short) (this.clear_grade % 10);
            this.clear_grade /= 10;
        }
        int[] intArray = PlayerPrefsX.GetIntArray("n15");
        this.cur_stage_index = Crypto.Load_int_key("cur_stage_index");
        this.max_stage_index = Crypto.Load_int_key("n06");
        int num3 = 0;
        if (this.max_stage_index < 5)
        {
            UnityEngine.Object.Destroy(GameObject.Find("pet_eagle_UI"));
        }
        num3 = intArray[this.cur_stage_index];
        for (int j = 0; j < 3; j++)
        {
            this.mission_archive_already[j] = (short) (num3 % 10);
            num3 /= 10;
        }
        int num5 = 0;
        if ((this.mission_archive_already[2] + this.mission_archive_current[2]) > 0)
        {
            num5 += 100;
        }
        if ((this.mission_archive_already[1] + this.mission_archive_current[1]) > 0)
        {
            num5 += 10;
        }
        if ((this.mission_archive_already[0] + this.mission_archive_current[0]) > 0)
        {
            num5++;
        }
        intArray[this.cur_stage_index] = num5;
        PlayerPrefsX.SetIntArray("n15", intArray);
        Time.timeScale = 1f;
    }

    public void CashshopOpen(int _kind)
    {
        Crypto.Save_int_key("cashshopkind", _kind);
        if (this.cashshop == null)
        {
            this.cashshop = Resources.Load("CashShop") as GameObject;
        }
        UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
    }

    public void GetGem()
    {
        this.b_getgem = true;
    }

    public void GoNext()
    {
        this.gonext = true;
    }

    private void OnEnable()
    {
        this.coin = Crypto.Load_int_key("n17");
        this.jade = Crypto.Load_int_key("n24");
        this.inven_weapon.gameObject.GetComponent<Inventory_Weapon>().EnableGUI();
    }

    private void OnGUI()
    {
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.skin = this.basicSkin;
        GUI.Box(Crypto.Rect2(380f, 4f, 80f, 20f), Language.intxt[this.language, 0x40] + " " + (this.cur_stage_index + 1));
        if (this.b_openshop)
        {
            GUI.DrawTexture(Crypto.Rect2(112f, 0f, 256f, 32f), this.bg_asset);
            GUI.Label(Crypto.Rect2(146f, 6f, 80f, 14f), string.Empty + this.coin, "txt12_w");
            GUI.Label(Crypto.Rect2(280f, 6f, 64f, 14f), string.Empty + this.jade, "txt12_w");
            if (GUI.Button(Crypto.Rect2(144f, 2f, 100f, 24f), string.Empty, this.bt_empty))
            {
                this.CashshopOpen(2);
            }
            if (GUI.Button(Crypto.Rect2(272f, 2f, 88f, 24f), string.Empty, this.bt_empty))
            {
                this.CashshopOpen(1);
            }
        }
        if (this.isclear > -1)
        {
            GUI.DrawTexture(Crypto.Rect2(this.posX, 44f, 180f, 190f), this.bg_list);
            GUI.DrawTexture(Crypto.Rect2(this.posX + 26f, 137f, 16f, 16f), this.icon_coin);
            GUI.Label(Crypto.Rect2(this.posX + 76f, 138f, 124f, 14f), string.Empty + ((int) this.getcoin_f), "txt12_0");
            GUI.DrawTexture(Crypto.Rect2(this.posX + 55f, 118f, 114f, 14f), this.bg_gauge);
            GUI.Label(Crypto.Rect2(this.posX + 4f, 118f, 50f, 16f), "      " + this.chalv, "txt14_w");
            GUI.DrawTexture(Crypto.Rect2(this.posX + 57f, 120f, (this.getexp_f * 112f) / ((float) (this.chalv * 100)), 10f), this.gauge_exp);
            GUI.Label(Crypto.Rect2(this.posX, 98f, 180f, 16f), Language.intxt[this.language, 0x106], "txt14_w");
            GUI.Label(Crypto.Rect2(this.posX, 167f, 180f, 16f), Language.intxt[this.language, 0x107], "txt14_w");
            GUI.DrawTexture(Crypto.Rect2(this.posX + 26f, 186f, 16f, 16f), this.icon_coin);
            GUI.DrawTexture(Crypto.Rect2(this.posX + 26f, 206f, 16f, 16f), this.icon_jade);
            GUI.Label(Crypto.Rect2(this.posX + 76f, 187f, 124f, 14f), string.Empty + this.dropcoin, "txt12_0");
            GUI.Label(Crypto.Rect2(this.posX + 76f, 207f, 124f, 14f), string.Empty + this.dropjade, "txt12_0");
            for (int i = 0; i < 3; i++)
            {
                if (this.mission_archive_already[i] > 0)
                {
                    GUI.DrawTexture(Crypto.Rect2((float) (0x115 + (50 * i)), 34f, 64f, 64f), this.star_big);
                }
            }
            if (this.starmove)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (this.mission_archive_current[j] > 0)
                    {
                        if (!this.efon[j])
                        {
                            GUI.DrawTexture(Crypto.Rect2((0x115 + (50 * j)) - (this.icon_size[j] * 3f), 34f, this.icon_size[j] + 64f, this.icon_size[j] + 64f), this.star_big);
                        }
                        else
                        {
                            GUI.DrawTexture(Crypto.Rect2((0x115 + (50 * j)) - (this.icon_size[j] * 0.5f), 34f - (this.icon_size[j] * 0.5f), this.icon_size[j] + 64f, this.icon_size[j] + 64f), this.star_big);
                        }
                    }
                    GUI.DrawTexture(Crypto.Rect2((float) (0x125 + (50 * j)), 50f, 32f, 32f), this.icon_mission[j]);
                }
            }
        }
        if (this.gonext)
        {
            GUI.DrawTexture(Crypto.Rect2(400f, 250f, 64f, 64f), this.img_bts[0]);
            if (GUI.Button(Crypto.Rect2(400f, 250f, 64f, 64f), Language.intxt[this.language, 0xca], this.bt_empty))
            {
                Application.LoadLevel("Map");
            }
            if (this.isclear == 0)
            {
                this.icon_pluspos = 0x4c;
                GUI.DrawTexture(Crypto.Rect2(324f, 250f, 64f, 64f), this.img_bts[1]);
                if (GUI.Button(Crypto.Rect2(324f, 250f, 64f, 64f), Language.intxt[this.language, 0xc9], this.bt_empty))
                {
                    Application.LoadLevel("Stage");
                }
            }
            else if (((this.isclear == 2) || this.b_getgem) && (this.max_stage_index >= 3))
            {
                this.icon_pluspos = 0x4c;
                GUI.DrawTexture(Crypto.Rect2(324f, 250f, 64f, 64f), this.img_bts[3]);
                if (GUI.Button(Crypto.Rect2(324f, 250f, 64f, 64f), Language.intxt[this.language, 0x18e], this.bt_empty))
                {
                    Application.LoadLevel("Forge");
                }
            }
            if (this.changelevel == 1)
            {
                GUI.DrawTexture(Crypto.Rect2((float) (0x144 - this.icon_pluspos), 250f, 64f, 64f), this.img_bts[2]);
                if (GUI.Button(Crypto.Rect2((float) (0x144 - this.icon_pluspos), 250f, 64f, 64f), Language.intxt[this.language, 0x18b], this.bt_empty))
                {
                    Application.LoadLevel("Skill");
                }
                GUI.DrawTexture(Crypto.Rect2((float) (0xc6 - this.icon_pluspos), 256f, 128f, 64f), this.bg_speech2);
                GUI.Label(Crypto.Rect2((float) (0xce - this.icon_pluspos), 264f, 112f, 32f), Language.intxt[this.language, 0x105], "txt12_0");
            }
            else if (((this.isclear == 0) && (this.max_stage_index >= 3)) && !this.trainmax)
            {
                GUI.DrawTexture(Crypto.Rect2((float) (0x144 - this.icon_pluspos), 250f, 64f, 64f), this.img_bts[4]);
                if (GUI.Button(Crypto.Rect2((float) (0x144 - this.icon_pluspos), 250f, 64f, 64f), Language.intxt[this.language, 0x18d], this.bt_empty))
                {
                    Application.LoadLevel("Status");
                }
                GUI.DrawTexture(Crypto.Rect2((float) (0xc6 - this.icon_pluspos), 256f, 128f, 64f), this.bg_speech2);
                GUI.Label(Crypto.Rect2((float) (0xce - this.icon_pluspos), 264f, 112f, 32f), Language.intxt[this.language, 0x12d], "txt12_0");
            }
        }
    }

    public void OpenShop()
    {
        this.b_openshop = true;
    }

    private void Start()
    {
        float num3;
        this.language = PlayerPrefs.GetInt("language");
        base.audio.volume = PlayerPrefs.GetFloat("vol_bgm");
        AudioListener.volume = PlayerPrefs.GetFloat("vol_master");
        this.dropjade = Crypto.Load_int_key("n58");
        this.dropcoin = Crypto.Load_int_key("n59");
        Crypto.Save_int_key("n58", 0);
        Crypto.Save_int_key("n59", 0);
        this.coin -= this.dropcoin;
        this.jade -= this.dropjade;
        this.chalv = Crypto.Load_int_key("n47");
        this.chaexp = Crypto.Load_int_key("n11");
        this.getexp_f = this.chaexp;
        if (this.chalv < 0x13)
        {
            this.changelevel = Crypto.Load_int_key("changelevel");
            if ((this.changelevel == 1) && ((this.chalv % 2) == 1))
            {
                this.changelevel = 1;
            }
            else
            {
                this.changelevel = 0;
            }
        }
        Crypto.Save_int_key("changelevel", 0);
        if (this.isclear != 0)
        {
            num3 = 1f;
            switch (this.cur_difficulty)
            {
                case 0:
                    num3 = 1f;
                    break;

                case 1:
                    num3 = 1.1f;
                    break;

                case 2:
                    num3 = 1.5f;
                    break;
            }
        }
        else
        {
            this.getcoin = 0;
            this.getexp = 0;
            base.audio.clip = this.bgm_defeat;
            base.audio.Play();
            this.curtraining = PlayerPrefsX.GetIntArray("n20");
            int num = 0;
            for (int i = 0; i < 6; i++)
            {
                if (this.curtraining[i] < 10)
                {
                    break;
                }
                num++;
            }
            if (num == 6)
            {
                this.trainmax = true;
            }
            return;
        }
        this.getcoin = (int) (((this.cur_stage_index * 2) + 100) * num3);
        this.getexp = (this.cur_stage_index + 5) * 20;
        base.audio.clip = this.bgm_victory;
        base.audio.Play();
    }

    private void Update()
    {
        if (!this.movefinish)
        {
            this.posX = Mathf.MoveTowards(this.posX, 270f, Time.deltaTime * 1200f);
            if ((this.posX == 270f) && (this.isclear > 0))
            {
                this.icon_size[0] = Mathf.MoveTowards(this.icon_size[0], 0f, Time.deltaTime * 800f);
                if (this.icon_size[0] == 0f)
                {
                    if (!this.efon[0])
                    {
                        if (this.mission_archive_current[0] > 0)
                        {
                            UnityEngine.Object.Instantiate(this.pt_star, new Vector3(-0.44f, 0.55f, 0.1f), Quaternion.identity);
                        }
                        this.icon_size[0] = 80f;
                        this.efon[0] = true;
                    }
                    this.icon_size[1] = Mathf.MoveTowards(this.icon_size[1], 0f, Time.deltaTime * 800f);
                    if (this.icon_size[1] == 0f)
                    {
                        if (!this.efon[1])
                        {
                            if (this.mission_archive_current[1] > 0)
                            {
                                UnityEngine.Object.Instantiate(this.pt_star, new Vector3(-0.74f, 0.55f, 0.1f), Quaternion.identity);
                            }
                            this.icon_size[1] = 80f;
                            this.efon[1] = true;
                        }
                        this.icon_size[2] = Mathf.MoveTowards(this.icon_size[2], 0f, Time.deltaTime * 800f);
                        if (this.icon_size[2] == 0f)
                        {
                            if (!this.efon[2])
                            {
                                if (this.mission_archive_current[2] > 0)
                                {
                                    UnityEngine.Object.Instantiate(this.pt_star, new Vector3(-1.04f, 0.55f, 0.1f), Quaternion.identity);
                                }
                                this.icon_size[2] = 80f;
                                this.efon[2] = true;
                            }
                            else
                            {
                                this.movefinish = true;
                            }
                        }
                    }
                }
                this.starmove = true;
            }
        }
        if (!this.openbox)
        {
            if (this.isclear > 0)
            {
                if (this.show_delay > 3f)
                {
                    GameObject.Find("cha_ui").GetComponent<Cha_Costume>().OpenGiftBox();
                    this.openbox = true;
                }
                else
                {
                    this.show_delay += Time.deltaTime;
                }
            }
            else if (this.show_delay > 3f)
            {
                this.GoNext();
                this.openbox = true;
            }
            else
            {
                this.show_delay += Time.deltaTime;
            }
        }
        if (this.getpoint)
        {
            this.getcoin_f += Time.deltaTime * 50f;
            if (this.getcoin_f >= this.getcoin)
            {
                this.getcoin_f = this.getcoin;
                this.startexpgain = true;
                this.getpoint = false;
                this.coin += this.getcoin + this.dropcoin;
                this.jade += this.dropjade;
                Crypto.Property_change(this.getcoin + this.dropcoin, false);
            }
        }
        else if (this.startexpgain)
        {
            if (this.chalv >= 0xc7)
            {
                this.startexpgain = false;
                this.chaexp = 0;
                this.getexp_f = 0f;
                this.getexp = 0;
                Crypto.Save_int_key("n11", 0);
            }
            else
            {
                this.getexp_f += Time.deltaTime * ((this.cur_stage_index * 20) + 50);
                if (this.getexp_f >= (this.getexp + this.chaexp))
                {
                    this.getexp_f = this.getexp + this.chaexp;
                    this.startexpgain = false;
                    Crypto.Save_int_key("n11", (int) this.getexp_f);
                }
                else if (this.getexp_f >= (this.chalv * 100))
                {
                    this.getexp_f = 0f;
                    this.getexp -= this.chalv * 100;
                    this.chalv++;
                    Crypto.Save_int_key("n47", this.chalv);
                    if (this.chalv >= 0x13)
                    {
                        this.changelevel = 0;
                    }
                    else if ((this.changelevel == 0) && ((this.chalv % 2) == 1))
                    {
                        this.changelevel = 1;
                    }
                }
            }
        }
    }
}


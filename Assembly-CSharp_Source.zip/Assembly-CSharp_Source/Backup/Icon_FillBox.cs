using System;
using UnityEngine;

public class Icon_FillBox : MonoBehaviour
{
    private float cur_cooltime;
    private float cur_moveUV;
    private bool isthisready;
    private float max_cooltime = 100f;
    private Vector3 originPos;
    private Vector2[] originUV = new Vector2[4];
    private float prev_moveUV;
    private Vector2[] resetUV = new Vector2[4];
    private float scaleratio;
    private Icon_Skill script_skillcontrol;
    private int slotindex;
    private Mesh thismesh;

    private void Awake()
    {
        this.script_skillcontrol = GameObject.FindWithTag("icon_skill").GetComponent<Icon_Skill>();
        this.thismesh = base.GetComponent<MeshFilter>().mesh;
        this.originUV = this.thismesh.uv;
        this.resetUV = new Vector2[] { new Vector2(0.6875f, 0.375f), new Vector2(0.75f, 0.375f), new Vector2(0.6875f, 0.3125f), new Vector2(0.75f, 0.3125f) };
    }

    public void ResetScale()
    {
        this.cur_cooltime = 0f;
        this.thismesh.uv = this.resetUV;
    }

    public void SkillKind(int _slotindex, float _cooltime)
    {
        this.slotindex = _slotindex;
        this.max_cooltime = _cooltime;
        this.scaleratio = 0.0625f / this.max_cooltime;
        this.cur_cooltime = this.max_cooltime;
    }

    public void SoulFull()
    {
        this.thismesh.uv = this.originUV;
    }

    public void SoulLack()
    {
        this.thismesh.uv = new Vector2[] { this.resetUV[0] - (Vector2.right * 0.0625f), this.resetUV[1] - (Vector2.right * 0.0625f), this.resetUV[2] - (Vector2.right * 0.0625f), this.resetUV[3] - (Vector2.right * 0.0625f) };
    }

    private void Update()
    {
        if (this.cur_cooltime < this.max_cooltime)
        {
            this.cur_moveUV += this.scaleratio * Time.deltaTime;
            if ((this.cur_moveUV - this.prev_moveUV) > 0.002f)
            {
                this.thismesh.uv = new Vector2[] { this.resetUV[0] - new Vector2(0f, this.cur_moveUV), this.resetUV[1] - new Vector2(0f, this.cur_moveUV), this.resetUV[2] - new Vector2(0f, this.cur_moveUV), this.resetUV[3] - new Vector2(0f, this.cur_moveUV) };
                this.prev_moveUV = this.cur_moveUV;
            }
            this.cur_cooltime += Time.deltaTime;
            this.isthisready = false;
        }
        else if (!this.isthisready)
        {
            this.cur_moveUV = 0f;
            this.prev_moveUV = 0f;
            this.thismesh.uv = this.originUV;
            this.cur_cooltime = this.max_cooltime;
            this.isthisready = true;
            this.script_skillcontrol.Skill_Possible(this.slotindex);
        }
    }
}


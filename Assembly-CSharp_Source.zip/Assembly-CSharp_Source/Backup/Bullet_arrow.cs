using System;
using UnityEngine;

public class Bullet_arrow : MonoBehaviour
{
    public float bullet_speed;
    private Transform mytransform;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void Update()
    {
        this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * this.bullet_speed);
    }
}


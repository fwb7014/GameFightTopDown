using System;
using UnityEngine;

public class Ef_block : MonoBehaviour
{
    private Transform mytransform;

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    private void Update()
    {
        if (this.mytransform.localScale.x < 1.4f)
        {
            this.mytransform.localScale += (Vector3) ((Vector3.one * 2f) * Time.deltaTime);
        }
        else
        {
            base.gameObject.active = false;
            this.mytransform.localScale = Vector3.one;
        }
    }
}


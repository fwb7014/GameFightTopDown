using System;
using UnityEngine;

public class Sk_groundbreak : MonoBehaviour
{
    private void ColliderDisable()
    {
        base.collider.enabled = false;
    }

    private void GameobjectDisable()
    {
        base.transform.position = (Vector3) (Vector3.one * 30f);
        base.gameObject.active = false;
        base.animation.Stop();
    }

    private void OnEnable()
    {
        base.animation.Play();
        base.collider.enabled = true;
        base.Invoke("ColliderDisable", 0.4f);
        base.Invoke("GameobjectDisable", 2f);
    }
}


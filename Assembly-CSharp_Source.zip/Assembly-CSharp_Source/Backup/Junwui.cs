using System;
using UnityEngine;

public class Junwui : MonoBehaviour
{
    private int attack_count;
    private bool attack_start = true;
    private Transform c_splash;
    private Transform cha1;
    public Transform ef_splash;
    private AnimationState finish;
    private Animation myanimation;
    private Collider mycollider;
    private Transform mytransform;
    private float power;
    public Transform pt_body;
    private Vector3 rndpos;
    private Quaternion rotate;
    private Vector3 scalereduce;
    public AudioClip snd_attack;

    private void Attack()
    {
        base.audio.clip = this.snd_attack;
        base.audio.Play();
        if (this.c_splash == null)
        {
            this.c_splash = (Transform) UnityEngine.Object.Instantiate(this.ef_splash, this.mytransform.position, this.mytransform.rotation);
            this.c_splash.rigidbody.mass = this.power;
        }
        else
        {
            this.c_splash.position = this.mytransform.position;
            this.c_splash.rotation = this.mytransform.rotation;
            this.c_splash.gameObject.active = true;
        }
        this.mycollider.enabled = false;
        this.attack_count++;
        if (this.attack_count >= 12)
        {
            this.finish = this.myanimation.PlayQueued("junwui_finish");
            this.finish.speed = 0.2f;
            this.finish.layer = 1;
        }
    }

    private void Awake()
    {
        this.mytransform = base.transform;
        this.mycollider = base.collider;
        this.myanimation = base.animation;
        this.myanimation["junwui_appear"].speed = 0.2f;
        this.myanimation["junwui_attack"].speed = 0.3f;
        this.myanimation["junwui_idle"].speed = 0.2f;
        this.myanimation["junwui_finish"].speed = 0.2f;
        this.myanimation["junwui_appear"].layer = 2;
        this.myanimation["junwui_attack"].layer = 1;
    }

    private void OnEnable()
    {
        this.myanimation.Stop();
        this.mycollider.enabled = true;
        this.myanimation.Play("junwui_appear");
        this.myanimation.Play("junwui_idle");
        this.pt_body.particleEmitter.emit = true;
        this.mytransform.localScale = (Vector3) (Vector3.one * 1.5f);
        this.attack_count = 0;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!this.attack_start && (other.gameObject.layer == 8))
        {
            this.myanimation.Play("junwui_attack");
            this.attack_start = true;
            this.rotate = Quaternion.LookRotation(other.transform.position - this.mytransform.position);
        }
    }

    public void SetDamage(float _damage)
    {
        this.power = _damage;
    }

    public void SetRndPosition()
    {
        this.rndpos = ((Vector3) (UnityEngine.Random.onUnitSphere * 0.4f)) + this.cha1.position;
        this.rndpos[1] = 0f;
    }

    private void Start()
    {
        this.cha1 = GameObject.FindWithTag("Player").transform;
        base.InvokeRepeating("SetRndPosition", 0f, 2f);
        this.scalereduce = new Vector3(1f, -1f, 1f);
    }

    private void Update()
    {
        if (this.myanimation.IsPlaying("junwui_finish"))
        {
            this.mytransform.localScale -= (Vector3) ((this.scalereduce * Time.deltaTime) * 3f);
            if (this.mytransform.localScale.x < 0.1)
            {
                this.mytransform.position = (Vector3) (Vector3.one * 20f);
                this.pt_body.particleEmitter.emit = false;
                base.gameObject.active = false;
            }
        }
        else if (this.myanimation.IsPlaying("junwui_appear"))
        {
            this.attack_start = true;
        }
        else if (this.myanimation.IsPlaying("junwui_attack"))
        {
            this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, this.rotate, Time.deltaTime * 8f);
            this.attack_start = true;
        }
        else if (this.myanimation.IsPlaying("junwui_idle"))
        {
            if (this.attack_start)
            {
                this.attack_start = false;
                this.mycollider.enabled = true;
            }
            this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, Quaternion.LookRotation(this.rndpos - this.mytransform.position), Time.deltaTime * 2f);
            this.mytransform.position = Vector3.Lerp(this.mytransform.position, this.rndpos, Time.deltaTime);
        }
    }
}


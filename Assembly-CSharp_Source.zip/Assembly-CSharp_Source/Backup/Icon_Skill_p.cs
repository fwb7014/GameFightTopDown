using System;
using UnityEngine;

public class Icon_Skill_p : MonoBehaviour
{
    private bool clickon;
    private int currentSkill = -1;
    public bool g_skill;
    public bool general;
    private bool ispetready;
    private int isskillready;
    private bool pause;
    private bool roll;
    private Cha_Skill script_chaskill;
    private UI_Ingame script_IngameUI;
    private Icon_Skill script_skillcontrol;
    private int skill_pet_item;
    private int slotindex;
    private int soulcost = 1;

    public bool SkillColliderOn()
    {
        this.clickon = false;
        if (this.general)
        {
            this.clickon = this.script_IngameUI.CallGeneral(0);
        }
        else if (this.g_skill)
        {
            this.isskillready = this.script_skillcontrol.isskillready[20];
            if ((this.isskillready == 2) && this.script_skillcontrol.ResetCooltime_general())
            {
                this.script_chaskill.SkillOn(this.currentSkill, true);
                this.script_IngameUI.GainSoul((float) -this.soulcost);
                this.clickon = true;
            }
        }
        else if (this.pause)
        {
            this.script_IngameUI.PauseOn();
        }
        else if (this.roll)
        {
            this.script_skillcontrol.Skillset_roll();
        }
        else if (this.skill_pet_item == 0)
        {
            if (this.script_skillcontrol.move_icon_skill)
            {
                return this.clickon;
            }
            this.isskillready = this.script_skillcontrol.isskillready[this.slotindex];
            if (this.isskillready == 2)
            {
                this.script_skillcontrol.Ef_SkillUse(base.transform.position);
                this.script_skillcontrol.ResetCooltime_skill(this.slotindex);
                this.script_IngameUI.GainSoul((float) -this.soulcost);
                this.script_chaskill.SkillOn(this.currentSkill, false);
                this.clickon = true;
            }
        }
        else if (this.skill_pet_item == 1)
        {
            if (this.script_skillcontrol.move_icon_pet)
            {
                return this.clickon;
            }
            this.ispetready = this.script_skillcontrol.ispetready[this.currentSkill];
            if (this.ispetready)
            {
                this.script_skillcontrol.Ef_SkillUse(base.transform.position);
                this.script_skillcontrol.Duration_reduce(this.currentSkill);
                this.script_chaskill.PetSkillOn(this.currentSkill);
                this.clickon = true;
            }
        }
        else
        {
            this.script_skillcontrol.Ef_SkillUse(base.transform.position);
            this.script_skillcontrol.ItemUse(this.slotindex);
        }
        return this.clickon;
    }

    public void SkillKind(int _slotindex, int _kind, int _skill_pet_item, short _soulcost)
    {
        this.slotindex = _slotindex;
        this.currentSkill = _kind;
        this.skill_pet_item = _skill_pet_item;
        this.soulcost = _soulcost;
    }

    private void Start()
    {
        this.script_chaskill = GameObject.FindWithTag("Player").GetComponent<Cha_Skill>();
        this.script_skillcontrol = GameObject.FindWithTag("icon_skill").GetComponent<Icon_Skill>();
        this.script_IngameUI = GameObject.FindWithTag("ui").GetComponent<UI_Ingame>();
    }

    public void ThisisPause()
    {
        this.pause = true;
    }

    public void ThisisRoll()
    {
        this.roll = true;
    }
}


using System;
using UnityEngine;

public class Bullet_punch : MonoBehaviour
{
    private int addforce;
    private bool boom;
    private Transform cha1;
    private Color currentColor;
    private float delay;
    private Vector3 directionVector;
    private short efon;
    private Transform enemy;
    private Vector3 growVector = new Vector3(1f, 0f, 1f);
    private SphereCollider mycollider;
    private Material mymaterial;
    private Renderer myrenderer;
    private Transform mytransform;
    private Vector3 originScale = new Vector3(0.5f, 2f, 0.5f);
    public Transform pt_thrust;
    private Cha_Skill script_cha;
    private float stepfactor = 1f;
    private Color targetColor = new Color(0.5f, 0.5f, 0.5f, 0f);
    private Color transColor;
    private float upangle;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myrenderer = base.renderer;
        this.mymaterial = this.myrenderer.material;
        this.mycollider = base.collider as SphereCollider;
        this.cha1 = GameObject.FindWithTag("Player").transform;
        this.script_cha = this.cha1.GetComponent<Cha_Skill>();
        base.gameObject.active = false;
    }

    public void PunchOff()
    {
        this.delay = 4f;
        this.efon = 0;
        this.mycollider.enabled = false;
        this.myrenderer.enabled = false;
        base.gameObject.active = false;
        this.mytransform.localScale = this.originScale;
        this.pt_thrust.particleEmitter.emit = false;
    }

    public void PunchShoot(float _delay, int _addforce, Transform _mon, float _step, float _upangle, float _collidersize, bool _boom)
    {
        base.gameObject.active = true;
        this.delay = _delay;
        this.efon = 1;
        this.enemy = _mon;
        this.addforce = _addforce;
        this.mycollider.enabled = false;
        this.stepfactor = _step;
        this.upangle = _upangle;
        this.mycollider.radius = _collidersize;
        this.boom = _boom;
    }

    private void Update()
    {
        if (this.efon > 0)
        {
            if (this.efon == 1)
            {
                if (this.enemy != null)
                {
                    this.directionVector = this.enemy.position - this.cha1.position;
                }
                else
                {
                    this.directionVector = (Vector3) (this.cha1.forward * 0.1f);
                }
                if (this.directionVector != Vector3.zero)
                {
                    this.cha1.rotation = Quaternion.LookRotation(this.directionVector);
                }
                this.cha1.position += (Vector3) ((((this.directionVector * 10f) + (this.cha1.right * this.stepfactor)) * Time.deltaTime) * 0.5f);
                if (this.delay > 0f)
                {
                    this.delay -= Time.deltaTime;
                }
                else
                {
                    if (this.addforce > 0)
                    {
                        this.cha1.rigidbody.AddForce(this.cha1.transform.forward * this.addforce);
                    }
                    this.efon = 2;
                    this.mytransform.position = (Vector3) ((this.cha1.position + (Vector3.up * (0.1f + (this.upangle * 0.1f)))) + (this.cha1.forward * 0.15f));
                    this.mytransform.up = -this.cha1.forward - ((Vector3) (Vector3.up * this.upangle));
                    this.mytransform.localScale = this.originScale;
                    this.myrenderer.enabled = true;
                    this.mycollider.enabled = true;
                    this.mymaterial.SetColor("_TintColor", Color.gray);
                    this.pt_thrust.particleEmitter.emit = true;
                    if (this.boom)
                    {
                        this.script_cha.BoomOn(1, false);
                    }
                }
            }
            else if (this.efon == 2)
            {
                if (this.mytransform.localScale.x > 3f)
                {
                    this.efon = 0;
                    this.myrenderer.enabled = false;
                    base.gameObject.active = false;
                    this.mytransform.position = (Vector3) (Vector3.one * 4f);
                }
                else if (this.mytransform.localScale.x > 1f)
                {
                    this.pt_thrust.particleEmitter.emit = false;
                    this.mycollider.enabled = false;
                }
            }
            this.mytransform.localScale += (Vector3) ((this.growVector * Time.deltaTime) * 6f);
            this.currentColor = this.mymaterial.GetColor("_TintColor");
            this.transColor = Color.Lerp(this.currentColor, this.targetColor, Time.deltaTime * 5f);
            this.mymaterial.SetColor("_TintColor", this.transColor);
        }
    }
}


using System;
using UnityEngine;

public class Toast_Splash_Ani : MonoBehaviour
{
    private float ani_time;
    public Transform ci_hidea;
    private bool finish_ani;
    private int framesPerSecond = 20;
    private int index;
    private int lastframe;
    private Material mymaterial;
    private Vector2 offset;
    private int oldindex = -1;
    private Vector2 size;
    private bool start_snd;
    private float starttime;
    private float uIndex;
    private int uvAnimationTileX = 4;
    private int uvAnimationTileY = 5;
    private int vIndex;

    private void Awake()
    {
    }

    private void Start()
    {
        this.starttime = 0f;
        this.lastframe = this.uvAnimationTileX * this.uvAnimationTileY;
        this.size = new Vector2(1f / ((float) this.uvAnimationTileX), 1f / ((float) this.uvAnimationTileY));
        this.mymaterial = base.renderer.material;
    }

    private void Update()
    {
        this.ani_time += Time.deltaTime;
        if (this.finish_ani)
        {
            if (this.ani_time > 4f)
            {
                this.ci_hidea.localScale = Vector3.MoveTowards(this.ci_hidea.localScale, Vector3.zero, Time.deltaTime * 800f);
            }
            else if (this.ani_time > 2.6f)
            {
                base.transform.localScale = Vector3.zero;
                this.ci_hidea.localScale = Vector3.MoveTowards(this.ci_hidea.localScale, new Vector3(60f, 30f, 0f), Time.deltaTime * 600f);
            }
        }
        else
        {
            if (this.ani_time > 0.5f)
            {
                this.starttime += Time.deltaTime;
                this.index = (int) (this.starttime * this.framesPerSecond);
                this.uIndex = this.index % this.uvAnimationTileX;
                this.vIndex = this.index / this.uvAnimationTileX;
                if (!this.start_snd)
                {
                    base.audio.Play();
                    this.start_snd = true;
                }
            }
            if (this.index != this.oldindex)
            {
                if (this.index >= (this.lastframe - 1))
                {
                    this.index = this.lastframe - 1;
                    this.oldindex = this.index;
                    this.finish_ani = true;
                }
                this.offset = (Vector2) (((Vector2.right * this.uIndex) * this.size.x) + (Vector2.up * ((1f - this.size.y) - (this.vIndex * this.size.y))));
                this.mymaterial.mainTextureOffset = this.offset;
                this.mymaterial.mainTextureScale = this.size;
                this.oldindex = this.index;
            }
        }
    }
}


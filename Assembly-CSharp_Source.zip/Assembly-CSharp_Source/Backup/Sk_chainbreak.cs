using System;
using UnityEngine;

public class Sk_chainbreak : MonoBehaviour
{
    private SphereCollider childcollider;
    private float delay_exp;
    private Collider mycollider;
    private ParticleEmitter myparticleEmitter;
    private Transform mytransform;
    private short p_step;
    private Transform pt_exp;

    private void Awake()
    {
        this.myparticleEmitter = base.particleEmitter;
        this.mytransform = base.transform;
        this.mycollider = base.collider;
        this.pt_exp = this.mytransform.GetChild(0);
        this.childcollider = this.pt_exp.collider as SphereCollider;
    }

    private void OnEnable()
    {
        this.myparticleEmitter.ClearParticles();
        this.mycollider.enabled = false;
        this.myparticleEmitter.emit = true;
        this.delay_exp = 0f;
        base.InvokeRepeating("RepeatDamage", 0.1f, 0.4f);
        this.p_step = 0;
        base.audio.Play();
    }

    private void RepeatDamage()
    {
        this.mycollider.enabled = false;
        this.mycollider.enabled = true;
    }

    private void Start()
    {
        this.pt_exp.rigidbody.mass = base.rigidbody.mass;
        this.pt_exp.gameObject.active = false;
    }

    private void Update()
    {
        this.delay_exp += Time.deltaTime;
        if (this.mytransform.position.y < 0.1f)
        {
            this.mytransform.position += (Vector3) ((Vector3.up * 0.6f) * Time.deltaTime);
        }
        if (this.p_step == 2)
        {
            if (this.delay_exp > 4f)
            {
                base.gameObject.active = false;
                this.pt_exp.gameObject.active = false;
                this.mytransform.position = (Vector3) (Vector3.one * 30f);
                this.p_step = 0;
            }
        }
        else if (this.p_step == 1)
        {
            if (this.delay_exp > 2.5f)
            {
                this.pt_exp.particleEmitter.emit = false;
                this.childcollider.enabled = false;
                this.childcollider.radius = 0.01f;
                this.p_step = 2;
            }
        }
        else if ((this.p_step == 0) && (this.delay_exp > 2f))
        {
            this.mycollider.enabled = false;
            base.CancelInvoke();
            this.p_step = 1;
            this.myparticleEmitter.ClearParticles();
            this.myparticleEmitter.emit = false;
            this.pt_exp.gameObject.active = true;
            this.pt_exp.particleEmitter.emit = true;
            this.childcollider.enabled = true;
            this.childcollider.radius = 0.7f;
        }
    }
}


using System;
using UnityEngine;

public class UI_result_ride : MonoBehaviour
{
    public GUISkin basicSkin;
    public Texture2D bg_asset;
    public Texture2D bg_list;
    public GUIStyle bt_empty;
    private int coin;
    private int count_behit;
    private int count_coin;
    private int count_loss;
    private int count_monster;
    private int getcoin;
    private float getcoin_f;
    private int getcoin_og;
    private bool getpoint;
    private bool gonext;
    public Texture2D img_map;
    private int jade;
    private int language;
    private bool movefinish;
    private int[] pet_passiveskill = new int[2];
    private float posX = 1000f;
    private Cha_Control_ride_cha script_cha;
    private float show_delay;
    private bool show_ui;

    private void Awake()
    {
        Time.timeScale = 1f;
    }

    private void OnGUI()
    {
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.skin = this.basicSkin;
        GUI.DrawTexture(Crypto.Rect2(112f, 0f, 256f, 32f), this.bg_asset);
        GUI.Label(Crypto.Rect2(146f, 6f, 80f, 14f), string.Empty + this.coin, "txt12_w");
        GUI.Label(Crypto.Rect2(280f, 6f, 64f, 14f), string.Empty + this.jade, "txt12_w");
        if (this.show_ui)
        {
            GUI.DrawTexture(Crypto.Rect2(this.posX, 64f, 180f, 135f), this.bg_list);
            GUI.Label(Crypto.Rect2(300f, 96f, 124f, 14f), string.Empty + this.count_coin, "txt12_0");
            GUI.Label(Crypto.Rect2(348f, 96f, 124f, 14f), string.Empty + this.count_coin, "txt12_0");
            GUI.Label(Crypto.Rect2(300f, 121f, 124f, 14f), string.Empty + this.count_monster, "txt12_0");
            GUI.Label(Crypto.Rect2(348f, 121f, 124f, 14f), string.Empty + (this.count_monster * 3), "txt12_0");
            GUI.Label(Crypto.Rect2(300f, 146f, 124f, 14f), string.Empty + this.count_behit, "txt12_0");
            GUI.Label(Crypto.Rect2(348f, 146f, 124f, 14f), string.Empty + this.count_loss, "txt12_0");
            if (this.getcoin == this.getcoin_og)
            {
                GUI.Label(Crypto.Rect2(348f, 171f, 124f, 14f), string.Empty + this.getcoin, "txt12_0");
            }
            else
            {
                GUI.Label(Crypto.Rect2(320f, 171f, 124f, 14f), string.Empty + this.getcoin_og, "txt12_0");
                GUI.Label(Crypto.Rect2(348f, 171f, 124f, 14f), "(+" + (this.getcoin - this.getcoin_og) + ")", "txt12_b");
            }
            GUI.Label(Crypto.Rect2(this.posX, 70f, 180f, 14f), Language.intxt[this.language, 0x131], "txt14_w");
        }
        if (this.gonext)
        {
            GUI.DrawTexture(Crypto.Rect2(400f, 250f, 64f, 64f), this.img_map);
            if (GUI.Button(Crypto.Rect2(400f, 250f, 64f, 64f), Language.intxt[this.language, 0xca], this.bt_empty))
            {
                Application.LoadLevel("Map");
                UnityEngine.Object.Destroy(GameObject.FindWithTag("Player"));
                UnityEngine.Object.Destroy(GameObject.FindWithTag("general"));
            }
        }
    }

    private void Start()
    {
        this.pet_passiveskill = PlayerPrefsX.GetIntArray("n27");
        this.language = PlayerPrefs.GetInt("language");
        base.audio.volume = PlayerPrefs.GetFloat("vol_bgm");
        AudioListener.volume = PlayerPrefs.GetFloat("vol_master");
        this.coin = Crypto.Load_int_key("n17");
        this.jade = Crypto.Load_int_key("n24");
        this.script_cha = GameObject.FindWithTag("Player").GetComponent<Cha_Control_ride_cha>();
        this.getcoin = this.script_cha.amount_soulstone;
        this.getcoin_og = this.getcoin;
        this.count_monster = this.script_cha.count_monster;
        this.count_coin = this.script_cha.count_coin;
        this.count_behit = this.script_cha.count_behit;
        this.count_loss = ((this.count_monster * 3) + this.count_coin) - this.getcoin;
        this.count_loss = Mathf.Max(0, this.count_loss);
        this.getcoin += (int) ((this.getcoin * this.pet_passiveskill[0]) * 0.1f);
    }

    private void Update()
    {
        if (this.getpoint)
        {
            this.getcoin_f += Time.deltaTime * 20f;
            if (this.getcoin_f >= this.getcoin)
            {
                this.getcoin_f = this.getcoin;
                this.getpoint = false;
                this.coin += this.getcoin;
                Crypto.Property_change(this.getcoin, false);
                this.gonext = true;
            }
        }
        else if (!this.show_ui)
        {
            this.show_delay += Time.deltaTime;
            if (this.show_delay > 1f)
            {
                this.getpoint = true;
                this.show_ui = true;
            }
        }
        if (!this.movefinish)
        {
            this.posX = Mathf.MoveTowards(this.posX, 270f, Time.deltaTime * 1200f);
            if (this.posX == 270f)
            {
                this.movefinish = true;
            }
        }
    }
}


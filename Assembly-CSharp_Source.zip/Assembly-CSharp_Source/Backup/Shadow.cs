using System;
using UnityEngine;

public class Shadow : MonoBehaviour
{
    private Transform mytransform;
    private Transform pickparent;
    private Vector3 shadowpos;

    private void Awake()
    {
        this.mytransform = base.transform;
        base.renderer.sharedMaterial.renderQueue = 0x7d1;
    }

    public void Finish()
    {
        this.mytransform.position = (Vector3) (Vector3.one * 3f);
        base.gameObject.active = false;
        this.pickparent = null;
    }

    public void Pickparent(Transform pick, float shadowscale)
    {
        this.pickparent = pick;
        if (shadowscale > 1f)
        {
            this.mytransform.localScale = (Vector3) (Vector3.one * shadowscale);
        }
    }

    private void Update()
    {
        if (this.pickparent != null)
        {
            this.shadowpos = this.pickparent.position;
            this.shadowpos[1] = 0f;
            this.mytransform.position = this.shadowpos;
        }
        else
        {
            this.Finish();
        }
    }
}


using System;
using UnityEngine;

public class Icon_Stage : MonoBehaviour
{
    public int _index;
    private bool _isclear;
    public int _kind;
    private string _name;
    public int _play;

    public void IconDown()
    {
        GameObject.FindWithTag("ui").GetComponent<UI_map>().SetStage(this._index, this._kind, base.transform.position, this._play);
    }
}


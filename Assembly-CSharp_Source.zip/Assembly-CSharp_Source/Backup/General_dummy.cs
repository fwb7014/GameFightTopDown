using System;
using UnityEngine;

public class General_dummy : MonoBehaviour
{
    public Transform bip01;
    private Transform cha1;
    private bool changeready;
    private bool dead;
    private Transform general_weapon;
    private int generalkind;
    private bool jumpatk;
    public Transform l_hand;
    private Animation myanimation;
    private Transform mytransform;
    public Transform r_hand;
    private Cha_Control script_cha;
    public Transform shadow;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myanimation = base.animation;
        this.myanimation["change_in"].speed = 0.3f;
        this.myanimation["change_out"].speed = 0.2f;
        this.myanimation["change_in_atk"].speed = 0.3f;
        this.myanimation["dead"].speed = 0.3f;
        this.cha1 = GameObject.FindWithTag("Player").transform;
        this.script_cha = this.cha1.GetComponent<Cha_Control>();
        Transform transform = (Transform) UnityEngine.Object.Instantiate(this.shadow, this.mytransform.position, this.mytransform.rotation);
        transform.GetComponent<Shadow>().Pickparent(this.bip01, 1f);
    }

    public void Dead()
    {
        base.gameObject.active = true;
        GameObject.FindWithTag("Respawn").GetComponent<Spawn>().GeneralDead();
        this.myanimation.Play("dead");
        this.dead = true;
        UnityEngine.Object.Destroy(base.gameObject, 3f);
    }

    public void SetCostume(int _generalkind, int _weaponindex)
    {
        this.generalkind = _generalkind;
        this.mytransform.GetChild(_generalkind + 1).gameObject.active = true;
        GameObject obj2 = Resources.Load("wp_general" + _weaponindex.ToString()) as GameObject;
        this.general_weapon = (Transform) UnityEngine.Object.Instantiate(obj2.transform, this.r_hand.position, this.r_hand.rotation);
        this.general_weapon.parent = this.r_hand;
        if (_generalkind == 0)
        {
            this.general_weapon = (Transform) UnityEngine.Object.Instantiate(obj2.transform, this.l_hand.position, this.l_hand.rotation);
            this.general_weapon.parent = this.l_hand;
        }
    }

    public void ShowIn()
    {
        base.gameObject.active = true;
        this.myanimation.Play("change_in");
        this.changeready = true;
        if (this.generalkind == 4)
        {
            this.general_weapon.GetComponent<TrailRenderer>().enabled = true;
        }
    }

    public void ShowIn_atk()
    {
        base.gameObject.active = true;
        this.myanimation.Play("change_in_atk");
        this.changeready = true;
        this.jumpatk = true;
        if (this.generalkind == 4)
        {
            this.general_weapon.GetComponent<TrailRenderer>().enabled = true;
        }
    }

    public void ShowOut()
    {
        base.gameObject.active = true;
        this.myanimation.Play("change_out");
        if (this.generalkind == 4)
        {
            this.general_weapon.GetComponent<TrailRenderer>().enabled = true;
        }
    }

    private void Start()
    {
        base.gameObject.active = false;
        this.mytransform.position = (Vector3) (Vector3.one * 6f);
    }

    private void Update()
    {
        if (!this.dead)
        {
            if (!this.myanimation.isPlaying)
            {
                if (this.generalkind == 4)
                {
                    this.general_weapon.GetComponent<TrailRenderer>().enabled = false;
                }
                this.mytransform.position = (Vector3) (Vector3.one * 6f);
                base.gameObject.active = false;
                this.script_cha.ChangeFinish(this.changeready, this.jumpatk);
                this.changeready = false;
                this.jumpatk = false;
            }
            else
            {
                this.mytransform.position = this.cha1.position;
            }
        }
    }
}


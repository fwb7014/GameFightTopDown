using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using UnityEngine;

public class CommonUtils
{
    private static System.Random random = new System.Random();
    public const string STR_BLANK = "";

    public static bool EqualsIgnoreCase(string src, string target)
    {
        return (((src != null) && (target != null)) && src.ToLower().Equals(target.ToLower()));
    }

    public static byte[] GetFileData(string fileName)
    {
        FileStream stream = new FileStream(fileName, FileMode.Open);
        byte[] array = new byte[stream.Length];
        stream.Read(array, 0, array.Length);
        stream.Close();
        return array;
    }

    public static T GetVal<T>(Dictionary<string, object> dic, string key)
    {
        object obj2 = default(T);
        if ((dic != null) && dic.ContainsKey(key))
        {
            object obj3 = dic[key];
            if (obj3 != null)
            {
                string str = obj3.ToString();
                string str2 = true.ToString();
                if ((obj2 != null) && !string.IsNullOrEmpty(str))
                {
                    if (obj2 is int)
                    {
                        obj2 = ParseInt(str);
                    }
                    else if (obj2 is float)
                    {
                        obj2 = float.Parse(str);
                    }
                    else if (obj2 is bool)
                    {
                        obj2 = str == "True";
                    }
                    else if (obj2 is DateTime)
                    {
                        obj2 = DateTime.Parse(str);
                    }
                }
                else
                {
                    obj2 = obj3;
                }
            }
        }
        return (T) obj2;
    }

    public static bool IsEmpty(string val)
    {
        try
        {
            return string.IsNullOrEmpty(val);
        }
        catch (Exception exception)
        {
            Debug.LogWarning(exception.Message);
            return true;
        }
    }

    public static bool IsNumeric(string str)
    {
        Regex regex = new Regex(@"^[-]?\d+[.]?\d*$");
        return regex.IsMatch(str);
    }

    public static bool ParseBool(string val)
    {
        return (val == "1");
    }

    public static float ParseFloat(string val)
    {
        if (IsEmpty(val))
        {
            return 0f;
        }
        return float.Parse(val);
    }

    public static int ParseInt(string val)
    {
        if (IsEmpty(val))
        {
            return 0;
        }
        return int.Parse(val);
    }

    public static int ParseInt16(string val)
    {
        if (IsEmpty(val))
        {
            return 0;
        }
        int num = 0;
        try
        {
            num = int.Parse(val, NumberStyles.HexNumber);
        }
        catch
        {
        }
        return num;
    }

    public static string ToString(int intVal, int toBase)
    {
        return Convert.ToString(intVal, toBase);
    }
}


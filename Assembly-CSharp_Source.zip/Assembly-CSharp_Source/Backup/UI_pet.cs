using System;
using UnityEngine;

public class UI_pet : MonoBehaviour
{
    public Texture2D[] angel = new Texture2D[8];
    private float angel_firerate;
    private string angel_info = string.Empty;
    private string angel_name = string.Empty;
    private bool b_delay;
    public GUISkin basicSkin;
    public Texture2D bg_asset;
    public Texture2D bg_black;
    public Texture2D bg_pet;
    private int bg_posX_l;
    private int bg_posX_r;
    public GUIStyle bt_back;
    public GUIStyle bt_empty;
    public GUIStyle bt_info;
    public GUIStyle bt_petkind;
    public GUIStyle bt_yesno;
    public Texture2D c_equip;
    private GameObject cashshop;
    private int coin;
    private int confirm;
    private int cost_feed;
    public Texture2D cost_icon;
    private int cur_angel;
    private int currentpet;
    private float currentX;
    private bool dragOn;
    private float dragposX;
    private float dragrange;
    private float f_delay;
    private int gamemode;
    public Texture2D ico_arrow;
    public Texture2D ico_feed;
    public Texture2D ico_stamina;
    public Texture2D ico_stamina_empty;
    public Texture2D ico_warn;
    private int icon_posY;
    private int icon_size;
    public Texture2D icon_unlock;
    public Texture2D[] item_stat = new Texture2D[2];
    private int jade;
    public Texture2D jade_icon;
    private int language;
    private const int MAXANGEL = 8;
    private int maxExtremeStage = 1;
    private const int MAXPET = 2;
    private int menu_kind;
    private int[] pet_activeskill = new int[2];
    private int[] pet_hunger = new int[2];
    public Transform[] pet_mesh = new Transform[2];
    private int[] pet_passiveskill = new int[2];
    public Texture2D[] petkind = new Texture2D[3];
    public Texture2D pop_blank;
    public Texture2D pop_blank2;
    public Texture2D pop_detail;
    private float prevposX;
    private petset[,] ps = new petset[2, 10];
    private Cha_Costume script_costume;
    private DB_angel script_dbangel;
    private SoundEf_UI script_soundUI;
    private bool scrollOn;
    private int sel_angel;
    public Texture2D[] skill_stat = new Texture2D[4];
    private GameObject sound_UI;
    public Texture2D titlebase;
    public Texture2D txt_name;
    private bool warning_hungry;

    public void CashshopOpen()
    {
        if (this.cashshop == null)
        {
            this.cashshop = Resources.Load("CashShop") as GameObject;
        }
        UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
    }

    public void Delay(float t)
    {
        this.b_delay = true;
        this.f_delay = t;
    }

    private void OnEnable()
    {
        this.coin = Crypto.Load_int_key("n17");
        this.jade = Crypto.Load_int_key("n24");
    }

    private void OnGUI()
    {
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(((float) Screen.width) / 960f, ((float) Screen.height) / 640f, 1f));
        GUI.skin = this.basicSkin;
        GUI.DrawTexture(Crypto.Rect2((float) this.bg_posX_l, 0f, 320f, 320f), this.bg_pet);
        GUI.DrawTexture(Crypto.Rect2(126f, 30f, 100f, 50f), this.txt_name);
        GUI.Box(Crypto.Rect2(216f, 52f, 80f, 24f), Language.intxt[this.language, 0x4a]);
        GUI.DrawTexture(Crypto.Rect2(112f, 0f, 256f, 32f), this.bg_asset);
        GUI.Label(Crypto.Rect2(146f, 6f, 80f, 14f), string.Empty + this.coin, "txt12_w");
        GUI.Label(Crypto.Rect2(280f, 6f, 64f, 14f), string.Empty + this.jade, "txt12_w");
        if (GUI.Button(Crypto.Rect2(144f, 2f, 100f, 24f), string.Empty, this.bt_empty))
        {
            if (this.sound_UI != null)
            {
                this.script_soundUI.SoundOn(0);
            }
            Crypto.Save_int_key("cashshopkind", 2);
            this.CashshopOpen();
        }
        if (GUI.Button(Crypto.Rect2(272f, 2f, 88f, 24f), string.Empty, this.bt_empty))
        {
            if (this.sound_UI != null)
            {
                this.script_soundUI.SoundOn(0);
            }
            Crypto.Save_int_key("cashshopkind", 1);
            this.CashshopOpen();
        }
        if (this.confirm > 0)
        {
            GUI.enabled = false;
        }
        if (this.menu_kind == 0)
        {
            if (this.warning_hungry)
            {
                GUI.Label(Crypto.Rect2(212f, 157f, 230f, 36f), Language.intxt[this.language, 0x10c], "txt12_0");
            }
            else if (this.gamemode != 0)
            {
                GUI.Label(Crypto.Rect2(212f, 157f, 230f, 36f), Language.intxt[this.language, 0x1a7], "txt12_0");
            }
            else
            {
                GUI.Label(Crypto.Rect2(212f, 157f, 230f, 36f), Language.intxt[this.language, 20], "txt12_0");
            }
            for (int i = 0; i < 3; i++)
            {
                if (GUI.Button(Crypto.Rect2((float) (220 + (0x4c * i)), 90f, 64f, 64f), string.Empty, this.bt_petkind))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    if (i < 2)
                    {
                        this.menu_kind = 1;
                        this.currentpet = i;
                    }
                    else
                    {
                        this.menu_kind = 2;
                    }
                }
                GUI.DrawTexture(Crypto.Rect2((float) (220 + (0x4c * i)), 90f, 64f, 64f), this.petkind[i]);
                if ((i < 2) && (this.pet_hunger[i] <= 0))
                {
                    GUI.DrawTexture(Crypto.Rect2((float) (220 + (0x4c * i)), 88f, (float) (this.icon_size * 0x20), 32f), this.ico_warn);
                }
            }
            if (GUI.Button(Crypto.Rect2(416f, 0f, 64f, 64f), string.Empty, this.bt_back))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(1);
                }
                if (this.gamemode == 0)
                {
                    Application.LoadLevel("Map");
                }
                else
                {
                    Application.LoadLevel("Extreme");
                }
            }
        }
        else if (this.menu_kind == 1)
        {
            this.pet_mesh[this.currentpet].position = new Vector3(this.pet_mesh[this.currentpet].position.x, this.pet_mesh[this.currentpet].position.y, -1f);
            if (GUI.Button(Crypto.Rect2(370f, 158f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(1);
                }
                this.menu_kind = 0;
                for (int n = 0; n < 2; n++)
                {
                    this.pet_mesh[n].position = new Vector3(this.pet_mesh[n].position.x, this.pet_mesh[n].position.y, 1f);
                }
            }
            else if (GUI.Button(Crypto.Rect2(320f, 158f, 32f, 32f), string.Empty, this.bt_info))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(0);
                }
                this.confirm = 10;
            }
            GUI.DrawTexture(Crypto.Rect2((float) this.bg_posX_r, 212f, 480f, 100f), this.bg_black);
            for (int j = 0; j < 2; j++)
            {
                if (GUI.Button(Crypto.Rect2((float) ((j * 0x4c) + 0x5e), (float) this.icon_posY, 64f, 64f), string.Empty, this.bt_petkind))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    switch (j)
                    {
                        case 0:
                            if (this.coin >= this.cost_feed)
                            {
                                if (this.pet_hunger[this.currentpet] < 5)
                                {
                                    this.confirm = 1;
                                }
                                else
                                {
                                    this.confirm = 7;
                                    this.Delay(1f);
                                }
                            }
                            else
                            {
                                this.confirm = 5;
                                this.Delay(1f);
                            }
                            break;

                        case 1:
                            if (this.coin >= this.cost_feed)
                            {
                                if (this.pet_hunger[this.currentpet] < 5)
                                {
                                    this.confirm = 2;
                                }
                                else
                                {
                                    this.confirm = 7;
                                    this.Delay(1f);
                                }
                            }
                            else
                            {
                                this.confirm = 5;
                                this.Delay(1f);
                            }
                            break;
                    }
                }
                GUI.DrawTexture(Crypto.Rect2((float) ((j * 0x4c) + 0x5e), (float) this.icon_posY, 64f, 64f), this.item_stat[j]);
            }
            if (this.cost_feed > 0)
            {
                GUI.DrawTexture(Crypto.Rect2(98f, (float) (this.icon_posY + 0x42), 16f, 16f), this.cost_icon);
                GUI.Label(Crypto.Rect2(94f, (float) (this.icon_posY + 0x42), 64f, 14f), "\t  " + this.cost_feed, "txt12_w");
            }
            int num4 = this.cost_feed * (5 - this.pet_hunger[this.currentpet]);
            if (num4 > 0)
            {
                GUI.DrawTexture(Crypto.Rect2(174f, (float) (this.icon_posY + 0x42), 16f, 16f), this.cost_icon);
                GUI.Label(Crypto.Rect2(170f, (float) (this.icon_posY + 0x42), 64f, 14f), "\t  " + num4, "txt12_w");
            }
            for (int k = 0; k < 2; k++)
            {
                if (GUI.Button(Crypto.Rect2((float) ((k * 0x4c) + 0xf6), (float) this.icon_posY, 64f, 64f), string.Empty, this.bt_petkind))
                {
                    if (this.sound_UI != null)
                    {
                        this.script_soundUI.SoundOn(0);
                    }
                    switch (k)
                    {
                        case 0:
                            if (this.pet_passiveskill[this.currentpet] < 9)
                            {
                                this.confirm = 3;
                            }
                            else
                            {
                                this.confirm = 7;
                                this.Delay(1f);
                            }
                            break;

                        case 1:
                            goto Label_08FF;
                    }
                }
                goto Label_0936;
            Label_08FF:
                if (this.pet_activeskill[this.currentpet] < 9)
                {
                    this.confirm = 4;
                }
                else
                {
                    this.confirm = 7;
                    this.Delay(1f);
                }
            Label_0936:
                GUI.DrawTexture(Crypto.Rect2((float) ((k * 0x4c) + 0xf6), (float) this.icon_posY, 64f, 64f), this.skill_stat[k + (this.currentpet * 2)]);
            }
            if (this.pet_passiveskill[this.currentpet] < 9)
            {
                GUI.DrawTexture(Crypto.Rect2(248f, (float) (this.icon_posY + 0x42), 16f, 16f), this.jade_icon);
                GUI.Label(Crypto.Rect2(246f, (float) (this.icon_posY + 0x42), 64f, 14f), "\t  " + this.ps[this.currentpet, this.pet_passiveskill[this.currentpet]]._price, "txt12_w");
                GUI.Label(Crypto.Rect2(246f, (float) (this.icon_posY - 14), 64f, 14f), "Level " + (this.pet_passiveskill[this.currentpet] + 1), "txt12_w");
            }
            else
            {
                GUI.Label(Crypto.Rect2(246f, (float) (this.icon_posY - 14), 64f, 14f), Language.intxt[this.language, 60], "txt12_w");
            }
            if (this.pet_activeskill[this.currentpet] < 9)
            {
                GUI.DrawTexture(Crypto.Rect2(324f, (float) (this.icon_posY + 0x42), 16f, 16f), this.jade_icon);
                GUI.Label(Crypto.Rect2(322f, (float) (this.icon_posY + 0x42), 64f, 14f), "\t  " + this.ps[this.currentpet, this.pet_activeskill[this.currentpet]]._price, "txt12_w");
                GUI.Label(Crypto.Rect2(322f, (float) (this.icon_posY - 14), 64f, 14f), "Level " + (this.pet_activeskill[this.currentpet] + 1), "txt12_w");
            }
            else
            {
                GUI.Label(Crypto.Rect2(322f, (float) (this.icon_posY - 14), 64f, 14f), Language.intxt[this.language, 60], "txt12_w");
            }
            GUI.DrawTexture(Crypto.Rect2(310f, 85f, 128f, 16f), this.titlebase);
            GUI.Label(Crypto.Rect2(246f, 86f, 256f, 14f), Language.intxt[this.language, this.ps[this.currentpet, 0]._info], "txt12_w");
            GUI.Label(Crypto.Rect2(246f, 110f, 256f, 14f), Language.intxt[this.language, 0x109] + "  " + this.pet_hunger[this.currentpet], "txt12_0");
            for (int m = 0; m < 5; m++)
            {
                if (m >= this.pet_hunger[this.currentpet])
                {
                    GUI.DrawTexture(Crypto.Rect2((float) (0x144 + (20 * m)), 130f, 16f, 16f), this.ico_stamina_empty);
                }
                else
                {
                    GUI.DrawTexture(Crypto.Rect2((float) (320 + (20 * m)), 126f, 24f, 24f), this.ico_stamina);
                }
            }
        }
        else if (this.menu_kind == 2)
        {
            GUI.DrawTexture(Crypto.Rect2((float) this.bg_posX_r, 212f, 480f, 100f), this.bg_black);
            for (int num7 = 0; num7 < 8; num7++)
            {
                if (GUI.Button(Crypto.Rect2(((num7 * 0x4c) + 0x12) + this.dragposX, (float) (this.icon_posY + 8), 64f, 64f), string.Empty, this.bt_petkind) && !this.scrollOn)
                {
                    this.sel_angel = num7 + 1;
                    this.SetAngel(num7);
                }
                if (this.maxExtremeStage > num7)
                {
                    GUI.DrawTexture(Crypto.Rect2(((num7 * 0x4c) + 0x12) + this.dragposX, (float) (this.icon_posY + 8), 64f, 64f), this.angel[num7]);
                }
                else
                {
                    GUI.DrawTexture(Crypto.Rect2(((num7 * 0x4c) + 0x12) + this.dragposX, (float) (this.icon_posY + 8), 64f, 64f), this.icon_unlock);
                    GUI.Label(Crypto.Rect2(((num7 * 0x4c) + 0x12) + this.dragposX, (float) (this.icon_posY + 0x39), 64f, 14f), "???", "txt12_w");
                }
                if (num7 == (this.cur_angel - 1))
                {
                    GUI.DrawTexture(Crypto.Rect2(((num7 * 0x4c) + 0x12) + this.dragposX, (float) (this.icon_posY + 8), 64f, 64f), this.c_equip);
                }
            }
            if (this.sel_angel > 0)
            {
                if (this.maxExtremeStage >= this.sel_angel)
                {
                    GUI.DrawTexture(Crypto.Rect2(216f, 104f, 64f, 64f), this.angel[this.sel_angel - 1]);
                    if (this.cur_angel == this.sel_angel)
                    {
                        if (GUI.Button(Crypto.Rect2(300f, 158f, 64f, 32f), Language.intxt[this.language, 0xaf], this.bt_yesno))
                        {
                            this.cur_angel = 0;
                            Crypto.Save_int_key("n61", this.cur_angel);
                        }
                    }
                    else if (GUI.Button(Crypto.Rect2(300f, 158f, 64f, 32f), Language.intxt[this.language, 10], this.bt_yesno))
                    {
                        this.cur_angel = this.sel_angel;
                        Crypto.Save_int_key("n61", this.cur_angel);
                    }
                    GUI.DrawTexture(Crypto.Rect2(310f, 85f, 128f, 16f), this.titlebase);
                    GUI.Label(Crypto.Rect2(246f, 86f, 256f, 14f), this.angel_name, "txt12_w");
                    GUI.Label(Crypto.Rect2(246f, 106f, 256f, 14f), Language.intxt[this.language, 0x99] + "   " + this.angel_firerate, "txt12_0");
                    GUI.Label(Crypto.Rect2(300f, 134f, 140f, 14f), this.angel_info, "txt12_b");
                }
                else
                {
                    GUI.Label(Crypto.Rect2(216f, 110f, 220f, 14f), Language.intxt[this.language, 0x1c8], "txt12_0");
                    GUI.Label(Crypto.Rect2(216f, 140f, 220f, 14f), string.Concat(new object[] { "Stage  ", this.sel_angel * 8, "  ", Language.intxt[this.language, 0x57] }), "txt12_b");
                }
            }
            else
            {
                GUI.Label(Crypto.Rect2(216f, 116f, 220f, 14f), Language.intxt[this.language, 0x1c9], "txt12_0");
            }
            if (GUI.Button(Crypto.Rect2(370f, 158f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
            {
                if (this.sound_UI != null)
                {
                    this.script_soundUI.SoundOn(1);
                }
                this.menu_kind = 0;
            }
        }
        if (this.confirm > 0)
        {
            GUI.enabled = true;
            switch (this.confirm)
            {
                case 1:
                    GUI.DrawTexture(Crypto.Rect2(112f, 100f, 256f, 128f), this.pop_blank2);
                    GUI.Label(Crypto.Rect2(112f, 120f, 256f, 14f), Language.intxt[this.language, 0x10d], "txt12_0");
                    GUI.DrawTexture(Crypto.Rect2(144f, 150f, 192f, 16f), this.titlebase);
                    GUI.DrawTexture(Crypto.Rect2(180f, 150f, 16f, 16f), this.ico_stamina);
                    GUI.DrawTexture(Crypto.Rect2(236f, 150f, 16f, 16f), this.ico_arrow);
                    GUI.Label(Crypto.Rect2(180f, 150f, 128f, 14f), string.Concat(new object[] { string.Empty, this.pet_hunger[this.currentpet], "            ", Mathf.Min(5, this.pet_hunger[this.currentpet] + 1) }), "txt12_w");
                    GUI.DrawTexture(Crypto.Rect2(214f, 168f, 16f, 16f), this.cost_icon);
                    GUI.Label(Crypto.Rect2(214f, 168f, 64f, 16f), "20", "txt12_0");
                    if (GUI.Button(Crypto.Rect2(170f, 190f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        if (Crypto.Property_change(-this.cost_feed, false))
                        {
                            this.coin -= this.cost_feed;
                            this.pet_hunger[this.currentpet] = Mathf.Min(5, this.pet_hunger[this.currentpet] + 1);
                            PlayerPrefsX.SetIntArray("n25", this.pet_hunger);
                            this.warning_hungry = false;
                            this.confirm = 0;
                        }
                        for (int num8 = 0; num8 < 2; num8++)
                        {
                            if (this.pet_hunger[num8] <= 0)
                            {
                                this.warning_hungry = true;
                            }
                        }
                    }
                    else if (GUI.Button(Crypto.Rect2(240f, 190f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.confirm = 0;
                    }
                    break;

                case 2:
                    GUI.DrawTexture(Crypto.Rect2(112f, 100f, 256f, 128f), this.pop_blank2);
                    GUI.Label(Crypto.Rect2(112f, 120f, 256f, 14f), Language.intxt[this.language, 270], "txt12_0");
                    GUI.DrawTexture(Crypto.Rect2(144f, 150f, 192f, 16f), this.titlebase);
                    GUI.DrawTexture(Crypto.Rect2(180f, 150f, 16f, 16f), this.ico_stamina);
                    GUI.DrawTexture(Crypto.Rect2(236f, 150f, 16f, 16f), this.ico_arrow);
                    GUI.Label(Crypto.Rect2(180f, 150f, 128f, 14f), string.Empty + this.pet_hunger[this.currentpet] + "            5", "txt12_w");
                    GUI.DrawTexture(Crypto.Rect2(214f, 168f, 16f, 16f), this.cost_icon);
                    GUI.Label(Crypto.Rect2(214f, 168f, 64f, 16f), string.Empty + ((5 - this.pet_hunger[this.currentpet]) * 20), "txt12_0");
                    if (GUI.Button(Crypto.Rect2(170f, 190f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        if (Crypto.Property_change(-this.cost_feed * (5 - this.pet_hunger[this.currentpet]), false))
                        {
                            this.coin -= this.cost_feed * (5 - this.pet_hunger[this.currentpet]);
                            this.pet_hunger[this.currentpet] = 5;
                            PlayerPrefsX.SetIntArray("n25", this.pet_hunger);
                            this.confirm = 0;
                        }
                    }
                    else if (GUI.Button(Crypto.Rect2(240f, 190f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.confirm = 0;
                    }
                    break;

                case 3:
                    GUI.DrawTexture(Crypto.Rect2(112f, 100f, 256f, 128f), this.pop_blank2);
                    GUI.Label(Crypto.Rect2(112f, 110f, 256f, 16f), Language.intxt[this.language, 0x10f], "txt12_0");
                    GUI.Label(Crypto.Rect2(128f, 132f, 224f, 16f), Language.intxt[this.language, this.ps[this.currentpet, 2]._info], "txt12_0");
                    GUI.DrawTexture(Crypto.Rect2(144f, 156f, 192f, 16f), this.titlebase);
                    GUI.DrawTexture(Crypto.Rect2(260f, 156f, 16f, 16f), this.ico_arrow);
                    GUI.Label(Crypto.Rect2(160f, 156f, 80f, 14f), Language.intxt[this.language, this.ps[this.currentpet, 3]._info], "txt12_w");
                    GUI.Label(Crypto.Rect2(204f, 156f, 128f, 14f), string.Concat(new object[] { string.Empty, this.ps[this.currentpet, this.pet_passiveskill[this.currentpet]]._passive, "            ", this.ps[this.currentpet, this.pet_passiveskill[this.currentpet] + 1]._passive }), "txt12_w");
                    GUI.DrawTexture(Crypto.Rect2(214f, 174f, 16f, 16f), this.jade_icon);
                    GUI.Label(Crypto.Rect2(214f, 174f, 64f, 16f), "2", "txt12_0");
                    GUI.Label(Crypto.Rect2(240f, 174f, 128f, 16f), Language.intxt[this.language, 350], "txt12_b");
                    if (GUI.Button(Crypto.Rect2(170f, 190f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                    {
                        if (this.jade >= this.ps[this.currentpet, this.pet_passiveskill[this.currentpet]]._price)
                        {
                            if (Crypto.Property_change(-this.ps[this.currentpet, this.pet_passiveskill[this.currentpet]]._price, true))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(0);
                                }
                                this.jade -= this.ps[this.currentpet, this.pet_passiveskill[this.currentpet]]._price;
                                this.pet_passiveskill[this.currentpet]++;
                                PlayerPrefsX.SetIntArray("n27", this.pet_passiveskill);
                                PurchaseLog.LogOn(Language.intxt[this.language, 0xea] + " (2)\t" + Language.intxt[this.language, 0xe7]);
                            }
                            this.confirm = 0;
                        }
                        else
                        {
                            this.confirm = 6;
                            this.Delay(1f);
                        }
                    }
                    else if (GUI.Button(Crypto.Rect2(240f, 190f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.confirm = 0;
                    }
                    break;

                case 4:
                    GUI.DrawTexture(Crypto.Rect2(112f, 100f, 256f, 128f), this.pop_blank2);
                    GUI.Label(Crypto.Rect2(112f, 110f, 256f, 16f), Language.intxt[this.language, 0x110], "txt12_0");
                    GUI.DrawTexture(Crypto.Rect2(144f, 132f, 192f, 16f), this.titlebase);
                    GUI.DrawTexture(Crypto.Rect2(144f, 152f, 192f, 16f), this.titlebase);
                    GUI.DrawTexture(Crypto.Rect2(260f, 132f, 16f, 16f), this.ico_arrow);
                    GUI.DrawTexture(Crypto.Rect2(260f, 152f, 16f, 16f), this.ico_arrow);
                    GUI.Label(Crypto.Rect2(152f, 132f, 80f, 14f), Language.intxt[this.language, 0x112], "txt12_w");
                    GUI.Label(Crypto.Rect2(152f, 152f, 80f, 14f), Language.intxt[this.language, 0x111], "txt12_w");
                    GUI.Label(Crypto.Rect2(204f, 132f, 128f, 14f), string.Concat(new object[] { string.Empty, this.ps[this.currentpet, this.pet_activeskill[this.currentpet]]._attackpoint, "            ", this.ps[this.currentpet, this.pet_activeskill[this.currentpet] + 1]._attackpoint }), "txt12_w");
                    GUI.Label(Crypto.Rect2(204f, 152f, 128f, 14f), string.Concat(new object[] { string.Empty, this.ps[this.currentpet, this.pet_activeskill[this.currentpet]]._duration, "            ", this.ps[this.currentpet, this.pet_activeskill[this.currentpet] + 1]._duration }), "txt12_w");
                    GUI.DrawTexture(Crypto.Rect2(214f, 170f, 16f, 16f), this.jade_icon);
                    GUI.Label(Crypto.Rect2(214f, 170f, 64f, 16f), "2", "txt12_0");
                    GUI.Label(Crypto.Rect2(240f, 170f, 128f, 16f), Language.intxt[this.language, 350], "txt12_b");
                    if (GUI.Button(Crypto.Rect2(170f, 190f, 64f, 32f), Language.intxt[this.language, 0], this.bt_yesno))
                    {
                        if (this.jade >= this.ps[this.currentpet, this.pet_activeskill[this.currentpet]]._price)
                        {
                            if (Crypto.Property_change(-this.ps[this.currentpet, this.pet_activeskill[this.currentpet]]._price, true))
                            {
                                if (this.sound_UI != null)
                                {
                                    this.script_soundUI.SoundOn(0);
                                }
                                this.jade -= this.ps[this.currentpet, this.pet_activeskill[this.currentpet]]._price;
                                this.pet_activeskill[this.currentpet]++;
                                PlayerPrefsX.SetIntArray("n23", this.pet_activeskill);
                                PurchaseLog.LogOn(Language.intxt[this.language, 0xea] + " (2)\t" + Language.intxt[this.language, 0xe8]);
                            }
                            this.confirm = 0;
                        }
                        else
                        {
                            this.confirm = 6;
                            this.Delay(1f);
                        }
                    }
                    else if (GUI.Button(Crypto.Rect2(240f, 190f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.confirm = 0;
                    }
                    break;

                case 5:
                    GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                    GUI.Label(Crypto.Rect2(120f, 130f, 240f, 16f), Language.intxt[this.language, 0x16], "txt12_0");
                    if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        Crypto.Save_int_key("cashshopkind", 2);
                        this.confirm = 0;
                        if (this.cashshop == null)
                        {
                            this.cashshop = Resources.Load("CashShop") as GameObject;
                        }
                        UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
                    }
                    else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.confirm = 0;
                    }
                    break;

                case 6:
                    GUI.DrawTexture(Crypto.Rect2(112f, 90f, 256f, 128f), this.pop_blank2);
                    GUI.Label(Crypto.Rect2(120f, 130f, 230f, 16f), Language.intxt[this.language, 0x15], "txt12_0");
                    if (GUI.Button(Crypto.Rect2(170f, 180f, 64f, 32f), Language.intxt[this.language, 1], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(0);
                        }
                        Crypto.Save_int_key("cashshopkind", 1);
                        this.confirm = 0;
                        if (this.cashshop == null)
                        {
                            this.cashshop = Resources.Load("CashShop") as GameObject;
                        }
                        UnityEngine.Object.Instantiate(this.cashshop.transform, Vector3.zero, Quaternion.identity);
                    }
                    else if (GUI.Button(Crypto.Rect2(240f, 180f, 64f, 32f), Language.intxt[this.language, 2], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.confirm = 0;
                    }
                    break;

                case 7:
                    GUI.DrawTexture(Crypto.Rect2(112f, 110f, 256f, 64f), this.pop_blank);
                    GUI.Label(Crypto.Rect2(112f, 110f, 256f, 64f), Language.intxt[this.language, 0x10b], "txt12_0");
                    if (this.f_delay == 0f)
                    {
                        this.confirm = 0;
                    }
                    break;

                case 10:
                    GUI.DrawTexture(Crypto.Rect2(112f, 100f, 256f, 128f), this.pop_blank2);
                    GUI.Box(Crypto.Rect2(176f, 116f, 128f, 22f), Language.intxt[this.language, 0x109]);
                    GUI.Label(Crypto.Rect2(128f, 130f, 224f, 42f), Language.intxt[this.language, 0x117], "txt12_0");
                    GUI.Label(Crypto.Rect2(128f, 156f, 224f, 42f), Language.intxt[this.language, 280], "txt12_0");
                    if (GUI.Button(Crypto.Rect2(286f, 188f, 64f, 32f), Language.intxt[this.language, 3], this.bt_yesno))
                    {
                        if (this.sound_UI != null)
                        {
                            this.script_soundUI.SoundOn(1);
                        }
                        this.confirm = 0;
                    }
                    break;
            }
        }
    }

    private void SetAngel(int _index)
    {
        this.angel_name = Language.intxt[this.language, this.script_dbangel.ag[_index]._name];
        this.angel_info = Language.intxt[this.language, this.script_dbangel.ag[_index]._info];
        this.angel_firerate = 10f - this.script_dbangel.ag[_index]._firerate;
    }

    private void Start()
    {
        this.maxExtremeStage = Crypto.Load_int_key("n48");
        this.maxExtremeStage = (this.maxExtremeStage - 1) / 8;
        this.language = PlayerPrefs.GetInt("language");
        this.ps = base.GetComponent<DB_PetSkill>().ps;
        this.script_dbangel = base.GetComponent<DB_angel>();
        this.cur_angel = Crypto.Load_int_key("n61");
        if (this.cur_angel != 0)
        {
            this.sel_angel = this.cur_angel;
            this.SetAngel(this.sel_angel - 1);
        }
        this.bg_posX_l = -380;
        this.bg_posX_r = 480;
        this.icon_posY = 340;
        this.cost_feed = 20;
        this.dragrange = Screen.height * 0.375f;
        this.pet_activeskill = PlayerPrefsX.GetIntArray("n23");
        this.pet_passiveskill = PlayerPrefsX.GetIntArray("n27");
        this.pet_hunger = PlayerPrefsX.GetIntArray("n25");
        for (int i = 0; i < 2; i++)
        {
            if (this.pet_hunger[i] <= 0)
            {
                this.warning_hungry = true;
            }
        }
        base.InvokeRepeating("Warning_iconsize", 0.5f, 0.34f);
        this.sound_UI = GameObject.FindWithTag("sound");
        if (this.sound_UI != null)
        {
            this.script_soundUI = this.sound_UI.GetComponent<SoundEf_UI>();
        }
        this.gamemode = Crypto.Load_int_key("gamemode");
    }

    private void Update()
    {
        if (this.b_delay)
        {
            this.f_delay -= Time.deltaTime;
            if (this.f_delay <= 0f)
            {
                this.b_delay = false;
                this.f_delay = 0f;
            }
        }
        if (this.bg_posX_l < -64)
        {
            this.bg_posX_l += (int) Mathf.Min((float) -this.bg_posX_l, Time.deltaTime * 600f);
        }
        else
        {
            this.bg_posX_l = -64;
        }
        if (this.menu_kind > 0)
        {
            this.bg_posX_r -= (int) Mathf.Min((float) this.bg_posX_r, Time.deltaTime * 1500f);
            if (this.bg_posX_r <= 0)
            {
                this.bg_posX_r = 0;
                this.icon_posY -= (int) Mathf.Min((float) this.icon_posY, Time.deltaTime * 500f);
                if (this.icon_posY <= 230)
                {
                    this.icon_posY = 230;
                }
            }
        }
        else
        {
            this.bg_posX_r = 480;
            this.icon_posY = 340;
        }
        if (Input.GetMouseButtonDown(0))
        {
            if (Input.mousePosition.y < this.dragrange)
            {
                this.dragOn = true;
                this.prevposX = Input.mousePosition.x;
                this.currentX = this.dragposX;
            }
        }
        else if (Input.GetMouseButtonUp(0))
        {
            this.dragOn = false;
            this.scrollOn = false;
        }
        if (this.dragOn)
        {
            if (Mathf.Abs((float) (Input.mousePosition.x - this.prevposX)) > 8f)
            {
                this.scrollOn = true;
            }
            this.dragposX = ((Input.mousePosition.x - this.prevposX) * (480f / ((float) Screen.width))) + this.currentX;
            this.dragposX = Mathf.Min(this.dragposX, 0f);
            this.dragposX = Mathf.Max(this.dragposX, -150f);
        }
    }

    private void Warning_iconsize()
    {
        this.icon_size = (this.icon_size + 1) % 2;
    }
}


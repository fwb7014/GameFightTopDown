using System;
using UnityEngine;

public class Obj_break : MonoBehaviour
{
    public bool isrunning;

    private void Start()
    {
        base.animation["obj_break"].speed = 0.25f;
        if (!this.isrunning)
        {
            UnityEngine.Object.Destroy(base.gameObject, 1.2f);
        }
    }

    private void Update()
    {
        if (this.isrunning)
        {
            if (base.transform.position.z > -0.6f)
            {
                Transform transform = base.transform;
                transform.position += (Vector3) ((Vector3.forward * -1.8f) * Time.deltaTime);
            }
            else
            {
                UnityEngine.Object.Destroy(base.gameObject);
            }
        }
    }
}


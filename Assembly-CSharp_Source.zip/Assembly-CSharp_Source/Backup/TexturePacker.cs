using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class TexturePacker : MonoBehaviour
{
    public bool generateColorTextures = true;
    public Color generatedMaterialColor = Color.white;
    private Dictionary<Shader, Material> generatedMaterials = new Dictionary<Shader, Material>();
    private Dictionary<Material, Rect> generatedUV2s = new Dictionary<Material, Rect>();
    private Dictionary<Material, Rect> generatedUVs = new Dictionary<Material, Rect>();
    public bool generateLightMapUVs = true;
    private Dictionary<Shader, List<Material>> shaderToMaterial = new Dictionary<Shader, List<Material>>();

    public static Array DeleteDuplicates(Array arr)
    {
        if (arr.Rank != 1)
        {
            throw new ArgumentException("Multiple-dimension arrays are not supported");
        }
        Hashtable hashtable = new Hashtable(arr.Length * 2);
        ArrayList list = new ArrayList();
        IEnumerator enumerator = arr.GetEnumerator();
        try
        {
            while (enumerator.MoveNext())
            {
                object current = enumerator.Current;
                if (!hashtable.Contains(current))
                {
                    list.Add(current);
                    hashtable.Add(current, null);
                }
            }
        }
        finally
        {
            IDisposable disposable = enumerator as IDisposable;
            if (disposable == null)
            {
            }
            disposable.Dispose();
        }
        return list.ToArray(arr.GetType().GetElementType());
    }

    private void Start()
    {
        Vector2[] uv;
        Vector2[] vectorArray2;
        List<Component> list = new List<Component>();
        list.AddRange(base.GetComponentsInChildren(typeof(MeshFilter)));
        for (int i = 0; i < list.Count; i++)
        {
            Renderer renderer = list[i].renderer;
            vectorArray2 = ((MeshFilter) list[i]).mesh.uv2;
            if (((vectorArray2 == null) || (vectorArray2.Length == 0)) && this.generateLightMapUVs)
            {
                uv = ((MeshFilter) list[i]).mesh.uv;
                vectorArray2 = new Vector2[uv.Length];
                Array.Copy(uv, vectorArray2, uv.Length);
                ((MeshFilter) list[i]).mesh.uv2 = vectorArray2;
            }
            bool flag = true;
            if (((renderer != null) && renderer.enabled) && (renderer.material != null))
            {
                Material[] sharedMaterials = renderer.sharedMaterials;
                if (sharedMaterials != null)
                {
                    foreach (Material material in sharedMaterials)
                    {
                        if (this.generateColorTextures)
                        {
                            if (material.mainTexture == null)
                            {
                                Texture2D texture = new Texture2D(4, 4);
                                for (int k = 0; k < texture.height; k++)
                                {
                                    for (int m = 0; m < texture.width; m++)
                                    {
                                        texture.SetPixel(m, k, material.color);
                                    }
                                }
                                texture.Apply();
                                material.SetTexture("_MainTex", texture);
                                material.color = Color.white;
                            }
                            else
                            {
                                flag = false;
                            }
                        }
                        if ((((material.HasProperty("_LightMap") && ((((MeshFilter) list[i]).mesh.uv2.Length != 0) || this.generateLightMapUVs)) && (material.GetTexture("_LightMap") != null)) || !material.HasProperty("_LightMap")) && (((material.mainTextureScale == new Vector2(1f, 1f)) && (material.mainTextureOffset == Vector2.zero)) && ((material.shader != null) && (material.mainTexture != null))))
                        {
                            if (this.shaderToMaterial.ContainsKey(material.shader))
                            {
                                this.shaderToMaterial[material.shader].Add(material);
                            }
                            else
                            {
                                this.shaderToMaterial[material.shader] = new List<Material>();
                                this.shaderToMaterial[material.shader].Add(material);
                            }
                        }
                    }
                    if (this.generateColorTextures && flag)
                    {
                        Vector2[] vectorArray3 = ((MeshFilter) list[i]).mesh.uv;
                        for (int n = 0; n < vectorArray3.Length; n++)
                        {
                            vectorArray3[n] = new Vector2(0.5f, 0.5f);
                        }
                        ((MeshFilter) list[i]).mesh.uv = vectorArray3;
                    }
                }
            }
        }
        foreach (Shader shader in this.shaderToMaterial.Keys)
        {
            Texture2D textured2 = new Texture2D(0x400, 0x400);
            Texture2D[] textures = new Texture2D[this.shaderToMaterial[shader].Count];
            this.generatedMaterials[shader] = new Material(shader);
            for (int num6 = 0; num6 < textures.Length; num6++)
            {
                textures[num6] = this.shaderToMaterial[shader][num6].mainTexture as Texture2D;
            }
            Rect[] rectArray = textured2.PackTextures(textures, 0, 0x800);
            textured2.Apply();
            this.generatedMaterials[shader].CopyPropertiesFromMaterial(this.shaderToMaterial[shader][0]);
            this.generatedMaterials[shader].mainTexture = textured2;
            this.generatedMaterials[shader].color = this.generatedMaterialColor;
            for (int num7 = 0; num7 < textures.Length; num7++)
            {
                if (this.shaderToMaterial[shader][num7].HasProperty("_LightMap"))
                {
                    textures[num7] = this.shaderToMaterial[shader][num7].GetTexture("_LightMap") as Texture2D;
                }
            }
            textured2 = new Texture2D(0x400, 0x400);
            Rect[] rectArray2 = textured2.PackTextures(textures, 0, 0x800);
            textured2.Apply();
            if (this.generatedMaterials[shader].HasProperty("_LightMap"))
            {
                this.generatedMaterials[shader].SetTexture("_LightMap", textured2);
            }
            for (int num8 = 0; num8 < textures.Length; num8++)
            {
                this.generatedUVs[this.shaderToMaterial[shader][num8]] = rectArray[num8];
                this.generatedUV2s[this.shaderToMaterial[shader][num8]] = rectArray2[num8];
            }
        }
        for (int j = 0; j < list.Count; j++)
        {
            int subMeshCount = ((MeshFilter) list[j]).mesh.subMeshCount;
            Material[] materialArray3 = list[j].gameObject.renderer.sharedMaterials;
            uv = ((MeshFilter) list[j]).mesh.uv;
            vectorArray2 = ((MeshFilter) list[j]).mesh.uv2;
            for (int num11 = 0; num11 < subMeshCount; num11++)
            {
                if (this.generatedUVs.ContainsKey(materialArray3[num11]))
                {
                    Rect rect = this.generatedUVs[materialArray3[num11]];
                    Rect rect2 = this.generatedUV2s[materialArray3[num11]];
                    int[] numArray = DeleteDuplicates(((MeshFilter) list[j]).mesh.GetTriangles(num11)) as int[];
                    materialArray3[num11] = this.generatedMaterials[list[j].gameObject.renderer.sharedMaterials[num11].shader];
                    foreach (int num12 in numArray)
                    {
                        uv[num12] = new Vector2((uv[num12].x * rect.width) + rect.x, (uv[num12].y * rect.height) + rect.y);
                        if ((vectorArray2 != null) && (vectorArray2.Length != 0))
                        {
                            vectorArray2[num12] = new Vector2((vectorArray2[num12].x * rect2.width) + rect2.x, (vectorArray2[num12].y * rect2.height) + rect2.y);
                        }
                    }
                }
            }
            list[j].gameObject.renderer.sharedMaterials = materialArray3;
            ((MeshFilter) list[j]).mesh.uv = uv;
            if ((vectorArray2 != null) && (vectorArray2.Length != 0))
            {
                ((MeshFilter) list[j]).mesh.uv2 = vectorArray2;
            }
        }
    }
}


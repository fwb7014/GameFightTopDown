using System;
using UnityEngine;

public class SoundEf_UI : MonoBehaviour
{
    public AudioClip[] s_click = new AudioClip[2];

    public void SetBGM(float _vol)
    {
        base.audio.volume = _vol;
    }

    public void SoundOn(short s)
    {
        base.transform.GetChild(0).audio.PlayOneShot(this.s_click[s]);
    }

    private void Start()
    {
        UnityEngine.Object.DontDestroyOnLoad(base.transform.gameObject);
        base.audio.volume = PlayerPrefs.GetFloat("vol_bgm");
    }

    private void Update()
    {
    }
}


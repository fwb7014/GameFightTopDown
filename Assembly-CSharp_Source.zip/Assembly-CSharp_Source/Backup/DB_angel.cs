using System;
using UnityEngine;

public class DB_angel : MonoBehaviour
{
    public angelkind[] ag = new angelkind[8];

    private void Awake()
    {
        this.ag[0]._name = 0x1b4;
        this.ag[0]._info = 0x1be;
        this.ag[0]._firerate = 3f;
        this.ag[0]._speed = 0.3f;
        this.ag[0]._arrowkind = 0x19;
        this.ag[0]._splashEF = 0;
        this.ag[1]._name = 0x1b5;
        this.ag[1]._info = 0x1bf;
        this.ag[1]._firerate = 3f;
        this.ag[1]._speed = 0.32f;
        this.ag[1]._arrowkind = 30;
        this.ag[1]._splashEF = 2;
        this.ag[2]._name = 0x1b6;
        this.ag[2]._info = 0x1c0;
        this.ag[2]._firerate = 5f;
        this.ag[2]._speed = 0.34f;
        this.ag[2]._arrowkind = 0x17;
        this.ag[2]._splashEF = 3;
        this.ag[3]._name = 0x1b7;
        this.ag[3]._info = 0x1c1;
        this.ag[3]._firerate = 4f;
        this.ag[3]._speed = 0.36f;
        this.ag[3]._arrowkind = 0x1f;
        this.ag[3]._splashEF = 4;
        this.ag[4]._name = 440;
        this.ag[4]._info = 450;
        this.ag[4]._firerate = 3.5f;
        this.ag[4]._speed = 0.38f;
        this.ag[4]._arrowkind = 0x1f;
        this.ag[4]._splashEF = 5;
        this.ag[5]._name = 0x1b9;
        this.ag[5]._info = 0x1c3;
        this.ag[5]._firerate = 3.4f;
        this.ag[5]._speed = 0.4f;
        this.ag[5]._arrowkind = 0x19;
        this.ag[5]._splashEF = 6;
        this.ag[6]._name = 0x1ba;
        this.ag[6]._info = 0x1c4;
        this.ag[6]._firerate = 2.2f;
        this.ag[6]._speed = 0.6f;
        this.ag[6]._arrowkind = 0x19;
        this.ag[6]._splashEF = 0;
        this.ag[7]._name = 0x1bb;
        this.ag[7]._info = 0x1c5;
        this.ag[7]._firerate = 3.2f;
        this.ag[7]._speed = 0.5f;
        this.ag[7]._arrowkind = 0x19;
        this.ag[7]._splashEF = 8;
    }
}


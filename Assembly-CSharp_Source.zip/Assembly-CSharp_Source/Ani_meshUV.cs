using System;
using UnityEngine;

public class Ani_meshUV : MonoBehaviour
{
    private bool attack;
    private bool damaged;
    private bool dead;
    private int framesPerSecond = 20;
    private int impact = 0x12;
    private int index;
    private int length = 14;
    private bool loop = true;
    private bool loopattack;
    private Collider mycollider;
    private Material mymaterial;
    private Renderer myrenderer;
    private Transform mytransform;
    private Vector2 offset;
    private int oldindex = -1;
    private Vector2 size;
    private int startframe;
    private float starttime;
    private Vector2[] tempUV = new Vector2[4];
    private Mesh thismesh;
    private float uIndex;
    private int uvAnimationTileX = 5;
    private int uvAnimationTileY = 5;
    private int vIndex;
    private bool visible;

    private void Awake()
    {
        this.thismesh = base.GetComponent<MeshFilter>().mesh;
        this.starttime = 0f;
        this.mytransform = base.transform;
        this.mycollider = base.collider;
        this.myrenderer = base.renderer;
        this.size = new Vector2(1f / ((float) this.uvAnimationTileX), 1f / ((float) this.uvAnimationTileY));
    }

    public void ColliderOn()
    {
        this.mycollider.enabled = true;
    }

    public void Damaged(Vector3 _hitdir)
    {
        if (!this.damaged)
        {
            this.index = 0;
            this.starttime = 0f;
            this.startframe = 0x16;
            this.length = 3;
            this.loop = false;
            this.damaged = true;
            this.attack = false;
            this.framesPerSecond = 10;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if ((!this.damaged && !this.attack) && (other.gameObject.layer == 8))
        {
            this.index = 0;
            this.starttime = 0f;
            this.startframe = 14;
            this.length = 9;
            this.loop = false;
            this.attack = true;
            this.framesPerSecond = 12;
            this.mycollider.enabled = false;
        }
    }

    private void Update()
    {
        if (!this.dead)
        {
            this.visible = this.myrenderer.isVisible;
            if (!this.attack && !this.damaged)
            {
                if (this.mytransform.position.z < 9.4f)
                {
                    this.mytransform.position += (Vector3) ((Vector3.forward * Time.deltaTime) * 0.2f);
                }
                else if (!this.loopattack)
                {
                    this.startframe = 14;
                    this.length = 9;
                    this.loop = false;
                    this.attack = true;
                    this.framesPerSecond = 12;
                }
                if (!this.visible)
                {
                    return;
                }
            }
            this.starttime += Time.deltaTime;
            this.index = (int) (this.starttime * this.framesPerSecond);
            if (this.loop)
            {
                this.index = (this.index % this.length) + this.startframe;
            }
            else
            {
                this.index += this.startframe;
            }
            this.uIndex = this.index % this.uvAnimationTileX;
            this.vIndex = (this.uvAnimationTileY - 1) - (this.index / this.uvAnimationTileX);
            if (this.index != this.oldindex)
            {
                if (this.index >= (this.startframe + this.length))
                {
                    if (this.attack)
                    {
                        this.index = 0;
                        this.starttime = 0f;
                        this.startframe = 0;
                        this.oldindex = -1;
                        this.length = 14;
                        this.loop = true;
                        this.attack = false;
                        this.framesPerSecond = 20;
                        base.gameObject.layer = 15;
                        base.Invoke("ColliderOn", 0.5f);
                    }
                    else if (this.damaged)
                    {
                        this.index = (this.startframe + this.length) - 1;
                        this.dead = true;
                        UnityEngine.Object.Destroy(base.gameObject, 2f);
                    }
                    this.mycollider.enabled = false;
                    this.uIndex = this.index % this.uvAnimationTileX;
                    this.vIndex = (this.uvAnimationTileY - 1) - (this.index / this.uvAnimationTileX);
                }
                if (this.index == this.impact)
                {
                    this.mycollider.enabled = true;
                    base.gameObject.layer = 0x1b;
                }
                if (this.visible)
                {
                    this.offset = (Vector2) (((Vector2.right * this.uIndex) * this.size.x) + ((Vector2.up * this.vIndex) * this.size.y));
                    this.tempUV[2] = this.offset + ((Vector2) (Vector2.up * this.size.y));
                    this.tempUV[3] = (Vector2) ((this.offset + (Vector2.up * this.size.y)) + (Vector2.right * this.size.x));
                    this.tempUV[0] = this.offset;
                    this.tempUV[1] = this.offset + ((Vector2) (Vector2.right * this.size.x));
                    this.thismesh.uv = this.tempUV;
                }
                this.oldindex = this.index;
            }
        }
    }
}


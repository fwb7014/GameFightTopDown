using System;
using UnityEngine;

public class AI_StoryEnemy : MonoBehaviour
{
    private int accuracy;
    private float attackrange;
    private bool attackstart;
    private int block;
    private Transform cha1;
    private Vector3 chapos;
    private int currentattack;
    private float damage;
    private bool dash;
    public AudioClip death;
    private Vector3 directionVector;
    private bool downhigh;
    private bool downhigh2;
    private monster enemy;
    public int enemykind;
    private float firerange;
    private int hp;
    private Transform hpbar;
    private bool impact;
    public AudioClip kick;
    private bool life = true;
    private Quaternion lookrotation;
    private int maxhp;
    private Transform mon_destroy;
    public int monmovestat;
    public AudioClip move;
    private float movespeed;
    private Transform mytransform;
    private Texture originTex;
    private float runspeed;
    public AudioClip scream;
    private Cam_Move script_cam;
    private Cha_Control script_cha;
    private Hp_bar script_hpbar;
    private Monster_efs script_monEf;
    private NPC1 script_npc;
    private SoundEf_slash script_sound;
    public AudioClip stab;
    public Transform target;
    private Vector3 targetpos;

    public void Attack(int _kind)
    {
        switch (_kind)
        {
            case 0:
                base.animation.Play("story_attack1");
                base.animation.PlayQueued("story_attack1_i", QueueMode.CompleteOthers).speed = base.animation["story_attack1_i"].speed;
                break;

            case 1:
                base.animation.Play("story_attack2");
                base.animation.PlayQueued("story_attack2_i", QueueMode.CompleteOthers).speed = base.animation["story_attack2_i"].speed;
                break;

            case 2:
                base.animation.Play("story_attack3");
                base.animation.PlayQueued("story_attack3_i", QueueMode.CompleteOthers).speed = base.animation["story_attack3_i"].speed;
                break;
        }
    }

    private void Awake()
    {
        this.mytransform = base.transform;
    }

    public void Grabed()
    {
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer >= 20)
        {
            this.currentattack = 0;
            this.hpbar.renderer.enabled = true;
            this.accuracy = this.script_cha.hitrate;
            this.attackstart = false;
            this.downhigh2 = this.script_cha.attack_rising;
            Vector3 vector = Vector3.Normalize(this.mytransform.position - this.chapos);
            float num = 0f;
            int num2 = 0;
            switch (other.gameObject.layer)
            {
                case 20:
                    num = 50f;
                    num2 = UnityEngine.Random.Range(0, 100);
                    this.damage = this.script_cha.atk;
                    this.script_cam.Hitcam();
                    this.downhigh = false;
                    break;

                case 0x15:
                    num = 30f;
                    num2 = 100;
                    this.damage = this.script_cha.atk;
                    this.script_cam.Hitcam2(1f);
                    this.downhigh = true;
                    break;

                case 0x1c:
                    num = 50f;
                    this.damage = this.script_cha.atk;
                    this.script_cam.Hitcam();
                    this.movespeed = 0f;
                    break;
            }
            if ((num2 < (this.block - this.accuracy)) && (this.monmovestat >= 0))
            {
                this.script_cha.Blocked(this.mytransform.position);
                base.rigidbody.AddForce((Vector3) (vector * 10f));
            }
            else
            {
                this.script_sound.SoundOn(1);
                base.animation.Stop();
                if (this.downhigh || this.downhigh2)
                {
                    this.mytransform.Rotate((float) 0f, (float) UnityEngine.Random.Range(0, 360), (float) 0f);
                    base.animation.Play("down_high");
                }
                else
                {
                    base.animation.Play("down");
                }
                base.rigidbody.AddForce((Vector3) (vector * num));
                this.script_monEf.CreatBlood(this.mytransform.position, this.directionVector);
                this.hp -= (int) this.damage;
                this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, 0.15f, 0);
                base.audio.PlayOneShot(this.scream);
            }
            if ((this.hp <= 0) && this.life)
            {
                this.monmovestat = -4;
                this.life = false;
                this.script_sound.SoundOn(4);
                UnityEngine.Object.Destroy(base.gameObject);
                UnityEngine.Object.Destroy(this.hpbar.gameObject);
                Vector3 position = this.mytransform.position;
                position[1] = 0f;
                this.script_monEf.EnemyDead(2, position, this.originTex, this.mytransform.localScale, vector);
                GameObject.FindWithTag("Respawn").GetComponent<Spawn_story>().StoryEnemyDead();
            }
        }
    }

    private void Start()
    {
        GameObject obj2 = GameObject.FindWithTag("Respawn");
        this.enemy = obj2.GetComponent<DB_Monster>().enemy[this.enemykind];
        this.maxhp = 5;
        this.block = this.enemy._block;
        this.runspeed = this.enemy._runspeed;
        this.firerange = 0.22f;
        base.animation["move"].speed = this.enemy._speed_move;
        base.animation["down"].speed = 0.24f;
        base.animation["down_high"].speed = 0.28f;
        base.animation["stop"].speed = 0.1f;
        base.animation["story_attack1"].speed = 0.3f;
        base.animation["story_attack1_i"].speed = 0.3f;
        base.animation["story_attack2"].speed = 0.3f;
        base.animation["story_attack2_i"].speed = 0.3f;
        base.animation["story_attack3"].speed = 0.3f;
        base.animation["story_attack3_i"].speed = 0.3f;
        base.animation["idle"].speed = this.enemy._speed_idle;
        base.animation["down"].layer = 2;
        base.animation["down_high"].layer = 2;
        base.animation["move"].layer = 0;
        base.animation["stop"].layer = 0;
        base.animation["story_attack1"].layer = 1;
        base.animation["story_attack1_i"].layer = 1;
        base.animation["story_attack2"].layer = 1;
        base.animation["story_attack2_i"].layer = 1;
        base.animation["story_attack3"].layer = 1;
        base.animation["story_attack3_i"].layer = 1;
        base.animation["idle"].layer = 0;
        this.monmovestat = 0;
        this.originTex = this.mytransform.Find("mon").renderer.material.mainTexture;
        this.cha1 = GameObject.FindWithTag("Player").transform;
        this.script_cha = this.cha1.gameObject.GetComponent<Cha_Control>();
        this.script_sound = GameObject.FindWithTag("sound").GetComponent<SoundEf_slash>();
        this.script_cam = Camera.main.GetComponent<Cam_Move>();
        this.script_monEf = GameObject.FindWithTag("efs_mon").GetComponent<Monster_efs>();
        this.hpbar = this.script_monEf.CreatHpbar(new Vector2(0.05f, 0.01f), false, false);
        this.script_npc = this.target.GetComponent<NPC1>();
        this.script_hpbar = this.hpbar.GetComponent<Hp_bar>();
        this.hp = this.maxhp;
        this.accuracy = this.script_cha.hitrate;
        this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, 0.15f, 0);
        this.script_monEf.CreatShadow(this.mytransform.Find("Bone_pelvis"), 1f);
        this.hpbar.renderer.enabled = false;
        base.animation.Play("move");
    }

    private void Update()
    {
        if (this.life)
        {
            this.targetpos = this.target.position;
            this.chapos = this.cha1.position;
            this.attackrange = Vector3.Distance(this.mytransform.position, this.targetpos);
            if (base.animation.IsPlaying("down_high"))
            {
                this.directionVector = Vector3.Normalize(this.targetpos - this.mytransform.position);
                this.monmovestat = -1;
            }
            else if (base.animation.IsPlaying("down"))
            {
                this.directionVector = Vector3.Normalize(this.targetpos - this.mytransform.position);
                this.monmovestat = -1;
            }
            else if ((base.animation.IsPlaying("story_attack1") || base.animation.IsPlaying("story_attack2")) || base.animation.IsPlaying("story_attack3"))
            {
                this.directionVector = Vector3.Normalize(this.targetpos - this.mytransform.position);
                this.impact = false;
                this.monmovestat = 11;
                if (this.directionVector != Vector3.zero)
                {
                    this.lookrotation = Quaternion.LookRotation(this.directionVector);
                    this.mytransform.rotation = Quaternion.Slerp(this.mytransform.rotation, this.lookrotation, Time.deltaTime * 6f);
                }
                if (!this.dash)
                {
                    this.mytransform.position += (Vector3) ((this.directionVector * Time.deltaTime) * 0.7f);
                }
                else
                {
                    this.mytransform.position = Vector3.Lerp(this.mytransform.position, this.target.position, Time.deltaTime * 5f);
                }
            }
            else if ((base.animation.IsPlaying("story_attack1_i") || base.animation.IsPlaying("story_attack2_i")) || base.animation.IsPlaying("story_attack3_i"))
            {
                this.dash = true;
                this.monmovestat = 12;
                if (!this.impact)
                {
                    this.script_npc.Behit();
                    this.impact = true;
                    base.audio.PlayOneShot(this.stab);
                }
                this.directionVector = Vector3.Normalize(this.targetpos - this.mytransform.position);
                if (this.directionVector != Vector3.zero)
                {
                    this.lookrotation = Quaternion.LookRotation(this.directionVector);
                    this.mytransform.rotation = Quaternion.Slerp(this.mytransform.rotation, this.lookrotation, Time.deltaTime * 6f);
                }
            }
            else if ((base.animation.IsPlaying("move") || base.animation.IsPlaying("stop")) || !base.animation.isPlaying)
            {
                this.directionVector = Vector3.Normalize(this.targetpos - this.mytransform.position);
                this.attackstart = false;
                this.monmovestat = 1;
                this.mytransform.position += (Vector3) ((this.directionVector * Time.deltaTime) * this.movespeed);
                if (this.directionVector != Vector3.zero)
                {
                    this.lookrotation = Quaternion.LookRotation(this.directionVector);
                }
                this.mytransform.rotation = Quaternion.Slerp(this.mytransform.rotation, this.lookrotation, Time.deltaTime * 3f);
            }
            else
            {
                this.monmovestat = 1;
            }
            if (this.attackrange > 1.1f)
            {
                this.movespeed = this.runspeed;
            }
            else if (this.attackrange < this.firerange)
            {
                if (!this.attackstart)
                {
                    if (this.monmovestat >= 0)
                    {
                        this.Attack(this.currentattack);
                        this.currentattack = (this.currentattack + 1) % 3;
                        this.attackstart = true;
                    }
                }
                else
                {
                    base.animation.CrossFade("stop");
                }
            }
            else
            {
                this.movespeed = this.runspeed;
                base.animation.CrossFade("move");
            }
        }
    }
}


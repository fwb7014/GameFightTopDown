using System;
using UnityEngine;

public class AI_General : MonoBehaviour
{
    private Vector3 arrowRotVector;
    private Vector3 arrowTargetVector;
    private int atkcount;
    private float atkspeed;
    private AnimationState attack_i;
    private bool attack_start;
    private Vector3 behitdir;
    private Transform c_spweapon;
    private Transform c_weapon;
    private bool call;
    private Transform cha1;
    private int damage;
    private int dash;
    private int defence;
    private float delay_call;
    private float delay_invicibility;
    public Transform direction_arrow;
    private Vector3 directionVector;
    private bool disable;
    private float distance_cha;
    public Transform ef_weapon;
    private bool efattach;
    private Vector3 efpos;
    private Quaternion efrot;
    private float fb;
    private Transform g_hp;
    private Gauge_UV gauge_hp;
    private int generalmovestat;
    private int grade;
    public int hp;
    private float hp_length;
    private bool life = true;
    private int maxhp;
    private Animation myanimation;
    private Collider mycollider;
    private Transform mytransform;
    private float power;
    private Vector3 rndpos;
    private float runspeed;
    private Cam_Move script_cam;
    private bool showme;
    public AudioClip snd_attack;
    private Transform sp_selweapon;
    public Transform[] sp_weapon = new Transform[2];
    private bool superarmor;
    private short unique = -1;

    public void AttackOn(Vector3 _enemypos)
    {
        if ((!this.life || this.showme) || this.call)
        {
            this.mycollider.enabled = false;
        }
        else if (!this.attack_start)
        {
            if (this.unique >= 0)
            {
                this.atkcount = (this.atkcount + 1) % (5 - this.grade);
            }
            this.directionVector = _enemypos - this.mytransform.position;
            this.myanimation.Play("m_attack1");
            this.attack_i = this.myanimation.PlayQueued("m_attack1_i");
            this.attack_i.layer = 1;
            this.attack_i.speed = this.atkspeed;
            this.attack_start = true;
            this.mytransform.rotation = Quaternion.LookRotation(this.directionVector);
        }
    }

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myanimation = base.animation;
        this.mycollider = base.collider;
        this.myanimation["move"].speed = 0.5f;
        this.myanimation["down"].speed = 0.2f;
        this.myanimation["dead_general"].speed = 0.2f;
        this.myanimation["idle"].speed = 0.25f;
        this.myanimation["down"].layer = 4;
        this.myanimation["dead_general"].layer = 4;
        this.myanimation["m_attack1"].layer = 1;
        this.myanimation["m_attack1_i"].layer = 1;
    }

    public void CallGeneral()
    {
        this.script_cam.LookTarget(this.mytransform, 30, 2f);
    }

    public void Damaged(Vector3 _damageVector)
    {
        if (!this.superarmor && this.life)
        {
            this.damage = (int) _damageVector.y;
            _damageVector[1] = 0f;
            this.myanimation.Stop();
            base.rigidbody.AddForce((Vector3) (_damageVector * 60f));
            this.damage = Mathf.Max(1, this.damage - this.defence);
            this.hp -= this.damage;
            this.mycollider.enabled = false;
            this.delay_invicibility = 3.5f;
            this.superarmor = true;
            this.HPgaugeSet();
            if (this.hp <= 0)
            {
                this.delay_invicibility = 0f;
                this.myanimation.Play("dead_general");
                this.life = false;
                base.CancelInvoke();
                this.showme = false;
                if (this.c_weapon != null)
                {
                    this.c_weapon.gameObject.active = false;
                    this.c_weapon.transform.position = (Vector3) (Vector3.up * 24f);
                }
                this.g_hp.gameObject.active = false;
                this.hp = 1;
            }
            else if (!this.call)
            {
                this.myanimation.Play("down");
            }
        }
    }

    public void HPfull()
    {
        this.g_hp.gameObject.active = true;
        this.hp = this.maxhp;
        this.HPgaugeSet();
        base.InvokeRepeating("SetRndPosition", 0f, 1f);
        this.disable = false;
        this.life = true;
        this.superarmor = false;
        this.mytransform.position = new Vector3(this.cha1.position.x, 0f, this.cha1.position.z);
        this.myanimation.Play("idle");
        this.mycollider.enabled = true;
    }

    public void HPgaugeSet()
    {
        this.hp_length = (1f - (((float) this.hp) / ((float) this.maxhp))) * 0.25f;
        this.gauge_hp.UvMove((Vector2) (Vector2.right * this.hp_length));
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == 8)
        {
            this.AttackOn(other.transform.position);
            this.mycollider.enabled = false;
        }
    }

    public void Set_stat(int _power, int _defence, int _mhp, int _hp, int _dash, float _speed, float _atkspeed, int _grade, short _unique, bool _efattach)
    {
        this.grade = _grade;
        this.unique = _unique;
        this.efattach = _efattach;
        if (this.unique == -1)
        {
            this.atkcount = -1;
        }
        this.sp_selweapon = this.sp_weapon[(int) (this.unique * 0.2f)];
        this.atkspeed = _atkspeed;
        this.myanimation["m_attack1"].speed = this.atkspeed;
        this.myanimation["m_attack1_i"].speed = this.atkspeed;
        this.power = 1f + (_power * 0.5f);
        this.defence = 1 + _defence;
        this.maxhp = _mhp;
        this.hp = _hp;
        if (this.hp > this.maxhp)
        {
            this.hp = this.maxhp;
        }
        this.runspeed = _speed;
        this.dash = _dash;
        this.myanimation["move"].speed = this.runspeed;
    }

    public void SetRndPosition()
    {
        this.rndpos = (Vector3) (((UnityEngine.Random.onUnitSphere * 0.2f) + this.cha1.position) + (this.cha1.forward * 0.3f));
        this.rndpos[1] = 0f;
        this.distance_cha = Vector3.Distance(this.mytransform.position, this.cha1.position);
        if (this.distance_cha > 0.35f)
        {
            this.myanimation.CrossFade("move");
            this.showme = true;
        }
        else
        {
            this.mycollider.enabled = true;
            this.myanimation.CrossFade("idle");
            this.showme = false;
        }
        if (Mathf.Abs(this.mytransform.position.x) > 2.6)
        {
            this.fb = Mathf.Abs(this.mytransform.position.x) / this.mytransform.position.x;
            this.mytransform.position = new Vector3(this.fb * 2.6f, this.mytransform.position.y, this.mytransform.position.z);
        }
        if (Mathf.Abs(this.mytransform.position.z) > 2.5)
        {
            this.fb = Mathf.Abs(this.mytransform.position.z) / this.mytransform.position.z;
            this.mytransform.position = new Vector3(this.mytransform.position.x, this.mytransform.position.y, this.fb * 2.5f);
        }
    }

    private void Start()
    {
        this.cha1 = GameObject.FindWithTag("Player").transform;
        base.InvokeRepeating("SetRndPosition", 0.1f, 1f);
        this.myanimation.Play("idle");
        this.g_hp = GameObject.FindWithTag("p_plan").GetComponent<MakeUI>().CreatCustomPlane(new Vector2(0.2f, 0.06f), 0f, new Vector3(-1.4f, 2.36f, 1.8f), new Vector2(0f, 0.5625f), new Vector2(0.25f, 0.625f), "general_hp", "Gauge_UV", 0.1f, 0);
        this.gauge_hp = this.g_hp.GetComponent<Gauge_UV>();
        this.HPgaugeSet();
        this.script_cam = Camera.main.GetComponent<Cam_Move>();
    }

    private void Update()
    {
        if (!this.disable)
        {
            if (!this.life)
            {
                this.delay_invicibility += Time.deltaTime;
                if (this.delay_invicibility > 2f)
                {
                    this.delay_invicibility = 0f;
                    this.mytransform.position += (Vector3) (Vector3.up * 14f);
                    this.myanimation.Stop();
                    this.disable = true;
                }
            }
            else
            {
                if (this.superarmor)
                {
                    this.delay_invicibility -= Time.deltaTime;
                    if (this.delay_invicibility < 0f)
                    {
                        this.delay_invicibility = 0f;
                        this.superarmor = false;
                        this.mycollider.enabled = true;
                    }
                }
                if (this.call)
                {
                    this.delay_call += Time.deltaTime;
                    if (this.delay_call > 3f)
                    {
                        this.delay_call = 0f;
                        this.call = false;
                    }
                }
                if (this.myanimation.IsPlaying("down"))
                {
                    this.attack_start = true;
                }
                else if (this.myanimation.IsPlaying("m_attack1_i"))
                {
                    if (this.generalmovestat != 2)
                    {
                        this.generalmovestat = 2;
                        if (this.atkcount != 0)
                        {
                            this.efpos = (Vector3) (((this.mytransform.position + (Vector3.up * this.ef_weapon.localPosition.y)) + (this.mytransform.forward * this.ef_weapon.localPosition.z)) + (this.mytransform.right * this.ef_weapon.localPosition.x));
                            this.efrot = Quaternion.Euler(this.ef_weapon.eulerAngles.x, this.ef_weapon.eulerAngles.y + this.mytransform.eulerAngles.y, this.ef_weapon.eulerAngles.z);
                            if (this.c_weapon == null)
                            {
                                this.c_weapon = (Transform) UnityEngine.Object.Instantiate(this.ef_weapon, this.efpos, this.efrot);
                                if (this.efattach)
                                {
                                    this.c_weapon.parent = this.mytransform;
                                }
                                this.c_weapon.gameObject.active = true;
                                this.c_weapon.rigidbody.mass = this.power;
                            }
                            else
                            {
                                this.c_weapon.position = this.efpos;
                                this.c_weapon.rotation = this.efrot;
                                this.c_weapon.gameObject.active = true;
                            }
                        }
                        else
                        {
                            this.efpos = (Vector3) (((this.mytransform.position + (Vector3.up * this.sp_selweapon.localPosition.y)) + (this.mytransform.forward * this.sp_selweapon.localPosition.z)) + (this.mytransform.right * this.sp_selweapon.localPosition.x));
                            this.efrot = Quaternion.Euler(this.sp_selweapon.eulerAngles.x, this.sp_selweapon.eulerAngles.y + this.mytransform.eulerAngles.y, this.sp_selweapon.eulerAngles.z);
                            if (this.c_spweapon == null)
                            {
                                this.c_spweapon = (Transform) UnityEngine.Object.Instantiate(this.sp_selweapon, this.efpos, this.efrot);
                                this.c_spweapon.gameObject.active = true;
                                this.c_spweapon.rigidbody.mass = this.power;
                            }
                            else
                            {
                                this.c_spweapon.position = this.efpos;
                                this.c_spweapon.rotation = this.efrot;
                                this.c_spweapon.gameObject.active = true;
                            }
                        }
                    }
                }
                else if (this.myanimation.IsPlaying("m_attack1"))
                {
                    if (this.generalmovestat != 1)
                    {
                        this.generalmovestat = 1;
                        base.rigidbody.AddForce(this.directionVector * this.dash);
                        if (this.atkcount == 0)
                        {
                            this.delay_invicibility = 1.5f;
                            this.superarmor = true;
                        }
                    }
                }
                else if (this.myanimation.IsPlaying("move"))
                {
                    if (this.generalmovestat != 0)
                    {
                        this.mycollider.enabled = true;
                        this.generalmovestat = 0;
                    }
                    this.attack_start = false;
                    this.directionVector = this.cha1.position - this.mytransform.position;
                    if (this.directionVector != Vector3.zero)
                    {
                        this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, Quaternion.LookRotation(this.directionVector), Time.deltaTime * 5f);
                    }
                    this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * (this.runspeed - 0.1f));
                }
                else if (this.myanimation.IsPlaying("idle"))
                {
                    if (this.generalmovestat != 0)
                    {
                        this.mycollider.enabled = true;
                        this.generalmovestat = 0;
                    }
                    this.attack_start = false;
                    this.directionVector = this.rndpos - this.mytransform.position;
                    if (this.directionVector != Vector3.zero)
                    {
                        this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, Quaternion.LookRotation(this.directionVector), Time.deltaTime * 2f);
                    }
                    this.mytransform.position += (Vector3) ((this.mytransform.forward * Time.deltaTime) * 0.1f);
                }
            }
        }
    }
}


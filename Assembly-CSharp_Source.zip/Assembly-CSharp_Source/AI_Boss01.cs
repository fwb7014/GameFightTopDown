using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class AI_Boss01 : MonoBehaviour
{
    private int accuracy;
    private Vector3 arrowTargetVector;
    private int atk;
    private short atkkind;
    private short att_status = 1;
    private short[] attach_weaponEf = new short[3];
    private AnimationState attack_impact;
    private Vector3 attackdir;
    private float attackforce;
    private float attackrange;
    private bool attackstart;
    private int behaviour;
    private float behaviour_delay = 2f;
    private short block;
    private int blockrate;
    private bool bosscutin;
    private Transform cha1;
    private int chamovestat;
    private Transform clone_arrow;
    private Transform[] clone_weapon = new Transform[3];
    private bool[] collideroff = new bool[3];
    private short currentAtk;
    private float damage;
    private short[] dash = new short[3];
    public Transform direction_arrow;
    private Vector3 directionVector;
    public Transform ef_secondweapon;
    public Transform[] ef_weapon = new Transform[3];
    private bossmonster enemy;
    public int enemykind;
    private float firerange1;
    private float firerange2;
    private float firerange3;
    private float haveExp;
    private short hp;
    private Transform hpbar;
    private bool impact;
    private bool invince;
    private bool jump;
    private short level;
    private bool life = true;
    private Quaternion lookrotation;
    private float m_atk_delay;
    private short maxhp;
    public short monmovestat;
    private Renderer monrender;
    private Vector2[] moving_atk = new Vector2[3];
    private Animation myanimation;
    private AudioSource myaudio;
    private Collider mycollider;
    private Transform mytransform;
    private short old_delay;
    private Texture originTex;
    private float petrify_rate;
    private float plusmaxhp = 1f;
    private float pluspower = 1f;
    private bool poison;
    private float poison_damage;
    private float poison_delay;
    private short[] power = new short[3];
    private float restrictArea;
    private float runspeed;
    private Cam_Move script_cam;
    private Cha_Control script_cha;
    private Hp_bar script_hpbar;
    private Monster_efs script_monEf;
    private SoundEf_slash script_sound;
    private Spawn script_spawn;
    private bool setattackkind;
    private bool showme;
    public AudioClip snd_attack;
    public AudioClip snd_move;
    public AudioClip snd_scream;
    private Transform target;
    private float turnspeed;
    public Transform weapon;

    private void Awake()
    {
        this.mytransform = base.transform;
        this.myanimation = base.animation;
        this.myaudio = base.audio;
    }

    public void Dead(int _kind)
    {
        this.monmovestat = -4;
        this.life = false;
        this.script_hpbar.FreeSelect();
        if (this.weapon != null)
        {
            this.weapon.parent = null;
            this.weapon.GetComponent<WeaponDrop>().Drop(true);
        }
        this.script_sound.SoundOn(4);
        UnityEngine.Object.Destroy(base.gameObject);
        UnityEngine.Object.Destroy(this.hpbar.gameObject);
        UnityEngine.Object.Destroy(this.clone_arrow.gameObject);
        for (int i = 0; i < 3; i++)
        {
            if (this.clone_weapon[i] != null)
            {
                UnityEngine.Object.Destroy(this.clone_weapon[i].gameObject);
            }
        }
        if (this.ef_secondweapon != null)
        {
            UnityEngine.Object.Destroy(this.ef_secondweapon.gameObject);
        }
        if (this.enemykind != 9)
        {
            this.script_cha.GainExp(this.haveExp);
            this.script_monEf.EnemyDead(_kind, this.mytransform.position, this.originTex, (Vector3) (Vector3.one * 2.5f), this.attackdir);
            this.script_monEf.SetItemBox(this.level, this.mytransform.position);
            this.script_spawn.BossKill(this.enemykind);
        }
        else
        {
            this.script_spawn.ChangeBoss(this.mytransform.position, this.mytransform.rotation);
        }
    }

    [DebuggerHidden]
    public IEnumerator Freeze(short _damage)
    {
        return new <Freeze>c__Iterator0 { <>f__this = this };
    }

    public void Grabed()
    {
    }

    public void Impact()
    {
        this.ef_secondweapon.GetComponent<WeaponDamage>().PressDamage(this.power[this.currentAtk]);
        this.ef_secondweapon.gameObject.active = true;
    }

    public void Impact2()
    {
        this.ef_secondweapon.GetComponent<WeaponDamage>().PressDamage(this.power[this.currentAtk]);
        this.ef_secondweapon.gameObject.active = true;
        this.script_cam.Hitcam();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!this.invince)
        {
            int layer = other.gameObject.layer;
            if (layer >= 0x10)
            {
                this.setattackkind = true;
                this.accuracy = this.script_cha.hitrate;
                this.atk = this.script_cha.atk;
                if (layer == 0x1c)
                {
                    this.attackdir = this.mytransform.position - this.cha1.position;
                    this.attackdir[1] = 0f;
                    this.attackdir = Vector3.Normalize(this.attackdir);
                }
                else
                {
                    this.attackdir = this.mytransform.position - other.transform.position;
                    this.attackdir[1] = 0f;
                    this.attackdir = Vector3.Normalize(this.attackdir);
                }
                if (this.attackdir == Vector3.zero)
                {
                    this.attackdir = -Vector3.forward;
                }
                switch (layer)
                {
                    case 0x10:
                        this.attackforce = -50f;
                        this.damage = 0f;
                        this.target = this.cha1;
                        if (this.att_status != 1)
                        {
                            this.myanimation.enabled = false;
                            base.StartCoroutine(this.Freeze((short) this.damage));
                            this.att_status = 2;
                        }
                        break;

                    case 0x11:
                        this.attackforce = 40f;
                        this.damage = other.rigidbody.mass;
                        this.script_cam.Hitcam2(0.2f);
                        this.target = this.cha1;
                        this.script_monEf.CreatBlood(this.mytransform.position, this.attackdir);
                        break;

                    case 0x12:
                        this.attackforce = 100f;
                        this.damage = this.script_cha.atk;
                        this.script_cam.Hitcam();
                        this.target = this.cha1;
                        this.script_monEf.CreatBlood(this.mytransform.position, this.attackdir);
                        break;

                    case 0x13:
                        this.attackforce = 100f;
                        this.damage = this.script_cha.atk;
                        this.script_cam.Hitcam();
                        this.target = this.cha1;
                        this.script_monEf.CreatBlood(this.mytransform.position, this.attackdir);
                        break;

                    case 20:
                        other.transform.root.rigidbody.AddForce((Vector3) (-this.attackdir * 80f));
                        this.script_cam.Hitcam();
                        this.attackforce = 60f;
                        this.blockrate = UnityEngine.Random.Range(0, 100);
                        if ((this.blockrate >= (this.block - this.accuracy)) || (this.monmovestat < 0))
                        {
                            this.damage = this.atk;
                            this.target = this.cha1;
                            this.script_monEf.CreatBlood(this.mytransform.position, this.attackdir);
                            break;
                        }
                        base.rigidbody.AddForce((Vector3) (this.attackdir * 10f));
                        this.script_cha.Blocked(this.mytransform.position);
                        return;

                    case 0x15:
                        this.script_cam.Hitcam2(1f);
                        this.attackforce = 100f;
                        this.damage = this.atk;
                        this.target = this.cha1;
                        this.script_monEf.CreatBlood_Only(this.mytransform.position, this.attackdir);
                        break;

                    case 0x16:
                        this.script_cam.Hitcam();
                        this.attackforce = 50f;
                        this.damage = other.rigidbody.mass;
                        this.target = this.cha1;
                        this.script_monEf.CreatBlood(this.mytransform.position, this.attackdir);
                        break;

                    case 0x17:
                    {
                        float mass = other.rigidbody.mass;
                        if (mass != 0.1f)
                        {
                            this.attackforce = 100f;
                            this.poison_damage = mass;
                            this.damage = this.poison_damage * 2f;
                            this.script_cam.Hitcam();
                            this.poison = true;
                            this.poison_delay = 12f;
                            this.target = this.cha1;
                            this.script_monEf.CreatBlood(this.mytransform.position, this.attackdir);
                            break;
                        }
                        this.damage = 0f;
                        this.poison = true;
                        this.poison_damage = this.script_cha.atk * 0.6f;
                        this.poison_delay = 4f;
                        this.target = this.cha1;
                        return;
                    }
                    case 0x18:
                        this.attackforce = 100f;
                        this.script_cam.Hitcam();
                        this.life = false;
                        this.petrify_rate = ((int) other.rigidbody.mass) * 0.01f;
                        base.gameObject.layer = 10;
                        base.StartCoroutine(this.Petrify());
                        this.monrender.material.mainTexture = this.script_monEf.attribute_tex[1];
                        this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, 0.4f, 2);
                        this.target = this.cha1;
                        break;

                    case 0x19:
                        this.attackforce = 60f;
                        this.damage = this.atk;
                        this.target = this.cha1;
                        this.script_monEf.CreatBlood_Only(this.mytransform.position, this.attackdir);
                        break;

                    case 0x1a:
                        this.myanimation.Stop();
                        this.attackforce = 10f;
                        this.damage = other.rigidbody.mass;
                        this.hp = (short) (this.hp - ((short) this.damage));
                        this.script_hpbar.Damaged(this.maxhp, 0, this.mytransform, 9f, 0);
                        this.target = this.cha1;
                        this.script_monEf.CreatBlood_Only(this.mytransform.position, this.attackdir);
                        this.myanimation.Play("b_down");
                        break;

                    case 0x1c:
                        this.attackforce = 100f;
                        this.damage = this.script_cha.atk;
                        this.script_cam.Hitcam();
                        this.target = this.cha1;
                        this.script_monEf.CreatBlood(this.mytransform.position, this.attackdir);
                        break;

                    case 0x1d:
                        this.attackforce = 50f;
                        this.damage = this.script_cha.atk * 0.4f;
                        this.target = this.cha1;
                        this.script_monEf.CreatBlood(this.mytransform.position, this.attackdir);
                        break;

                    case 30:
                        this.attackforce = 100f;
                        this.damage = this.script_cha.atk;
                        this.script_cam.Hitcam();
                        this.target = this.cha1;
                        this.script_monEf.CreatBlood(this.mytransform.position, this.attackdir);
                        break;

                    case 0x1f:
                        this.attackforce = 100f;
                        this.damage = this.script_cha.atk;
                        this.script_cam.Hitcam();
                        this.target = this.cha1;
                        this.script_monEf.CreatBlood(this.mytransform.position, this.attackdir);
                        break;
                }
                if (!this.life)
                {
                    this.script_sound.SoundOn(1);
                    this.myanimation.Stop();
                }
                else
                {
                    this.script_sound.SoundOn(1);
                    int num3 = (int) (this.maxhp * 0.3f);
                    int num4 = this.hp / num3;
                    if (this.hp == this.maxhp)
                    {
                        num4--;
                    }
                    this.hp = (short) (this.hp - ((short) this.damage));
                    this.script_monEf.SetDamageNum(this.mytransform.position, (short) this.damage, this.attackdir);
                    this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, 0.4f, -1);
                    if ((this.hp <= 0) && this.life)
                    {
                        this.Dead(2);
                    }
                    else if (this.hp < (num3 * num4))
                    {
                        this.attackforce = 300f;
                        this.myanimation.Stop();
                        this.myanimation.Play("b_down");
                        this.script_spawn.Summon(4, this.mytransform.position);
                        if (this.clone_weapon[this.currentAtk] != null)
                        {
                            this.clone_weapon[this.currentAtk].gameObject.active = false;
                            this.clone_weapon[this.currentAtk].position = (Vector3) (Vector3.one * 8f);
                        }
                        if (this.ef_secondweapon != null)
                        {
                            this.ef_secondweapon.gameObject.active = false;
                        }
                        this.myaudio.clip = this.snd_scream;
                        this.myaudio.Play();
                    }
                    base.rigidbody.AddForce((Vector3) (this.attackdir * this.attackforce));
                }
            }
        }
    }

    [DebuggerHidden]
    public IEnumerator Petrify()
    {
        return new <Petrify>c__Iterator1 { <>f__this = this };
    }

    public void SetDir()
    {
        if (this.life)
        {
            if ((this.behaviour_delay < 0f) && this.bosscutin)
            {
                this.behaviour = UnityEngine.Random.Range(0, 6);
                if (this.behaviour == 0)
                {
                    this.myaudio.clip = this.snd_move;
                    this.myaudio.Play();
                }
                this.behaviour_delay = 1f;
            }
            if (this.target.position.y > 2f)
            {
                this.target = this.cha1;
            }
            this.attackrange = Vector3.Distance(this.mytransform.position, this.target.position);
            if (!this.bosscutin && (this.attackrange < 0.7f))
            {
                this.script_spawn.BossCutin(this.enemykind);
                this.bosscutin = true;
                this.script_cam.LookTarget(this.mytransform, 30, 0f);
            }
            if (this.att_status == 2)
            {
                this.directionVector = Vector3.zero;
                this.attackrange = 2f;
            }
            else
            {
                this.directionVector = this.target.position - this.mytransform.position;
                this.directionVector[1] = 0f;
                this.directionVector = Vector3.Normalize(this.directionVector);
            }
            this.directionVector = this.target.position - this.mytransform.position;
            this.directionVector[1] = 0f;
            this.directionVector = Vector3.Normalize(this.directionVector);
            this.chamovestat = this.script_cha.chamovestat;
            if (this.attackrange < this.firerange3)
            {
                this.showme = false;
                this.clone_arrow.renderer.enabled = false;
                if (!this.attackstart)
                {
                    if ((this.chamovestat < 50) && (this.monmovestat >= 0))
                    {
                        if (this.setattackkind)
                        {
                            this.atkkind = (short) UnityEngine.Random.Range(0, 3);
                            this.setattackkind = false;
                        }
                        if (this.atkkind == 2)
                        {
                            if (this.attackrange < this.firerange3)
                            {
                                this.myanimation.Play("b_attack3");
                                this.attack_impact = this.myanimation.PlayQueued("b_attack3_i", QueueMode.CompleteOthers);
                                this.attack_impact.speed = this.myanimation["b_attack3_i"].speed;
                                this.attack_impact.layer = 1;
                                this.attack_impact = this.myanimation.PlayQueued("b_idle", QueueMode.CompleteOthers);
                                this.attack_impact.speed = this.myanimation["b_idle"].speed;
                                this.attack_impact.layer = 1;
                                this.currentAtk = 2;
                                this.setattackkind = true;
                            }
                            else
                            {
                                this.myanimation.CrossFade("b_move");
                            }
                        }
                        else if (this.atkkind == 1)
                        {
                            if (this.attackrange < this.firerange2)
                            {
                                this.myanimation.Play("b_attack2");
                                this.attack_impact = this.myanimation.PlayQueued("b_attack2_i", QueueMode.CompleteOthers);
                                this.attack_impact.speed = this.myanimation["b_attack2_i"].speed;
                                this.attack_impact.layer = 1;
                                this.attack_impact = this.myanimation.PlayQueued("b_idle", QueueMode.CompleteOthers);
                                this.attack_impact.speed = this.myanimation["b_idle"].speed;
                                this.attack_impact.layer = 1;
                                this.currentAtk = 1;
                                this.setattackkind = true;
                            }
                            else
                            {
                                this.myanimation.CrossFade("b_move");
                            }
                        }
                        else if (this.attackrange < this.firerange1)
                        {
                            this.myanimation.Play("b_attack1");
                            this.attack_impact = this.myanimation.PlayQueued("b_attack1_i", QueueMode.CompleteOthers);
                            this.attack_impact.speed = this.myanimation["b_attack1_i"].speed;
                            this.attack_impact.layer = 1;
                            this.attack_impact = this.myanimation.PlayQueued("b_idle", QueueMode.CompleteOthers);
                            this.attack_impact.speed = this.myanimation["b_idle"].speed;
                            this.attack_impact.layer = 1;
                            this.currentAtk = 0;
                            this.setattackkind = true;
                        }
                        else
                        {
                            this.myanimation.CrossFade("b_move");
                        }
                        this.attackstart = true;
                    }
                    else if (!this.attackstart)
                    {
                        this.myanimation.CrossFade("b_idle");
                        this.behaviour = 4;
                        this.behaviour_delay = 1f;
                    }
                }
            }
            else if (!this.attackstart)
            {
                if (this.behaviour >= 5)
                {
                    this.myanimation.CrossFade("b_idle");
                }
                else
                {
                    this.myanimation.CrossFade("b_move");
                }
                this.showme = true;
                this.clone_arrow.renderer.enabled = true;
            }
        }
    }

    public void SetLevel(short _level, float _restrictArea)
    {
        this.level = (short) (_level + 1);
        this.restrictArea = _restrictArea;
        this.plusmaxhp = (0.55f * (((float) this.level) / 3f)) + 0.5f;
        if (this.level >= 0x3d)
        {
            this.pluspower = (0.05f * (((float) this.level) / 3f)) + 3.5f;
        }
        else if (this.level >= 0x1f)
        {
            this.pluspower = 2.5f;
        }
        else
        {
            this.pluspower = (0.05f * (((float) this.level) / 3f)) + 0.8f;
        }
        this.block = (short) (this.block + ((short) (this.level * 0.5f)));
        this.haveExp += this.level;
        this.hp = this.maxhp;
    }

    private void Start()
    {
        this.monrender = this.mytransform.Find("mon").renderer;
        GameObject obj2 = GameObject.FindWithTag("Respawn");
        this.script_spawn = obj2.GetComponent<Spawn>();
        this.enemy = obj2.GetComponent<DB_Boss>().boss[this.enemykind];
        this.mycollider = base.collider;
        this.maxhp = (short) (this.enemy._maxhp * this.plusmaxhp);
        this.power[0] = (short) (this.enemy._power1 * this.pluspower);
        this.power[1] = (short) (this.enemy._power2 * this.pluspower);
        this.power[2] = (short) (this.enemy._power3 * this.pluspower);
        this.haveExp += this.enemy._haveExp;
        this.block = (short) (this.block + this.enemy._block);
        this.runspeed = this.enemy._runspeed;
        this.turnspeed = this.enemy._turnspeed;
        this.firerange1 = this.enemy._firerange1;
        this.firerange2 = this.enemy._firerange2;
        this.firerange3 = this.enemy._firerange3;
        this.dash[0] = this.enemy._dash1;
        this.dash[1] = this.enemy._dash2;
        this.dash[2] = this.enemy._dash3;
        this.moving_atk[0] = this.enemy._moving_atk1;
        this.moving_atk[1] = this.enemy._moving_atk2;
        this.moving_atk[2] = this.enemy._moving_atk3;
        this.attach_weaponEf[0] = this.enemy._attach_ef1;
        this.attach_weaponEf[1] = this.enemy._attach_ef2;
        this.attach_weaponEf[2] = this.enemy._attach_ef3;
        this.collideroff[0] = this.enemy._collideroff1;
        this.collideroff[1] = this.enemy._collideroff2;
        this.collideroff[2] = this.enemy._collideroff3;
        this.myanimation["b_move"].speed = this.enemy._speed_move;
        this.myanimation["b_down"].speed = this.enemy._speed_down;
        this.myanimation["b_attack1"].speed = this.enemy._speed_b_attack1;
        this.myanimation["b_attack1_i"].speed = this.enemy._speed_b_attack1_i;
        this.myanimation["b_attack2"].speed = this.enemy._speed_b_attack2;
        this.myanimation["b_attack2_i"].speed = this.enemy._speed_b_attack2_i;
        this.myanimation["b_attack3"].speed = this.enemy._speed_b_attack3;
        this.myanimation["b_attack3_i"].speed = this.enemy._speed_b_attack3_i;
        this.myanimation["b_idle"].speed = this.enemy._speed_idle;
        this.myanimation["b_down"].layer = 2;
        this.myanimation["b_move"].layer = 1;
        this.myanimation["b_attack1"].layer = 1;
        this.myanimation["b_attack1_i"].layer = 1;
        this.myanimation["b_attack2"].layer = 1;
        this.myanimation["b_attack2_i"].layer = 1;
        this.myanimation["b_attack3"].layer = 1;
        this.myanimation["b_attack3_i"].layer = 1;
        this.myanimation["b_idle"].layer = 1;
        this.monmovestat = 0;
        this.originTex = this.monrender.material.mainTexture;
        this.cha1 = GameObject.FindWithTag("Player").transform;
        this.hp = this.maxhp;
        this.script_cha = this.cha1.gameObject.GetComponent<Cha_Control>();
        this.script_sound = GameObject.FindWithTag("sound").GetComponent<SoundEf_slash>();
        this.script_cam = Camera.main.GetComponent<Cam_Move>();
        this.script_monEf = GameObject.FindWithTag("efs_mon").GetComponent<Monster_efs>();
        this.hpbar = this.script_monEf.CreatHpbar(new Vector2(0.1f, 0.02f), false, false);
        this.hpbar.position = this.mytransform.position;
        this.script_hpbar = this.hpbar.GetComponent<Hp_bar>();
        this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, 0.4f, 0);
        this.accuracy = this.script_cha.hitrate;
        this.atk = this.script_cha.atk;
        this.script_monEf.CreatShadow(this.mytransform.GetChild(0), 2.2f);
        this.clone_arrow = (Transform) UnityEngine.Object.Instantiate(this.direction_arrow, this.cha1.position, Quaternion.identity);
        this.clone_arrow.renderer.enabled = false;
        if (this.enemykind == 0)
        {
            this.myanimation["trans"].speed = 0.25f;
            this.myanimation["trans"].layer = 3;
            this.myanimation.Play("trans");
            this.bosscutin = true;
            this.script_cam.LookTarget(this.mytransform, 30, 4f);
            this.cha1.rigidbody.AddForce((Vector3) (this.cha1.forward * -240f));
            this.script_cha.StopControl();
            this.invince = true;
            base.Invoke("TurnNormal", 3f);
        }
        else
        {
            base.InvokeRepeating("SetDir", 0.1f, 0.5f);
        }
        this.target = this.cha1;
    }

    private void TurnNormal()
    {
        this.invince = false;
        base.InvokeRepeating("SetDir", 0.1f, 0.5f);
    }

    private void Update()
    {
        if (this.life)
        {
            this.behaviour_delay -= Time.deltaTime;
            if (!this.myanimation.IsPlaying("trans"))
            {
                if (this.myanimation.IsPlaying("b_down"))
                {
                    this.monmovestat = -1;
                }
                else if ((this.myanimation.IsPlaying("b_attack1") || this.myanimation.IsPlaying("b_attack2")) || this.myanimation.IsPlaying("b_attack3"))
                {
                    this.impact = false;
                    if (this.directionVector != Vector3.zero)
                    {
                        this.lookrotation = Quaternion.LookRotation(this.directionVector);
                    }
                    this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, this.lookrotation, Time.deltaTime * this.turnspeed);
                    if (this.monmovestat != 11)
                    {
                        if (this.collideroff[this.currentAtk] && !this.jump)
                        {
                            this.mycollider.enabled = false;
                            this.jump = true;
                        }
                        if (this.attach_weaponEf[this.currentAtk] == 2)
                        {
                            this.ef_secondweapon.gameObject.active = true;
                        }
                    }
                    if (this.moving_atk[this.currentAtk] != Vector2.zero)
                    {
                        if (this.m_atk_delay > this.moving_atk[this.currentAtk].x)
                        {
                            this.mytransform.position += (Vector3) ((this.directionVector * Time.deltaTime) * this.moving_atk[this.currentAtk].y);
                        }
                        else
                        {
                            this.m_atk_delay += Time.deltaTime;
                        }
                    }
                    this.monmovestat = 11;
                }
                else if ((this.myanimation.IsPlaying("b_attack1_i") || this.myanimation.IsPlaying("b_attack2_i")) || this.myanimation.IsPlaying("b_attack3_i"))
                {
                    this.monmovestat = 12;
                    if (!this.impact)
                    {
                        if (this.jump)
                        {
                            this.mycollider.enabled = true;
                            this.jump = false;
                        }
                        base.rigidbody.AddForce(this.mytransform.forward * this.dash[this.currentAtk]);
                        this.impact = true;
                        Vector3 position = (Vector3) (((this.mytransform.position + (Vector3.up * this.ef_weapon[this.currentAtk].localPosition.y)) + (this.mytransform.forward * this.ef_weapon[this.currentAtk].localPosition.z)) + (this.mytransform.right * this.ef_weapon[this.currentAtk].localPosition.x));
                        Quaternion rotation = Quaternion.Euler(this.ef_weapon[this.currentAtk].eulerAngles.x, this.ef_weapon[this.currentAtk].eulerAngles.y + this.mytransform.eulerAngles.y, this.ef_weapon[this.currentAtk].eulerAngles.z);
                        if (this.clone_weapon[this.currentAtk] == null)
                        {
                            this.clone_weapon[this.currentAtk] = (Transform) UnityEngine.Object.Instantiate(this.ef_weapon[this.currentAtk], position, rotation);
                            this.clone_weapon[this.currentAtk].gameObject.active = true;
                            this.clone_weapon[this.currentAtk].GetComponent<WeaponDamage>().PressDamage(this.power[this.currentAtk]);
                            if (this.attach_weaponEf[this.currentAtk] >= 1)
                            {
                                this.clone_weapon[this.currentAtk].parent = this.mytransform;
                                if (this.attach_weaponEf[this.currentAtk] == 2)
                                {
                                    this.ef_secondweapon.GetComponent<WeaponDamage>().PressDamage(this.power[this.currentAtk]);
                                }
                            }
                        }
                        else
                        {
                            this.clone_weapon[this.currentAtk].position = position;
                            this.clone_weapon[this.currentAtk].rotation = rotation;
                            this.clone_weapon[this.currentAtk].gameObject.active = true;
                        }
                        this.m_atk_delay = 0f;
                        this.mytransform.position = (Vector3) ((Vector3.right * this.mytransform.position.x) + (Vector3.forward * this.mytransform.position.z));
                    }
                }
                else if (this.myanimation.IsPlaying("b_move"))
                {
                    this.attackstart = false;
                    this.monmovestat = 1;
                    this.mytransform.position += (Vector3) ((this.directionVector * Time.deltaTime) * this.runspeed);
                    if (this.directionVector != Vector3.zero)
                    {
                        this.lookrotation = Quaternion.LookRotation(this.directionVector);
                    }
                    this.mytransform.rotation = Quaternion.Lerp(this.mytransform.rotation, this.lookrotation, Time.deltaTime * 3f);
                }
                else
                {
                    this.monmovestat = 1;
                    this.attackstart = false;
                }
                if (this.showme)
                {
                    this.arrowTargetVector = Vector3.Normalize(this.mytransform.position - this.cha1.position);
                    if (this.arrowTargetVector != Vector3.zero)
                    {
                        this.clone_arrow.rotation = Quaternion.LookRotation(this.arrowTargetVector);
                    }
                    this.arrowTargetVector = (Vector3) ((this.cha1.position + (Vector3.up * 0.02f)) + (this.arrowTargetVector * 0.3f));
                    this.clone_arrow.position = Vector3.Lerp(this.clone_arrow.position, this.arrowTargetVector, Time.deltaTime * 4f);
                    this.clone_arrow.renderer.enabled = true;
                    this.chamovestat = 0;
                }
                if (this.poison)
                {
                    this.poison_delay -= Time.deltaTime;
                    if (this.poison_delay < 0f)
                    {
                        this.poison = false;
                        this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, 0.4f, 0);
                    }
                    else if (((short) this.poison_delay) != this.old_delay)
                    {
                        this.hp = (short) (this.hp - ((short) this.poison_damage));
                        this.script_hpbar.Damaged(this.maxhp, this.hp, this.mytransform, 0.4f, 1);
                        this.old_delay = (short) this.poison_delay;
                        if (this.hp <= 0)
                        {
                            this.Dead(1);
                        }
                    }
                }
                if (Vector3.SqrMagnitude(this.mytransform.position) > this.restrictArea)
                {
                    base.rigidbody.AddForce((Vector3) (-this.mytransform.position * 20f));
                }
            }
        }
    }

    [CompilerGenerated]
    private sealed class <Freeze>c__Iterator0 : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal AI_Boss01 <>f__this;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.$current = new WaitForSeconds(2f);
                    this.$PC = 1;
                    return true;

                case 1:
                    this.<>f__this.att_status = 0;
                    this.<>f__this.myanimation.enabled = true;
                    this.$PC = -1;
                    break;
            }
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [CompilerGenerated]
    private sealed class <Petrify>c__Iterator1 : IEnumerator, IEnumerator<object>, IDisposable
    {
        internal object $current;
        internal int $PC;
        internal int <_rate>__0;
        internal AI_Boss01 <>f__this;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<_rate>__0 = UnityEngine.Random.Range(0, 100);
                    this.$current = new WaitForSeconds(2.5f);
                    this.$PC = 1;
                    return true;

                case 1:
                    if (this.<>f__this.petrify_rate <= this.<_rate>__0)
                    {
                        this.<>f__this.gameObject.layer = 8;
                        this.<>f__this.mytransform.Find("mon").renderer.sharedMaterial.mainTexture = this.<>f__this.originTex;
                        this.<>f__this.life = true;
                        this.<>f__this.script_hpbar.Damaged(this.<>f__this.maxhp, this.<>f__this.hp, this.<>f__this.mytransform, 0.4f, 0);
                        break;
                    }
                    this.<>f__this.Dead(0);
                    break;

                default:
                    goto Label_00FD;
            }
            this.$PC = -1;
        Label_00FD:
            return false;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }
}


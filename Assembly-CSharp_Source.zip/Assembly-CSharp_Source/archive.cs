using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct archive
{
    public short _name;
    public short _info;
    public short _reward_kind;
    public short _reward_amount;
    public short _require_kind;
    public short _require_kind_sub;
    public short _require_amount;
}


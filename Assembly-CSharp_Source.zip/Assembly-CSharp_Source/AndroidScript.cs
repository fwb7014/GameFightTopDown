using System;
using UnityEngine;

public class AndroidScript : MonoBehaviour
{
    private static AndroidScript _i;
    private AndroidJavaClass jcBI;

    private void Awake()
    {
        _i = this;
        if (PlayerPrefs.GetString("isFirst", "NONE").CompareTo("NONE") == 0)
        {
            PlayerPrefs.SetString("isFirst", "YES");
        }
    }

    public void changeLoginState()
    {
        PlayerPrefs.SetString("isFirst", "NO");
        string str = PlayerPrefs.GetString("isFirst");
    }

    public string getDeviceId()
    {
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.common.libs.CommonActivity"))
        {
            return class2.CallStatic<string>("getDeviceId", new object[0]);
        }
    }

    public bool isScreenLocked()
    {
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.common.libs.CommonActivity"))
        {
            return class2.CallStatic<bool>("isScreenLocked", new object[0]);
        }
    }

    public void loadWDJAds()
    {
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.nhncorp.ads.wdj.WdjAds"))
        {
            class2.CallStatic("showAppWidgetAds", new object[0]);
        }
    }

    public void LogEvent(string eventId)
    {
        object[] args = new object[] { eventId };
        this.jcBI.CallStatic("logEvent", args);
    }

    public void LogEvent(string eventId, string jsonValue)
    {
        object[] args = new object[] { eventId, jsonValue };
        this.jcBI.CallStatic("logEvent", args);
    }

    public void loginQihoo()
    {
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.pay.qihoo.QihooPay"))
        {
            class2.CallStatic("doLoginQihoo", new object[0]);
        }
    }

    public void MoreGames()
    {
        if (ChannelMgr.GetInstance().IsCM())
        {
            using (AndroidJavaClass class2 = new AndroidJavaClass("com.pay.cm.CMPay"))
            {
                class2.CallStatic("moreGame", new object[0]);
            }
        }
        if (ChannelMgr.GetInstance().IsCT())
        {
            using (AndroidJavaClass class3 = new AndroidJavaClass("com.nhncorp.skundeadct.Game"))
            {
                class3.CallStatic("moreGame", new object[0]);
            }
        }
    }

    public bool MusicEnabled()
    {
        if (ChannelMgr.GetInstance().IsCM())
        {
            using (AndroidJavaClass class2 = new AndroidJavaClass("com.pay.cm.CMPay"))
            {
                return class2.CallStatic<bool>("musicEnabled", new object[0]);
            }
        }
        return true;
    }

    public void onPause()
    {
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.common.libs.CommonActivity"))
        {
            class2.CallStatic("onPause", new object[0]);
        }
    }

    public void pay(string goodsId, string goodsName, float price, int num, string payType, string cmIap, string ctIap, string cuIap, string cmmIap, string middleIap)
    {
        object[] objArray1 = new object[] { 
            "{'payId':", goodsId, ",'name':", goodsName, ",'count':", price, ",'num':", num, ",'payType':", payType, ",'cmIap':", cmIap, ",'ctIap':", ctIap, ",'cuIap':", cuIap, 
            ",'cmmIap':", cmmIap, ",'middleIap':", middleIap, "}"
         };
        string str = string.Concat(objArray1);
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.nhncorp.pay.outinterface.PayOutInterface"))
        {
            object[] args = new object[] { str };
            class2.CallStatic("Pay", args);
        }
    }

    private void PayCallBack(string jsonValue)
    {
        char[] separator = new char[] { ',' };
        string[] strArray = jsonValue.Substring(1, jsonValue.Length - 2).Split(separator);
        string str2 = strArray[0];
        char[] chArray2 = new char[] { ':' };
        string[] strArray2 = str2.Split(chArray2);
        int num = int.Parse(strArray2[1].Substring(1, strArray2[1].Length - 2));
        string str3 = strArray[2];
        char[] chArray3 = new char[] { ':' };
        string[] strArray3 = str3.Split(chArray3);
        int num2 = int.Parse(strArray3[1].Substring(1, strArray3[1].Length - 2));
        if ((num == 1) && (num2 == 100))
        {
            int[] intArray = new int[20];
            intArray = PlayerPrefsX.GetIntArray("n22");
            int num3 = intArray[14];
            if (num3 >= 0)
            {
                Crypto.Property_change(0x2710, false);
            }
            else
            {
                intArray[14] = 0;
                PlayerPrefsX.SetIntArray("n22", intArray);
                Crypto.Property_change(0x1f40, false);
            }
            PlayerPrefs.SetInt("haveDrawedGift", 1);
            PlayerPrefs.SetString("charge", "true");
        }
    }

    public void QuitGame(string coin, string stage, string isFirst)
    {
        if (ChannelMgr.GetInstance().IsCT())
        {
            using (AndroidJavaClass class2 = new AndroidJavaClass("com.nhncorp.skundeadct.Game"))
            {
                object[] args = new object[] { coin, stage, isFirst };
                class2.CallStatic("quitGame", args);
            }
        }
        else
        {
            using (AndroidJavaClass class3 = new AndroidJavaClass("com.common.libs.CommonActivity"))
            {
                object[] objArray2 = new object[] { coin, stage, isFirst };
                class3.CallStatic("quitGame", objArray2);
            }
        }
        if (PlayerPrefs.GetString("isFirst").CompareTo("YES") == 0)
        {
            PlayerPrefs.SetString("isFirst", "NO");
        }
    }

    public void RedeemFeedbackFail()
    {
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.bi.libs.Redeem"))
        {
            object[] args = new object[] { false };
            class2.CallStatic("showText", args);
        }
    }

    public void RedeemFeedbackSuc(string id)
    {
        int num = int.Parse(id);
        int num2 = 0;
        int num3 = 0;
        bool flag = false;
        bool flag2 = false;
        bool flag3 = false;
        switch (num)
        {
            case 0x2711:
                flag3 = true;
                num3 = 0x834;
                break;

            case 0x2712:
                flag3 = true;
                num3 = 0x10cc;
                break;

            case 0x2713:
                flag3 = true;
                num3 = 0x21fc;
                break;

            case 0x2714:
                flag3 = true;
                num3 = 0x3e8;
                flag = true;
                break;

            case 0x2715:
                flag3 = true;
                num3 = 0x3e8;
                flag2 = true;
                break;

            case 0x2716:
            {
                int[] intArray = new int[20];
                intArray = PlayerPrefsX.GetIntArray("n22");
                int num4 = intArray[14];
                if (num4 < 0)
                {
                    intArray[14] = 0;
                    PlayerPrefsX.SetIntArray("n22", intArray);
                    Crypto.Property_change(0x1f40, false);
                }
                else
                {
                    Crypto.Property_change(0x2710, false);
                }
                PlayerPrefs.SetInt("haveDrawedGift", 1);
                break;
            }
            case 0x2719:
                num2 = 9;
                break;

            case 0x2720:
                num2 = 0x10;
                break;

            case 0x2734:
                num2 = 0x24;
                break;

            case 0x274c:
                num2 = 60;
                break;

            case 0x2788:
                num2 = 120;
                break;

            case 0x27d8:
                num2 = 200;
                break;

            case 0x2878:
                num2 = 360;
                break;

            case 0x2a94:
                num2 = 900;
                break;
        }
        if (num2 > 0)
        {
            Crypto.Property_change(num2, true);
        }
        if (flag3)
        {
            Crypto.Property_change(num3, false);
        }
        if (flag)
        {
            int[] numArray2 = PlayerPrefsX.GetIntArray("n39");
            int num5 = UnityEngine.Random.Range(0, 100);
            int index = 0;
            if (num5 > 0x60)
            {
                index = 4;
            }
            else if (num5 > 0x58)
            {
                index = 3;
            }
            else if (num5 > 0x44)
            {
                index = 2;
            }
            else if (num5 > 40)
            {
                index = 1;
            }
            else
            {
                index = 0;
            }
            numArray2[index]++;
            PlayerPrefsX.SetIntArray("n39", numArray2);
        }
        if (flag2)
        {
            int num7 = Crypto.Load_int_key("n10") + 1;
            Crypto.Save_int_key("n10", num7);
        }
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.bi.libs.Redeem"))
        {
            object[] args = new object[] { true };
            class2.CallStatic("showText", args);
        }
    }

    public void SetPushOnOff(bool isOpen)
    {
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.common.push.LocalPush"))
        {
            object[] args = new object[] { isOpen };
            class2.CallStatic("setPushFlag", args);
        }
    }

    private void Start()
    {
        UnityEngine.Object.DontDestroyOnLoad(base.gameObject);
        this.jcBI = new AndroidJavaClass("com.bi.libs.BIWrapper");
    }

    public void StartFeedBack()
    {
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.common.libs.CommonActivity"))
        {
            class2.CallStatic("FeedBack", new object[0]);
        }
    }

    public void StartRedeemService()
    {
        using (AndroidJavaClass class2 = new AndroidJavaClass("com.bi.libs.Redeem"))
        {
            class2.CallStatic("inputCode", new object[0]);
        }
    }

    private void Update()
    {
        if ((Input.GetKeyDown(KeyCode.Escape) && (Time.timeScale != 0f)) && (Application.loadedLevel != 0))
        {
            int @int = PlayerPrefs.GetInt("IsInit");
            int num2 = 0;
            int num3 = 0;
            string eventId = "exitGameEvent";
            if (@int == 1)
            {
                num3 = Crypto.Load_int_key("n24");
                num2 = Crypto.Load_int_key("n06");
            }
            if (num2 < 0)
            {
                num2 = 0;
            }
            object[] objArray1 = new object[] { "{jade:", num3, ",stage:", num2, "}" };
            string jsonValue = string.Concat(objArray1);
            i.LogEvent(eventId, jsonValue);
            string isFirst = PlayerPrefs.GetString("isFirst");
            if (isFirst.CompareTo("YES") == 0)
            {
                string str4 = "firstPlay";
                string str5 = "{stage:" + num2 + "}";
                i.LogEvent(str4, str5);
            }
            this.QuitGame(num3 + string.Empty, num2 + string.Empty, isFirst);
        }
    }

    public static AndroidScript i
    {
        get
        {
            return _i;
        }
    }
}

